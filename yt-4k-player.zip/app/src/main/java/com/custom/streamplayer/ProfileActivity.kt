package com.custom.streamplayer

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial

class ProfileActivity : AppCompatActivity() {

    private lateinit var signInBtn: Button
    private lateinit var signInPrompt: TextView

    override fun onResume() {
        super.onResume()
        refreshAuthUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        signInBtn = findViewById(R.id.meSignInBtn)
        signInPrompt = findViewById(R.id.meSignInPrompt)

        findViewById<ImageButton>(R.id.meCloseBtn).setOnClickListener { finish() }

        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val themeSwitch = findViewById<SwitchMaterial>(R.id.meThemeSwitch)
        themeSwitch.isChecked = ThemeHelper.isDark(this)
        themeSwitch.setOnCheckedChangeListener { _, isChecked ->
            val newTheme = if (isChecked) "Dark" else "Light"
            prefs.edit().putString("theme", newTheme).apply()
            Toast.makeText(
                this,
                if (isChecked) "Switched to black page mode" else "Switched to day mode",
                Toast.LENGTH_SHORT
            ).show()
            ThemeHelper.applyTheme(this)
            recreate()
        }

        signInBtn.setOnClickListener {
            if (YouTubeAuthStore.isLoggedIn(this)) {
                AlertDialog.Builder(this)
                    .setTitle("Account")
                    .setMessage("You are signed in. Sign out?")
                    .setPositiveButton("Sign out") { _, _ ->
                        YouTubeAuthStore.logout(this)
                        refreshAuthUi()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
            }
        }

        findViewById<LinearLayout>(R.id.meRowSetting).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.meRowHelp).setOnClickListener {
            Toast.makeText(this, "Vanced Player v5.5.80.378", Toast.LENGTH_SHORT).show()
        }

        findViewById<LinearLayout>(R.id.meRowShare).setOnClickListener {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Check out Vanced 4K HDR Player!")
            }
            startActivity(Intent.createChooser(sendIntent, "Share Vanced"))
        }

        findViewById<LinearLayout>(R.id.meRowUpdate).setOnClickListener {
            Toast.makeText(this, "You are on the latest version (5.5.80.378)", Toast.LENGTH_SHORT).show()
        }

        findViewById<TextView>(R.id.mePrivacyPolicy).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Privacy Policy")
                .setMessage("All watch history and preferences are stored locally on your device.")
                .setPositiveButton("OK", null)
                .show()
        }

        refreshAuthUi()
    }

    private fun refreshAuthUi() {
        val loggedIn = YouTubeAuthStore.isLoggedIn(this)
        if (loggedIn) {
            signInPrompt.text = "Signed in to YouTube"
            signInBtn.text = "Signed In"
        } else {
            signInPrompt.text = "Sign in now to browse your subscriptions and playlists."
            signInBtn.text = "Sign In"
        }
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}