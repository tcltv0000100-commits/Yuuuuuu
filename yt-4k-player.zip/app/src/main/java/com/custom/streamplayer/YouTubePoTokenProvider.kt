package com.custom.streamplayer

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

object YouTubePoTokenProvider {

    private const val MOBILE_CHROME_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36"

    @Volatile
    private var appContext: Context? = null

    @Volatile
    var cachedPoToken: String? = null
        private set

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun resolveViaWebView(videoUrl: String): ResolvedStreamResult? {
        val ctx = appContext ?: return null
        val videoId = InnertubeStreamResolver.extractVideoId(videoUrl) ?: return null
        if (Looper.myLooper() == Looper.getMainLooper()) return null

        val resultRef = AtomicReference<ResolvedStreamResult?>(null)
        val latch = CountDownLatch(1)
        val mainHandler = Handler(Looper.getMainLooper())
        val webViewRef = AtomicReference<WebView?>(null)

        mainHandler.post {
            try {
                val wv = WebView(ctx)
                webViewRef.set(wv)
                val cm = CookieManager.getInstance()
                cm.setAcceptCookie(true)
                cm.setAcceptThirdPartyCookies(wv, true)

                wv.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    loadsImagesAutomatically = false
                    mediaPlaybackRequiresUserGesture = true
                    userAgentString = MOBILE_CHROME_UA
                }

                var finished = false
                fun tryExtractPlayerResponse() {
                    if (finished) return
                    val js = """
                        (function() {
                            try {
                                document.querySelectorAll('video,audio').forEach(function(m){ m.muted = true; m.pause(); });
                                var r = window.ytInitialPlayerResponse;
                                if (!r && window.ytplayer && window.ytplayer.config && window.ytplayer.config.args) {
                                    r = window.ytplayer.config.args.raw_player_response;
                                }
                                if (r && r.streamingData) {
                                    return JSON.stringify(r);
                                }
                            } catch (e) {}
                            return '';
                        })();
                    """.trimIndent()
                    wv.evaluateJavascript(js) { raw ->
                        if (finished) return@evaluateJavascript
                        val unquoted = decodeJsString(raw)
                        if (!unquoted.isNullOrBlank() && unquoted.startsWith("{")) {
                            try {
                                val json = JSONObject(unquoted)
                                val parsed = InnertubeStreamResolver.parsePlayerResponseJson(
                                    root = json,
                                    videoId = videoId,
                                    clientName = "MWEB_WEBVIEW",
                                    userAgent = MOBILE_CHROME_UA
                                )
                                if (parsed != null && (
                                        parsed.videoOnlyStreams.isNotEmpty() ||
                                            parsed.muxedStreams.isNotEmpty() ||
                                            !parsed.hlsUrl.isNullOrEmpty() ||
                                            !parsed.dashUrl.isNullOrEmpty()
                                        )
                                ) {
                                    finished = true
                                    resultRef.set(parsed)
                                    latch.countDown()
                                }
                            } catch (_: Exception) {}
                        }
                    }
                }

                wv.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val reqUrl = request?.url?.toString() ?: return null
                        if (reqUrl.contains("googlevideo.com/videoplayback") && reqUrl.contains("pot=")) {
                            try {
                                val pot = Uri.parse(reqUrl).getQueryParameter("pot")
                                if (!pot.isNullOrBlank()) {
                                    cachedPoToken = pot
                                }
                            } catch (_: Exception) {}
                        }
                        return null
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        tryExtractPlayerResponse()
                        mainHandler.postDelayed({ tryExtractPlayerResponse() }, 900)
                        mainHandler.postDelayed({ tryExtractPlayerResponse() }, 2000)
                    }
                }

                wv.loadUrl("https://m.youtube.com/watch?v=$videoId")
            } catch (_: Exception) {
                latch.countDown()
            }
        }

        latch.await(7, TimeUnit.SECONDS)

        mainHandler.post {
            try {
                webViewRef.get()?.apply {
                    stopLoading()
                    destroy()
                }
            } catch (_: Exception) {}
        }

        return resultRef.get()
    }

    private fun decodeJsString(raw: String?): String? {
        if (raw.isNullOrBlank() || raw == "null" || raw == "\"\"") return null
        return try {
            JSONObject("{\"v\":$raw}").optString("v")
        } catch (_: Exception) {
            null
        }
    }
}
