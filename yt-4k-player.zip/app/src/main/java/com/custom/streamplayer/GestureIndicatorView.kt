package com.custom.streamplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class GestureIndicatorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { NONE, BRIGHTNESS, VOLUME, SEEK }

    private var mode = Mode.NONE
    private var progress = 0.5f // 0f..1f
    private var seekLabel = ""

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(160, 0, 0, 0)
        style = Paint.Style.FILL
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 10f
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 42f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val rect = RectF()

    fun showBrightness(level: Float) {
        mode = Mode.BRIGHTNESS
        progress = level.coerceIn(0f, 1f)
        visibility = VISIBLE
        invalidate()
    }

    fun showVolume(level: Float) {
        mode = Mode.VOLUME
        progress = level.coerceIn(0f, 1f)
        visibility = VISIBLE
        invalidate()
    }

    fun showSeek(label: String) {
        mode = Mode.SEEK
        seekLabel = label
        visibility = VISIBLE
        invalidate()
    }

    fun hide() {
        mode = Mode.NONE
        visibility = GONE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (mode == Mode.NONE) return

        val cx = width / 2f
        val cy = height / 2f

        if (mode == Mode.SEEK) {
            val w = 260f
            val h = 100f
            rect.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
            canvas.drawRoundRect(rect, 50f, 50f, bgPaint)
            val fm = textPaint.fontMetrics
            val ty = cy - (fm.ascent + fm.descent) / 2f
            canvas.drawText(seekLabel, cx, ty, textPaint)
            return
        }

        val r = 95f
        canvas.drawCircle(cx, cy, r, bgPaint)

        val arcR = r - 12f
        rect.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR)
        canvas.drawArc(rect, -90f, 360f, false, trackPaint)
        canvas.drawArc(rect, -90f, 360f * progress, false, arcPaint)

        if (mode == Mode.BRIGHTNESS) {
            // Draw sun icon
            canvas.drawCircle(cx, cy, 20f, iconPaint)
            for (i in 0 until 8) {
                val angle = Math.toRadians((i * 45).toDouble())
                val sx = cx + (28f * cos(angle)).toFloat()
                val sy = cy + (28f * sin(angle)).toFloat()
                val ex = cx + (38f * cos(angle)).toFloat()
                val ey = cy + (38f * sin(angle)).toFloat()
                iconPaint.strokeWidth = 6f
                canvas.drawLine(sx, sy, ex, ey, iconPaint)
            }
        } else if (mode == Mode.VOLUME) {
            // Draw speaker icon
            val path = Path().apply {
                moveTo(cx - 26f, cy - 12f)
                lineTo(cx - 10f, cy - 12f)
                lineTo(cx + 10f, cy - 28f)
                lineTo(cx + 10f, cy + 28f)
                lineTo(cx - 10f, cy + 12f)
                lineTo(cx - 26f, cy + 12f)
                close()
            }
            canvas.drawPath(path, iconPaint)
            if (progress > 0.02f) {
                rect.set(cx + 4f, cy - 18f, cx + 26f, cy + 18f)
                canvas.drawArc(rect, -55f, 110f, false, arcPaint.apply { strokeWidth = 6f })
                arcPaint.strokeWidth = 10f
            }
        }
    }
}
