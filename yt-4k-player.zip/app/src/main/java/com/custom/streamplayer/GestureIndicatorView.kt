package com.custom.streamplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class GestureIndicatorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { NONE, BRIGHTNESS, VOLUME, SEEK, ZOOM_PCT }

    private var mode = Mode.NONE
    private var progress = 0.5f
    private var centerLabel = ""

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(175, 0, 0, 0)
        style = Paint.Style.FILL
    }
    private val zoomBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(190, 220, 220, 220)
        style = Paint.Style.FILL
    }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 14f
        strokeCap = Paint.Cap.ROUND
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(75, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 14f
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 44f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val zoomTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 48f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val rect = RectF()

    fun showBrightness(level: Float) {
        mode = Mode.BRIGHTNESS
        progress = level.coerceIn(0f, 1f)
        visibility = VISIBLE
        invalidate()
    }

    fun showVolume(level: Float) {
        mode = Mode.VOLUME
        progress = level.coerceIn(0f, 1f)
        visibility = VISIBLE
        invalidate()
    }

    fun showSeek(label: String) {
        mode = Mode.SEEK
        centerLabel = label
        visibility = VISIBLE
        invalidate()
    }

    fun showZoomPercent(pct: Int) {
        mode = Mode.ZOOM_PCT
        centerLabel = "$pct%"
        visibility = VISIBLE
        invalidate()
    }

    fun hide() {
        mode = Mode.NONE
        visibility = GONE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (mode == Mode.NONE) return

        val cx = width / 2f
        val cy = height / 2f

        if (mode == Mode.ZOOM_PCT) {
            val w = 180f
            val h = 130f
            rect.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
            canvas.drawRoundRect(rect, 28f, 28f, zoomBgPaint)
            val fm = zoomTextPaint.fontMetrics
            val ty = cy - (fm.ascent + fm.descent) / 2f
            canvas.drawText(centerLabel, cx, ty, zoomTextPaint)
            return
        }

        if (mode == Mode.SEEK) {
            val w = 300f
            val h = 104f
            rect.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
            canvas.drawRoundRect(rect, 52f, 52f, bgPaint)
            val fm = textPaint.fontMetrics
            val ty = cy - (fm.ascent + fm.descent) / 2f
            canvas.drawText(centerLabel, cx, ty, textPaint)
            return
        }

        val r = 135f
        canvas.drawCircle(cx, cy, r, bgPaint)

        val arcR = r - 16f
        rect.set(cx - arcR, cy - arcR, cx + arcR, cy + arcR)
        canvas.drawArc(rect, -90f, 360f, false, trackPaint)
        canvas.drawArc(rect, -90f, 360f * progress, false, arcPaint)

        if (mode == Mode.BRIGHTNESS) {
            canvas.drawCircle(cx, cy, 30f, iconPaint)
            iconPaint.strokeWidth = 9f
            for (i in 0 until 8) {
                val angle = Math.toRadians((i * 45).toDouble())
                val sx = cx + (40f * cos(angle)).toFloat()
                val sy = cy + (40f * sin(angle)).toFloat()
                val ex = cx + (56f * cos(angle)).toFloat()
                val ey = cy + (56f * sin(angle)).toFloat()
                canvas.drawLine(sx, sy, ex, ey, iconPaint)
            }
        } else if (mode == Mode.VOLUME) {
            val path = Path().apply {
                moveTo(cx - 42f, cy - 18f)
                lineTo(cx - 16f, cy - 18f)
                lineTo(cx + 16f, cy - 44f)
                lineTo(cx + 16f, cy + 44f)
                lineTo(cx - 16f, cy + 18f)
                lineTo(cx - 42f, cy + 18f)
                close()
            }
            canvas.drawPath(path, iconPaint)
            if (progress > 0.02f) {
                val wavePaint = Paint(arcPaint).apply { strokeWidth = 8f }
                rect.set(cx + 8f, cy - 26f, cx + 38f, cy + 26f)
                canvas.drawArc(rect, -55f, 110f, false, wavePaint)
            }
        }
    }
}
