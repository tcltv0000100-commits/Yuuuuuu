package com.custom.streamplayer

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.math.min

@OptIn(UnstableApi::class)
class YoutubeChunkedDataSource(
    private val userAgent: String,
    private val extraHeaders: Map<String, String> = emptyMap()
) : BaseDataSource(/* isNetwork = */ true) {

    class Factory(
        private val userAgent: String,
        private val extraHeaders: Map<String, String> = emptyMap()
    ) : DataSource.Factory {
        override fun createDataSource(): DataSource {
            return YoutubeChunkedDataSource(userAgent, extraHeaders)
        }
    }

    companion object {
        private const val CHUNK_SIZE_BYTES = 2L * 1024L * 1024L // 2 MB chunks bypass YouTube CDN per-stream throttling

        private val sharedClient = OkHttpClient.Builder()
            .connectionPool(ConnectionPool(8, 5, TimeUnit.MINUTES))
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    private var currentDataSpec: DataSpec? = null
    private var currentResponse: Response? = null
    private var currentStream: InputStream? = null
    private var opened = false

    private var isChunkedVideoPlayback = false
    private var currentUri: Uri? = null
    private var nextReadPosition = 0L
    private var totalKnownLength = C.LENGTH_UNSET.toLong()
    private var bytesRemainingInCurrentSpec = C.LENGTH_UNSET.toLong()
    private var bytesRemainingInChunk = 0L

    override fun open(dataSpec: DataSpec): Long {
        currentDataSpec = dataSpec
        currentUri = dataSpec.uri
        nextReadPosition = dataSpec.position
        totalKnownLength = C.LENGTH_UNSET.toLong()
        bytesRemainingInChunk = 0L

        val urlStr = dataSpec.uri.toString()
        isChunkedVideoPlayback =
            urlStr.contains("googlevideo.com/videoplayback") && dataSpec.length == C.LENGTH_UNSET.toLong()

        transferInitializing(dataSpec)

        val firstChunkEnd = if (isChunkedVideoPlayback) {
            nextReadPosition + CHUNK_SIZE_BYTES - 1L
        } else if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
            nextReadPosition + dataSpec.length - 1L
        } else {
            -1L
        }

        val openedLen = openChunk(dataSpec, nextReadPosition, firstChunkEnd)
        opened = true
        transferStarted(dataSpec)
        return openedLen
    }

    private fun openChunk(dataSpec: DataSpec, start: Long, endInclusive: Long): Long {
        closeCurrentResponse()

        val reqBuilder = Request.Builder()
            .url(dataSpec.uri.toString())
            .header("User-Agent", userAgent)
            .header("Connection", "keep-alive")

        for ((k, v) in extraHeaders) {
            reqBuilder.header(k, v)
        }
        for ((k, v) in dataSpec.httpRequestHeaders) {
            reqBuilder.header(k, v)
        }

        if (start > 0L || endInclusive >= start) {
            val rangeHeader = if (endInclusive >= start) {
                "bytes=$start-$endInclusive"
            } else {
                "bytes=$start-"
            }
            reqBuilder.header("Range", rangeHeader)
        }

        val resp = try {
            sharedClient.newCall(reqBuilder.build()).execute()
        } catch (e: IOException) {
            throw HttpDataSource.HttpDataSourceException.createForIOException(
                e,
                dataSpec,
                HttpDataSource.HttpDataSourceException.TYPE_OPEN
            )
        }

        val code = resp.code
        if (code < 200 || code >= 300) {
            val headers = resp.headers.toMultimap()
            resp.close()
            if (code == 416 && isChunkedVideoPlayback) {
                bytesRemainingInChunk = 0L
                bytesRemainingInCurrentSpec = 0L
                return 0L
            }
            throw HttpDataSource.InvalidResponseCodeException(
                code,
                resp.message,
                null,
                headers,
                dataSpec,
                ByteArray(0)
            )
        }

        val body = resp.body ?: run {
            resp.close()
            throw HttpDataSource.HttpDataSourceException(
                "Empty response body",
                dataSpec,
                PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
                HttpDataSource.HttpDataSourceException.TYPE_OPEN
            )
        }

        currentResponse = resp
        currentStream = body.byteStream()

        val contentRange = resp.header("Content-Range")
        if (!contentRange.isNullOrBlank()) {
            // Format: bytes start-end/total
            val slashIdx = contentRange.lastIndexOf('/')
            if (slashIdx != -1) {
                val totalStr = contentRange.substring(slashIdx + 1).trim()
                val parsedTotal = totalStr.toLongOrNull()
                if (parsedTotal != null && parsedTotal > 0L) {
                    totalKnownLength = parsedTotal
                }
            }
        }

        val contentLen = body.contentLength()
        bytesRemainingInChunk = if (contentLen >= 0L) contentLen else C.LENGTH_UNSET.toLong()

        if (isChunkedVideoPlayback) {
            bytesRemainingInCurrentSpec = if (totalKnownLength > 0L) {
                (totalKnownLength - start).coerceAtLeast(0L)
            } else {
                C.LENGTH_UNSET.toLong()
            }
            return bytesRemainingInCurrentSpec
        }

        bytesRemainingInCurrentSpec = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
            dataSpec.length
        } else if (contentLen >= 0L) {
            contentLen
        } else {
            C.LENGTH_UNSET.toLong()
        }
        return bytesRemainingInCurrentSpec
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemainingInCurrentSpec == 0L) return C.RESULT_END_OF_INPUT

        while (true) {
            val stream = currentStream
            if (stream == null) {
                if (!advanceNextChunkIfPossible()) return C.RESULT_END_OF_INPUT
                continue
            }

            val toRead = if (bytesRemainingInChunk > 0L) {
                min(length.toLong(), bytesRemainingInChunk).toInt()
            } else {
                length
            }

            val bytesRead = try {
                stream.read(buffer, offset, toRead)
            } catch (e: IOException) {
                val spec = currentDataSpec ?: throw e
                throw HttpDataSource.HttpDataSourceException.createForIOException(
                    e,
                    spec,
                    HttpDataSource.HttpDataSourceException.TYPE_READ
                )
            }

            if (bytesRead == -1) {
                if (isChunkedVideoPlayback && advanceNextChunkIfPossible()) {
                    continue
                }
                return C.RESULT_END_OF_INPUT
            }

            nextReadPosition += bytesRead
            if (bytesRemainingInChunk > 0L) {
                bytesRemainingInChunk -= bytesRead
            }
            if (bytesRemainingInCurrentSpec > 0L) {
                bytesRemainingInCurrentSpec = (bytesRemainingInCurrentSpec - bytesRead).coerceAtLeast(0L)
            }
            bytesTransferred(bytesRead)
            return bytesRead
        }
    }

    private fun advanceNextChunkIfPossible(): Boolean {
        val spec = currentDataSpec ?: return false
        if (!isChunkedVideoPlayback) return false
        if (totalKnownLength > 0L && nextReadPosition >= totalKnownLength) return false
        val nextEnd = if (totalKnownLength > 0L) {
            min(nextReadPosition + CHUNK_SIZE_BYTES - 1L, totalKnownLength - 1L)
        } else {
            nextReadPosition + CHUNK_SIZE_BYTES - 1L
        }
        if (nextEnd < nextReadPosition) return false
        val remaining = openChunk(spec, nextReadPosition, nextEnd)
        return remaining != 0L && currentStream != null
    }

    override fun getUri(): Uri? = currentUri

    override fun close() {
        currentUri = null
        currentDataSpec = null
        closeCurrentResponse()
        if (opened) {
            opened = false
            transferEnded()
        }
    }

    private fun closeCurrentResponse() {
        try {
            currentStream?.close()
        } catch (_: Exception) {
        }
        currentStream = null
        try {
            currentResponse?.close()
        } catch (_: Exception) {
        }
        currentResponse = null
    }
}
