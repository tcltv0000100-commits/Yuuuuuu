package com.custom.streamplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import org.schabi.newpipe.extractor.comments.CommentsInfoItem

class CommentAdapter(
    private val items: List<CommentsInfoItem>
) : RecyclerView.Adapter<CommentAdapter.VH>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_comment, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = items[position]
        val time = c.textualUploadDate ?: ""
        holder.author.text = if (time.isNotEmpty()) "${c.uploaderName} • $time" else (c.uploaderName ?: "User")
        holder.body.text = c.commentText?.content ?: ""
        val likes = c.likeCount
        holder.likes.text = if (likes > 0) "👍 $likes" else "👍"
        val avatar = c.uploaderAvatars.firstOrNull()?.url
        if (!avatar.isNullOrEmpty()) {
            holder.avatar.load(avatar) { transformations(CircleCropTransformation()) }
        } else {
            holder.avatar.setImageDrawable(null)
        }
    }

    override fun getItemCount(): Int = items.size

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val avatar: ImageView = v.findViewById(R.id.commentAvatar)
        val author: TextView = v.findViewById(R.id.commentAuthor)
        val body: TextView = v.findViewById(R.id.commentBody)
        val likes: TextView = v.findViewById(R.id.commentLikes)
    }
}
