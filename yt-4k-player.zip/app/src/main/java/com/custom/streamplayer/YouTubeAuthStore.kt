package com.custom.streamplayer

import android.content.Context
import android.webkit.CookieManager
import java.security.MessageDigest

object YouTubeAuthStore {
    private const val PREF_NAME = "yt_auth"
    private const val KEY_COOKIE = "yt_cookie"

    @Volatile
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun saveCookie(context: Context, cookie: String) {
        appContext = context.applicationContext
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_COOKIE, cookie)
            .apply()
    }

    fun getCookie(context: Context? = appContext): String? {
        val ctx = context ?: appContext ?: return null
        return ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(KEY_COOKIE, null)
            ?.takeIf { it.isNotBlank() }
    }

    fun isLoggedIn(context: Context? = appContext): Boolean {
        val cookie = getCookie(context) ?: return false
        return cookie.contains("SAPISID=") ||
            cookie.contains("__Secure-3PAPISID=") ||
            cookie.contains("LOGIN_INFO=")
    }

    fun logout(context: Context) {
        appContext = context.applicationContext
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_COOKIE)
            .apply()
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        } catch (_: Exception) {}
    }

    fun buildSapisidHash(cookie: String, origin: String = "https://www.youtube.com"): String? {
        val sapisid = extractCookieValue(cookie, "__Secure-3PAPISID")
            ?: extractCookieValue(cookie, "SAPISID")
            ?: return null
        val ts = (System.currentTimeMillis() / 1000L).toString()
        val input = "$ts $sapisid $origin"
        val digest = MessageDigest.getInstance("SHA-1").digest(input.toByteArray(Charsets.UTF_8))
        val hex = digest.joinToString("") { "%02x".format(it) }
        return "SAPISIDHASH ${ts}_$hex"
    }

    private fun extractCookieValue(cookieHeader: String, name: String): String? {
        for (part in cookieHeader.split(";")) {
            val trimmed = part.trim()
            val prefix = "$name="
            if (trimmed.startsWith(prefix)) {
                return trimmed.substring(prefix.length).takeIf { it.isNotBlank() }
            }
        }
        return null
    }
}
