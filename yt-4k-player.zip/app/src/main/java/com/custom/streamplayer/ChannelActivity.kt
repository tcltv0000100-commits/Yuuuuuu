package com.custom.streamplayer

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class ChannelActivity : AppCompatActivity() {

    private lateinit var adapter: VideoAdapter
    private lateinit var progress: ProgressBar
    private val allVideos = mutableListOf<VideoItem>()
    private var isSubbed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_channel)

        val channelName = intent.getStringExtra("channel_name") ?: "Channel"
        val channelUrl = intent.getStringExtra("channel_url") ?: ""

        findViewById<ImageButton>(R.id.chBackBtn).setOnClickListener { finish() }
        findViewById<TextView>(R.id.chTopTitle).text = channelName
        findViewById<TextView>(R.id.chName).text = channelName
        progress = findViewById(R.id.chProgress)

        val subBtn = findViewById<Button>(R.id.chSubBtn)
        subBtn.setOnClickListener {
            isSubbed = !isSubbed
            subBtn.text = if (isSubbed) "Subscribed" else "Subscribe"
        }

        val rv = findViewById<RecyclerView>(R.id.chRecycler)
        adapter = VideoAdapter { video ->
            val i = Intent(this, PlayerActivity::class.java).apply {
                putExtra("video_url", video.url)
                putExtra("video_title", video.title)
                putExtra("channel_name", video.channel)
                putExtra("thumb_url", video.thumbnailUrl)
                putExtra("avatar_url", video.avatarUrl)
                putExtra("duration_sec", video.durationSec)
            }
            startActivity(i)
        }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        val tabVideos = findViewById<Button>(R.id.tabVideos)
        val tabShorts = findViewById<Button>(R.id.tabShorts)

        tabVideos.setOnClickListener {
            adapter.submitList(allVideos.filter { it.durationSec == 0L || it.durationSec > 90 })
        }
        tabShorts.setOnClickListener {
            val shorts = allVideos.filter { it.durationSec in 1..90 }
            if (shorts.isEmpty()) {
                Toast.makeText(this, "Showing all channel videos", Toast.LENGTH_SHORT).show()
                adapter.submitList(allVideos)
            } else {
                adapter.submitList(shorts)
            }
        }

        loadChannel(channelName, channelUrl)
    }

    private fun loadChannel(channelName: String, channelUrl: String) {
        progress.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val items = mutableListOf<VideoItem>()
                var avatarUrl = ""
                var subsText = ""

                if (channelUrl.isNotEmpty()) {
                    val info = ChannelInfo.getInfo(ServiceList.YouTube, channelUrl)
                    avatarUrl = info.avatars.firstOrNull()?.url ?: ""
                    if (info.subscriberCount > 0) {
                        val s = info.subscriberCount
                        subsText = when {
                            s >= 1_000_000 -> String.format("%.1fM subscribers", s / 1_000_000.0)
                            s >= 1_000 -> String.format("%.1fK subscribers", s / 1_000.0)
                            else -> "$s subscribers"
                        }
                    }
                    for (tab in info.tabs.take(2)) {
                        try {
                            val tabInfo = ChannelTabInfo.getInfo(ServiceList.YouTube, tab)
                            tabInfo.relatedItems.filterIsInstance<StreamInfoItem>().forEach {
                                items.add(
                                    VideoItem(
                                        title = it.name ?: "",
                                        url = it.url ?: "",
                                        channel = it.uploaderName ?: channelName,
                                        thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                                        avatarUrl = avatarUrl,
                                        durationSec = it.duration
                                    )
                                )
                            }
                        } catch (_: Exception) {}
                    }
                }

                if (items.isEmpty()) {
                    val qh = ServiceList.YouTube.searchQHFactory.fromQuery(channelName)
                    val sInfo = SearchInfo.getInfo(ServiceList.YouTube, qh)
                    sInfo.relatedItems.filterIsInstance<StreamInfoItem>().forEach {
                        items.add(
                            VideoItem(
                                title = it.name ?: "",
                                url = it.url ?: "",
                                channel = it.uploaderName ?: channelName,
                                thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                                avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                                durationSec = it.duration
                            )
                        )
                    }
                }

                withContext(Dispatchers.Main) {
                    progress.visibility = View.GONE
                    if (subsText.isNotEmpty()) findViewById<TextView>(R.id.chSubs).text = subsText
                    if (avatarUrl.isNotEmpty()) {
                        findViewById<ImageView>(R.id.chAvatar).load(avatarUrl) {
                            transformations(CircleCropTransformation())
                        }
                    }
                    allVideos.clear()
                    allVideos.addAll(items.distinctBy { it.url })
                    adapter.submitList(allVideos)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progress.visibility = View.GONE
                    Toast.makeText(this@ChannelActivity, "Channel error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
