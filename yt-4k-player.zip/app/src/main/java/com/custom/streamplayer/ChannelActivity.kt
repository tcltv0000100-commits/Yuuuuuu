package com.custom.streamplayer

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.tabs.ChannelTabInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class ChannelActivity : AppCompatActivity() {

    private lateinit var rv: RecyclerView
    private lateinit var adapter: VideoAdapter
    private lateinit var progress: ProgressBar
    private lateinit var videosFilterRow: LinearLayout

    private lateinit var tabHome: TextView
    private lateinit var tabVideos: TextView
    private lateinit var tabShorts: TextView
    private lateinit var tabLive: TextView

    private val allVideos = mutableListOf<VideoItem>()
    private val shortsVideos = mutableListOf<VideoItem>()
    private val liveVideos = mutableListOf<VideoItem>()
    private var isSubbed = false
    private var channelUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_channel)

        val channelName = intent.getStringExtra("channel_name") ?: "Channel"
        channelUrl = intent.getStringExtra("channel_url") ?: ""

        findViewById<ImageButton>(R.id.chBackBtn).setOnClickListener { finish() }
        findViewById<TextView>(R.id.chTopTitle).text = channelName
        findViewById<TextView>(R.id.chName).text = channelName
        progress = findViewById(R.id.chProgress)
        videosFilterRow = findViewById(R.id.chVideosFilterRow)

        findViewById<ImageButton>(R.id.chShareBtn).setOnClickListener {
            val shareUrl = channelUrl.ifBlank { channelName }
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, shareUrl)
            }
            startActivity(Intent.createChooser(sendIntent, "Share Channel"))
        }

        findViewById<ImageButton>(R.id.chMoreBtn).setOnClickListener { btn ->
            val popup = PopupMenu(this, btn)
            popup.menu.add(0, 1, 0, "Share channel")
            popup.menu.add(0, 2, 1, "Refresh")
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> findViewById<ImageButton>(R.id.chShareBtn).performClick()
                    2 -> loadChannel(channelName, channelUrl)
                }
                true
            }
            popup.show()
        }

        val subBtn = findViewById<Button>(R.id.chSubBtn)
        subBtn.setOnClickListener {
            isSubbed = !isSubbed
            subBtn.text = if (isSubbed) "SUBSCRIBED" else "SUBSCRIBE"
            subBtn.setBackgroundColor(if (isSubbed) 0xFF666666.toInt() else 0xFFCC0000.toInt())
        }

        rv = findViewById(R.id.chRecycler)
        adapter = VideoAdapter { video -> openVideo(video) }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        tabHome = findViewById(R.id.tabHome)
        tabVideos = findViewById(R.id.tabVideos)
        tabShorts = findViewById(R.id.tabShorts)
        tabLive = findViewById(R.id.tabLive)

        fun selectTab(active: TextView) {
            listOf(tabHome, tabVideos, tabShorts, tabLive).forEach { t ->
                t.setTypeface(null, if (t === active) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
                t.alpha = if (t === active) 1.0f else 0.6f
            }
        }

        tabHome.setOnClickListener {
            selectTab(tabHome)
            videosFilterRow.visibility = View.GONE
            rv.layoutManager = LinearLayoutManager(this)
            rv.adapter = adapter
            adapter.submitList(allVideos)
        }

        tabVideos.setOnClickListener {
            selectTab(tabVideos)
            videosFilterRow.visibility = View.VISIBLE
            rv.layoutManager = LinearLayoutManager(this)
            rv.adapter = adapter
            adapter.submitList(allVideos)
        }

        tabShorts.setOnClickListener {
            selectTab(tabShorts)
            videosFilterRow.visibility = View.GONE
            val list = if (shortsVideos.isNotEmpty()) shortsVideos else allVideos.filter { it.durationSec in 1..90 }
            rv.layoutManager = GridLayoutManager(this, 3)
            rv.adapter = ChannelShortsAdapter(list)
        }

        tabLive.setOnClickListener {
            selectTab(tabLive)
            videosFilterRow.visibility = View.GONE
            val list = if (liveVideos.isNotEmpty()) liveVideos else allVideos.filter { it.durationSec <= 0 }
            rv.layoutManager = LinearLayoutManager(this)
            rv.adapter = adapter
            adapter.submitList(list)
        }

        val filterLatest = findViewById<TextView>(R.id.filterLatest)
        val filterPopular = findViewById<TextView>(R.id.filterPopular)
        val filterOldest = findViewById<TextView>(R.id.filterOldest)

        fun selectFilter(active: TextView) {
            listOf(filterLatest, filterPopular, filterOldest).forEach { f ->
                val isSel = f === active
                f.setBackgroundColor(if (isSel) 0xFF212121.toInt() else 0xFFE8E8E8.toInt())
                f.setTextColor(if (isSel) 0xFFFFFFFF.toInt() else 0xFF212121.toInt())
            }
        }

        filterLatest.setOnClickListener {
            selectFilter(filterLatest)
            adapter.submitList(allVideos)
        }
        filterPopular.setOnClickListener {
            selectFilter(filterPopular)
            adapter.submitList(allVideos.sortedByDescending { it.durationSec })
        }
        filterOldest.setOnClickListener {
            selectFilter(filterOldest)
            adapter.submitList(allVideos.reversed())
        }

        selectTab(tabHome)
        loadChannel(channelName, channelUrl)
    }

    private fun openVideo(video: VideoItem) {
        PlayerActivity.closePipIfActive()
        if (video.url.contains("/shorts/")) {
            val i = Intent(this, ShortsActivity::class.java).apply {
                putStringArrayListExtra("short_urls", arrayListOf(video.url))
                putStringArrayListExtra("short_titles", arrayListOf(video.title))
                putStringArrayListExtra("short_channels", arrayListOf(video.channel))
                putStringArrayListExtra("short_thumbs", arrayListOf(video.thumbnailUrl))
                putStringArrayListExtra("short_avatars", arrayListOf(video.avatarUrl))
                putExtra("start_index", 0)
            }
            startActivity(i)
            return
        }
        val i = Intent(this, PlayerActivity::class.java).apply {
            putExtra("video_url", video.url)
            putExtra("video_title", video.title)
            putExtra("channel_name", video.channel)
            putExtra("thumb_url", video.thumbnailUrl)
            putExtra("avatar_url", video.avatarUrl)
            putExtra("duration_sec", video.durationSec)
        }
        startActivity(i)
    }

    private fun loadChannel(channelName: String, channelUrl: String) {
        progress.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val items = mutableListOf<VideoItem>()
                val shorts = mutableListOf<VideoItem>()
                val lives = mutableListOf<VideoItem>()
                var avatarUrl = ""
                var subsText = ""
                var bioText = ""

                if (channelUrl.isNotEmpty()) {
                    val info = ChannelInfo.getInfo(ServiceList.YouTube, channelUrl)
                    avatarUrl = info.avatars.firstOrNull()?.url ?: ""
                    bioText = info.description?.trim()?.takeIf { it.isNotBlank() } ?: ""
                    if (info.subscriberCount > 0) {
                        val s = info.subscriberCount
                        subsText = when {
                            s >= 1_000_000 -> String.format("%.1fM subscribers", s / 1_000_000.0)
                            s >= 1_000 -> String.format("%.1fK subscribers", s / 1_000.0)
                            else -> "$s subscribers"
                        }
                    }
                    for (tab in info.tabs.take(3)) {
                        try {
                            val tabInfo = ChannelTabInfo.getInfo(ServiceList.YouTube, tab)
                            tabInfo.relatedItems.filterIsInstance<StreamInfoItem>().forEach {
                                val v = VideoItem(
                                    title = it.name ?: "",
                                    url = it.url ?: "",
                                    channel = it.uploaderName ?: channelName,
                                    thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                                    avatarUrl = avatarUrl,
                                    durationSec = it.duration
                                )
                                items.add(v)
                                if (v.url.contains("/shorts/") || v.durationSec in 1..60) {
                                    shorts.add(v)
                                }
                                if (v.durationSec <= 0) {
                                    lives.add(v)
                                }
                            }
                        } catch (_: Exception) {}
                    }
                }

                if (items.isEmpty()) {
                    val qh = ServiceList.YouTube.searchQHFactory.fromQuery(channelName)
                    val sInfo = SearchInfo.getInfo(ServiceList.YouTube, qh)
                    sInfo.relatedItems.filterIsInstance<StreamInfoItem>().forEach {
                        val v = VideoItem(
                            title = it.name ?: "",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: channelName,
                            thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                        items.add(v)
                        if (v.url.contains("/shorts/") || v.durationSec in 1..60) shorts.add(v)
                    }
                }

                withContext(Dispatchers.Main) {
                    progress.visibility = View.GONE
                    if (subsText.isNotEmpty()) findViewById<TextView>(R.id.chSubs).text = subsText
                    if (bioText.isNotEmpty()) findViewById<TextView>(R.id.chBio).text = bioText
                    if (avatarUrl.isNotEmpty()) {
                        findViewById<ImageView>(R.id.chAvatar).load(avatarUrl) {
                            transformations(CircleCropTransformation())
                        }
                    }
                    allVideos.clear()
                    allVideos.addAll(items.distinctBy { it.url })
                    shortsVideos.clear()
                    shortsVideos.addAll(shorts.distinctBy { it.url })
                    liveVideos.clear()
                    liveVideos.addAll(lives.distinctBy { it.url })
                    adapter.submitList(allVideos)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progress.visibility = View.GONE
                    Toast.makeText(this@ChannelActivity, "Channel error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private inner class ChannelShortsAdapter(
        private val items: List<VideoItem>
    ) : RecyclerView.Adapter<ChannelShortsAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.chShortThumb)
            val views: TextView = v.findViewById(R.id.chShortViews)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel_short, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.thumb.load(item.thumbnailUrl) { crossfade(false) }
            holder.views.text = item.title
            holder.itemView.setOnClickListener { openVideo(item) }
        }

        override fun getItemCount(): Int = items.size
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}