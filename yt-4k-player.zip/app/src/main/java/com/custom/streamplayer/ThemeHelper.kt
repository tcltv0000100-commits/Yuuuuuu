package com.custom.streamplayer

import android.app.Activity
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat

object ThemeHelper {
    fun applyTheme(context: Context) {
        val prefs = context.getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val theme = prefs.getString("theme", "Light") ?: "Light"
        val dark = theme == "Dark"
        val mode = if (dark) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        if (AppCompatDelegate.getDefaultNightMode() != mode) {
            AppCompatDelegate.setDefaultNightMode(mode)
        }
        if (context is Activity) {
            context.window.statusBarColor = if (dark) 0xFF0F0F0F.toInt() else 0xFFFFFFFF.toInt()
            WindowCompat.getInsetsController(context.window, context.window.decorView)
                .isAppearanceLightStatusBars = !dark
        }
    }

    fun isDark(context: Context): Boolean {
        val prefs = context.getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        return prefs.getString("theme", "Light") == "Dark"
    }
}
