package com.custom.streamplayer

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

object ThemeHelper {
    fun applyTheme(context: Context) {
        val prefs = context.getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val theme = prefs.getString("theme", "Light") ?: "Light"
        val mode = if (theme == "Dark") AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        if (AppCompatDelegate.getDefaultNightMode() != mode) {
            AppCompatDelegate.setDefaultNightMode(mode)
        }
    }

    fun isDark(context: Context): Boolean {
        val prefs = context.getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        return prefs.getString("theme", "Light") == "Dark"
    }
}
