package com.custom.streamplayer

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    override fun onResume() {
        super.onResume()
        findViewById<TextView?>(R.id.valAccount)?.let {
            val loggedIn = YouTubeAuthStore.isLoggedIn(this)
            it.text = if (loggedIn) "Signed in" else "Sign in"
            it.setTextColor(if (loggedIn) 0xFF2E7D32.toInt() else 0xFFFF0000.toInt())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)

        findViewById<ImageButton>(R.id.backBtn).setOnClickListener { finish() }

        val valAccount = findViewById<TextView>(R.id.valAccount)
        fun refreshAccountLabel() {
            val loggedIn = YouTubeAuthStore.isLoggedIn(this)
            valAccount.text = if (loggedIn) "Signed in" else "Sign in"
            valAccount.setTextColor(if (loggedIn) 0xFF2E7D32.toInt() else 0xFFFF0000.toInt())
        }
        refreshAccountLabel()

        findViewById<LinearLayout>(R.id.rowAccount).setOnClickListener {
            if (YouTubeAuthStore.isLoggedIn(this)) {
                AlertDialog.Builder(this)
                    .setTitle("YouTube Account")
                    .setMessage("Signed in. Do you want to sign out or re-login?")
                    .setPositiveButton("Re-login") { _, _ ->
                        startActivity(Intent(this, LoginActivity::class.java))
                    }
                    .setNegativeButton("Sign out") { _, _ ->
                        YouTubeAuthStore.logout(this)
                        refreshAccountLabel()
                    }
                    .setNeutralButton("Cancel", null)
                    .show()
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
            }
        }

        val valTheme = findViewById<TextView>(R.id.valTheme)
        val valResolution = findViewById<TextView>(R.id.valResolution)
        val valHdrMode = findViewById<TextView>(R.id.valHdrMode)
        val valFormat = findViewById<TextView>(R.id.valFormat)
        val valSeek = findViewById<TextView>(R.id.valSeek)

        val switchAutoRotate = findViewById<SwitchMaterial>(R.id.switchAutoRotate)
        val switchAmbient = findViewById<SwitchMaterial>(R.id.switchAmbient)
        val switchBg = findViewById<SwitchMaterial>(R.id.switchBackground)
        val switchResume = findViewById<SwitchMaterial>(R.id.switchResume)
        val switchFastSeek = findViewById<SwitchMaterial>(R.id.switchFastSeek)

        valTheme.text = prefs.getString("theme", "Light")
        valResolution.text = prefs.getString("default_res", "Auto")
        valHdrMode.text = prefs.getString("hdr_mode", "HDR")
        valFormat.text = prefs.getString("video_format", "Auto")
        valSeek.text = "${prefs.getInt("seek_sec", 10)} seconds"

        switchAutoRotate.isChecked = prefs.getBoolean("auto_rotate", true)
        switchAmbient.isChecked = prefs.getBoolean("ambient_mode", true)
        switchBg.isChecked = prefs.getBoolean("auto_bg", true)
        switchResume.isChecked = prefs.getBoolean("resume_play", true)
        switchFastSeek.isChecked = prefs.getBoolean("fast_seek", true)

        switchAutoRotate.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_rotate", isChecked).apply()
        }
        switchAmbient.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("ambient_mode", isChecked).apply()
        }
        switchBg.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_bg", isChecked).apply()
        }
        switchResume.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("resume_play", isChecked).apply()
        }
        switchFastSeek.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("fast_seek", isChecked).apply()
        }

        findViewById<LinearLayout>(R.id.rowTheme).setOnClickListener {
            val opts = arrayOf("Light", "Dark")
            AlertDialog.Builder(this).setTitle("Theme").setItems(opts) { _, i ->
                prefs.edit().putString("theme", opts[i]).apply()
                valTheme.text = opts[i]
                ThemeHelper.applyTheme(this)
                recreate()
            }.show()
        }

        findViewById<LinearLayout>(R.id.rowResolution).setOnClickListener {
            val opts = arrayOf("Auto", "2160p", "1440p", "1080p", "720p", "480p", "360p")
            AlertDialog.Builder(this).setTitle("Default resolution").setItems(opts) { _, i ->
                prefs.edit().putString("default_res", opts[i]).apply()
                valResolution.text = opts[i]
            }.show()
        }

        findViewById<LinearLayout>(R.id.rowHdrMode).setOnClickListener {
            val opts = arrayOf("HDR", "No HDR")
            AlertDialog.Builder(this)
                .setTitle("HDR Quality")
                .setItems(opts) { _, i ->
                    prefs.edit().putString("hdr_mode", opts[i]).apply()
                    valHdrMode.text = opts[i]
                }.show()
        }

        findViewById<LinearLayout>(R.id.rowFormat).setOnClickListener {
            val opts = arrayOf("Auto", "WebM", "MPEG_4", "AV1")
            AlertDialog.Builder(this).setTitle("Default video format").setItems(opts) { _, i ->
                prefs.edit().putString("video_format", opts[i]).apply()
                valFormat.text = opts[i]
            }.show()
        }

        findViewById<LinearLayout>(R.id.rowSeek).setOnClickListener {
            val opts = arrayOf("5 seconds", "10 seconds", "15 seconds", "30 seconds")
            val secs = intArrayOf(5, 10, 15, 30)
            AlertDialog.Builder(this).setTitle("Double-tap to seek").setItems(opts) { _, i ->
                prefs.edit().putInt("seek_sec", secs[i]).apply()
                valSeek.text = opts[i]
            }.show()
        }


        val valAppLanguage = findViewById<TextView>(R.id.valAppLanguage)
        val valLocation = findViewById<TextView>(R.id.valLocation)
        val switchRestricted = findViewById<SwitchMaterial>(R.id.switchRestricted)
        val switchNotifPush = findViewById<SwitchMaterial>(R.id.switchNotifPush)
        val switchTrendingPush = findViewById<SwitchMaterial>(R.id.switchTrendingPush)
        val switchQuickSearch = findViewById<SwitchMaterial>(R.id.switchQuickSearch)

        valAppLanguage.text = prefs.getString("app_language", "English")
        valLocation.text = prefs.getString("app_location", "India")
        switchRestricted.isChecked = prefs.getBoolean("restricted_mode", false)
        switchNotifPush.isChecked = prefs.getBoolean("notif_push", true)
        switchTrendingPush.isChecked = prefs.getBoolean("trending_push", true)
        switchQuickSearch.isChecked = prefs.getBoolean("quick_search", true)

        switchRestricted.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("restricted_mode", isChecked).apply()
        }
        switchNotifPush.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("notif_push", isChecked).apply()
        }
        switchTrendingPush.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("trending_push", isChecked).apply()
        }
        switchQuickSearch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("quick_search", isChecked).apply()
        }

        findViewById<LinearLayout>(R.id.rowAppLanguage).setOnClickListener {
            val opts = arrayOf("English", "Hindi", "Spanish", "Arabic")
            AlertDialog.Builder(this).setTitle("App language").setItems(opts) { _, i ->
                prefs.edit().putString("app_language", opts[i]).apply()
                valAppLanguage.text = opts[i]
            }.show()
        }

        findViewById<LinearLayout>(R.id.rowLocation).setOnClickListener {
            val opts = arrayOf("India", "United States", "United Kingdom", "Global")
            AlertDialog.Builder(this).setTitle("Location").setItems(opts) { _, i ->
                prefs.edit().putString("app_location", opts[i]).apply()
                valLocation.text = opts[i]
            }.show()
        }

        findViewById<LinearLayout>(R.id.rowClearSearchHistory).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear search history?")
                .setMessage("Remove all saved search queries?")
                .setPositiveButton("Clear") { _, _ ->
                    HistoryStore.clearSearches(this)
                    Toast.makeText(this, "Search history cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<LinearLayout>(R.id.rowClearWatchHistory).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear watch history?")
                .setMessage("Remove all watched videos from history?")
                .setPositiveButton("Clear") { _, _ ->
                    HistoryStore.clearWatchHistory(this)
                    Toast.makeText(this, "Watch history cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }
}