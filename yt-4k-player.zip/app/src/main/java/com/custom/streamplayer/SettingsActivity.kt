package com.custom.streamplayer

import android.content.Context
import android.os.Bundle
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)

        findViewById<ImageButton>(R.id.backBtn).setOnClickListener { finish() }

        val valTheme = findViewById<TextView>(R.id.valTheme)
        val valResolution = findViewById<TextView>(R.id.valResolution)
        val valFormat = findViewById<TextView>(R.id.valFormat)
        val valSeek = findViewById<TextView>(R.id.valSeek)

        val switchAmbient = findViewById<SwitchMaterial>(R.id.switchAmbient)
        val switchBg = findViewById<SwitchMaterial>(R.id.switchBackground)
        val switchResume = findViewById<SwitchMaterial>(R.id.switchResume)
        val switchFastSeek = findViewById<SwitchMaterial>(R.id.switchFastSeek)

        valTheme.text = prefs.getString("theme", "Light")
        valResolution.text = prefs.getString("default_res", "Auto")
        valFormat.text = prefs.getString("video_format", "WebM")
        valSeek.text = "${prefs.getInt("seek_sec", 15)} seconds"

        switchAmbient.isChecked = prefs.getBoolean("ambient_mode", true)
        switchBg.isChecked = prefs.getBoolean("auto_bg", true)
        switchResume.isChecked = prefs.getBoolean("resume_play", true)
        switchFastSeek.isChecked = prefs.getBoolean("fast_seek", true)

        switchAmbient.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("ambient_mode", isChecked).apply()
        }
        switchBg.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_bg", isChecked).apply()
        }
        switchResume.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("resume_play", isChecked).apply()
        }
        switchFastSeek.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("fast_seek", isChecked).apply()
        }

        findViewById<LinearLayout>(R.id.rowTheme).setOnClickListener {
            val opts = arrayOf("Light", "Dark")
            AlertDialog.Builder(this).setTitle("Theme").setItems(opts) { _, i ->
                prefs.edit().putString("theme", opts[i]).apply()
                valTheme.text = opts[i]
                ThemeHelper.applyTheme(this)
                recreate()
            }.show()
        }

        findViewById<LinearLayout>(R.id.rowResolution).setOnClickListener {
            val opts = arrayOf("Auto", "2160p", "1440p", "1080p", "720p", "480p")
            AlertDialog.Builder(this).setTitle("Default resolution").setItems(opts) { _, i ->
                prefs.edit().putString("default_res", opts[i]).apply()
                valResolution.text = opts[i]
            }.show()
        }

        findViewById<LinearLayout>(R.id.rowFormat).setOnClickListener {
            val opts = arrayOf("WebM", "MPEG_4", "AV1")
            AlertDialog.Builder(this).setTitle("Default video format").setItems(opts) { _, i ->
                prefs.edit().putString("video_format", opts[i]).apply()
                valFormat.text = opts[i]
            }.show()
        }

        findViewById<LinearLayout>(R.id.rowSeek).setOnClickListener {
            val opts = arrayOf("5 seconds", "10 seconds", "15 seconds", "30 seconds")
            val secs = intArrayOf(5, 10, 15, 30)
            AlertDialog.Builder(this).setTitle("Double-tap to seek").setItems(opts) { _, i ->
                prefs.edit().putInt("seek_sec", secs[i]).apply()
                valSeek.text = opts[i]
            }.show()
        }
    }
}
