package com.custom.streamplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation

class VideoAdapter(
    private val onClick: (VideoItem) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    private val items = mutableListOf<VideoItem>()

    fun submitList(newItems: List<VideoItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_video_card, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.title.text = item.title
        holder.channel.text = item.channel
        holder.duration.text = formatDuration(item.durationSec)
        holder.thumb.load(item.thumbnailUrl)
        if (item.avatarUrl.isNotEmpty()) {
            holder.avatar.load(item.avatarUrl) {
                transformations(CircleCropTransformation())
            }
        } else {
            holder.avatar.setImageDrawable(null)
        }
        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size

    private fun formatDuration(sec: Long): String {
        if (sec <= 0) return "LIVE"
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s)
        else String.format("%d:%02d", m, s)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumbImage)
        val avatar: ImageView = v.findViewById(R.id.avatarImage)
        val duration: TextView = v.findViewById(R.id.durationBadge)
        val title: TextView = v.findViewById(R.id/videoTitle)
        val channel: TextView = v.findViewById(R.id.channelName)
    }
}
