package com.custom.streamplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation

class VideoAdapter(
    private val onClick: (VideoItem) -> Unit
) : ListAdapter<VideoItem, VideoAdapter.VH>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<VideoItem>() {
            override fun areItemsTheSame(oldItem: VideoItem, newItem: VideoItem): Boolean =
                oldItem.url == newItem.url

            override fun areContentsTheSame(oldItem: VideoItem, newItem: VideoItem): Boolean =
                oldItem == newItem
        }
    }

    override fun submitList(list: List<VideoItem>?) {
        super.submitList(list?.toList())
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_video_card, parent, false)
        return VH(v, onClick)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position))
    }

    class VH(v: View, private val onClick: (VideoItem) -> Unit) : RecyclerView.ViewHolder(v) {
        private val thumb: ImageView = v.findViewById(R.id.thumbImage)
        private val avatar: ImageView = v.findViewById(R.id.avatarImage)
        private val duration: TextView = v.findViewById(R.id.durationBadge)
        private val title: TextView = v.findViewById(R.id.videoTitle)
        private val channel: TextView = v.findViewById(R.id.channelName)
        private var currentItem: VideoItem? = null

        init {
            v.setOnClickListener {
                currentItem?.let(onClick)
            }
        }

        fun bind(item: VideoItem) {
            currentItem = item
            title.text = item.title
            channel.text = item.channel
            duration.text = formatDuration(item.durationSec)
            thumb.load(item.thumbnailUrl) {
                crossfade(150)
            }
            if (item.avatarUrl.isNotEmpty()) {
                avatar.load(item.avatarUrl) {
                    crossfade(150)
                    transformations(CircleCropTransformation())
                }
            } else {
                avatar.setImageDrawable(null)
            }
        }

        private fun formatDuration(sec: Long): String {
            if (sec <= 0) return "LIVE"
            val h = sec / 3600
            val m = (sec % 3600) / 60
            val s = sec % 60
            return if (h > 0) String.format("%d:%02d:%02d", h, m, s)
            else String.format("%d:%02d", m, s)
        }
    }
}
