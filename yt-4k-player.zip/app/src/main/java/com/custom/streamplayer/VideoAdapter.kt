package com.custom.streamplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.imageLoader
import coil.load
import coil.request.ImageRequest
import coil.transform.CircleCropTransformation
import kotlin.math.abs

class VideoAdapter(
    private val onClick: (VideoItem) -> Unit
) : ListAdapter<VideoItem, VideoAdapter.VH>(DIFF) {

    private var appContext: Context? = null

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<VideoItem>() {
            override fun areItemsTheSame(oldItem: VideoItem, newItem: VideoItem): Boolean =
                oldItem.url == newItem.url

            override fun areContentsTheSame(oldItem: VideoItem, newItem: VideoItem): Boolean =
                oldItem == newItem
        }

        private val AVATAR_COLORS = intArrayOf(
            0xFFD32F2F.toInt(),
            0xFF1976D2.toInt(),
            0xFF388E3C.toInt(),
            0xFF7B1FA2.toInt(),
            0xFFE64A19.toInt(),
            0xFF00796B.toInt(),
            0xFF5D4037.toInt(),
            0xFF303F9F.toInt()
        )

        fun createLetterAvatar(channelName: String): Drawable {
            val letter = channelName.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "Y"
            val color = AVATAR_COLORS[abs(channelName.hashCode()) % AVATAR_COLORS.size]
            return object : Drawable() {
                private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
                private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = Color.WHITE
                    textAlign = Paint.Align.CENTER
                    isFakeBoldText = true
                }

                override fun draw(canvas: Canvas) {
                    val b = bounds
                    val cx = b.exactCenterX()
                    val cy = b.exactCenterY()
                    val r = minOf(b.width(), b.height()) / 2f
                    canvas.drawCircle(cx, cy, r, bgPaint)
                    textPaint.textSize = r * 1.05f
                    val textY = cy - (textPaint.descent() + textPaint.ascent()) / 2f
                    canvas.drawText(letter, cx, textY, textPaint)
                }

                override fun setAlpha(alpha: Int) { bgPaint.alpha = alpha; textPaint.alpha = alpha }
                override fun setColorFilter(colorFilter: ColorFilter?) {
                    bgPaint.colorFilter = colorFilter
                    textPaint.colorFilter = colorFilter
                }
                @Deprecated("Deprecated in Java")
                override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
            }
        }
    }

    override fun submitList(list: List<VideoItem>?) {
        val copy = list?.toList()
        super.submitList(copy)
        if (!copy.isNullOrEmpty()) {
            appContext?.let { preloadRange(it, copy, 0, minOf(10, copy.size)) }
        }
    }

    private fun preloadRange(context: Context, items: List<VideoItem>, start: Int, endExclusive: Int) {
        val loader = context.imageLoader
        for (i in start until endExclusive) {
            val item = items.getOrNull(i) ?: continue
            if (item.thumbnailUrl.isNotEmpty()) {
                loader.enqueue(
                    ImageRequest.Builder(context)
                        .data(item.thumbnailUrl)
                        .build()
                )
            }
            if (item.avatarUrl.isNotEmpty()) {
                loader.enqueue(
                    ImageRequest.Builder(context)
                        .data(item.avatarUrl)
                        .transformations(CircleCropTransformation())
                        .build()
                )
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        if (appContext == null) appContext = parent.context.applicationContext
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_video_card, parent, false)
        return VH(v, onClick)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position))
        // Preload upcoming thumbnails & channel logos ahead of scroll so logos never pop in late
        val list = currentList
        val nextStart = position + 1
        val nextEnd = minOf(position + 8, list.size)
        if (nextStart < nextEnd) {
            appContext?.let { preloadRange(it, list, nextStart, nextEnd) }
        }
    }

    class VH(v: View, private val onClick: (VideoItem) -> Unit) : RecyclerView.ViewHolder(v) {
        private val thumb: ImageView = v.findViewById(R.id.thumbImage)
        private val avatar: ImageView = v.findViewById(R.id.avatarImage)
        private val duration: TextView = v.findViewById(R.id.durationBadge)
        private val title: TextView = v.findViewById(R.id.videoTitle)
        private val channel: TextView = v.findViewById(R.id.channelName)
        private var currentItem: VideoItem? = null

        init {
            v.setOnClickListener {
                currentItem?.let(onClick)
            }
            v.setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        view.animate().scaleX(0.98f).scaleY(0.98f).setDuration(80).start()
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        view.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    }
                }
                false
            }
        }

        fun bind(item: VideoItem) {
            currentItem = item
            title.text = item.title
            channel.text = item.channel
            duration.text = formatDuration(item.durationSec)

            thumb.load(item.thumbnailUrl) {
                crossfade(false)
            }

            val fallbackDrawable = createLetterAvatar(item.channel)
            if (item.avatarUrl.isNotEmpty()) {
                avatar.load(item.avatarUrl) {
                    crossfade(false)
                    placeholder(fallbackDrawable)
                    error(fallbackDrawable)
                    transformations(CircleCropTransformation())
                }
            } else {
                avatar.setImageDrawable(fallbackDrawable)
            }
        }

        private fun formatDuration(sec: Long): String {
            if (sec <= 0) return "LIVE"
            val h = sec / 3600
            val m = (sec % 3600) / 60
            val s = sec % 60
            return if (h > 0) String.format("%d:%02d:%02d", h, m, s)
            else String.format("%d:%02d", m, s)
        }
    }
}
