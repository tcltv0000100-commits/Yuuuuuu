package com.custom.streamplayer

import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerContainer: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var gestureIndicator: GestureIndicatorView
    private lateinit var detailsSection: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var metaText: TextView
    private lateinit var overlayQuality: TextView
    private lateinit var overlaySpeed: TextView
    private lateinit var overlayResize: TextView
    private lateinit var overlayFullscreen: TextView
    private lateinit var qualityLabel: TextView
    private lateinit var channelTitle: TextView
    private lateinit var channelSubs: TextView
    private lateinit var channelAvatar: ImageView
    private lateinit var subscribeBtn: TextView
    private lateinit var relatedAdapter: VideoAdapter

    private var adaptiveVideos: List<VideoStream> = emptyList()
    private var muxedVideos: List<VideoStream> = emptyList()
    private var bestAudio: AudioStream? = null
    private var currentVideoUrl: String = ""
    private var isFullscreen = false
    private var isSubscribed = false

    private var pinchScale = 1.0f
    private var resizeModeIndex = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("Fit", "Zoom", "Fill")

    private val hideHandler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { gestureIndicator.hide() }

    private enum class DragMode { NONE, HORIZONTAL_SEEK, LEFT_BRIGHTNESS, RIGHT_VOLUME }
    private var dragMode = DragMode.NONE
    private var downX = 0f
    private var downY = 0f
    private var startBrightness = 0.5f
    private var startVolume = 0
    private var startSeekPos = 0L
    private var pendingSeekPos = -1L

    private val hdrItags = setOf(
        330, 331, 332, 333, 334, 335, 336, 337,
        694, 695, 696, 697, 698, 699, 700, 701, 702
    )

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.colorMode = ActivityInfo.COLOR_MODE_HDR
        }
        setContentView(R.layout.activity_player)

        playerContainer = findViewById(R.id.playerContainer)
        playerView = findViewById(R.id.playerView)
        gestureIndicator = findViewById(R.id.gestureIndicator)
        detailsSection = findViewById(R.id.detailsSection)
        titleText = findViewById(R.id.playerTitle)
        metaText = findViewById(R.id.playerMeta)
        overlayQuality = findViewById(R.id.overlayQuality)
        overlaySpeed = findViewById(R.id.overlaySpeed)
        overlayResize = findViewById(R.id.overlayResize)
        overlayFullscreen = findViewById(R.id.overlayFullscreen)
        qualityLabel = findViewById(R.id.qualityLabel)
        channelTitle = findViewById(R.id.channelTitle)
        channelSubs = findViewById(R.id.channelSubs)
        channelAvatar = findViewById(R.id.channelAvatar)
        subscribeBtn = findViewById(R.id.subscribeBtn)

        val relatedRecycler = findViewById<RecyclerView>(R.id.relatedRecycler)
        relatedAdapter = VideoAdapter { video ->
            val intent = Intent(this, PlayerActivity::class.java).apply {
                putExtra("video_url", video.url)
                putExtra("video_title", video.title)
                putExtra("channel_name", video.channel)
            }
            startActivity(intent)
            finish()
        }
        relatedRecycler.layoutManager = LinearLayoutManager(this)
        relatedRecycler.adapter = relatedAdapter

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 1_500, 3_000)
            .build()

        val renderersFactory = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)

        player = ExoPlayer.Builder(this, renderersFactory)
            .setLoadControl(loadControl)
            .build()
            .also {
                playerView.player = it
            }

        playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        setupPlayerGestures()

        currentVideoUrl = normalizeYouTubeUrl(intent.getStringExtra("video_url") ?: "")
        titleText.text = intent.getStringExtra("video_title") ?: ""
        channelTitle.text = intent.getStringExtra("channel_name") ?: "Channel"

        overlayQuality.setOnClickListener { showQualityDialog() }
        findViewById<LinearLayout>(R.id.btnQuality).setOnClickListener { showQualityDialog() }
        overlaySpeed.setOnClickListener { showSpeedDialog() }
        overlayResize.setOnClickListener { cycleResizeMode() }
        overlayFullscreen.setOnClickListener { toggleFullscreen() }

        findViewById<LinearLayout>(R.id.btnShare).setOnClickListener {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, currentVideoUrl)
            }
            startActivity(Intent.createChooser(sendIntent, "Share video"))
        }

        findViewById<LinearLayout>(R.id.btnPopup).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } else {
                Toast.makeText(this, "Pop-up requires Android 8+", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<LinearLayout>(R.id.btnBackground).setOnClickListener {
            Toast.makeText(this, "Background audio enabled", Toast.LENGTH_SHORT).show()
            moveTaskToBack(true)
        }

        findViewById<LinearLayout>(R.id.btnSave).setOnClickListener {
            Toast.makeText(this, "Saved to Playlist", Toast.LENGTH_SHORT).show()
        }

        subscribeBtn.setOnClickListener {
            isSubscribed = !isSubscribed
            subscribeBtn.text = if (isSubscribed) "SUBSCRIBED" else "SUBSCRIBE"
            subscribeBtn.setTextColor(if (isSubscribed) 0xFF606060.toInt() else 0xFFFF0000.toInt())
        }

        if (currentVideoUrl.isNotEmpty()) {
            loadStreams(currentVideoUrl)
        }
    }

    @OptIn(UnstableApi::class)
    private fun cycleResizeMode() {
        resizeModeIndex = (resizeModeIndex + 1) % resizeModes.size
        pinchScale = 1.0f
        playerView.scaleX = 1.0f
        playerView.scaleY = 1.0f
        playerView.resizeMode = resizeModes[resizeModeIndex]
        val name = resizeNames[resizeModeIndex]
        overlayResize.text = name
        gestureIndicator.showSeek(name)
        scheduleHideIndicator()
    }

    private fun normalizeYouTubeUrl(raw: String): String {
        if (raw.contains("/shorts/")) {
            val id = raw.substringAfter("/shorts/").substringBefore("?").substringBefore("/")
            if (id.isNotEmpty()) return "https://www.youtube.com/watch?v=$id"
        }
        return raw
    }

    private fun isHdrStream(v: VideoStream): Boolean {
        val c = v.codec ?: ""
        return v.itag in hdrItags ||
            c.contains("vp9.2", ignoreCase = true) ||
            c.contains("av01.0.10", ignoreCase = true) ||
            c.contains("hdr", ignoreCase = true) ||
            v.resolution.contains("HDR", ignoreCase = true)
    }

    private fun streamLabel(v: VideoStream): String {
        val hdr = if (isHdrStream(v) && !v.resolution.contains("HDR", true)) " HDR" else ""
        return "${v.resolution}$hdr"
    }

    @OptIn(UnstableApi::class)
    private fun setupPlayerGestures() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)

        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                pinchScale = (pinchScale * detector.scaleFactor).coerceIn(0.50f, 2.50f)
                playerView.scaleX = pinchScale
                playerView.scaleY = pinchScale
                val pct = (pinchScale * 100).toInt()
                gestureIndicator.showZoomPercent(pct)
                scheduleHideIndicator()
                return true
            }
        })

        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) {
                    playerView.hideController()
                } else {
                    playerView.showController()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return false
                val seekSec = prefs.getInt("seek_sec", 15)
                val seekMs = seekSec * 1000L
                val isRight = e.x > playerContainer.width / 2f
                val target = if (isRight) {
                    (p.currentPosition + seekMs).coerceAtMost(p.duration.coerceAtLeast(0L))
                } else {
                    (p.currentPosition - seekMs).coerceAtLeast(0L)
                }
                p.seekTo(target)
                gestureIndicator.showSeek(if (isRight) "+${seekSec}s" else "-${seekSec}s")
                scheduleHideIndicator()
                return true
            }
        })

        playerView.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            if (event.pointerCount > 1 || scaleDetector.isInProgress) {
                dragMode = DragMode.NONE
                return@setOnTouchListener true
            }

            tapDetector.onTouchEvent(event)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragMode = DragMode.NONE
                    downX = event.x
                    downY = event.y
                    pendingSeekPos = -1L
                    val lp = window.attributes
                    startBrightness = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                    startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    startSeekPos = player?.currentPosition ?: 0L
                    false
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    val threshold = 30f

                    if (dragMode == DragMode.NONE && (abs(dx) > threshold || abs(dy) > threshold)) {
                        dragMode = if (abs(dx) > abs(dy)) {
                            DragMode.HORIZONTAL_SEEK
                        } else if (downX < playerContainer.width / 2f) {
                            DragMode.LEFT_BRIGHTNESS
                        } else {
                            DragMode.RIGHT_VOLUME
                        }
                    }

                    when (dragMode) {
                        DragMode.HORIZONTAL_SEEK -> {
                            val dur = player?.duration?.coerceAtLeast(0L) ?: 0L
                            if (dur > 0) {
                                val deltaMs = ((dx / playerContainer.width.coerceAtLeast(1)) * 90_000L).toLong()
                                pendingSeekPos = (startSeekPos + deltaMs).coerceIn(0L, dur)
                                val secDiff = deltaMs / 1000L
                                val sign = if (secDiff >= 0) "+" else ""
                                gestureIndicator.showSeek("${formatTime(pendingSeekPos)} ($sign${secDiff}s)")
                            }
                            true
                        }
                        DragMode.LEFT_BRIGHTNESS -> {
                            val delta = -dy / playerContainer.height.coerceAtLeast(1)
                            val newB = (startBrightness + delta).coerceIn(0.02f, 1.0f)
                            val lp = window.attributes
                            lp.screenBrightness = newB
                            window.attributes = lp
                            gestureIndicator.showBrightness(newB)
                            true
                        }
                        DragMode.RIGHT_VOLUME -> {
                            val delta = -dy / playerContainer.height.coerceAtLeast(1)
                            val newVol = (startVolume + (delta * maxVolume)).toInt().coerceIn(0, maxVolume)
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                            gestureIndicator.showVolume(newVol.toFloat() / maxVolume.toFloat())
                            true
                        }
                        DragMode.NONE -> false
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragMode == DragMode.HORIZONTAL_SEEK && pendingSeekPos >= 0L) {
                        player?.seekTo(pendingSeekPos)
                    }
                    if (dragMode != DragMode.NONE) {
                        scheduleHideIndicator()
                        dragMode = DragMode.NONE
                        true
                    } else {
                        false
                    }
                }

                else -> false
            }
        }
    }

    private fun scheduleHideIndicator() {
        hideHandler.removeCallbacks(hideRunnable)
        hideHandler.postDelayed(hideRunnable, 750)
    }

    private fun formatTime(ms: Long): String {
        val totalSec = (ms / 1000).coerceAtLeast(0)
        val m = totalSec / 60
        val s = totalSec % 60
        return String.format("%02d:%02d", m, s)
    }

    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (isFullscreen) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            detailsSection.visibility = View.GONE
            playerContainer.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            controller.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            detailsSection.visibility = View.VISIBLE
            val heightPx = (230 * resources.displayMetrics.density).toInt()
            playerContainer.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                heightPx
            )
        }
    }

    private fun showSpeedDialog() {
        val speeds = arrayOf("0.5x", "0.75x", "1x", "1.25x", "1.5x", "2x")
        val vals = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        AlertDialog.Builder(this)
            .setTitle("Playback Speed")
            .setItems(speeds) { _, i ->
                player?.setPlaybackSpeed(vals[i])
                overlaySpeed.text = speeds[i]
            }
            .show()
    }

    @OptIn(UnstableApi::class)
    private fun loadStreams(url: String) {
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val preferredRes = prefs.getString("default_res", "2160p") ?: "2160p"
        val preferredFmt = prefs.getString("video_format", "WebM") ?: "WebM"
        val targetHeight = preferredRes.replace("p", "").toIntOrNull() ?: 2160

        metaText.text = "Fetching streams..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val info = StreamInfo.getInfo(ServiceList.YouTube, url)
                val vOnly = info.videoOnlyStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .sortedWith(
                        compareByDescending<VideoStream> { it.height }
                            .thenByDescending { isHdrStream(it) }
                            .thenByDescending { (it.format?.name ?: "").equals(preferredFmt, ignoreCase = true) }
                    )
                val vMuxed = info.videoStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .sortedByDescending { it.height }
                val audio = info.audioStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .maxByOrNull { it.averageBitrate }
                val related = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .map {
                        VideoItem(
                            title = it.name ?: "",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: "",
                            thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                    }

                withContext(Dispatchers.Main) {
                    titleText.text = info.name
                    channelTitle.text = info.uploaderName ?: "Channel"
                    val views = formatCount(info.viewCount)
                    metaText.text = if (views.isNotEmpty()) "$views views" else "Ready"
                    val subs = formatCount(info.uploaderSubscriberCount)
                    channelSubs.text = if (subs.isNotEmpty()) "$subs subscribers" else ""
                    val avatarUrl = info.uploaderAvatars.firstOrNull()?.url
                    if (!avatarUrl.isNullOrEmpty()) {
                        channelAvatar.load(avatarUrl) { transformations(CircleCropTransformation()) }
                    }
                    relatedAdapter.submitList(related)
                    adaptiveVideos = vOnly
                    muxedVideos = vMuxed
                    bestAudio = audio

                    when {
                        vOnly.isNotEmpty() && audio != null -> {
                            val underCap = vOnly.filter { it.height <= targetHeight }
                            val chosen = underCap.firstOrNull { (it.format?.name ?: "").equals(preferredFmt, true) }
                                ?: underCap.firstOrNull()
                                ?: vOnly.first()
                            playAdaptive(chosen, audio, preservePosition = false)
                        }
                        vMuxed.isNotEmpty() -> {
                            val chosen = vMuxed.firstOrNull { it.height <= targetHeight } ?: vMuxed.first()
                            playSingleUrl(chosen.content, streamLabel(chosen), preservePosition = false)
                        }
                        !info.hlsUrl.isNullOrEmpty() -> playHls(info.hlsUrl)
                        !info.dashMpdUrl.isNullOrEmpty() -> playDash(info.dashMpdUrl)
                        else -> metaText.text = "No playable streams found."
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    metaText.text = "Error: ${e.localizedMessage}"
                }
            }
        }
    }

    private fun formatCount(count: Long): String {
        if (count <= 0) return ""
        return when {
            count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
            count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
            else -> count.toString()
        }
    }

    @OptIn(UnstableApi::class)
    private fun makeDataSourceFactory(): DefaultHttpDataSource.Factory {
        return DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0")
    }

    @OptIn(UnstableApi::class)
    private fun playAdaptive(video: VideoStream, audio: AudioStream, preservePosition: Boolean = true) {
        val resumePos = if (preservePosition) (player?.currentPosition ?: 0L).coerceAtLeast(0L) else 0L
        val factory = makeDataSourceFactory()
        val vSource = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(video.content))
        val aSource = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(audio.content))
        player?.apply {
            setMediaSource(MergingMediaSource(vSource, aSource))
            if (resumePos > 0L) seekTo(resumePos)
            prepare()
            playWhenReady = true
        }
        val label = streamLabel(video)
        overlayQuality.text = label
        qualityLabel.text = label
    }

    @OptIn(UnstableApi::class)
    private fun playSingleUrl(streamUrl: String, label: String, preservePosition: Boolean = true) {
        val resumePos = if (preservePosition) (player?.currentPosition ?: 0L).coerceAtLeast(0L) else 0L
        val source = ProgressiveMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(streamUrl))
        player?.apply {
            setMediaSource(source)
            if (resumePos > 0L) seekTo(resumePos)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = label
        qualityLabel.text = label
    }

    @OptIn(UnstableApi::class)
    private fun playHls(hlsUrl: String) {
        val source = HlsMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(hlsUrl))
        player?.apply {
            setMediaSource(source)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = "LIVE"
        qualityLabel.text = "LIVE"
    }

    @OptIn(UnstableApi::class)
    private fun playDash(dashUrl: String) {
        val source = DashMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(dashUrl))
        player?.apply {
            setMediaSource(source)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = "DASH"
        qualityLabel.text = "DASH"
    }

    private fun showQualityDialog() {
        if (adaptiveVideos.isNotEmpty() && bestAudio != null) {
            val labels = adaptiveVideos.map {
                "${streamLabel(it)} • ${it.format?.name ?: "DASH"}"
            }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Select Quality")
                .setItems(labels) { _, which ->
                    playAdaptive(adaptiveVideos[which], bestAudio!!, preservePosition = true)
                }
                .show()
        } else if (muxedVideos.isNotEmpty()) {
            val labels = muxedVideos.map { "${streamLabel(it)} • MP4" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Select Quality")
                .setItems(labels) { _, which ->
                    val v = muxedVideos[which]
                    playSingleUrl(v.content, streamLabel(v), preservePosition = true)
                }
                .show()
        }
    }

    override fun onPause() {
        super.onPause()
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val autoBg = prefs.getBoolean("auto_bg", true)
        if (!autoBg && !isInPictureInPictureMode) {
            player?.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        hideHandler.removeCallbacks(hideRunnable)
        player?.release()
        player = null
    }
}
