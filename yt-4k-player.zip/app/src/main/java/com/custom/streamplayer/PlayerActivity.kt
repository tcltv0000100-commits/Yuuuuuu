package com.custom.streamplayer

import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerContainer: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var detailsSection: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var metaText: TextView
    private lateinit var overlayQuality: TextView
    private lateinit var overlaySpeed: TextView
    private lateinit var overlayFullscreen: TextView
    private lateinit var qualityLabel: TextView
    private lateinit var channelTitle: TextView
    private lateinit var channelSubs: TextView
    private lateinit var channelAvatar: ImageView
    private lateinit var subscribeBtn: TextView
    private lateinit var relatedAdapter: VideoAdapter

    private var adaptiveVideos: List<VideoStream> = emptyList()
    private var muxedVideos: List<VideoStream> = emptyList()
    private var bestAudio: AudioStream? = null
    private var currentVideoUrl: String = ""
    private var isFullscreen = false
    private var isSubscribed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerContainer = findViewById(R.id.playerContainer)
        playerView = findViewById(R.id.playerView)
        detailsSection = findViewById(R.id.detailsSection)
        titleText = findViewById(R.id.playerTitle)
        metaText = findViewById(R.id.playerMeta)
        overlayQuality = findViewById(R.id.overlayQuality)
        overlaySpeed = findViewById(R.id.overlaySpeed)
        overlayFullscreen = findViewById(R.id.overlayFullscreen)
        qualityLabel = findViewById(R.id.qualityLabel)
        channelTitle = findViewById(R.id.channelTitle)
        channelSubs = findViewById(R.id.channelSubs)
        channelAvatar = findViewById(R.id.channelAvatar)
        subscribeBtn = findViewById(R.id.subscribeBtn)

        val relatedRecycler = findViewById<RecyclerView>(R.id.relatedRecycler)
        relatedAdapter = VideoAdapter { video ->
            val intent = Intent(this, PlayerActivity::class.java).apply {
                putExtra("video_url", video.url)
                putExtra("video_title", video.title)
                putExtra("channel_name", video.channel)
            }
            startActivity(intent)
            finish()
        }
        relatedRecycler.layoutManager = LinearLayoutManager(this)
        relatedRecycler.adapter = relatedAdapter

        player = ExoPlayer.Builder(this).build().also {
            playerView.player = it
        }

        currentVideoUrl = intent.getStringExtra("video_url") ?: ""
        titleText.text = intent.getStringExtra("video_title") ?: ""
        channelTitle.text = intent.getStringExtra("channel_name") ?: "Channel"

        overlayQuality.setOnClickListener { showQualityDialog() }
        findViewById<LinearLayout>(R.id.btnQuality).setOnClickListener { showQualityDialog() }

        overlaySpeed.setOnClickListener { showSpeedDialog() }
        overlayFullscreen.setOnClickListener { toggleFullscreen() }

        findViewById<LinearLayout>(R.id.btnShare).setOnClickListener {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, currentVideoUrl)
            }
            startActivity(Intent.createChooser(sendIntent, "Share video"))
        }

        findViewById<LinearLayout>(R.id.btnPopup).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } else {
                Toast.makeText(this, "Pop-up requires Android 8+", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<LinearLayout>(R.id.btnBackground).setOnClickListener {
            Toast.makeText(this, "Background audio enabled", Toast.LENGTH_SHORT).show()
            moveTaskToBack(true)
        }

        findViewById<LinearLayout>(R.id.btnSave).setOnClickListener {
            Toast.makeText(this, "Saved to Playlist", Toast.LENGTH_SHORT).show()
        }

        subscribeBtn.setOnClickListener {
            isSubscribed = !isSubscribed
            subscribeBtn.text = if (isSubscribed) "SUBSCRIBED" else "SUBSCRIBE"
            subscribeBtn.setTextColor(if (isSubscribed) 0xFF606060.toInt() else 0xFFFF0000.toInt())
        }

        if (currentVideoUrl.isNotEmpty()) {
            loadStreams(currentVideoUrl)
        }
    }

    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        if (isFullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            detailsSection.visibility = View.GONE
            playerContainer.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            detailsSection.visibility = View.VISIBLE
            val heightPx = (230 * resources.displayMetrics.density).toInt()
            playerContainer.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                heightPx
            )
        }
    }

    private fun showSpeedDialog() {
        val speeds = arrayOf("0.5x", "0.75x", "1x", "1.25x", "1.5x", "2x")
        val vals = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        AlertDialog.Builder(this)
            .setTitle("Playback Speed")
            .setItems(speeds) { _, i ->
                player?.setPlaybackSpeed(vals[i])
                overlaySpeed.text = speeds[i]
            }
            .show()
    }

    @OptIn(UnstableApi::class)
    private fun loadStreams(url: String) {
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val preferredRes = prefs.getString("default_res", "2160p") ?: "2160p"
        val targetHeight = preferredRes.replace("p", "").toIntOrNull() ?: 2160

        metaText.text = "Fetching streams..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val info = StreamInfo.getInfo(ServiceList.YouTube, url)
                val vOnly = info.videoOnlyStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .sortedByDescending { it.height }
                val vMuxed = info.videoStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .sortedByDescending { it.height }
                val audio = info.audioStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .maxByOrNull { it.averageBitrate }
                val related = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .map {
                        VideoItem(
                            title = it.name ?: "",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: "",
                            thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                    }

                withContext(Dispatchers.Main) {
                    titleText.text = info.name
                    channelTitle.text = info.uploaderName ?: "Channel"
                    val views = formatCount(info.viewCount)
                    metaText.text = if (views.isNotEmpty()) "$views views" else "Ready"
                    val subs = formatCount(info.uploaderSubscriberCount)
                    channelSubs.text = if (subs.isNotEmpty()) "$subs subscribers" else ""
                    val avatarUrl = info.uploaderAvatars.firstOrNull()?.url
                    if (!avatarUrl.isNullOrEmpty()) {
                        channelAvatar.load(avatarUrl) { transformations(CircleCropTransformation()) }
                    }
                    relatedAdapter.submitList(related)
                    adaptiveVideos = vOnly
                    muxedVideos = vMuxed
                    bestAudio = audio

                    when {
                        vOnly.isNotEmpty() && audio != null -> {
                            val chosen = vOnly.firstOrNull { it.height <= targetHeight } ?: vOnly.first()
                            playAdaptive(chosen, audio)
                        }
                        vMuxed.isNotEmpty() -> {
                            val chosen = vMuxed.firstOrNull { it.height <= targetHeight } ?: vMuxed.first()
                            playSingleUrl(chosen.content, chosen.resolution)
                        }
                        !info.hlsUrl.isNullOrEmpty() -> playHls(info.hlsUrl)
                        !info.dashMpdUrl.isNullOrEmpty() -> playDash(info.dashMpdUrl)
                        else -> metaText.text = "No playable streams found."
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    metaText.text = "Error: ${e.localizedMessage}"
                }
            }
        }
    }

    private fun formatCount(count: Long): String {
        if (count <= 0) return ""
        return when {
            count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
            count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
            else -> count.toString()
        }
    }

    @OptIn(UnstableApi::class)
    private fun makeDataSourceFactory(): DefaultHttpDataSource.Factory {
        return DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0")
    }

    @OptIn(UnstableApi::class)
    private fun playAdaptive(video: VideoStream, audio: AudioStream) {
        val factory = makeDataSourceFactory()
        val vSource = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(video.content))
        val aSource = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(audio.content))
        player?.apply {
            setMediaSource(MergingMediaSource(vSource, aSource))
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = video.resolution
        qualityLabel.text = video.resolution
    }

    @OptIn(UnstableApi::class)
    private fun playSingleUrl(streamUrl: String, label: String) {
        val source = ProgressiveMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(streamUrl))
        player?.apply {
            setMediaSource(source)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = label
        qualityLabel.text = label
    }

    @OptIn(UnstableApi::class)
    private fun playHls(hlsUrl: String) {
        val source = HlsMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(hlsUrl))
        player?.apply {
            setMediaSource(source)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = "LIVE"
        qualityLabel.text = "LIVE"
    }

    @OptIn(UnstableApi::class)
    private fun playDash(dashUrl: String) {
        val source = DashMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(dashUrl))
        player?.apply {
            setMediaSource(source)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = "DASH"
        qualityLabel.text = "DASH"
    }

    private fun showQualityDialog() {
        if (adaptiveVideos.isNotEmpty() && bestAudio != null) {
            val labels = adaptiveVideos.map { "${it.resolution} (${it.format?.name ?: "DASH"})" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Select Quality")
                .setItems(labels) { _, which ->
                    playAdaptive(adaptiveVideos[which], bestAudio!!)
                }
                .show()
        } else if (muxedVideos.isNotEmpty()) {
            val labels = muxedVideos.map { "${it.resolution} (MP4)" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Select Quality")
                .setItems(labels) { _, which ->
                    val v = muxedVideos[which]
                    playSingleUrl(v.content, v.resolution)
                }
                .show()
        }
    }

    override fun onPause() {
        super.onPause()
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val autoBg = prefs.getBoolean("auto_bg", true)
        if (!autoBg && !isInPictureInPictureMode) {
            player?.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}
