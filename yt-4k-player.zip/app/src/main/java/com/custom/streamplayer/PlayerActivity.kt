package com.custom.streamplayer

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleText: TextView
    private lateinit var statusText: TextView
    private lateinit var qualityBtn: Button
    private lateinit var relatedAdapter: VideoAdapter

    private var videoStreams: List<VideoStream> = emptyList()
    private var bestAudio: AudioStream? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        titleText = findViewById(R.id.playerTitle)
        statusText = findViewById(R.id.playerStatus)
        qualityBtn = findViewById(R.id.qualityBtn)

        val relatedRecycler = findViewById<RecyclerView>(R.id.relatedRecycler)
        relatedAdapter = VideoAdapter { video ->
            val intent = Intent(this, PlayerActivity::class.java).apply {
                putExtra("video_url", video.url)
                putExtra("video_title", video.title)
                putExtra("channel_name", video.channel)
            }
            startActivity(intent)
            finish()
        }
        relatedRecycler.layoutManager = LinearLayoutManager(this)
        relatedRecycler.adapter = relatedAdapter

        player = ExoPlayer.Builder(this).build().also {
            playerView.player = it
        }

        val url = intent.getStringExtra("video_url") ?: ""
        val title = intent.getStringExtra("video_title") ?: ""
        titleText.text = title

        qualityBtn.setOnClickListener { showQualityDialog() }

        if (url.isNotEmpty()) {
            loadStreams(url)
        }
    }

    private fun loadStreams(url: String) {
        statusText.text = "Fetching 1080p / 2K / 4K streams..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val info = StreamInfo.getInfo(ServiceList.YouTube, url)
                val adaptiveVideos = info.videoOnlyStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .sortedByDescending { it.height }
                val audio = info.audioStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .maxByOrNull { it.averageBitrate }
                val related = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .map {
                        VideoItem(
                            title = it.name ?: "",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: "",
                            thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                    }

                withContext(Dispatchers.Main) {
                    titleText.text = info.name
                    relatedAdapter.submitList(related)

                    if (adaptiveVideos.isEmpty() || audio == null) {
                        statusText.text = "No adaptive streams available."
                        return@withContext
                    }
                    videoStreams = adaptiveVideos
                    bestAudio = audio
                    qualityBtn.isEnabled = true

                    val highest = adaptiveVideos.first()
                    statusText.text = "${info.uploaderName} • Max: ${highest.resolution}"
                    playAdaptive(highest, audio)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    statusText.text = "Error: ${e.localizedMessage}"
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun playAdaptive(video: VideoStream, audio: AudioStream) {
        val factory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")

        val vSource = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(video.content))
        val aSource = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(audio.content))
        val merged = MergingMediaSource(vSource, aSource)

        player?.apply {
            setMediaSource(merged)
            prepare()
            playWhenReady = true
        }
        qualityBtn.text = video.resolution
    }

    private fun showQualityDialog() {
        val labels = videoStreams.map { "${it.resolution} (${it.format?.name ?: "DASH"})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select Quality")
            .setItems(labels) { _, which ->
                val v = videoStreams[which]
                val a = bestAudio ?: return@setItems
                playAdaptive(v, a)
            }
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}
