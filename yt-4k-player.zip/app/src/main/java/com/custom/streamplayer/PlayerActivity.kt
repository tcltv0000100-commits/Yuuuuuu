package com.custom.streamplayer

import android.app.DownloadManager
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.NestedScrollView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.comments.CommentsInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.VideoStream
import java.util.Locale
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerContainer: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var gestureIndicator: GestureIndicatorView
    private lateinit var topOverlayRow: LinearLayout
    private lateinit var detailsSection: NestedScrollView
    private lateinit var overlayMore: TextView
    private lateinit var titleText: TextView
    private lateinit var metaText: TextView
    private lateinit var overlayQuality: TextView
    private lateinit var overlaySpeed: TextView
    private lateinit var overlayAudio: TextView
    private lateinit var overlayHdr: TextView
    private lateinit var overlayResize: TextView
    private lateinit var overlayFullscreen: TextView
    private lateinit var qualityLabel: TextView
    private lateinit var channelTitle: TextView
    private lateinit var channelSubs: TextView
    private lateinit var channelAvatar: ImageView
    private lateinit var subscribeBtn: TextView
    private lateinit var commentsHeader: TextView
    private lateinit var commentsPreview: TextView
    private lateinit var relatedAdapter: VideoAdapter

    private var adaptiveVideos: List<ResolvedVideoStream> = emptyList()
    private var muxedVideos: List<ResolvedVideoStream> = emptyList()
    private var audioStreamsList: List<ResolvedAudioStream> = emptyList()
    private var currentVideoStream: ResolvedVideoStream? = null
    private var bestAudio: ResolvedAudioStream? = null
    private var currentHlsUrl: String? = null
    private var currentDashUrl: String? = null
    private var currentStreamUserAgent: String = DEFAULT_FIREFOX_UA
    private var usedInnertubeFallback = false
    private val triedInnertubeClients = mutableSetOf<String>()
    private var triedMuxedFallback = false
    private var triedHlsFallback = false

    private var loadedComments: List<CommentsInfoItem> = emptyList()
    private var loadedRelated: List<VideoItem> = emptyList()
    private val videoBackStack = mutableListOf<VideoItem>()
    private var currentVideoUrl: String = ""
    private var currentChannelUrl: String = ""
    private var currentVideoTitle: String = "video"
    private var isFullscreen = false
    private var isSubscribed = false
    private var isHdrBoostOn = true
    private var streamJob: Job? = null
    private val loginLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK && currentVideoUrl.isNotEmpty()) {
            loadStreams(currentVideoUrl)
        }
    }
    private var commentsJob: Job? = null

    private var pinchScale = 1.0f
    private var resizeModeIndex = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("Fit", "Zoom", "Fill")

    private val hideHandler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { gestureIndicator.hide() }

    private enum class DragMode { NONE, HORIZONTAL_SEEK, LEFT_BRIGHTNESS, RIGHT_VOLUME }
    private var dragMode = DragMode.NONE
    private var downX = 0f
    private var downY = 0f
    private var startBrightness = 0.5f
    private var startVolumeFloat = 0.5f
    private var startSeekPos = 0L
    private var pendingSeekPos = -1L

    private val hdrItags = setOf(
        330, 331, 332, 333, 334, 335, 336, 337,
        694, 695, 696, 697, 698, 699, 700, 701, 702
    )

    companion object {
        private const val DEFAULT_FIREFOX_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"
    }

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        YouTubeCipherDecryptor.init(this)
        YouTubeAuthStore.init(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.colorMode = ActivityInfo.COLOR_MODE_HDR
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        setContentView(R.layout.activity_player)

        playerContainer = findViewById(R.id.playerContainer)
        playerView = findViewById(R.id.playerView)
        gestureIndicator = findViewById(R.id.gestureIndicator)
        topOverlayRow = findViewById(R.id.topOverlayRow)
        detailsSection = findViewById(R.id.detailsSection)
        overlayMore = findViewById(R.id.overlayMore)
        titleText = findViewById(R.id.playerTitle)
        metaText = findViewById(R.id.playerMeta)
        overlayQuality = findViewById(R.id.overlayQuality)
        overlaySpeed = findViewById(R.id.overlaySpeed)
        overlayAudio = findViewById(R.id.overlayAudio)
        overlayHdr = findViewById(R.id.overlayHdr)
        overlayResize = findViewById(R.id.overlayResize)
        overlayFullscreen = findViewById(R.id.overlayFullscreen)
        qualityLabel = findViewById(R.id.qualityLabel)
        channelTitle = findViewById(R.id.channelTitle)
        channelSubs = findViewById(R.id.channelSubs)
        channelAvatar = findViewById(R.id.channelAvatar)
        subscribeBtn = findViewById(R.id.subscribeBtn)
        commentsHeader = findViewById(R.id.commentsHeader)
        commentsPreview = findViewById(R.id.commentsPreview)

        val relatedRecycler = findViewById<RecyclerView>(R.id.relatedRecycler)
        relatedAdapter = VideoAdapter { video ->
            switchToVideo(video, pushToBackStack = true)
        }
        relatedRecycler.layoutManager = LinearLayoutManager(this)
        relatedRecycler.adapter = relatedAdapter

        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(DefaultAllocator(true, 65536))
            .setBufferDurationsMs(25_000, 60_000, 2_500, 5_000)
            .setTargetBufferBytes(64 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val renderersFactory = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)

        player = ExoPlayer.Builder(this, renderersFactory)
            .setLoadControl(loadControl)
            .build()
            .also {
                if (prefs.getBoolean("fast_seek", true)) {
                    it.setSeekParameters(SeekParameters.CLOSEST_SYNC)
                }
                playerView.player = it
            }

        player?.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && loadedRelated.isNotEmpty()) {
                    clearSavedPosition(currentVideoUrl)
                    playNextVideo()
                }
            }

            override fun onEvents(player: Player, events: Player.Events) {
                bindPrevNextButtons()
            }

            override fun onPlayerError(error: PlaybackException) {
                handlePlaybackFallback(error)
            }
        })

        playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        playerView.controllerHideOnTouch = false
        playerView.controllerShowTimeoutMs = 3500
        playerView.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.visibility = View.GONE
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
            topOverlayRow.visibility = visibility
            overlayFullscreen.visibility = visibility
            overlayMore.visibility = if (isFullscreen && visibility == View.VISIBLE) View.VISIBLE else View.GONE
            if (visibility == View.VISIBLE) bindPrevNextButtons()
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isFullscreen) {
                    toggleFullscreen()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        setupPlayerGestures()
        applyHdrBoost()

        val rawUrl = intent.getStringExtra("video_url") ?: ""
        currentVideoUrl = normalizeYouTubeUrl(rawUrl)
        currentVideoTitle = intent.getStringExtra("video_title") ?: "YouTube Video"
        titleText.text = currentVideoTitle
        channelTitle.text = intent.getStringExtra("channel_name") ?: "Channel"

        HistoryStore.add(
            this,
            VideoItem(
                title = currentVideoTitle,
                url = currentVideoUrl,
                channel = intent.getStringExtra("channel_name") ?: "",
                thumbnailUrl = intent.getStringExtra("thumb_url") ?: "",
                avatarUrl = intent.getStringExtra("avatar_url") ?: "",
                durationSec = intent.getLongExtra("duration_sec", 0L)
            )
        )

        overlayQuality.setOnClickListener { showQualityDialog() }
        findViewById<LinearLayout>(R.id.btnQuality).setOnClickListener { showQualityDialog() }
        overlaySpeed.setOnClickListener { showSpeedDialog() }
        overlayAudio.setOnClickListener { showAudioDialog() }
        overlayHdr.setOnClickListener { toggleHdrBoost() }
        overlayResize.setOnClickListener { cycleResizeMode() }
        overlayFullscreen.setOnClickListener { toggleFullscreen() }
        overlayMore.setOnClickListener { showMoreVideosDialog() }
        bindPrevNextButtons()
        findViewById<LinearLayout>(R.id.btnDownload).setOnClickListener { showDownloadDialog() }
        findViewById<LinearLayout>(R.id.commentsSection).setOnClickListener { showCommentsDialog() }

        findViewById<LinearLayout>(R.id.btnShare).setOnClickListener {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, currentVideoUrl)
            }
            startActivity(Intent.createChooser(sendIntent, "Share video"))
        }

        findViewById<LinearLayout>(R.id.btnPopup).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } else {
                Toast.makeText(this, "Pop-up requires Android 8+", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<LinearLayout>(R.id.btnBackground).setOnClickListener {
            Toast.makeText(this, "Background audio enabled", Toast.LENGTH_SHORT).show()
            moveTaskToBack(true)
        }

        val openChannel = View.OnClickListener {
            val i = Intent(this, ChannelActivity::class.java).apply {
                putExtra("channel_name", channelTitle.text.toString())
                putExtra("channel_url", currentChannelUrl)
            }
            startActivity(i)
        }
        channelAvatar.setOnClickListener(openChannel)
        channelTitle.setOnClickListener(openChannel)

        subscribeBtn.setOnClickListener {
            isSubscribed = !isSubscribed
            subscribeBtn.text = if (isSubscribed) "SUBSCRIBED" else "SUBSCRIBE"
            subscribeBtn.setTextColor(if (isSubscribed) 0xFF888888.toInt() else 0xFFFF0000.toInt())
        }

        if (currentVideoUrl.isNotEmpty()) {
            loadStreams(currentVideoUrl)
            hideHandler.postDelayed({ loadComments(currentVideoUrl) }, 800)
        }
    }

    @OptIn(UnstableApi::class)
    private fun bindPrevNextButtons() {
        playerView.findViewById<View>(androidx.media3.ui.R.id.exo_next)?.apply {
            isEnabled = true
            isClickable = true
            alpha = 1.0f
            setOnClickListener { playNextVideo() }
        }
        playerView.findViewById<View>(androidx.media3.ui.R.id.exo_prev)?.apply {
            isEnabled = true
            isClickable = true
            alpha = 1.0f
            setOnClickListener { playPreviousVideo() }
        }
    }

    @OptIn(UnstableApi::class)
    private fun handlePlaybackFallback(error: PlaybackException) {
        if (!triedHlsFallback) {
            triedHlsFallback = true
            val hls = currentHlsUrl
            if (!hls.isNullOrEmpty()) {
                playHls(hls)
                return
            }
        }
        if (triedInnertubeClients.size < InnertubeStreamResolver.totalProfiles) {
            metaText.text = "Switching to HD alternate stream..."
            loadViaInnertubeOnly(currentVideoUrl)
            return
        }
        if (!triedMuxedFallback) {
            triedMuxedFallback = true
            val fallback = muxedVideos.firstOrNull()
            if (fallback != null) {
                Toast.makeText(this, "Switching to 360p fallback stream...", Toast.LENGTH_SHORT).show()
                playSingleUrl(fallback.url, streamLabel(fallback), preservePosition = true)
                return
            }
        }
        metaText.text = "Playback error: ${error.errorCodeName}"
    }

    private fun switchToVideo(video: VideoItem, pushToBackStack: Boolean) {
        saveCurrentPosition()
        if (pushToBackStack && currentVideoUrl.isNotEmpty()) {
            videoBackStack.add(
                VideoItem(
                    title = currentVideoTitle,
                    url = currentVideoUrl,
                    channel = channelTitle.text.toString(),
                    thumbnailUrl = "",
                    avatarUrl = "",
                    durationSec = 0L
                )
            )
        }
        player?.stop()
        player?.clearMediaItems()
        currentVideoUrl = normalizeYouTubeUrl(video.url)
        currentVideoTitle = video.title
        titleText.text = video.title
        channelTitle.text = video.channel
        commentsPreview.text = "Loading comments..."
        HistoryStore.add(this, video.copy(url = currentVideoUrl))
        loadStreams(currentVideoUrl)
        hideHandler.postDelayed({ loadComments(currentVideoUrl) }, 800)
    }

    private fun playNextVideo() {
        val next = loadedRelated.firstOrNull()
        if (next == null) {
            Toast.makeText(this, "No next video available", Toast.LENGTH_SHORT).show()
            return
        }
        switchToVideo(next, pushToBackStack = true)
    }

    private fun playPreviousVideo() {
        val prev = videoBackStack.removeLastOrNull()
        if (prev == null) {
            player?.seekTo(0L)
            return
        }
        switchToVideo(prev, pushToBackStack = false)
    }

    private fun showMoreVideosDialog() {
        if (loadedRelated.isEmpty()) {
            Toast.makeText(this, "No related videos loaded", Toast.LENGTH_SHORT).show()
            return
        }
        val dialog = BottomSheetDialog(this)
        val sheetView = layoutInflater.inflate(R.layout.dialog_comments_sheet, null)
        sheetView.findViewById<TextView>(R.id.sheetTitle).text = "More Videos"
        sheetView.findViewById<TextView>(R.id.sheetClose).setOnClickListener { dialog.dismiss() }
        val rv = sheetView.findViewById<RecyclerView>(R.id.commentsRecycler)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = VideoAdapter { video ->
            dialog.dismiss()
            switchToVideo(video, pushToBackStack = true)
        }.also { it.submitList(loadedRelated) }
        dialog.setContentView(sheetView)
        dialog.show()
    }

    private fun audioLangName(a: ResolvedAudioStream): String {
        val localeName = if (a.langCode.isNotBlank() && a.langCode != "und") {
            Locale(a.langCode).getDisplayLanguage(Locale.ENGLISH).takeIf { it.isNotBlank() && it != "und" }
        } else null
        val trackName = a.trackName.takeIf { it.isNotBlank() && !it.equals("Default", true) }
        return trackName ?: localeName ?: "Original Audio"
    }

    private fun audioLabel(a: ResolvedAudioStream): String {
        val lang = audioLangName(a)
        val type = when {
            a.isOriginal -> " • Original"
            a.isDubbed -> " • Dubbed"
            a.isDescriptive -> " • Descriptive"
            else -> ""
        }
        return "$lang$type (${a.bitrateKbps}k)"
    }

    private fun showAudioDialog() {
        if (audioStreamsList.isEmpty()) {
            Toast.makeText(this, "Only single audio track available", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = audioStreamsList.map { audioLabel(it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select Audio Language / Track")
            .setItems(labels) { _, i ->
                val chosenAudio = audioStreamsList[i]
                bestAudio = chosenAudio
                val v = currentVideoStream
                if (v != null) {
                    playAdaptive(v, chosenAudio, preservePosition = true)
                }
            }
            .show()
    }

    @OptIn(UnstableApi::class)
    private fun toggleHdrBoost() {
        isHdrBoostOn = !isHdrBoostOn
        applyHdrBoost()
        Toast.makeText(this, if (isHdrBoostOn) "Dynamic HDR ON" else "Dynamic HDR OFF", Toast.LENGTH_SHORT).show()
    }

    @OptIn(UnstableApi::class)
    private fun applyHdrBoost() {
        overlayHdr.text = if (isHdrBoostOn) "HDR ON" else "HDR"
        overlayHdr.setTextColor(if (isHdrBoostOn) 0xFFFFD54F.toInt() else 0xFFFFFFFF.toInt())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.colorMode = if (isHdrBoostOn) ActivityInfo.COLOR_MODE_HDR else ActivityInfo.COLOR_MODE_DEFAULT
        }
        val surface = playerView.videoSurfaceView ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (isHdrBoostOn) {
                val sat = ColorMatrix().apply { setSaturation(1.32f) }
                val c = 1.12f
                val t = (-0.5f * c + 0.5f) * 255f
                val contrast = ColorMatrix(
                    floatArrayOf(
                        c, 0f, 0f, 0f, t,
                        0f, c, 0f, 0f, t,
                        0f, 0f, c, 0f, t,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
                sat.postConcat(contrast)
                surface.setRenderEffect(RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(sat)))
            } else {
                surface.setRenderEffect(null)
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun cycleResizeMode() {
        resizeModeIndex = (resizeModeIndex + 1) % resizeModes.size
        pinchScale = 1.0f
        playerView.videoSurfaceView?.apply {
            scaleX = 1.0f
            scaleY = 1.0f
        }
        playerView.resizeMode = resizeModes[resizeModeIndex]
        val name = resizeNames[resizeModeIndex]
        overlayResize.text = name
        gestureIndicator.showSeek(name)
        scheduleHideIndicator()
    }

    private fun normalizeYouTubeUrl(raw: String): String {
        if (raw.contains("/shorts/")) {
            val id = raw.substringAfter("/shorts/").substringBefore("?").substringBefore("/")
            if (id.isNotEmpty()) return "https://www.youtube.com/watch?v=$id"
        }
        return raw
    }

    private fun isHdrStream(v: ResolvedVideoStream): Boolean {
        val c = v.codec
        return v.itag in hdrItags ||
            c.contains("vp9.2", ignoreCase = true) ||
            c.contains("av01.0.10", ignoreCase = true) ||
            c.contains("hdr", ignoreCase = true) ||
            v.resolution.contains("HDR", ignoreCase = true)
    }

    private fun isAv1(v: ResolvedVideoStream): Boolean {
        return v.codec.contains("av01", ignoreCase = true)
    }

    private fun codecShort(v: ResolvedVideoStream): String {
        val c = v.codec.lowercase()
        return when {
            c.contains("vp9") -> "VP9"
            c.contains("av01") -> "AV1"
            c.contains("avc") -> "H.264"
            else -> v.formatName.ifBlank { "DASH" }
        }
    }

    private fun streamLabel(v: ResolvedVideoStream): String {
        val hdr = if (isHdrStream(v) && !v.resolution.contains("HDR", true)) " HDR" else ""
        return "${v.resolution}$hdr"
    }

    @OptIn(UnstableApi::class)
    private fun setupPlayerGestures() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)

        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                pinchScale = (pinchScale * detector.scaleFactor).coerceIn(0.50f, 2.50f)
                playerView.videoSurfaceView?.apply {
                    scaleX = pinchScale
                    scaleY = pinchScale
                }
                val pct = (pinchScale * 100).toInt()
                gestureIndicator.showZoomPercent(pct)
                scheduleHideIndicator()
                return true
            }
        })

        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) {
                    playerView.hideController()
                } else {
                    playerView.showController()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return false
                val seekSec = prefs.getInt("seek_sec", 15)
                val seekMs = seekSec * 1000L
                val isRight = e.x > playerContainer.width / 2f
                val target = if (isRight) {
                    (p.currentPosition + seekMs).coerceAtMost(p.duration.coerceAtLeast(0L))
                } else {
                    (p.currentPosition - seekMs).coerceAtLeast(0L)
                }
                p.seekTo(target)
                gestureIndicator.showSeek(if (isRight) "+${seekSec}s" else "-${seekSec}s")
                scheduleHideIndicator()
                return true
            }
        })

        playerView.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event)
            if (event.pointerCount > 1 || scaleDetector.isInProgress) {
                dragMode = DragMode.NONE
                return@setOnTouchListener true
            }

            val handledTap = tapDetector.onTouchEvent(event)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragMode = DragMode.NONE
                    downX = event.x
                    downY = event.y
                    pendingSeekPos = -1L
                    val lp = window.attributes
                    startBrightness = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                    startVolumeFloat = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume.toFloat()
                    startSeekPos = player?.currentPosition ?: 0L
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    val threshold = 18f

                    if (dragMode == DragMode.NONE && (abs(dx) > threshold || abs(dy) > threshold)) {
                        dragMode = if (abs(dx) > abs(dy)) {
                            DragMode.HORIZONTAL_SEEK
                        } else if (downX < playerContainer.width / 2f) {
                            DragMode.LEFT_BRIGHTNESS
                        } else {
                            DragMode.RIGHT_VOLUME
                        }
                    }

                    when (dragMode) {
                        DragMode.HORIZONTAL_SEEK -> {
                            val dur = player?.duration?.coerceAtLeast(0L) ?: 0L
                            if (dur > 0) {
                                val deltaMs = ((dx / playerContainer.width.coerceAtLeast(1)) * 90_000L).toLong()
                                pendingSeekPos = (startSeekPos + deltaMs).coerceIn(0L, dur)
                                val secDiff = deltaMs / 1000L
                                val sign = if (secDiff >= 0) "+" else ""
                                gestureIndicator.showSeek("${formatTime(pendingSeekPos)} ($sign${secDiff}s)")
                            }
                            true
                        }
                        DragMode.LEFT_BRIGHTNESS -> {
                            val delta = (-dy / playerContainer.height.coerceAtLeast(1)) * 1.4f
                            val newB = (startBrightness + delta).coerceIn(0.02f, 1.0f)
                            val lp = window.attributes
                            lp.screenBrightness = newB
                            window.attributes = lp
                            gestureIndicator.showBrightness(newB)
                            true
                        }
                        DragMode.RIGHT_VOLUME -> {
                            val delta = (-dy / playerContainer.height.coerceAtLeast(1)) * 1.4f
                            val smoothVol = (startVolumeFloat + delta).coerceIn(0.0f, 1.0f)
                            val targetStep = (smoothVol * maxVolume).toInt().coerceIn(0, maxVolume)
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetStep, 0)
                            gestureIndicator.showVolume(smoothVol)
                            true
                        }
                        DragMode.NONE -> handledTap
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragMode == DragMode.HORIZONTAL_SEEK && pendingSeekPos >= 0L) {
                        player?.seekTo(pendingSeekPos)
                    }
                    if (dragMode != DragMode.NONE) {
                        scheduleHideIndicator()
                        dragMode = DragMode.NONE
                    }
                    true
                }

                else -> handledTap
            }
        }
    }

    private fun scheduleHideIndicator() {
        hideHandler.removeCallbacks(hideRunnable)
        hideHandler.postDelayed(hideRunnable, 750)
    }

    private fun formatTime(ms: Long): String {
        val totalSec = (ms / 1000).coerceAtLeast(0)
        val m = totalSec / 60
        val s = totalSec % 60
        return String.format("%02d:%02d", m, s)
    }

    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (isFullscreen) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            detailsSection.visibility = View.GONE
            playerContainer.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            window.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
            controller.show(WindowInsetsCompat.Type.systemBars())
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            overlayMore.visibility = View.GONE
            detailsSection.visibility = View.VISIBLE
            val heightPx = (230 * resources.displayMetrics.density).toInt()
            playerContainer.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                heightPx
            )
        }
    }

    private fun showSpeedDialog() {
        val speeds = arrayOf("0.5x", "0.75x", "1x", "1.25x", "1.5x", "2x")
        val vals = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        AlertDialog.Builder(this)
            .setTitle("Playback Speed")
            .setItems(speeds) { _, i ->
                player?.setPlaybackSpeed(vals[i])
                overlaySpeed.text = speeds[i]
            }
            .show()
    }

    private fun loadComments(url: String) {
        commentsJob?.cancel()
        commentsJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val cInfo = CommentsInfo.getInfo(ServiceList.YouTube, url)
                val items = cInfo.relatedItems.filterIsInstance<CommentsInfoItem>()
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    loadedComments = items
                    commentsHeader.text = "Comments (${items.size})"
                    val first = items.firstOrNull()
                    commentsPreview.text = if (first != null) {
                        "${first.uploaderName}: ${HtmlCompat.fromHtml(first.commentText?.content ?: "", HtmlCompat.FROM_HTML_MODE_LEGACY).toString().trim()}"
                    } else {
                        "No comments found"
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    commentsPreview.text = "Comments unavailable"
                }
            }
        }
    }

    private fun showCommentsDialog() {
        if (loadedComments.isEmpty()) {
            Toast.makeText(this, "No comments loaded yet", Toast.LENGTH_SHORT).show()
            return
        }
        val dialog = BottomSheetDialog(this)
        val sheetView = layoutInflater.inflate(R.layout.dialog_comments_sheet, null)
        sheetView.findViewById<TextView>(R.id.sheetTitle).text = "Comments (${loadedComments.size})"
        sheetView.findViewById<TextView>(R.id.sheetClose).setOnClickListener { dialog.dismiss() }
        val rv = sheetView.findViewById<RecyclerView>(R.id.commentsRecycler)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = CommentAdapter(loadedComments)
        dialog.setContentView(sheetView)
        dialog.show()
    }

    private fun showDownloadDialog() {
        val options = mutableListOf<String>()
        val urls = mutableListOf<String>()
        val exts = mutableListOf<String>()

        for (v in muxedVideos) {
            options.add("Video + Audio • ${streamLabel(v)} (MP4)")
            urls.add(v.url)
            exts.add("mp4")
        }
        for (v in adaptiveVideos) {
            val ext = if (v.formatName.contains("WebM", true)) "webm" else "mp4"
            options.add("Video Only • ${streamLabel(v)} (${codecShort(v)})")
            urls.add(v.url)
            exts.add(ext)
        }
        for (a in audioStreamsList) {
            val ext = if (a.formatName.contains("WebM", true)) "webm" else "m4a"
            options.add("Audio Only • ${a.bitrateKbps} kbps (${a.formatName.ifBlank { "Audio" }})")
            urls.add(a.url)
            exts.add(ext)
        }

        if (options.isEmpty()) {
            Toast.makeText(this, "No downloadable streams available", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("Download Video / Audio")
            .setItems(options.toTypedArray()) { _, i ->
                chooseDownloadMethod(urls[i], exts[i])
            }
            .show()
    }

    private fun chooseDownloadMethod(streamUrl: String, ext: String) {
        val methods = arrayOf("Download inside Phone (Downloads folder)", "Open in External Downloader / Browser")
        AlertDialog.Builder(this)
            .setTitle("Choose Download Method")
            .setItems(methods) { _, which ->
                if (which == 0) {
                    val safeName = currentVideoTitle.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(40)
                    val req = DownloadManager.Request(Uri.parse(streamUrl))
                        .addRequestHeader("User-Agent", currentStreamUserAgent)
                        .setTitle(currentVideoTitle)
                        .setDescription("Downloading $ext...")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "$safeName.$ext")
                    val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    dm.enqueue(req)
                    Toast.makeText(this, "Download started in Downloads/", Toast.LENGTH_SHORT).show()
                } else {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(streamUrl)))
                }
            }
            .show()
    }

    private fun VideoStream.toResolved(): ResolvedVideoStream {
        return ResolvedVideoStream(
            url = content,
            height = height,
            fps = fps,
            itag = itag,
            codec = codec ?: "",
            formatName = format?.name ?: "DASH",
            resolution = resolution,
            bitrate = bitrate
        )
    }

    private fun AudioStream.toResolved(): ResolvedAudioStream {
        val lang = audioLocale?.language ?: "und"
        return ResolvedAudioStream(
            url = content,
            bitrateKbps = averageBitrate,
            codec = codec ?: "",
            formatName = format?.name ?: "Audio",
            langCode = lang,
            trackName = audioTrackName ?: "",
            isOriginal = audioTrackType == AudioTrackType.ORIGINAL,
            isDubbed = audioTrackType == AudioTrackType.DUBBED,
            isDescriptive = audioTrackType == AudioTrackType.DESCRIPTIVE
        )
    }

    @OptIn(UnstableApi::class)
    private fun loadStreams(url: String) {
        triedMuxedFallback = false
        triedHlsFallback = false
        triedInnertubeClients.clear()
        usedInnertubeFallback = false
        metaText.text = "Fetching streams..."
        streamJob?.cancel()
        streamJob = CoroutineScope(Dispatchers.IO).launch {
            var newPipeError: Exception? = null
            var info: StreamInfo? = null
            try {
                info = StreamInfo.getInfo(ServiceList.YouTube, url)
                val hasPlayable = info.videoOnlyStreams.any { !it.content.isNullOrEmpty() } ||
                    info.videoStreams.any { !it.content.isNullOrEmpty() } ||
                    !info.hlsUrl.isNullOrEmpty() ||
                    !info.dashMpdUrl.isNullOrEmpty()
                if (!hasPlayable) info = null
            } catch (e: Exception) {
                newPipeError = e
                info = null
            }

            if (info != null) {
                val vOnly = info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }.map { it.toResolved() }
                val vMuxed = info.videoStreams.filter { !it.content.isNullOrEmpty() }.map { it.toResolved() }
                val audios = info.audioStreams.filter { !it.content.isNullOrEmpty() }.map { it.toResolved() }
                val related = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .map {
                        VideoItem(
                            title = it.name ?: "",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: "",
                            thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                    }
                applyResolvedStreams(
                    title = info.name ?: currentVideoTitle,
                    uploaderName = info.uploaderName ?: "Channel",
                    uploaderUrl = info.uploaderUrl ?: "",
                    viewCount = info.viewCount,
                    subCount = info.uploaderSubscriberCount,
                    avatarUrl = info.uploaderAvatars.firstOrNull()?.url,
                    vOnlyRaw = vOnly,
                    vMuxedRaw = vMuxed,
                    audiosRaw = audios,
                    hlsUrl = info.hlsUrl,
                    dashUrl = info.dashMpdUrl,
                    userAgent = DEFAULT_FIREFOX_UA,
                    related = related,
                    isInnertube = false
                )
                return@launch
            }

            // Fallback to direct Innertube clients (ANDROID_VR / IOS / TVHTML5)
            val resolved = InnertubeStreamResolver.resolve(url, triedInnertubeClients)
            if (resolved != null) {
                triedInnertubeClients.add(resolved.clientName)
                val related = try {
                    val q = resolved.title.ifBlank { currentVideoTitle }
                    val qh = ServiceList.YouTube.searchQHFactory.fromQuery(q)
                    SearchInfo.getInfo(ServiceList.YouTube, qh).relatedItems
                        .filterIsInstance<StreamInfoItem>()
                        .filter { normalizeYouTubeUrl(it.url ?: "") != url }
                        .take(15)
                        .map {
                            VideoItem(
                                title = it.name ?: "",
                                url = it.url ?: "",
                                channel = it.uploaderName ?: "",
                                thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                                avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                                durationSec = it.duration
                            )
                        }
                } catch (_: Exception) {
                    emptyList()
                }
                val chUrl = if (resolved.channelId.isNotBlank()) {
                    "https://www.youtube.com/channel/${resolved.channelId}"
                } else ""
                applyResolvedStreams(
                    title = resolved.title.ifBlank { currentVideoTitle },
                    uploaderName = resolved.author.ifBlank { "Channel" },
                    uploaderUrl = chUrl,
                    viewCount = resolved.viewCount,
                    subCount = -1L,
                    avatarUrl = null,
                    vOnlyRaw = resolved.videoOnlyStreams,
                    vMuxedRaw = resolved.muxedStreams,
                    audiosRaw = resolved.audioStreams,
                    hlsUrl = resolved.hlsUrl,
                    dashUrl = resolved.dashUrl,
                    userAgent = resolved.userAgent,
                    related = related,
                    isInnertube = true
                )
            } else {
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    metaText.text = "Error: ${newPipeError?.localizedMessage ?: "Video unavailable"}"
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun loadViaInnertubeOnly(url: String) {
        streamJob?.cancel()
        streamJob = CoroutineScope(Dispatchers.IO).launch {
            val resolved = InnertubeStreamResolver.resolve(url, triedInnertubeClients)
            if (resolved != null) {
                triedInnertubeClients.add(resolved.clientName)
                triedMuxedFallback = false
                triedHlsFallback = false
                applyResolvedStreams(
                    title = resolved.title.ifBlank { currentVideoTitle },
                    uploaderName = resolved.author.ifBlank { channelTitle.text.toString() },
                    uploaderUrl = if (resolved.channelId.isNotBlank()) "https://www.youtube.com/channel/${resolved.channelId}" else currentChannelUrl,
                    viewCount = resolved.viewCount,
                    subCount = -1L,
                    avatarUrl = null,
                    vOnlyRaw = resolved.videoOnlyStreams,
                    vMuxedRaw = resolved.muxedStreams,
                    audiosRaw = resolved.audioStreams,
                    hlsUrl = resolved.hlsUrl,
                    dashUrl = resolved.dashUrl,
                    userAgent = resolved.userAgent,
                    related = loadedRelated,
                    isInnertube = true
                )
            } else {
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    val detail = InnertubeStreamResolver.lastErrorDetail
                    if (detail.contains("LOGIN_REQUIRED", ignoreCase = true) || detail.contains("Sign in", ignoreCase = true)) {
                        metaText.text = "Sign in required (Tap here to Sign in) • $detail"
                        metaText.setOnClickListener {
                            loginLauncher.launch(Intent(this@PlayerActivity, LoginActivity::class.java))
                        }
                    } else {
                        metaText.text = if (detail.isNotBlank()) "Error: $detail" else "Playback error: Unable to resolve stream"
                    }
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private suspend fun applyResolvedStreams(
        title: String,
        uploaderName: String,
        uploaderUrl: String,
        viewCount: Long,
        subCount: Long,
        avatarUrl: String?,
        vOnlyRaw: List<ResolvedVideoStream>,
        vMuxedRaw: List<ResolvedVideoStream>,
        audiosRaw: List<ResolvedAudioStream>,
        hlsUrl: String?,
        dashUrl: String?,
        userAgent: String,
        related: List<VideoItem>,
        isInnertube: Boolean
    ) {
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val preferredRes = prefs.getString("default_res", "Auto") ?: "Auto"
        val preferredFmt = prefs.getString("video_format", "WebM") ?: "WebM"
        val isAutoMode = preferredRes.equals("Auto", ignoreCase = true)
        val targetHeight = if (isAutoMode) {
            if (isOnWifi()) 1080 else 720
        } else {
            preferredRes.replace("p", "").toIntOrNull() ?: 1080
        }

        val vOnly = vOnlyRaw.sortedWith(
            compareByDescending<ResolvedVideoStream> { it.height }
                .thenBy { isAv1(it) }
                .thenByDescending { isHdrStream(it) }
                .thenByDescending { it.formatName.equals(preferredFmt, ignoreCase = true) }
        )
        val vMuxed = vMuxedRaw.sortedByDescending { it.height }
        val audios = audiosRaw.sortedWith(
            compareByDescending<ResolvedAudioStream> { it.isOriginal }
                .thenByDescending { it.bitrateKbps }
        )
        val audio = audios.firstOrNull()

        withContext(Dispatchers.Main) {
            if (isFinishing || isDestroyed) return@withContext
            usedInnertubeFallback = isInnertube
            currentStreamUserAgent = userAgent
            currentHlsUrl = hlsUrl
            currentDashUrl = dashUrl

            currentVideoTitle = title
            titleText.text = currentVideoTitle
            channelTitle.text = uploaderName
            if (uploaderUrl.isNotEmpty()) currentChannelUrl = uploaderUrl
            val views = formatCount(viewCount)
            metaText.text = if (views.isNotEmpty()) "$views views" else "Ready"
            val subs = formatCount(subCount)
            if (subs.isNotEmpty()) channelSubs.text = "$subs subscribers"
            if (!avatarUrl.isNullOrEmpty()) {
                channelAvatar.load(avatarUrl) { transformations(CircleCropTransformation()) }
            }
            if (related.isNotEmpty()) {
                loadedRelated = related
                relatedAdapter.submitList(related)
            }
            adaptiveVideos = vOnly
            muxedVideos = vMuxed
            audioStreamsList = audios.distinctBy { "${audioLangName(it)}_${it.isOriginal}_${it.isDubbed}" }
            bestAudio = audio

            val savedResumePos = getSavedPosition(currentVideoUrl)

            when {
                vOnly.isNotEmpty() && audio != null -> {
                    val underCap = vOnly.filter { it.height <= targetHeight }
                    val chosen = underCap.firstOrNull { !isAv1(it) && it.formatName.equals(preferredFmt, true) }
                        ?: underCap.firstOrNull { !isAv1(it) }
                        ?: underCap.firstOrNull()
                        ?: vOnly.first()
                    playAdaptive(chosen, audio, preservePosition = false, explicitStartPos = savedResumePos)
                }
                vMuxed.isNotEmpty() -> {
                    val chosen = vMuxed.firstOrNull { it.height <= targetHeight } ?: vMuxed.first()
                    playSingleUrl(chosen.url, streamLabel(chosen), preservePosition = false, explicitStartPos = savedResumePos)
                }
                !hlsUrl.isNullOrEmpty() -> playHls(hlsUrl)
                !dashUrl.isNullOrEmpty() -> playDash(dashUrl)
                else -> metaText.text = "No playable streams found."
            }
        }
    }

    private fun getSavedPosition(url: String): Long {
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("resume_play", true)) return 0L
        val id = InnertubeStreamResolver.extractVideoId(url) ?: return 0L
        return getSharedPreferences("yt_playback_pos", Context.MODE_PRIVATE).getLong(id, 0L)
    }

    private fun saveCurrentPosition() {
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("resume_play", true)) return
        val id = InnertubeStreamResolver.extractVideoId(currentVideoUrl) ?: return
        val pos = player?.currentPosition ?: 0L
        val dur = player?.duration ?: 0L
        if (pos > 5_000L && (dur <= 0L || pos < dur - 5_000L)) {
            getSharedPreferences("yt_playback_pos", Context.MODE_PRIVATE).edit().putLong(id, pos).apply()
        }
    }

    private fun clearSavedPosition(url: String) {
        val id = InnertubeStreamResolver.extractVideoId(url) ?: return
        getSharedPreferences("yt_playback_pos", Context.MODE_PRIVATE).edit().remove(id).apply()
    }

    private fun isOnWifi(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun formatCount(count: Long): String {
        if (count <= 0) return ""
        return when {
            count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
            count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
            else -> count.toString()
        }
    }

    @OptIn(UnstableApi::class)
    private fun makeDataSourceFactory(): DefaultHttpDataSource.Factory {
        return DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(currentStreamUserAgent)
            .setDefaultRequestProperties(
                mapOf(
                    "Origin" to "https://www.youtube.com",
                    "Referer" to "https://www.youtube.com/"
                )
            )
    }

    @OptIn(UnstableApi::class)
    private fun playAdaptive(
        video: ResolvedVideoStream,
        audio: ResolvedAudioStream,
        preservePosition: Boolean = true,
        explicitStartPos: Long = 0L
    ) {
        currentVideoStream = video
        overlayAudio.text = audioLangName(audio).take(10)
        val resumePos = if (preservePosition) {
            (player?.currentPosition ?: 0L).coerceAtLeast(0L)
        } else {
            explicitStartPos.coerceAtLeast(0L)
        }
        val factory = makeDataSourceFactory()
        val vSource = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(video.url))
        val aSource = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(audio.url))
        player?.apply {
            setMediaSource(MergingMediaSource(vSource, aSource))
            if (resumePos > 0L) seekTo(resumePos)
            prepare()
            playWhenReady = true
        }
        val label = streamLabel(video)
        overlayQuality.text = label
        qualityLabel.text = label
        applyHdrBoost()
    }

    @OptIn(UnstableApi::class)
    private fun playSingleUrl(
        streamUrl: String,
        label: String,
        preservePosition: Boolean = true,
        explicitStartPos: Long = 0L
    ) {
        val resumePos = if (preservePosition) {
            (player?.currentPosition ?: 0L).coerceAtLeast(0L)
        } else {
            explicitStartPos.coerceAtLeast(0L)
        }
        val source = ProgressiveMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(streamUrl))
        player?.apply {
            setMediaSource(source)
            if (resumePos > 0L) seekTo(resumePos)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = label
        qualityLabel.text = label
        applyHdrBoost()
    }

    @OptIn(UnstableApi::class)
    private fun playHls(hlsUrl: String) {
        val source = HlsMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(hlsUrl))
        player?.apply {
            setMediaSource(source)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = "LIVE"
        qualityLabel.text = "LIVE"
    }

    @OptIn(UnstableApi::class)
    private fun playDash(dashUrl: String) {
        val source = DashMediaSource.Factory(makeDataSourceFactory()).createMediaSource(MediaItem.fromUri(dashUrl))
        player?.apply {
            setMediaSource(source)
            prepare()
            playWhenReady = true
        }
        overlayQuality.text = "DASH"
        qualityLabel.text = "DASH"
    }

    private fun showQualityDialog() {
        if (adaptiveVideos.isNotEmpty() && bestAudio != null) {
            val labels = adaptiveVideos.map {
                "${streamLabel(it)} • ${codecShort(it)}"
            }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Select Quality")
                .setItems(labels) { _, which ->
                    triedMuxedFallback = false
                    triedHlsFallback = false
                    playAdaptive(adaptiveVideos[which], bestAudio!!, preservePosition = true)
                }
                .show()
        } else if (muxedVideos.isNotEmpty()) {
            val labels = muxedVideos.map { "${streamLabel(it)} • MP4" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Select Quality")
                .setItems(labels) { _, which ->
                    val v = muxedVideos[which]
                    playSingleUrl(v.url, streamLabel(v), preservePosition = true)
                }
                .show()
        }
    }

    override fun onPause() {
        super.onPause()
        saveCurrentPosition()
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val autoBg = prefs.getBoolean("auto_bg", true)
        if (!autoBg && !isInPictureInPictureMode) {
            player?.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        saveCurrentPosition()
        streamJob?.cancel()
        commentsJob?.cancel()
        hideHandler.removeCallbacks(hideRunnable)
        player?.release()
        player = null
    }
}
