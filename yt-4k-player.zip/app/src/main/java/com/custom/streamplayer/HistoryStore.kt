package com.custom.streamplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object HistoryStore {
    private const val PREF = "yt_history"
    private const val KEY = "items"

    private const val SEARCH_PREF = "yt_search_history"
    private const val SEARCH_KEY = "queries"

    private const val HOME_CACHE_PREF = "yt_home_cache"
    private const val HOME_CACHE_KEY = "feed_items"

    fun add(context: Context, video: VideoItem) {
        if (video.url.isEmpty()) return
        val list = getAll(context).toMutableList()
        list.removeAll { it.url == video.url }
        list.add(0, video)
        if (list.size > 50) {
            list.subList(50, list.size).clear()
        }
        saveVideoList(context, PREF, KEY, list)
    }

    fun getAll(context: Context): List<VideoItem> {
        return readVideoList(context, PREF, KEY)
    }

    fun removeWatchItem(context: Context, url: String) {
        val list = getAll(context).toMutableList()
        list.removeAll { it.url == url }
        saveVideoList(context, PREF, KEY, list)
    }

    fun clearWatchHistory(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply()
    }

    fun addSearch(context: Context, query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty() || trimmed.startsWith("http://") || trimmed.startsWith("https://")) return
        val list = getSearches(context).toMutableList()
        list.removeAll { it.equals(trimmed, ignoreCase = true) }
        list.add(0, trimmed)
        if (list.size > 30) {
            list.subList(30, list.size).clear()
        }
        val arr = JSONArray()
        for (q in list) arr.put(q)
        context.getSharedPreferences(SEARCH_PREF, Context.MODE_PRIVATE)
            .edit().putString(SEARCH_KEY, arr.toString()).apply()
    }

    fun getSearches(context: Context): List<String> {
        val raw = context.getSharedPreferences(SEARCH_PREF, Context.MODE_PRIVATE)
            .getString(SEARCH_KEY, null) ?: return emptyList()
        val result = mutableListOf<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val q = arr.optString(i)
                if (q.isNotBlank()) result.add(q)
            }
        } catch (_: Exception) {}
        return result
    }

    fun removeSearch(context: Context, query: String) {
        val list = getSearches(context).toMutableList()
        list.removeAll { it.equals(query, ignoreCase = true) }
        val arr = JSONArray()
        for (q in list) arr.put(q)
        context.getSharedPreferences(SEARCH_PREF, Context.MODE_PRIVATE)
            .edit().putString(SEARCH_KEY, arr.toString()).apply()
    }

    fun clearSearches(context: Context) {
        context.getSharedPreferences(SEARCH_PREF, Context.MODE_PRIVATE)
            .edit().remove(SEARCH_KEY).apply()
    }

    fun saveHomeCache(context: Context, items: List<VideoItem>) {
        if (items.isEmpty()) return
        saveVideoList(context, HOME_CACHE_PREF, HOME_CACHE_KEY, items.take(30))
    }

    fun getHomeCache(context: Context): List<VideoItem> {
        return readVideoList(context, HOME_CACHE_PREF, HOME_CACHE_KEY)
    }

    private fun saveVideoList(context: Context, pref: String, key: String, list: List<VideoItem>) {
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("title", item.title)
                put("url", item.url)
                put("channel", item.channel)
                put("thumb", item.thumbnailUrl)
                put("avatar", item.avatarUrl)
                put("duration", item.durationSec)
            }
            arr.put(obj)
        }
        context.getSharedPreferences(pref, Context.MODE_PRIVATE)
            .edit().putString(key, arr.toString()).apply()
    }

    private fun readVideoList(context: Context, pref: String, key: String): List<VideoItem> {
        val raw = context.getSharedPreferences(pref, Context.MODE_PRIVATE).getString(key, null)
            ?: return emptyList()
        val result = mutableListOf<VideoItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    VideoItem(
                        title = obj.optString("title"),
                        url = obj.optString("url"),
                        channel = obj.optString("channel"),
                        thumbnailUrl = obj.optString("thumb"),
                        avatarUrl = obj.optString("avatar"),
                        durationSec = obj.optLong("duration", 0L)
                    )
                )
            }
        } catch (_: Exception) {}
        return result
    }
}
