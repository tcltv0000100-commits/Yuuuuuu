package com.custom.streamplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object HistoryStore {
    private const val PREF = "yt_history"
    private const val KEY = "items"

    fun add(context: Context, video: VideoItem) {
        if (video.url.isEmpty()) return
        val list = getAll(context).toMutableList()
        list.removeAll { it.url == video.url }
        list.add(0, video)
        if (list.size > 50) {
            list.subList(50, list.size).clear()
        }
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("title", item.title)
                put("url", item.url)
                put("channel", item.channel)
                put("thumb", item.thumbnailUrl)
                put("avatar", item.avatarUrl)
                put("duration", item.durationSec)
            }
            arr.put(obj)
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun getAll(context: Context): List<VideoItem> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        val result = mutableListOf<VideoItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    VideoItem(
                        title = obj.optString("title"),
                        url = obj.optString("url"),
                        channel = obj.optString("channel"),
                        thumbnailUrl = obj.optString("thumb"),
                        avatarUrl = obj.optString("avatar"),
                        durationSec = obj.optLong("duration", 0L)
                    )
                )
            }
        } catch (_: Exception) {}
        return result
    }
}
