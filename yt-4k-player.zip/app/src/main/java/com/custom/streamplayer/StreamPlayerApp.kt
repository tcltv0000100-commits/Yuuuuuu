package com.custom.streamplayer

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import java.util.concurrent.TimeUnit

class StreamPlayerApp : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        YouTubeAuthStore.init(this)
        YouTubeCipherDecryptor.init(this)
        YouTubePoTokenProvider.init(this)
        NewPipe.init(OkHttpDownloader(), Localization("en", "IN"), ContentCountry("IN"))

        // Pre-warm DNS & TLS connection to YouTube in background for instant playback
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val client = OkHttpClient.Builder()
                    .connectTimeout(4, TimeUnit.SECONDS)
                    .build()
                val req = Request.Builder()
                    .url("https://www.youtube.com/generate_204")
                    .head()
                    .build()
                client.newCall(req).execute().close()
            } catch (_: Exception) {}
        }
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(100L * 1024 * 1024)
                    .build()
            }
            .respectCacheHeaders(false)
            .crossfade(false)
            .build()
    }
}
