package com.custom.streamplayer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

object YouTubeCipherDecryptor {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var cachedPlayerUrl: String? = null

    @Volatile
    private var cachedPlayerJs: String? = null

    @Volatile
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun decryptCipherUrl(
        signatureCipher: String,
        videoId: String
    ): String? {
        val params = parseQueryParams(signatureCipher)
        val rawUrl = params["url"] ?: return null
        val s = params["s"]
        val sp = params["sp"] ?: "signature"

        if (s.isNullOrEmpty()) return rawUrl

        val js = getPlayerJs(videoId) ?: return null
        val decryptedSig = evalSignatureInWebView(js, s) ?: return null

        val uri = Uri.parse(rawUrl).buildUpon()
            .appendQueryParameter(sp, decryptedSig)
            .build()
        return uri.toString()
    }

    private fun parseQueryParams(query: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        for (pair in query.split("&")) {
            val idx = pair.indexOf('=')
            if (idx > 0) {
                val k = Uri.decode(pair.substring(0, idx))
                val v = Uri.decode(pair.substring(idx + 1))
                map[k] = v
            }
        }
        return map
    }

    private fun getPlayerJs(videoId: String): String? {
        cachedPlayerJs?.let { return it }
        try {
            val embedReq = Request.Builder()
                .url("https://www.youtube.com/embed/$videoId")
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
                )
                .build()
            val html = client.newCall(embedReq).execute().use { resp ->
                if (!resp.isSuccessful) return null
                resp.body?.string()
            } ?: return null

            val jsPath = Regex("\"jsUrl\"\\s*:\\s*\"([^\"]+)\"").find(html)?.groupValues?.getOrNull(1)
                ?: Regex("(/s/player/[a-zA-Z0-9_-]+/player_ias\\.vflset/[^\"']+/base\\.js)").find(html)?.groupValues?.getOrNull(1)
                ?: return null

            val fullJsUrl = if (jsPath.startsWith("http")) jsPath else "https://www.youtube.com$jsPath"
            if (fullJsUrl == cachedPlayerUrl && cachedPlayerJs != null) {
                return cachedPlayerJs
            }

            val jsReq = Request.Builder().url(fullJsUrl).build()
            val jsBody = client.newCall(jsReq).execute().use { resp ->
                if (!resp.isSuccessful) return null
                resp.body?.string()
            } ?: return null

            cachedPlayerUrl = fullJsUrl
            cachedPlayerJs = jsBody
            return jsBody
        } catch (_: Exception) {
            return null
        }
    }

    private fun extractSigCode(js: String): String? {
        val funcName = Regex("\\b[cs]\\s*&&\\s*[adf]\\.set\\([^,]+\\s*,\\s*encodeURIComponent\\(([a-zA-Z0-9$]+)\\(")
            .find(js)?.groupValues?.getOrNull(1)
            ?: Regex("([a-zA-Z0-9$]+)\\s*=\\s*function\\(a\\)\\s*\\{\\s*a\\s*=\\s*a\\.split\\(\"\"\\)").find(js)?.groupValues?.getOrNull(1)
            ?: return null

        val escapedName = Regex.escape(funcName)
        val funcMatch = Regex("(?:var\\s+)?$escapedName\\s*=\\s*(function\\(a\\)\\s*\\{[^}]+\\});?").find(js)
            ?: return null
        val fnExpr = funcMatch.groupValues[1]

        val helperName = Regex("([a-zA-Z0-9$]+)\\.[a-zA-Z0-9$]+\\(a,").find(fnExpr)?.groupValues?.getOrNull(1)
        val helperDef = if (helperName != null) {
            val escHelper = Regex.escape(helperName)
            Regex("var\\s+$escHelper\\s*=\\s*\\{[\\s\\S]{10,600}?\\};").find(js)?.value ?: ""
        } else ""

        return "$helperDef\nvar __ytSigFn = $fnExpr;"
    }

    private fun evalSignatureInWebView(js: String, sig: String): String? {
        val ctx = appContext ?: return null
        val sigScript = extractSigCode(js) ?: return null
        val escapedSig = JSONObject.quote(sig)
        val evalJs = "(function(){ try { $sigScript return __ytSigFn($escapedSig); } catch(e) { return ''; } })()"

        val resultRef = AtomicReference<String?>(null)
        val latch = CountDownLatch(1)

        Handler(Looper.getMainLooper()).post {
            try {
                val wv = WebView(ctx)
                wv.settings.javaScriptEnabled = true
                wv.evaluateJavascript(evalJs) { value ->
                    val cleaned = value?.trim('"')
                    if (!cleaned.isNullOrEmpty() && cleaned != "null") {
                        resultRef.set(cleaned)
                    }
                    wv.destroy()
                    latch.countDown()
                }
            } catch (_: Exception) {
                latch.countDown()
            }
        }

        latch.await(4, TimeUnit.SECONDS)
        return resultRef.get()
    }
}
