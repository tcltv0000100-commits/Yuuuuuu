package com.custom.streamplayer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

object YouTubeCipherDecryptor {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var cachedPlayerUrl: String? = null

    @Volatile
    private var cachedPlayerJs: String? = null

    @Volatile
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun decryptCipherUrl(
        signatureCipher: String,
        videoId: String
    ): String? {
        val params = parseQueryParams(signatureCipher)
        val rawUrl = params["url"] ?: return null
        val s = params["s"]
        val sp = params["sp"] ?: "signature"

        if (s.isNullOrEmpty()) return rawUrl

        val js = getPlayerJs(videoId) ?: return null
        val decryptedSig = evalSignatureInWebView(js, s) ?: return null

        val uri = Uri.parse(rawUrl).buildUpon()
            .appendQueryParameter(sp, decryptedSig)
            .build()
        return uri.toString()
    }

    private fun parseQueryParams(query: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        for (pair in query.split("&")) {
            val idx = pair.indexOf('=')
            if (idx > 0) {
                val k = Uri.decode(pair.substring(0, idx))
                val v = Uri.decode(pair.substring(idx + 1))
                map[k] = v
            }
        }
        return map
    }

    private fun extractJsPathFromHtml(html: String): String? {
        return Regex("\"jsUrl\"\\s*:\\s*\"([^\"]+)\"").find(html)?.groupValues?.getOrNull(1)
            ?: Regex("\"PLAYER_JS_URL\"\\s*:\\s*\"([^\"]+)\"").find(html)?.groupValues?.getOrNull(1)
            ?: Regex("(/s/player/[a-zA-Z0-9_-]+/player_ias\\.vflset/[^\"']+/base\\.js)").find(html)?.groupValues?.getOrNull(1)
            ?: Regex("(/s/player/[a-zA-Z0-9_-]+/[^\"']*base\\.js)").find(html)?.groupValues?.getOrNull(1)
    }

    private fun fetchHtml(url: String): String? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
                )
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                resp.body?.string()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun getPlayerJs(videoId: String): String? {
        cachedPlayerJs?.let { return it }
        try {
            val candidateUrls = listOf(
                "https://www.youtube.com/watch?v=$videoId",
                "https://www.youtube.com/embed/$videoId",
                "https://www.youtube.com/iframe_api"
            )
            var jsPath: String? = null
            for (pageUrl in candidateUrls) {
                val html = fetchHtml(pageUrl) ?: continue
                jsPath = extractJsPathFromHtml(html)
                if (!jsPath.isNullOrBlank()) break
            }
            if (jsPath.isNullOrBlank()) return null

            val cleanPath = jsPath.replace("\\/", "/")
            val fullJsUrl = if (cleanPath.startsWith("http")) cleanPath else "https://www.youtube.com$cleanPath"
            if (fullJsUrl == cachedPlayerUrl && cachedPlayerJs != null) {
                return cachedPlayerJs
            }

            val jsReq = Request.Builder().url(fullJsUrl).build()
            val jsBody = client.newCall(jsReq).execute().use { resp ->
                if (!resp.isSuccessful) return null
                resp.body?.string()
            } ?: return null

            cachedPlayerUrl = fullJsUrl
            cachedPlayerJs = jsBody
            return jsBody
        } catch (_: Exception) {
            return null
        }
    }

    private fun evalSignatureInWebView(playerJs: String, sig: String): String? {
        val ctx = appContext ?: return null
        if (Looper.myLooper() == Looper.getMainLooper()) return null

        val fnName = Regex("""([a-zA-Z0-9_$]+)=function\(a\)\{a=a\.split\(""\);""")
            .find(playerJs)?.groupValues?.getOrNull(1)
            ?: Regex("""\b([a-zA-Z0-9_$]{2,4})\(decodeURIComponent\(""").find(playerJs)?.groupValues?.getOrNull(1)
            ?: return null

        val resultRef = AtomicReference<String?>(null)
        val latch = CountDownLatch(1)
        val mainHandler = Handler(Looper.getMainLooper())
        val escapedSig = JSONObject.quote(sig)

        val script = """
            (function(){
                try {
                    var window = this;
                    var document = {};
                    $playerJs
                    if (typeof $fnName === 'function') {
                        return $fnName($escapedSig);
                    }
                } catch(e) {}
                return '';
            })();
        """.trimIndent()

        mainHandler.post {
            try {
                val wv = WebView(ctx)
                wv.settings.javaScriptEnabled = true
                wv.evaluateJavascript(script) { raw ->
                    val cleaned = raw?.trim()?.removeSurrounding("\"")?.replace("\\\"", "\"")
                    if (!cleaned.isNullOrEmpty() && cleaned != "null") {
                        resultRef.set(cleaned)
                    }
                    wv.destroy()
                    latch.countDown()
                }
            } catch (_: Exception) {
                latch.countDown()
            }
        }

        latch.await(6, TimeUnit.SECONDS)
        return resultRef.get()
    }
}
