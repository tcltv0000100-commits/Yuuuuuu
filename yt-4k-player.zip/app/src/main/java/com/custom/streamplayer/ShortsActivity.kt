package com.custom.streamplayer

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class ShortsActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private var activePlayer: ExoPlayer? = null
    private var fetchJob: Job? = null
    private val shorts = mutableListOf<VideoItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shorts)

        pager = findViewById(R.id.shortsPager)
        findViewById<ImageButton>(R.id.shortsBackBtn).setOnClickListener { finish() }

        loadShortsFeed()
    }

    private fun loadShortsFeed() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery("youtube shorts viral 2026")
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val items = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .filter { it.duration in 1..120 || (it.url ?: "").contains("/shorts/") }
                    .map {
                        VideoItem(
                            title = it.name ?: "",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: "",
                            thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                    }
                withContext(Dispatchers.Main) {
                    shorts.clear()
                    shorts.addAll(items)
                    pager.adapter = ShortsAdapter(shorts)
                    pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                        override fun onPageSelected(position: Int) {
                            pager.post { playAt(position, 0) }
                        }
                    })
                    if (shorts.isNotEmpty()) {
                        pager.postDelayed({ playAt(0, 0) }, 180)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ShortsActivity, "Shorts load error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun playAt(position: Int, attempt: Int) {
        val item = shorts.getOrNull(position) ?: return
        val rv = pager.getChildAt(0) as? RecyclerView
        val holder = rv?.findViewHolderForAdapterPosition(position) as? ShortsAdapter.VH
        if (holder == null) {
            if (attempt < 6) {
                pager.postDelayed({ playAt(position, attempt + 1) }, 120)
            }
            return
        }

        fetchJob?.cancel()
        activePlayer?.release()
        val rf = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val player = ExoPlayer.Builder(this, rf).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }
        activePlayer = player
        holder.playerView.player = player
        holder.playerView.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
        }

        val rawUrl = item.url
        val watchUrl = if (rawUrl.contains("/shorts/")) {
            val id = rawUrl.substringAfter("/shorts/").substringBefore("?").substringBefore("/")
            "https://www.youtube.com/watch?v=$id"
        } else rawUrl

        fetchJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val info = try {
                    StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
                } catch (_: Exception) {
                    StreamInfo.getInfo(ServiceList.YouTube, rawUrl)
                }
                val mux = info.videoStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }
                val v = info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() && !(it.codec ?: "").contains("av01", true) }.maxByOrNull { it.height }
                    ?: info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }
                val a = info.audioStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.averageBitrate }

                withContext(Dispatchers.Main) {
                    val factory = DefaultHttpDataSource.Factory()
                        .setConnectTimeoutMs(10_000)
                        .setReadTimeoutMs(12_000)
                        .setAllowCrossProtocolRedirects(true)
                        .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0")

                    player.addListener(object : Player.Listener {
                        override fun onPlayerError(error: PlaybackException) {
                            if (mux != null) {
                                player.setMediaSource(ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(mux.content)))
                                player.prepare()
                                player.playWhenReady = true
                            }
                        }
                    })

                    when {
                        v != null && a != null -> {
                            val vs = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(v.content))
                            val asrc = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(a.content))
                            player.setMediaSource(MergingMediaSource(vs, asrc))
                        }
                        mux != null -> {
                            val ms = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(mux.content))
                            player.setMediaSource(ms)
                        }
                        !info.hlsUrl.isNullOrEmpty() -> {
                            val hs = HlsMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(info.hlsUrl))
                            player.setMediaSource(hs)
                        }
                        else -> return@withContext
                    }
                    holder.thumb.visibility = View.GONE
                    player.prepare()
                    player.playWhenReady = true
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ShortsActivity, "Swipe up for next Short", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        fetchJob?.cancel()
        activePlayer?.release()
        activePlayer = null
    }

    class ShortsAdapter(private val list: List<VideoItem>) : RecyclerView.Adapter<ShortsAdapter.VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_short_page, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = list[position]
            holder.title.text = item.title
            holder.channel.text = "@${item.channel}"
            holder.thumb.visibility = View.VISIBLE
            holder.thumb.load(item.thumbnailUrl)
        }

        override fun getItemCount(): Int = list.size

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val playerView: PlayerView = v.findViewById(R.id.shortPlayerView)
            val thumb: ImageView = v.findViewById(R.id.shortThumb)
            val channel: TextView = v.findViewById(R.id.shortChannel)
            val title: TextView = v.findViewById(R.id.shortTitle)
        }
    }
}
