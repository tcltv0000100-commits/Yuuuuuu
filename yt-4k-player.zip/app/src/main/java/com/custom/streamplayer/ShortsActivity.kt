package com.custom.streamplayer

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.viewpager2.widget.ViewPager2
import coil.load
import coil.transform.CircleCropTransformation
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.comments.CommentsInfo
import org.schabi.newpipe.extractor.comments.CommentsInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class ShortsActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private var player: ExoPlayer? = null
    private val shortsList = mutableListOf<VideoItem>()
    private var currentPosition = 0
    private var resolveJob: Job? = null
    private var commentsJob: Job? = null
    private var activeHolder: ShortVH? = null
    private var loadedComments: List<CommentsInfoItem> = emptyList()

    private lateinit var swipeRefresh: SwipeRefreshLayout
    private val shortsQueries = mutableListOf(
        "hindi shorts trending",
        "hindi comedy shorts",
        "bollywood shorts",
        "hindi facts shorts",
        "hindi music shorts",
        "indian viral shorts"
    )

    private fun buildPersonalizedShortsQueries() {
        val watch = HistoryStore.getWatchHistory(this)
        val searches = HistoryStore.getSearchHistory(this)
        val combinedText = (watch.map { it.title } + searches).joinToString(" ").lowercase()
        val hindiHints = listOf("hindi", "bollywood", "desi", "kahani", "gaana", "bhajan", "cricket", "india", "status", "punjabi", "bhojpuri", "marathi")
        val hasHindi = hindiHints.any { combinedText.contains(it) } || combinedText.any { it in 'ऀ'..'ॿ' }

        val dynamic = linkedSetOf<String>()
        // Topic-derived queries from recent watch & search history
        searches.take(3).forEach { s ->
            val q = s.trim()
            if (q.isNotEmpty()) dynamic.add("$q shorts")
        }
        watch.take(4).forEach { w ->
            val words = w.title.split(Regex("\\s+")).filter { it.length > 3 }.take(3).joinToString(" ")
            if (words.isNotEmpty()) dynamic.add("$words shorts")
        }
        if (hasHindi || dynamic.isEmpty()) {
            dynamic.addAll(
                listOf(
                    "hindi shorts trending",
                    "hindi comedy shorts",
                    "bollywood shorts",
                    "hindi motivation shorts",
                    "hindi facts shorts",
                    "hindi song shorts",
                    "indian viral shorts",
                    "desi comedy shorts"
                )
            )
        } else {
            dynamic.addAll(listOf("youtube shorts trending india", "viral shorts", "trending shorts", "music shorts"))
        }
        shortsQueries.clear()
        shortsQueries.addAll(dynamic.shuffled())
        queryIndex = (0 until shortsQueries.size.coerceAtLeast(1)).random()
    }
    private var queryIndex = 0
    private var nextPage: Page? = null
    private var isFetchingMore = false

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowCompat.getInsetsController(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.navigationBars())
        }
        setContentView(R.layout.activity_shorts)

        findViewById<ImageButton>(R.id.shortsBackBtn).setOnClickListener {
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.hold_fade, R.anim.slide_out_down)
        }

        findViewById<ImageButton>(R.id.shortsSearchBtn).setOnClickListener {
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.hold_fade, R.anim.slide_out_down)
        }

        val urls = intent.getStringArrayListExtra("short_urls") ?: arrayListOf()
        val titles = intent.getStringArrayListExtra("short_titles") ?: arrayListOf()
        val channels = intent.getStringArrayListExtra("short_channels") ?: arrayListOf()
        val thumbs = intent.getStringArrayListExtra("short_thumbs") ?: arrayListOf()
        val avatars = intent.getStringArrayListExtra("short_avatars") ?: arrayListOf()
        val startIndex = intent.getIntExtra("start_index", 0)

        for (i in urls.indices) {
            shortsList.add(
                VideoItem(
                    title = titles.getOrElse(i) { "Short" },
                    url = urls[i],
                    channel = channels.getOrElse(i) { "" },
                    thumbnailUrl = thumbs.getOrElse(i) { "" },
                    avatarUrl = avatars.getOrElse(i) { "" },
                    durationSec = 30L
                )
            )
        }

        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(DefaultAllocator(true, 65536))
            .setBufferDurationsMs(8_000, 20_000, 150, 300)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        player = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setLoadControl(loadControl)
            .build()
            .apply {
                repeatMode = Player.REPEAT_MODE_ONE
            }

        player?.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    val isPortrait = videoSize.height >= videoSize.width
                    activeHolder?.setFitMode(
                        if (isPortrait) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        else AspectRatioFrameLayout.RESIZE_MODE_FIT
                    )
                }
            }

            override fun onRenderedFirstFrame() {
                activeHolder?.hideLoading()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    activeHolder?.hideLoading()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                activeHolder?.hideLoading()
            }
        })

        buildPersonalizedShortsQueries()
        swipeRefresh = findViewById(R.id.shortsSwipeRefresh)
        swipeRefresh.setColorSchemeColors(Color.parseColor("#FF0000"), Color.WHITE)
        swipeRefresh.setOnRefreshListener {
            refreshShorts()
        }

        pager = findViewById(R.id.shortsPager)
        pager.offscreenPageLimit = 1
        pager.adapter = ShortsPagerAdapter()
        pager.setCurrentItem(startIndex.coerceIn(0, (shortsList.size - 1).coerceAtLeast(0)), false)

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                swipeRefresh.isEnabled = (position == 0)
                playAt(position)
                if (position >= shortsList.size - 4) {
                    fetchMoreShorts()
                }
            }
        })

        if (shortsList.isNotEmpty()) {
            pager.post { playAt(pager.currentItem) }
            if (shortsList.size < 10) fetchMoreShorts()
        } else {
            fetchMoreShorts(autoPlayFirst = true)
        }
    }

    private fun refreshShorts() {
        isFetchingMore = false
        nextPage = null
        buildPersonalizedShortsQueries()
        shortsList.clear()
        pager.adapter?.notifyDataSetChanged()
        fetchMoreShorts(autoPlayFirst = true)
    }

    private fun fetchMoreShorts(autoPlayFirst: Boolean = false) {
        if (isFetchingMore) return
        isFetchingMore = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val query = shortsQueries[queryIndex % shortsQueries.size]
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(query)
                val newItems: List<VideoItem>
                val pageToUse = nextPage
                if (pageToUse != null) {
                    val more = SearchInfo.getMoreItems(ServiceList.YouTube, qh, pageToUse)
                    nextPage = more.nextPage
                    if (nextPage == null) queryIndex++
                    newItems = more.items.filterIsInstance<StreamInfoItem>().map { it.toShortVideo() }
                } else {
                    val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                    nextPage = info.nextPage
                    if (nextPage == null) queryIndex++
                    newItems = info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toShortVideo() }
                }

                val filtered = newItems.filter { it.url.contains("/shorts/") || it.durationSec in 1..90 }
                    .ifEmpty { newItems }

                withContext(Dispatchers.Main) {
                    isFetchingMore = false
                    swipeRefresh.isRefreshing = false
                    val existing = shortsList.map { it.url }.toHashSet()
                    val unique = filtered.filter { it.url.isNotBlank() && it.url !in existing }.shuffled()
                    if (unique.isNotEmpty()) {
                        val oldSize = shortsList.size
                        shortsList.addAll(unique)
                        pager.adapter?.notifyItemRangeInserted(oldSize, unique.size)
                        HistoryStore.saveShortsCache(this@ShortsActivity, shortsList)
                        if (autoPlayFirst && oldSize == 0) {
                            pager.post { playAt(0) }
                        }
                    } else if (autoPlayFirst && shortsList.isEmpty()) {
                        Toast.makeText(this@ShortsActivity, "No Shorts loaded", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (_: Exception) {
                queryIndex++
                nextPage = null
                withContext(Dispatchers.Main) {
                    isFetchingMore = false
                    swipeRefresh.isRefreshing = false
                }
            }
        }
    }

    private fun StreamInfoItem.toShortVideo(): VideoItem {
        val vidId = InnertubeStreamResolver.extractVideoId(url ?: "")
        val thumb = thumbnails.firstOrNull { it.height in 240..720 }?.url
            ?: thumbnails.lastOrNull()?.url
            ?: vidId?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" }
            ?: ""
        return VideoItem(
            title = name ?: "Short",
            url = url ?: "",
            channel = uploaderName ?: "",
            thumbnailUrl = thumb,
            avatarUrl = uploaderAvatars.firstOrNull()?.url ?: "",
            durationSec = duration
        )
    }

    @OptIn(UnstableApi::class)
    private fun playAt(position: Int) {
        if (position !in shortsList.indices) return
        currentPosition = position
        val item = shortsList[position]

        shortsList.getOrNull(position + 1)?.let { InnertubeStreamResolver.prefetch(it.url) }

        val rv = pager.getChildAt(0) as? RecyclerView
        val vh = rv?.findViewHolderForAdapterPosition(position) as? ShortVH
        if (vh != null) {
            activeHolder?.detachPlayer()
            activeHolder = vh
            vh.attachPlayer(player)
        }

        player?.stop()
        player?.clearMediaItems()
        resolveJob?.cancel()
        loadedComments = emptyList()

        HistoryStore.add(this, item)
        loadCommentsForShort(item.url, position)

        resolveJob = CoroutineScope(Dispatchers.IO).launch {
            var res = InnertubeStreamResolver.resolveFast(item.url)
            if (res == null) {
                try {
                    val info = StreamInfo.getInfo(ServiceList.YouTube, item.url)
                    val vOnly = info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }.map {
                        ResolvedVideoStream(it.content, it.height, it.fps, it.itag, it.codec ?: "", it.format?.name ?: "DASH", it.resolution, it.bitrate)
                    }
                    val vMuxed = info.videoStreams.filter { !it.content.isNullOrEmpty() }.map {
                        ResolvedVideoStream(it.content, it.height, it.fps, it.itag, it.codec ?: "", it.format?.name ?: "MP4", it.resolution, it.bitrate)
                    }
                    val audios = info.audioStreams.filter { !it.content.isNullOrEmpty() }.map {
                        ResolvedAudioStream(it.content, it.averageBitrate, it.codec ?: "", it.format?.name ?: "Audio", "und", "", true, false, false)
                    }
                    if (vOnly.isNotEmpty() || vMuxed.isNotEmpty()) {
                        res = ResolvedStreamResult("NEWPIPE", info.name ?: item.title, info.uploaderName ?: item.channel, "", info.viewCount, vOnly, vMuxed, audios, info.hlsUrl, info.dashMpdUrl, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/133.0.0.0 Safari/537.36")
                    }
                } catch (_: Exception) {}
            }

            val resolved = res ?: return@launch
            val v = resolved.videoOnlyStreams.filter { it.height <= 1080 }.maxByOrNull { it.height }
                ?: resolved.videoOnlyStreams.firstOrNull()
                ?: resolved.muxedStreams.maxByOrNull { it.height }
            val a = resolved.audioStreams.maxByOrNull { it.bitrateKbps }

            withContext(Dispatchers.Main) {
                if (isFinishing || isDestroyed || currentPosition != position) return@withContext
                val factory = YoutubeChunkedDataSource.Factory(resolved.userAgent)
                if (v != null && a != null && resolved.videoOnlyStreams.contains(v)) {
                    val vs = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(v.url))
                    val asrc = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(a.url))
                    player?.setMediaSource(MergingMediaSource(vs, asrc))
                    player?.prepare()
                    player?.playWhenReady = true
                } else if (v != null) {
                    val src = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(v.url))
                    player?.setMediaSource(src)
                    player?.prepare()
                    player?.playWhenReady = true
                }
            }
        }
    }

    private fun loadCommentsForShort(url: String, pos: Int) {
        commentsJob?.cancel()
        commentsJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val cInfo = CommentsInfo.getInfo(ServiceList.YouTube, url)
                val items = cInfo.relatedItems.filterIsInstance<CommentsInfoItem>()
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed || currentPosition != pos) return@withContext
                    loadedComments = items
                    activeHolder?.setCommentCount(items.size)
                }
            } catch (_: Exception) {}
        }
    }

    private fun showCommentsSheet() {
        if (loadedComments.isEmpty()) {
            Toast.makeText(this, "Comments loading or unavailable", Toast.LENGTH_SHORT).show()
            return
        }
        val dialog = BottomSheetDialog(this)
        val sheetView = layoutInflater.inflate(R.layout.dialog_comments_sheet, null)
        sheetView.findViewById<TextView>(R.id.sheetTitle).text = "Comments (${loadedComments.size})"
        sheetView.findViewById<TextView>(R.id.sheetClose).setOnClickListener { dialog.dismiss() }
        val rv = sheetView.findViewById<RecyclerView>(R.id.commentsRecycler)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = CommentAdapter(loadedComments)
        dialog.setContentView(sheetView)
        dialog.show()
    }

    private fun showShortMoreDialog(item: VideoItem) {
        val opts = arrayOf("Open in Full Player (4K / HDR / Download)", "Playback Speed: 1x", "Playback Speed: 1.5x", "Playback Speed: 2x")
        AlertDialog.Builder(this)
            .setTitle(item.title)
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> {
                        player?.pause()
                        val i = Intent(this, PlayerActivity::class.java).apply {
                            putExtra("video_url", item.url)
                            putExtra("video_title", item.title)
                            putExtra("channel_name", item.channel)
                            putExtra("thumb_url", item.thumbnailUrl)
                            putExtra("avatar_url", item.avatarUrl)
                            putExtra("duration_sec", item.durationSec)
                        }
                        startActivity(i)
                    }
                    1 -> player?.setPlaybackSpeed(1.0f)
                    2 -> player?.setPlaybackSpeed(1.5f)
                    3 -> player?.setPlaybackSpeed(2.0f)
                }
            }
            .show()
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        resolveJob?.cancel()
        commentsJob?.cancel()
        player?.release()
        player = null
    }

    private inner class ShortsPagerAdapter : RecyclerView.Adapter<ShortVH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShortVH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_short_page, parent, false)
            return ShortVH(v)
        }

        override fun onBindViewHolder(holder: ShortVH, position: Int) {
            holder.bind(shortsList[position], position)
        }

        override fun getItemCount(): Int = shortsList.size
    }

    private inner class ShortVH(v: View) : RecyclerView.ViewHolder(v) {
        private val playerView: PlayerView = v.findViewById(R.id.shortPlayerView)
        private val poster: ImageView = v.findViewById(R.id.shortPoster)
        private val progress: ProgressBar = v.findViewById(R.id.shortProgress)
        private val centerBurst: ImageView = v.findViewById(R.id.shortCenterBurst)
        private val likeBtn: ImageButton = v.findViewById(R.id.shortLikeBtn)
        private val likeLabel: TextView = v.findViewById(R.id.shortLikeLabel)
        private val commentBtn: ImageButton = v.findViewById(R.id.shortCommentBtn)
        private val commentCount: TextView = v.findViewById(R.id.shortCommentCount)
        private val shareBtn: ImageButton = v.findViewById(R.id.shortShareBtn)
        private val moreBtn: ImageButton = v.findViewById(R.id.shortMoreBtn)
        private val avatar: ImageView = v.findViewById(R.id.shortAvatar)
        private val channel: TextView = v.findViewById(R.id.shortChannel)
        private val title: TextView = v.findViewById(R.id.shortTitle)
        private val subBtn: TextView = v.findViewById(R.id.shortSubscribeBtn)

        private var isLiked = false
        private var isSubbed = false

        fun bind(item: VideoItem, pos: Int) {
            title.text = item.title
            channel.text = item.channel
            poster.visibility = View.VISIBLE
            progress.visibility = View.VISIBLE
            commentCount.text = "0"
            isLiked = false
            updateLikeUi()

            isSubbed = HistoryStore.isSubscribed(this@ShortsActivity, item.channel, "")
            updateSubUi()

            poster.load(item.thumbnailUrl) { crossfade(false) }

            val fallback = VideoAdapter.createLetterAvatar(item.channel)
            if (item.avatarUrl.isNotEmpty()) {
                avatar.load(item.avatarUrl) {
                    crossfade(false)
                    placeholder(fallback)
                    error(fallback)
                    transformations(CircleCropTransformation())
                }
            } else {
                avatar.setImageDrawable(fallback)
            }

            val gestureDetector = GestureDetector(itemView.context, object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    player?.let { p -> p.playWhenReady = !p.isPlaying }
                    return true
                }

                override fun onDoubleTap(e: MotionEvent): Boolean {
                    isLiked = true
                    updateLikeUi()
                    showLikeBurst()
                    return true
                }
            })

            playerView.setOnTouchListener { _, event ->
                gestureDetector.onTouchEvent(event)
                true
            }

            likeBtn.setOnClickListener {
                isLiked = !isLiked
                updateLikeUi()
                if (isLiked) showLikeBurst()
            }

            commentBtn.setOnClickListener { showCommentsSheet() }

            shareBtn.setOnClickListener {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, item.url)
                }
                startActivity(Intent.createChooser(sendIntent, "Share Short"))
            }

            moreBtn.setOnClickListener { showShortMoreDialog(item) }

            subBtn.setOnClickListener { v ->
                isSubbed = !isSubbed
                if (isSubbed) HistoryStore.addSubscription(this@ShortsActivity, item.channel, "")
                else HistoryStore.removeSubscription(this@ShortsActivity, item.channel, "")
                updateSubUi()
                v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(80).withEndAction {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                }.start()
            }

            if (pos == currentPosition && activeHolder == null) {
                activeHolder = this
                attachPlayer(player)
            }
        }

        private fun updateLikeUi() {
            likeBtn.setColorFilter(if (isLiked) 0xFFFF3333.toInt() else 0xFFFFFFFF.toInt())
            likeLabel.text = if (isLiked) "Liked" else "Like"
        }

        private fun updateSubUi() {
            subBtn.text = if (isSubbed) "SUBSCRIBED" else "SUBSCRIBE"
            subBtn.setBackgroundColor(if (isSubbed) 0xFF444444.toInt() else 0xFFCC0000.toInt())
        }

        private fun showLikeBurst() {
            centerBurst.visibility = View.VISIBLE
            centerBurst.alpha = 1f
            centerBurst.scaleX = 0.6f
            centerBurst.scaleY = 0.6f
            centerBurst.animate()
                .scaleX(1.25f)
                .scaleY(1.25f)
                .setDuration(180)
                .withEndAction {
                    centerBurst.animate().alpha(0f).setDuration(220).withEndAction {
                        centerBurst.visibility = View.GONE
                    }.start()
                }.start()
        }

        fun setCommentCount(count: Int) {
            commentCount.text = count.toString()
        }

        @OptIn(UnstableApi::class)
        fun setFitMode(mode: Int) {
            playerView.resizeMode = mode
        }

        fun attachPlayer(p: ExoPlayer?) {
            playerView.player = p
        }

        fun detachPlayer() {
            playerView.player = null
            poster.visibility = View.VISIBLE
        }

        fun hideLoading() {
            progress.visibility = View.GONE
            poster.visibility = View.GONE
        }
    }
}
