package com.custom.streamplayer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class ShortsActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var shortsAdapter: ShortsAdapter
    private var activePlayer: ExoPlayer? = null
    private var currentHolder: ShortsAdapter.VH? = null
    private var fetchJob: Job? = null
    private val shorts = mutableListOf<VideoItem>()
    private var nextPage: Page? = null
    private var isLoadingMore = false
    private val shortsQuery = "#shorts"

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shorts)

        YouTubeAuthStore.init(this)
        pager = findViewById(R.id.shortsPager)
        shortsAdapter = ShortsAdapter(shorts)
        pager.adapter = shortsAdapter
        pager.offscreenPageLimit = 1
        findViewById<ImageButton>(R.id.shortsBackBtn).setOnClickListener { finish() }

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                pager.post { playAt(position, 0) }
                if (position >= shorts.size - 4 && !isLoadingMore && nextPage != null) {
                    loadMoreShorts()
                }
            }
        })

        loadShortsFeed()
    }

    private fun mapShortsItems(rawItems: List<StreamInfoItem>): List<VideoItem> {
        val filtered = rawItems.filter {
            it.duration in 1..180 || (it.url ?: "").contains("/shorts/")
        }
        val source = if (filtered.size >= 4) filtered else rawItems
        return source.map {
            VideoItem(
                title = it.name ?: "",
                url = it.url ?: "",
                channel = it.uploaderName ?: "",
                thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                durationSec = it.duration
            )
        }
    }

    private fun loadShortsFeed() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(shortsQuery)
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val raw = info.relatedItems.filterIsInstance<StreamInfoItem>()
                val items = mapShortsItems(raw)
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    nextPage = info.nextPage
                    shorts.clear()
                    shorts.addAll(items)
                    shortsAdapter.notifyDataSetChanged()
                    if (shorts.isNotEmpty()) {
                        pager.postDelayed({ playAt(0, 0) }, 180)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    Toast.makeText(this@ShortsActivity, "Shorts load error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadMoreShorts() {
        val page = nextPage ?: return
        isLoadingMore = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(shortsQuery)
                val more = SearchInfo.getMoreItems(ServiceList.YouTube, qh, page)
                val raw = more.items.filterIsInstance<StreamInfoItem>()
                val newItems = mapShortsItems(raw)
                withContext(Dispatchers.Main) {
                    isLoadingMore = false
                    if (isFinishing || isDestroyed) return@withContext
                    nextPage = more.nextPage
                    val existing = shorts.map { it.url }.toHashSet()
                    val unique = newItems.filter { it.url !in existing }
                    if (unique.isNotEmpty()) {
                        val start = shorts.size
                        shorts.addAll(unique)
                        shortsAdapter.notifyItemRangeInserted(start, unique.size)
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) { isLoadingMore = false }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun ensurePlayer(): ExoPlayer {
        activePlayer?.let { return it }
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 40_000, 800, 2_000)
            .build()
        val rf = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        return ExoPlayer.Builder(this, rf)
            .setLoadControl(loadControl)
            .build()
            .apply {
                repeatMode = Player.REPEAT_MODE_ONE
            }
            .also { activePlayer = it }
    }

    @OptIn(UnstableApi::class)
    private fun playAt(position: Int, attempt: Int) {
        val item = shorts.getOrNull(position) ?: return
        val rv = pager.getChildAt(0) as? RecyclerView
        val holder = rv?.findViewHolderForAdapterPosition(position) as? ShortsAdapter.VH
        if (holder == null) {
            if (attempt < 6) {
                pager.postDelayed({ playAt(position, attempt + 1) }, 120)
            }
            return
        }

        fetchJob?.cancel()
        currentHolder?.playerView?.player = null
        currentHolder?.thumb?.visibility = View.VISIBLE
        currentHolder = holder

        val player = ensurePlayer()
        player.stop()
        player.clearMediaItems()
        holder.playerView.player = player
        holder.playerView.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
        }

        val rawUrl = item.url
        val watchUrl = if (rawUrl.contains("/shorts/")) {
            val id = rawUrl.substringAfter("/shorts/").substringBefore("?").substringBefore("/")
            "https://www.youtube.com/watch?v=$id"
        } else rawUrl

        fetchJob = CoroutineScope(Dispatchers.IO).launch {
            var vUrl: String? = null
            var aUrl: String? = null
            var muxUrl: String? = null
            var hlsUrl: String? = null
            var userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

            try {
                val info = StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
                val mux = info.videoStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }
                val v = info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() && !(it.codec ?: "").contains("av01", true) && it.height <= 1080 }.maxByOrNull { it.height }
                    ?: info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }
                val a = info.audioStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.averageBitrate }
                vUrl = v?.content
                aUrl = a?.content
                muxUrl = mux?.content
                hlsUrl = info.hlsUrl
            } catch (_: Exception) {}

            if ((vUrl == null || aUrl == null) && muxUrl == null && hlsUrl.isNullOrEmpty()) {
                val resolved = InnertubeStreamResolver.resolve(watchUrl)
                if (resolved != null) {
                    val mux = resolved.muxedStreams.maxByOrNull { it.height }
                    val v = resolved.videoOnlyStreams.filter { !it.codec.contains("av01", true) && it.height <= 1080 }.maxByOrNull { it.height }
                        ?: resolved.videoOnlyStreams.maxByOrNull { it.height }
                    val a = resolved.audioStreams.maxByOrNull { it.bitrateKbps }
                    vUrl = v?.url
                    aUrl = a?.url
                    muxUrl = mux?.url
                    hlsUrl = resolved.hlsUrl
                    userAgent = resolved.userAgent
                }
            }

            withContext(Dispatchers.Main) {
                if (isFinishing || isDestroyed || currentHolder != holder) return@withContext

                val factory = DefaultHttpDataSource.Factory()
                    .setConnectTimeoutMs(10_000)
                    .setReadTimeoutMs(12_000)
                    .setAllowCrossProtocolRedirects(true)
                    .setUserAgent(userAgent)

                var triedFallback = false
                player.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        if (!triedFallback && muxUrl != null) {
                            triedFallback = true
                            player.setMediaSource(ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(muxUrl)))
                            player.prepare()
                            player.playWhenReady = true
                        }
                    }
                })

                when {
                    vUrl != null && aUrl != null -> {
                        val vs = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(vUrl))
                        val asrc = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(aUrl))
                        player.setMediaSource(MergingMediaSource(vs, asrc))
                    }
                    muxUrl != null -> {
                        val ms = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(muxUrl))
                        player.setMediaSource(ms)
                    }
                    !hlsUrl.isNullOrEmpty() -> {
                        val hs = HlsMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(hlsUrl))
                        player.setMediaSource(hs)
                    }
                    else -> {
                        Toast.makeText(this@ShortsActivity, "Swipe up for next Short", Toast.LENGTH_SHORT).show()
                        return@withContext
                    }
                }
                holder.thumb.visibility = View.GONE
                player.prepare()
                player.playWhenReady = true
            }
        }
    }

    override fun onPause() {
        super.onPause()
        activePlayer?.pause()
    }

    override fun onResume() {
        super.onResume()
        activePlayer?.play()
    }

    override fun onDestroy() {
        super.onDestroy()
        fetchJob?.cancel()
        activePlayer?.release()
        activePlayer = null
    }

    class ShortsAdapter(private val list: List<VideoItem>) : RecyclerView.Adapter<ShortsAdapter.VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_short_page, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = list[position]
            holder.title.text = item.title
            holder.channel.text = "@${item.channel}"
            holder.thumb.visibility = View.VISIBLE
            holder.thumb.load(item.thumbnailUrl)
        }

        override fun getItemCount(): Int = list.size

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val playerView: PlayerView = v.findViewById(R.id.shortPlayerView)
            val thumb: ImageView = v.findViewById(R.id.shortThumb)
            val channel: TextView = v.findViewById(R.id.shortChannel)
            val title: TextView = v.findViewById(R.id.shortTitle)
        }
    }
}
