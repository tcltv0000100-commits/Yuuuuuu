package com.custom.streamplayer

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.viewpager2.widget.ViewPager2
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.ConcurrentHashMap

class ShortsActivity : AppCompatActivity() {

    private data class ResolvedShortStream(
        val vUrl: String?,
        val aUrl: String?,
        val muxUrl: String?,
        val hlsUrl: String?,
        val userAgent: String
    )

    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var pager: ViewPager2
    private lateinit var shortsAdapter: ShortsAdapter
    private var activePlayer: ExoPlayer? = null
    private var currentHolder: ShortsAdapter.VH? = null
    private var fetchJob: Job? = null
    private val shorts = mutableListOf<VideoItem>()
    private var nextPage: Page? = null
    private var isLoadingMore = false

    private val streamCache = ConcurrentHashMap<String, ResolvedShortStream>()
    private val inFlightResolves = ConcurrentHashMap.newKeySet<String>()
    private var currentMuxFallbackUrl: String? = null
    private var currentUserAgent: String = DEFAULT_UA
    private var triedFallbackForCurrent = false

    private val shortsQueries = listOf(
        "trending shorts india",
        "viral shorts india",
        "hindi shorts",
        "indian comedy shorts",
        "bollywood shorts",
        "cricket shorts india",
        "tech shorts india",
        "music shorts india"
    )
    private var currentShortsQuery = "trending shorts india"

    companion object {
        private const val DEFAULT_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shorts)

        try {
            NewPipe.init(OkHttpDownloader(), Localization("en", "IN"), ContentCountry("IN"))
        } catch (_: Exception) {
        }
        YouTubeAuthStore.init(this)
        YouTubeCipherDecryptor.init(this)
        YouTubePoTokenProvider.init(this)

        swipeRefresh = findViewById(R.id.shortsSwipeRefresh)
        progressBar = findViewById(R.id.shortsProgressBar)
        swipeRefresh.setColorSchemeColors(0xFFFF0000.toInt())
        swipeRefresh.setOnRefreshListener {
            loadShortsFeed(rotate = true)
        }

        pager = findViewById(R.id.shortsPager)
        shortsAdapter = ShortsAdapter(shorts)
        pager.adapter = shortsAdapter
        pager.offscreenPageLimit = 2

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                swipeRefresh.isEnabled = (position == 0)
                pager.post { playAt(position, 0) }
                preResolveAround(position)
                if (position >= shorts.size - 4 && !isLoadingMore && nextPage != null) {
                    loadMoreShorts()
                }
            }
        })

        loadShortsFeed(rotate = false)
    }

    private fun mapShortsItems(rawItems: List<StreamInfoItem>): List<VideoItem> {
        val filtered = rawItems.filter {
            it.duration in 1..180 || (it.url ?: "").contains("/shorts/")
        }
        val source = if (filtered.size >= 4) filtered else rawItems
        return source.map {
            VideoItem(
                title = it.name ?: "",
                url = it.url ?: "",
                channel = it.uploaderName ?: "",
                thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                durationSec = it.duration
            )
        }
    }

    private fun toWatchUrl(rawUrl: String): String {
        return if (rawUrl.contains("/shorts/")) {
            val id = rawUrl.substringAfter("/shorts/").substringBefore("?").substringBefore("/")
            "https://www.youtube.com/watch?v=$id"
        } else {
            rawUrl
        }
    }

    private fun loadShortsFeed(rotate: Boolean = false) {
        if (shorts.isEmpty()) {
            progressBar.visibility = View.VISIBLE
        }
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val idx = prefs.getInt("shorts_seed_idx", 0)
        val nextIdx = if (rotate) (idx + 1) % shortsQueries.size else idx
        if (rotate) prefs.edit().putInt("shorts_seed_idx", nextIdx).apply()
        currentShortsQuery = shortsQueries[nextIdx]

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(currentShortsQuery)
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val raw = info.relatedItems.filterIsInstance<StreamInfoItem>()
                val items = mapShortsItems(raw).shuffled()
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    nextPage = info.nextPage
                    shorts.clear()
                    shorts.addAll(items)
                    shortsAdapter.notifyDataSetChanged()
                    if (shorts.isNotEmpty()) {
                        pager.setCurrentItem(0, false)
                        pager.post { playAt(0, 0) }
                        preResolveAround(0)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    Toast.makeText(this@ShortsActivity, "Shorts load error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadMoreShorts() {
        val page = nextPage ?: return
        isLoadingMore = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(currentShortsQuery)
                val more = SearchInfo.getMoreItems(ServiceList.YouTube, qh, page)
                val raw = more.items.filterIsInstance<StreamInfoItem>()
                val newItems = mapShortsItems(raw)
                withContext(Dispatchers.Main) {
                    isLoadingMore = false
                    if (isFinishing || isDestroyed) return@withContext
                    nextPage = more.nextPage
                    val existing = shorts.map { it.url }.toHashSet()
                    val unique = newItems.filter { it.url !in existing }
                    if (unique.isNotEmpty()) {
                        val start = shorts.size
                        shorts.addAll(unique)
                        shortsAdapter.notifyItemRangeInserted(start, unique.size)
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) { isLoadingMore = false }
            }
        }
    }

    private fun resolveStreamSync(watchUrl: String): ResolvedShortStream? {
        streamCache[watchUrl]?.let { return it }

        var vUrl: String? = null
        var aUrl: String? = null
        var muxUrl: String? = null
        var hlsUrl: String? = null
        var userAgent = DEFAULT_UA
        val maxAutoHeight = if (isOnWifi()) 1080 else 720

        try {
            val info = StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
            val mux = info.videoStreams
                .filter { !it.content.isNullOrEmpty() }
                .maxByOrNull { it.height }
            val validV = info.videoOnlyStreams.filter {
                !it.content.isNullOrEmpty() && it.height in 144..maxAutoHeight
            }
            val v = validV.filter { !(it.codec ?: "").contains("av01", true) }.maxByOrNull { it.height }
                ?: validV.maxByOrNull { it.height }
                ?: info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }
            val a = info.audioStreams
                .filter { !it.content.isNullOrEmpty() }
                .maxByOrNull { it.averageBitrate }
            vUrl = v?.content
            aUrl = a?.content
            muxUrl = mux?.content
            hlsUrl = info.hlsUrl
        } catch (_: Exception) {
        }

        if ((vUrl == null || aUrl == null) && muxUrl == null && hlsUrl.isNullOrEmpty()) {
            val resolved = InnertubeStreamResolver.resolve(watchUrl)
            if (resolved != null) {
                val mux = resolved.muxedStreams.maxByOrNull { it.height }
                val validV = resolved.videoOnlyStreams.filter { it.height in 144..maxAutoHeight }
                val v = validV.filter { !it.codec.contains("av01", true) }.maxByOrNull { it.height }
                    ?: validV.maxByOrNull { it.height }
                    ?: resolved.videoOnlyStreams.maxByOrNull { it.height }
                val a = resolved.audioStreams.maxByOrNull { it.bitrateKbps }
                vUrl = v?.url
                aUrl = a?.url
                muxUrl = mux?.url
                hlsUrl = resolved.hlsUrl
                userAgent = resolved.userAgent
            }
        }

        if (vUrl == null && muxUrl == null && hlsUrl.isNullOrEmpty()) return null
        return ResolvedShortStream(vUrl, aUrl, muxUrl, hlsUrl, userAgent).also {
            streamCache[watchUrl] = it
        }
    }

    private fun preResolveAround(position: Int) {
        for (offset in 1..2) {
            val item = shorts.getOrNull(position + offset) ?: continue
            val watchUrl = toWatchUrl(item.url)
            if (streamCache.containsKey(watchUrl) || !inFlightResolves.add(watchUrl)) continue
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    resolveStreamSync(watchUrl)
                } finally {
                    inFlightResolves.remove(watchUrl)
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun makeDataSourceFactory(userAgent: String): DefaultHttpDataSource.Factory {
        return DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(8_000)
            .setReadTimeoutMs(10_000)
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent(userAgent)
    }

    @OptIn(UnstableApi::class)
    private fun ensurePlayer(): ExoPlayer {
        activePlayer?.let { return it }
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(8_000, 30_000, 250, 500)
            .build()
        val rf = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        return ExoPlayer.Builder(this, rf)
            .setLoadControl(loadControl)
            .build()
            .apply {
                repeatMode = Player.REPEAT_MODE_ONE
                addListener(object : Player.Listener {
                    override fun onRenderedFirstFrame() {
                        currentHolder?.thumb?.visibility = View.GONE
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        val fallbackUrl = currentMuxFallbackUrl
                        if (!triedFallbackForCurrent && !fallbackUrl.isNullOrEmpty()) {
                            triedFallbackForCurrent = true
                            val factory = makeDataSourceFactory(currentUserAgent)
                            setMediaSource(
                                ProgressiveMediaSource.Factory(factory)
                                    .createMediaSource(MediaItem.fromUri(fallbackUrl))
                            )
                            prepare()
                            playWhenReady = true
                        }
                    }
                })
            }
            .also { activePlayer = it }
    }

    @OptIn(UnstableApi::class)
    private fun playAt(position: Int, attempt: Int) {
        val item = shorts.getOrNull(position) ?: return
        val rv = pager.getChildAt(0) as? RecyclerView
        val holder = rv?.findViewHolderForAdapterPosition(position) as? ShortsAdapter.VH
        if (holder == null) {
            if (attempt < 6) {
                pager.postDelayed({ playAt(position, attempt + 1) }, 80)
            }
            return
        }

        fetchJob?.cancel()
        currentHolder?.playerView?.player = null
        currentHolder?.thumb?.visibility = View.VISIBLE
        currentHolder = holder
        triedFallbackForCurrent = false
        currentMuxFallbackUrl = null

        val player = ensurePlayer()
        player.stop()
        player.clearMediaItems()
        holder.playerView.player = player
        holder.playerView.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
        }

        val watchUrl = toWatchUrl(item.url)
        val cached = streamCache[watchUrl]
        if (cached != null) {
            startStreamOnPlayer(player, holder, cached)
            return
        }

        fetchJob = CoroutineScope(Dispatchers.IO).launch {
            val resolved = resolveStreamSync(watchUrl)
            withContext(Dispatchers.Main) {
                if (isFinishing || isDestroyed || currentHolder != holder) return@withContext
                if (resolved == null) {
                    Toast.makeText(this@ShortsActivity, "Swipe up for next Short", Toast.LENGTH_SHORT).show()
                    return@withContext
                }
                startStreamOnPlayer(player, holder, resolved)
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun startStreamOnPlayer(
        player: ExoPlayer,
        holder: ShortsAdapter.VH,
        stream: ResolvedShortStream
    ) {
        if (currentHolder != holder) return
        currentUserAgent = stream.userAgent
        currentMuxFallbackUrl = stream.muxUrl
        triedFallbackForCurrent = false
        val factory = makeDataSourceFactory(stream.userAgent)

        when {
            stream.vUrl != null && stream.aUrl != null -> {
                val vs = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(stream.vUrl))
                val asrc = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(stream.aUrl))
                player.setMediaSource(MergingMediaSource(vs, asrc))
            }
            stream.muxUrl != null -> {
                val ms = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(stream.muxUrl))
                player.setMediaSource(ms)
            }
            !stream.hlsUrl.isNullOrEmpty() -> {
                val hs = HlsMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(stream.hlsUrl))
                player.setMediaSource(hs)
            }
            else -> {
                Toast.makeText(this@ShortsActivity, "Swipe up for next Short", Toast.LENGTH_SHORT).show()
                return
            }
        }
        player.prepare()
        player.playWhenReady = true
    }

    private fun isOnWifi(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    override fun onPause() {
        super.onPause()
        activePlayer?.pause()
    }

    override fun onResume() {
        super.onResume()
        activePlayer?.play()
    }

    override fun onDestroy() {
        super.onDestroy()
        fetchJob?.cancel()
        activePlayer?.release()
        activePlayer = null
    }

    class ShortsAdapter(private val list: List<VideoItem>) : RecyclerView.Adapter<ShortsAdapter.VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_short_page, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = list[position]
            holder.title.text = item.title
            holder.channel.text = "@${item.channel}"
            holder.thumb.visibility = View.VISIBLE
            holder.thumb.load(item.thumbnailUrl)
        }

        override fun getItemCount(): Int = list.size

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val playerView: PlayerView = v.findViewById(R.id.shortPlayerView)
            val thumb: ImageView = v.findViewById(R.id.shortThumb)
            val channel: TextView = v.findViewById(R.id.shortChannel)
            val title: TextView = v.findViewById(R.id.shortTitle)
        }
    }
}
