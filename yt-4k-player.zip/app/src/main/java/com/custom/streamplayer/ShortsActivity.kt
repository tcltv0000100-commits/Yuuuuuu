package com.custom.streamplayer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class ShortsActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private var activePlayer: ExoPlayer? = null
    private var fetchJob: Job? = null
    private val shorts = mutableListOf<VideoItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shorts)

        pager = findViewById(R.id.shortsPager)
        findViewById<ImageButton>(R.id.shortsBackBtn).setOnClickListener { finish() }

        loadShortsFeed()
    }

    private fun loadShortsFeed() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery("youtube shorts viral 2026")
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val items = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .filter { it.duration in 1..120 || (it.url ?: "").contains("/shorts/") }
                    .map {
                        VideoItem(
                            title = it.name ?: "",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: "",
                            thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                    }
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    shorts.clear()
                    shorts.addAll(items)
                    pager.adapter = ShortsAdapter(shorts)
                    pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                        override fun onPageSelected(position: Int) {
                            pager.post { playAt(position, 0) }
                        }
                    })
                    if (shorts.isNotEmpty()) {
                        pager.postDelayed({ playAt(0, 0) }, 180)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    if (isFinishing || isDestroyed) return@withContext
                    Toast.makeText(this@ShortsActivity, "Shorts load error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun playAt(position: Int, attempt: Int) {
        val item = shorts.getOrNull(position) ?: return
        val rv = pager.getChildAt(0) as? RecyclerView
        val holder = rv?.findViewHolderForAdapterPosition(position) as? ShortsAdapter.VH
        if (holder == null) {
            if (attempt < 6) {
                pager.postDelayed({ playAt(position, attempt + 1) }, 120)
            }
            return
        }

        fetchJob?.cancel()
        activePlayer?.release()
        val rf = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val player = ExoPlayer.Builder(this, rf).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }
        activePlayer = player
        holder.playerView.player = player
        holder.playerView.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
        }

        val rawUrl = item.url
        val watchUrl = if (rawUrl.contains("/shorts/")) {
            val id = rawUrl.substringAfter("/shorts/").substringBefore("?").substringBefore("/")
            "https://www.youtube.com/watch?v=$id"
        } else rawUrl

        fetchJob = CoroutineScope(Dispatchers.IO).launch {
            var vUrl: String? = null
            var aUrl: String? = null
            var muxUrl: String? = null
            var hlsUrl: String? = null
            var dashUrl: String? = null
            var userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0"

            try {
                val info = StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
                val mux = info.videoStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }
                val v = info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() && !(it.codec ?: "").contains("av01", true) }.maxByOrNull { it.height }
                    ?: info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }
                val a = info.audioStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.averageBitrate }
                vUrl = v?.content
                aUrl = a?.content
                muxUrl = mux?.content
                hlsUrl = info.hlsUrl
                dashUrl = info.dashMpdUrl
            } catch (_: Exception) {
                // Fall through to Innertube fallback
            }

            if ((vUrl == null || aUrl == null) && muxUrl == null &&
                hlsUrl.isNullOrEmpty() && dashUrl.isNullOrEmpty()) {
                val resolved = InnertubeStreamResolver.resolve(watchUrl)
                if (resolved != null) {
                    val mux = resolved.muxedStreams.maxByOrNull { it.height }
                    val v = resolved.videoOnlyStreams.filter { !it.codec.contains("av01", true) }.maxByOrNull { it.height }
                        ?: resolved.videoOnlyStreams.maxByOrNull { it.height }
                    val a = resolved.audioStreams.maxByOrNull { it.bitrateKbps }
                    vUrl = v?.url
                    aUrl = a?.url
                    muxUrl = mux?.url
                    hlsUrl = resolved.hlsUrl
                    dashUrl = resolved.dashUrl
                    userAgent = resolved.userAgent
                }
            }

            withContext(Dispatchers.Main) {
                if (isFinishing || isDestroyed || activePlayer != player) return@withContext

                val factory = DefaultHttpDataSource.Factory()
                    .setConnectTimeoutMs(10_000)
                    .setReadTimeoutMs(12_000)
                    .setAllowCrossProtocolRedirects(true)
                    .setUserAgent(userAgent)

                // Immutable snapshots make fallback selection safe inside the listener closure.
                val muxFallbackUrl = muxUrl
                val hlsFallbackUrl = hlsUrl
                val dashFallbackUrl = dashUrl
                var triedFallback = false
                var activeShortRoute = "DIRECT"
                player.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        if (triedFallback) return
                        triedFallback = true
                        when {
                            muxFallbackUrl != null && activeShortRoute != "MUXED" -> {
                                activeShortRoute = "MUXED"
                                player.setMediaSource(ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(muxFallbackUrl)))
                            }
                            !hlsFallbackUrl.isNullOrEmpty() && activeShortRoute != "HLS" -> {
                                activeShortRoute = "HLS"
                                player.setMediaSource(HlsMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(hlsFallbackUrl)))
                            }
                            !dashFallbackUrl.isNullOrEmpty() && activeShortRoute != "DASH" -> {
                                activeShortRoute = "DASH"
                                player.setMediaSource(DashMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(dashFallbackUrl)))
                            }
                            else -> return
                        }
                        player.prepare()
                        player.playWhenReady = true
                    }
                })

                when {
                    vUrl != null && aUrl != null -> {
                        activeShortRoute = "DIRECT"
                        val vs = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(vUrl))
                        val asrc = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(aUrl))
                        player.setMediaSource(MergingMediaSource(vs, asrc))
                    }
                    muxUrl != null -> {
                        activeShortRoute = "MUXED"
                        val ms = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(muxUrl))
                        player.setMediaSource(ms)
                    }
                    !hlsUrl.isNullOrEmpty() -> {
                        activeShortRoute = "HLS"
                        val hs = HlsMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(hlsUrl))
                        player.setMediaSource(hs)
                    }
                    !dashUrl.isNullOrEmpty() -> {
                        activeShortRoute = "DASH"
                        val ds = DashMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(dashUrl))
                        player.setMediaSource(ds)
                    }
                    else -> {
                        Toast.makeText(this@ShortsActivity, "Swipe up for next Short", Toast.LENGTH_SHORT).show()
                        return@withContext
                    }
                }
                holder.thumb.visibility = View.GONE
                player.prepare()
                player.playWhenReady = true
            }
        }
    }

    override fun onPause() {
        super.onPause()
        activePlayer?.pause()
    }

    override fun onResume() {
        super.onResume()
        activePlayer?.play()
    }

    override fun onDestroy() {
        super.onDestroy()
        fetchJob?.cancel()
        activePlayer?.release()
        activePlayer = null
    }

    class ShortsAdapter(private val list: List<VideoItem>) : RecyclerView.Adapter<ShortsAdapter.VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_short_page, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = list[position]
            holder.title.text = item.title
            holder.channel.text = "@${item.channel}"
            holder.thumb.visibility = View.VISIBLE
            holder.thumb.load(item.thumbnailUrl)
        }

        override fun getItemCount(): Int = list.size

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val playerView: PlayerView = v.findViewById(R.id.shortPlayerView)
            val thumb: ImageView = v.findViewById(R.id.shortThumb)
            val channel: TextView = v.findViewById(R.id.shortChannel)
            val title: TextView = v.findViewById(R.id.shortTitle)
        }
    }
}
