package com.custom.streamplayer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class ShortsActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private var activePlayer: ExoPlayer? = null
    private val shorts = mutableListOf<VideoItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shorts)

        pager = findViewById(R.id.shortsPager)
        findViewById<ImageButton>(R.id.shortsBackBtn).setOnClickListener { finish() }

        loadShortsFeed()
    }

    private fun loadShortsFeed() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery("#shorts")
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val items = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .filter { it.duration in 1..120 }
                    .map {
                        VideoItem(
                            title = it.name ?: "",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: "",
                            thumbnailUrl = it.thumbnails.lastOrNull()?.url ?: "",
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                    }
                withContext(Dispatchers.Main) {
                    shorts.clear()
                    shorts.addAll(items)
                    val adapter = ShortsAdapter(shorts)
                    pager.adapter = adapter
                    pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                        override fun onPageSelected(position: Int) {
                            playAt(position)
                        }
                    })
                    if (shorts.isNotEmpty()) playAt(0)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@ShortsActivity, "Shorts error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun playAt(position: Int) {
        val item = shorts.getOrNull(position) ?: return
        val rv = pager.getChildAt(0) as? RecyclerView ?: return
        val holder = rv.findViewHolderForAdapterPosition(position) as? ShortsAdapter.VH ?: return

        activePlayer?.release()
        val player = ExoPlayer.Builder(this).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }
        activePlayer = player
        holder.playerView.player = player
        holder.playerView.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
        }

        val rawUrl = item.url
        val watchUrl = if (rawUrl.contains("/shorts/")) {
            val id = rawUrl.substringAfter("/shorts/").substringBefore("?").substringBefore("/")
            "https://www.youtube.com/watch?v=$id"
        } else rawUrl

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val info = StreamInfo.getInfo(ServiceList.YouTube, watchUrl)
                val v = info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }
                val a = info.audioStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.averageBitrate }
                val mux = info.videoStreams.filter { !it.content.isNullOrEmpty() }.maxByOrNull { it.height }

                withContext(Dispatchers.Main) {
                    val factory = DefaultHttpDataSource.Factory()
                        .setAllowCrossProtocolRedirects(true)
                        .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0")
                    if (v != null && a != null) {
                        val vs = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(v.content))
                        val asrc = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(a.content))
                        player.setMediaSource(MergingMediaSource(vs, asrc))
                    } else if (mux != null) {
                        val ms = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(mux.content))
                        player.setMediaSource(ms)
                    } else {
                        return@withContext
                    }
                    holder.thumb.visibility = View.GONE
                    player.prepare()
                    player.playWhenReady = true
                }
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        activePlayer?.release()
        activePlayer = null
    }

    class ShortsAdapter(private val list: List<VideoItem>) : RecyclerView.Adapter<ShortsAdapter.VH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_short_page, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = list[position]
            holder.title.text = item.title
            holder.channel.text = "@${item.channel}"
            holder.thumb.visibility = View.VISIBLE
            holder.thumb.load(item.thumbnailUrl)
        }

        override fun getItemCount(): Int = list.size

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val playerView: PlayerView = v.findViewById(R.id.shortPlayerView)
            val thumb: ImageView = v.findViewById(R.id.shortThumb)
            val channel: TextView = v.findViewById(R.id.shortChannel)
            val title: TextView = v.findViewById(R.id.shortTitle)
        }
    }
}
