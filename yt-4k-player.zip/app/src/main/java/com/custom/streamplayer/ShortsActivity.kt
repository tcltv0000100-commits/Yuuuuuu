package com.custom.streamplayer

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import coil.transform.CircleCropTransformation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class ShortsActivity : AppCompatActivity() {

    private lateinit var pager: ViewPager2
    private lateinit var adapter: ShortsPagerAdapter
    private var player: ExoPlayer? = null
    private val shortsList = mutableListOf<VideoItem>()
    private var currentPosition = 0
    private var resolveJob: Job? = null
    private var activeHolder: ShortVH? = null

    private var nextShortsPage: Page? = null
    private var isFetchingMoreShorts = false
    private var shortsQueryIdx = 0
    private val shortsQueries = listOf(
        "youtube shorts trending india",
        "viral shorts 2026",
        "trending shorts",
        "funny shorts india",
        "music shorts"
    )

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowCompat.getInsetsController(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.navigationBars())
        }
        setContentView(R.layout.activity_shorts)

        findViewById<ImageButton>(R.id.shortsBackBtn).setOnClickListener {
            finish()
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.hold_fade, R.anim.slide_out_down)
        }

        findViewById<ImageButton>(R.id.shortsSearchBtn).setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }

        val urls = intent.getStringArrayListExtra("short_urls") ?: arrayListOf()
        val titles = intent.getStringArrayListExtra("short_titles") ?: arrayListOf()
        val channels = intent.getStringArrayListExtra("short_channels") ?: arrayListOf()
        val thumbs = intent.getStringArrayListExtra("short_thumbs") ?: arrayListOf()
        val avatars = intent.getStringArrayListExtra("short_avatars") ?: arrayListOf()
        val startIndex = intent.getIntExtra("start_index", 0)
        shortsQueryIdx = intent.getIntExtra("query_offset", 0)

        for (i in urls.indices) {
            shortsList.add(
                VideoItem(
                    title = titles.getOrElse(i) { "Short" },
                    url = urls[i],
                    channel = channels.getOrElse(i) { "" },
                    thumbnailUrl = thumbs.getOrElse(i) { "" },
                    avatarUrl = avatars.getOrElse(i) { "" },
                    durationSec = 30L
                )
            )
        }

        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(DefaultAllocator(true, 65536))
            .setBufferDurationsMs(8_000, 20_000, 150, 300)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        player = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true))
            .setLoadControl(loadControl)
            .build()
            .apply {
                repeatMode = Player.REPEAT_MODE_ONE
            }

        player?.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (videoSize.width > 0 && videoSize.height > 0) {
                    val isWideLandscape = videoSize.width > (videoSize.height * 1.15f)
                    activeHolder?.setFitMode(
                        if (isWideLandscape) AspectRatioFrameLayout.RESIZE_MODE_FIT
                        else AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    )
                }
            }

            override fun onRenderedFirstFrame() {
                activeHolder?.hideLoading()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    activeHolder?.hideLoading()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                activeHolder?.hideLoading()
            }
        })

        pager = findViewById(R.id.shortsPager)
        adapter = ShortsPagerAdapter()
        pager.adapter = adapter
        pager.setCurrentItem(startIndex.coerceIn(0, (shortsList.size - 1).coerceAtLeast(0)), false)

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                playAt(position)
                if (position >= shortsList.size - 3) {
                    fetchMoreShorts()
                }
            }
        })

        if (shortsList.isEmpty()) {
            fetchMoreShorts(playFirstAfterLoad = true)
        } else {
            pager.post { playAt(pager.currentItem) }
        }
    }

    private fun fetchMoreShorts(playFirstAfterLoad: Boolean = false) {
        if (isFetchingMoreShorts) return
        isFetchingMoreShorts = true
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val query = shortsQueries[shortsQueryIdx % shortsQueries.size]
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(query)
                val info = if (nextShortsPage != null) {
                    val more = SearchInfo.getMoreItems(ServiceList.YouTube, qh, nextShortsPage)
                    nextShortsPage = more.nextPage
                    more.items
                } else {
                    val res = SearchInfo.getInfo(ServiceList.YouTube, qh)
                    nextShortsPage = res.nextPage
                    res.relatedItems
                }
                if (nextShortsPage == null) shortsQueryIdx++

                val existing = shortsList.map { it.url }.toHashSet()
                val newItems = info.filterIsInstance<StreamInfoItem>()
                    .map {
                        val vidId = InnertubeStreamResolver.extractVideoId(it.url ?: "")
                        val thumb = it.thumbnails.lastOrNull()?.url
                            ?: vidId?.let { id -> "https://i.ytimg.com/vi/$id/hqdefault.jpg" }
                            ?: ""
                        VideoItem(
                            title = it.name ?: "Short",
                            url = it.url ?: "",
                            channel = it.uploaderName ?: "",
                            thumbnailUrl = thumb,
                            avatarUrl = it.uploaderAvatars.firstOrNull()?.url ?: "",
                            durationSec = it.duration
                        )
                    }
                    .filter { it.url.isNotBlank() && it.url !in existing }

                withContext(Dispatchers.Main) {
                    isFetchingMoreShorts = false
                    if (isFinishing || isDestroyed) return@withContext
                    if (newItems.isNotEmpty()) {
                        val oldSize = shortsList.size
                        shortsList.addAll(newItems)
                        adapter.notifyItemRangeInserted(oldSize, newItems.size)
                        HistoryStore.saveShortsCache(this@ShortsActivity, shortsList.take(30))
                        if (playFirstAfterLoad && oldSize == 0) {
                            pager.post { playAt(0) }
                        }
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    isFetchingMoreShorts = false
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun playAt(position: Int) {
        if (position !in shortsList.indices) return
        currentPosition = position
        val item = shortsList[position]

        shortsList.getOrNull(position + 1)?.let { InnertubeStreamResolver.prefetch(it.url) }

        val rv = pager.getChildAt(0) as? RecyclerView
        val vh = rv?.findViewHolderForAdapterPosition(position) as? ShortVH
        if (vh != null) {
            activeHolder?.detachPlayer()
            activeHolder = vh
            vh.attachPlayer(player)
        }

        player?.stop()
        player?.clearMediaItems()
        resolveJob?.cancel()

        HistoryStore.add(this, item)

        resolveJob = CoroutineScope(Dispatchers.IO).launch {
            var res = InnertubeStreamResolver.resolveFast(item.url)
            if (res == null) {
                try {
                    val info = StreamInfo.getInfo(ServiceList.YouTube, item.url)
                    val vOnly = info.videoOnlyStreams.filter { !it.content.isNullOrEmpty() }.map {
                        ResolvedVideoStream(it.content, it.height, it.fps, it.itag, it.codec ?: "", it.format?.name ?: "DASH", it.resolution, it.bitrate)
                    }
                    val vMuxed = info.videoStreams.filter { !it.content.isNullOrEmpty() }.map {
                        ResolvedVideoStream(it.content, it.height, it.fps, it.itag, it.codec ?: "", it.format?.name ?: "MP4", it.resolution, it.bitrate)
                    }
                    val audios = info.audioStreams.filter { !it.content.isNullOrEmpty() }.map {
                        ResolvedAudioStream(it.content, it.averageBitrate, it.codec ?: "", it.format?.name ?: "Audio", "und", "", true, false, false)
                    }
                    if (vOnly.isNotEmpty() || vMuxed.isNotEmpty()) {
                        res = ResolvedStreamResult("NEWPIPE", info.name ?: item.title, info.uploaderName ?: item.channel, "", info.viewCount, vOnly, vMuxed, audios, info.hlsUrl, info.dashMpdUrl, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/133.0.0.0 Safari/537.36")
                    }
                } catch (_: Exception) {}
            }

            val resolved = res ?: return@launch
            val v = resolved.videoOnlyStreams.filter { it.height <= 1080 }.maxByOrNull { it.height }
                ?: resolved.videoOnlyStreams.firstOrNull()
                ?: resolved.muxedStreams.maxByOrNull { it.height }
            val a = resolved.audioStreams.maxByOrNull { it.bitrateKbps }

            withContext(Dispatchers.Main) {
                if (isFinishing || isDestroyed || currentPosition != position) return@withContext
                val factory = YoutubeChunkedDataSource.Factory(resolved.userAgent)
                if (v != null && a != null && resolved.videoOnlyStreams.contains(v)) {
                    val vs = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(v.url))
                    val asrc = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(a.url))
                    player?.setMediaSource(MergingMediaSource(vs, asrc))
                    player?.prepare()
                    player?.playWhenReady = true
                } else if (v != null) {
                    val src = ProgressiveMediaSource.Factory(factory).createMediaSource(MediaItem.fromUri(v.url))
                    player?.setMediaSource(src)
                    player?.prepare()
                    player?.playWhenReady = true
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        resolveJob?.cancel()
        player?.release()
        player = null
    }

    private inner class ShortsPagerAdapter : RecyclerView.Adapter<ShortVH>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShortVH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_short_page, parent, false)
            return ShortVH(v)
        }

        override fun onBindViewHolder(holder: ShortVH, position: Int) {
            holder.bind(shortsList[position], position)
        }

        override fun getItemCount(): Int = shortsList.size
    }

    private inner class ShortVH(v: View) : RecyclerView.ViewHolder(v) {
        private val playerView: PlayerView = v.findViewById(R.id.shortPlayerView)
        private val poster: ImageView = v.findViewById(R.id.shortPoster)
        private val progress: ProgressBar = v.findViewById(R.id.shortProgress)
        private val avatar: ImageView = v.findViewById(R.id.shortAvatar)
        private val channel: TextView = v.findViewById(R.id.shortChannel)
        private val subBtn: TextView = v.findViewById(R.id.shortSubBtn)
        private val title: TextView = v.findViewById(R.id.shortTitle)
        private val likeBtn: ImageButton = v.findViewById(R.id.shortLikeBtn)
        private val likeText: TextView = v.findViewById(R.id.shortLikeText)
        private val commentBtn: ImageButton = v.findViewById(R.id.shortCommentBtn)
        private val shareBtn: ImageButton = v.findViewById(R.id.shortShareBtn)
        private val moreBtn: ImageButton = v.findViewById(R.id.shortMoreBtn)

        private var isLiked = false
        private var isSubbed = false

        fun bind(item: VideoItem, pos: Int) {
            title.text = item.title
            channel.text = item.channel
            poster.visibility = View.VISIBLE
            progress.visibility = View.VISIBLE
            poster.load(item.thumbnailUrl) { crossfade(false) }

            val fallback = VideoAdapter.createLetterAvatar(item.channel)
            if (item.avatarUrl.isNotEmpty()) {
                avatar.load(item.avatarUrl) {
                    crossfade(false)
                    placeholder(fallback)
                    error(fallback)
                    transformations(CircleCropTransformation())
                }
            } else {
                avatar.setImageDrawable(fallback)
            }

            playerView.setOnClickListener {
                player?.let { p ->
                    p.playWhenReady = !p.isPlaying
                }
            }

            likeBtn.setOnClickListener {
                isLiked = !isLiked
                likeBtn.setColorFilter(if (isLiked) 0xFFFF0000.toInt() else 0xFFFFFFFF.toInt())
                likeText.text = if (isLiked) "Liked" else "Like"
            }

            subBtn.setOnClickListener {
                isSubbed = !isSubbed
                subBtn.text = if (isSubbed) "SUBSCRIBED" else "SUBSCRIBE"
                subBtn.setBackgroundColor(if (isSubbed) 0xFF555555.toInt() else 0xFFCC0000.toInt())
            }

            commentBtn.setOnClickListener {
                Toast.makeText(this@ShortsActivity, "Open full player for comments", Toast.LENGTH_SHORT).show()
            }

            shareBtn.setOnClickListener {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, item.url)
                }
                startActivity(Intent.createChooser(sendIntent, "Share Short"))
            }

            moreBtn.setOnClickListener {
                val intent = Intent(this@ShortsActivity, PlayerActivity::class.java).apply {
                    putExtra("video_url", item.url)
                    putExtra("video_title", item.title)
                    putExtra("channel_name", item.channel)
                    putExtra("thumb_url", item.thumbnailUrl)
                    putExtra("avatar_url", item.avatarUrl)
                    putExtra("duration_sec", item.durationSec)
                }
                startActivity(intent)
            }

            if (pos == currentPosition && activeHolder == null) {
                activeHolder = this
                attachPlayer(player)
            }
        }

        @OptIn(UnstableApi::class)
        fun setFitMode(mode: Int) {
            playerView.resizeMode = mode
        }

        fun attachPlayer(p: ExoPlayer?) {
            playerView.player = p
        }

        fun detachPlayer() {
            playerView.player = null
            poster.visibility = View.VISIBLE
        }

        fun hideLoading() {
            progress.visibility = View.GONE
            poster.visibility = View.GONE
        }
    }
}
