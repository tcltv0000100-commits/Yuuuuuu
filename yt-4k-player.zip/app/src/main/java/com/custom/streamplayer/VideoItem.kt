package com.custom.streamplayer

data class VideoItem(
    val title: String,
    val url: String,
    val channel: String,
    val thumbnailUrl: String,
    val avatarUrl: String,
    val durationSec: Long
)
