package com.custom.streamplayer

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream

class MainActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var urlInput: EditText
    private lateinit var loadBtn: Button
    private lateinit var qualityBtn: Button
    private lateinit var statusText: TextView

    private var videoStreams: List<VideoStream> = emptyList()
    private var bestAudio: AudioStream? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NewPipe.init(OkHttpDownloader())

        playerView = findViewById(R.id.playerView)
        urlInput = findViewById(R.id.urlInput)
        loadBtn = findViewById(R.id.loadBtn)
        qualityBtn = findViewById(R.id.qualityBtn)
        statusText = findViewById(R.id.statusText)

        player = ExoPlayer.Builder(this).build().also {
            playerView.player = it
        }

        loadBtn.setOnClickListener {
            val url = urlInput.text.toString().trim()
            if (url.isNotEmpty()) {
                fetchStreams(url)
            } else {
                Toast.makeText(this, "Enter a video URL", Toast.LENGTH_SHORT).show()
            }
        }

        qualityBtn.setOnClickListener {
            showQualityDialog()
        }
    }

    private fun fetchStreams(url: String) {
        statusText.text = "Fetching streams (including 2K/4K)..."
        qualityBtn.isEnabled = false

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val info = StreamInfo.getInfo(ServiceList.YouTube, url)
                val adaptiveVideos = info.videoOnlyStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .sortedByDescending { it.height }
                val audio = info.audioStreams
                    .filter { !it.content.isNullOrEmpty() }
                    .maxByOrNull { it.averageBitrate }

                withContext(Dispatchers.Main) {
                    if (adaptiveVideos.isEmpty() || audio == null) {
                        statusText.text = "No adaptive streams found."
                        return@withContext
                    }
                    videoStreams = adaptiveVideos
                    bestAudio = audio
                    qualityBtn.isEnabled = true

                    val highest = adaptiveVideos.first()
                    statusText.text = "Loaded: ${info.name} (Max: ${highest.resolution})"
                    playAdaptiveStream(highest, audio)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    statusText.text = "Error: ${e.localizedMessage}"
                }
            }
        }
    }

    @OptIn(UnstableApi::class)
    private fun playAdaptiveStream(video: VideoStream, audio: AudioStream) {
        val dataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")

        val videoSource = ProgressiveMediaSource.Factory(dataSourceFactory)
            .createMediaSource(MediaItem.fromUri(video.content))
        val audioSource = ProgressiveMediaSource.Factory(dataSourceFactory)
            .createMediaSource(MediaItem.fromUri(audio.content))

        val mergedSource = MergingMediaSource(videoSource, audioSource)

        player?.apply {
            setMediaSource(mergedSource)
            prepare()
            playWhenReady = true
        }
        qualityBtn.text = video.resolution
    }

    private fun showQualityDialog() {
        val labels = videoStreams.map { "${it.resolution} (${it.format?.name ?: "DASH"})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Select Video Resolution")
            .setItems(labels) { _, which ->
                val selected = videoStreams[which]
                val audio = bestAudio ?: return@setItems
                playAdaptiveStream(selected, audio)
            }
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}
