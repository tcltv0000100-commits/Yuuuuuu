package com.custom.streamplayer

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class MainActivity : AppCompatActivity() {

    private lateinit var feedRecycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var searchBarLayout: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var adapter: VideoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NewPipe.init(OkHttpDownloader())

        feedRecycler = findViewById(R.id.feedRecycler)
        progressBar = findViewById(R.id.progressBar)
        searchBarLayout = findViewById(R.id.searchBarLayout)
        searchInput = findViewById(R.id.searchInput)

        adapter = VideoAdapter { video -> openPlayer(video) }
        feedRecycler.layoutManager = LinearLayoutManager(this)
        feedRecycler.adapter = adapter

        findViewById<ImageButton>(R.id.searchIconBtn).setOnClickListener {
            searchBarLayout.visibility =
                if (searchBarLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        findViewById<Button>(R.id.searchGoBtn).setOnClickListener { runSearch() }
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch()
                true
            } else false
        }

        findViewById<ChipGroup>(R.id.chipGroup).setOnCheckedStateChangeListener { _, checkedIds ->
            when (checkedIds.firstOrNull()) {
                R.id.chipAll -> loadTrending()
                R.id.chipMusic -> loadSearch("latest music 4k")
                R.id.chip4K -> loadSearch("4k 60fps hdr demo")
                R.id.chipGaming -> loadSearch("gaming 4k gameplay")
                R.id.chipTech -> loadSearch("tech review 4k")
                R.id.chipMovies -> loadSearch("new movie trailer 4k")
            }
        }

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> loadTrending()
                R.id.nav_shorts -> loadSearch("#shorts")
                R.id.nav_subs -> loadSearch("popular channels")
                R.id.nav_library -> loadSearch("4k hdr nature")
            }
            true
        }

        loadTrending()
    }

    private fun runSearch() {
        val q = searchInput.text.toString().trim()
        if (q.isEmpty()) return
        if (q.startsWith("http://") || q.startsWith("https://")) {
            openPlayer(VideoItem("Loading video...", q, "", "", "", 0L))
        } else {
            loadSearch(q)
        }
    }

    private fun loadTrending() {
        progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val kiosk = ServiceList.YouTube.kioskList.defaultKioskExtractor
                kiosk.fetchPage()
                val videos = kiosk.initialPage.items
                    .filterIsInstance<StreamInfoItem>()
                    .map { it.toVideoItem() }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    adapter.submitList(videos)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "Feed error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadSearch(query: String) {
        progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(query)
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val videos = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .map { it.toVideoItem() }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    adapter.submitList(videos)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "Search error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun StreamInfoItem.toVideoItem(): VideoItem {
        val thumb = thumbnails.lastOrNull()?.url ?: thumbnails.firstOrNull()?.url ?: ""
        val avatar = uploaderAvatars.firstOrNull()?.url ?: ""
        return VideoItem(
            title = name ?: "Untitled",
            url = url ?: "",
            channel = uploaderName ?: "",
            thumbnailUrl = thumb,
            avatarUrl = avatar,
            durationSec = duration
        )
    }

    private fun openPlayer(video: VideoItem) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra("video_url", video.url)
            putExtra("video_title", video.title)
            putExtra("channel_name", video.channel)
        }
        startActivity(intent)
    }
}
