package com.custom.streamplayer

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class MainActivity : AppCompatActivity() {

    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var feedRecycler: RecyclerView
    private var currentQuery: String? = null
    private lateinit var progressBar: ProgressBar
    private lateinit var searchBarLayout: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var suggestionsList: ListView
    private lateinit var adapter: VideoAdapter

    private var suggestJob: Job? = null
    private var suppressSuggestions = false

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                searchBarLayout.visibility = View.GONE
                hideSuggestionsAndKeyboard()
                loadSearch(spoken)
            }
        }
    }
    private val currentSuggestions = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        NewPipe.init(OkHttpDownloader())

        swipeRefresh = findViewById(R.id.swipeRefresh)
        feedRecycler = findViewById(R.id.feedRecycler)
        swipeRefresh.setColorSchemeColors(0xFFFF0000.toInt())
        swipeRefresh.setOnRefreshListener {
            val q = currentQuery
            if (q != null) loadSearch(q) else loadHomeFeed()
        }
        progressBar = findViewById(R.id.progressBar)
        searchBarLayout = findViewById(R.id.searchBarLayout)
        searchInput = findViewById(R.id.searchInput)
        suggestionsList = findViewById(R.id.suggestionsList)

        adapter = VideoAdapter { video -> openPlayer(video) }
        feedRecycler.layoutManager = LinearLayoutManager(this)
        feedRecycler.adapter = adapter

        findViewById<ImageButton>(R.id.settingsIconBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<ImageButton>(R.id.searchIconBtn).setOnClickListener {
            val show = searchBarLayout.visibility != View.VISIBLE
            searchBarLayout.visibility = if (show) View.VISIBLE else View.GONE
            if (!show) hideSuggestionsAndKeyboard()
        }

        findViewById<ImageButton>(R.id.voiceSearchBtn).setOnClickListener {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to search...")
                }
                voiceLauncher.launch(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Voice search not supported on device", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<ImageButton>(R.id.searchClearBtn).setOnClickListener {
            searchInput.setText("")
            hideSuggestionsAndKeyboard()
        }

        findViewById<Button>(R.id.searchGoBtn).setOnClickListener {
            suggestJob?.cancel()
            searchBarLayout.visibility = View.GONE
            hideSuggestionsAndKeyboard()
            runSearch()
        }

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                suggestJob?.cancel()
                searchBarLayout.visibility = View.GONE
                hideSuggestionsAndKeyboard()
                runSearch()
                true
            } else false
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressSuggestions) return
                val q = s?.toString()?.trim() ?: ""
                suggestJob?.cancel()
                if (q.length < 2 || q.startsWith("http")) {
                    suggestionsList.visibility = View.GONE
                    return
                }
                suggestJob = CoroutineScope(Dispatchers.IO).launch {
                    delay(250)
                    try {
                        val list = ServiceList.YouTube.suggestionExtractor.suggestionList(q)
                        withContext(Dispatchers.Main) {
                            if (list.isNotEmpty() && searchBarLayout.visibility == View.VISIBLE) {
                                currentSuggestions.clear()
                                currentSuggestions.addAll(list.take(5))
                                suggestionsList.adapter = ArrayAdapter(
                                    this@MainActivity,
                                    android.R.layout.simple_list_item_1,
                                    currentSuggestions
                                )
                                suggestionsList.visibility = View.VISIBLE
                            } else {
                                suggestionsList.visibility = View.GONE
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        })

        suggestionsList.setOnItemClickListener { _, _, position, _ ->
            val selected = currentSuggestions[position]
            suggestJob?.cancel()
            suppressSuggestions = true
            searchInput.setText("")
            suppressSuggestions = false
            searchBarLayout.visibility = View.GONE
            hideSuggestionsAndKeyboard()
            loadSearch(selected)
        }

        findViewById<ChipGroup>(R.id.chipGroup).setOnCheckedStateChangeListener { _, checkedIds ->
            hideSuggestionsAndKeyboard()
            when (checkedIds.firstOrNull()) {
                R.id.chipAll -> loadHomeFeed()
                R.id.chipMusic -> loadSearch("latest music 4k")
                R.id.chip4K -> loadSearch("4k 60fps hdr demo")
                R.id.chipGaming -> loadSearch("gaming 4k gameplay")
                R.id.chipTech -> loadSearch("tech review 4k")
                R.id.chipMovies -> loadSearch("new movie trailer 4k")
            }
        }

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            hideSuggestionsAndKeyboard()
            when (item.itemId) {
                R.id.nav_home -> loadHomeFeed()
                R.id.nav_shorts -> startActivity(Intent(this, ShortsActivity::class.java))
                R.id.nav_subs -> loadSearch("popular channels")
                R.id.nav_history -> loadHistory()
            }
            true
        }

        loadHomeFeed()
    }

    private fun hideSuggestionsAndKeyboard() {
        suggestionsList.visibility = View.GONE
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
    }



    private fun loadHistory() {
        val history = HistoryStore.getAll(this)
        if (history.isEmpty()) {
            Toast.makeText(this, "No watch history yet", Toast.LENGTH_SHORT).show()
        }
        adapter.submitList(history)
    }

    private fun runSearch() {
        val q = searchInput.text.toString().trim()
        suppressSuggestions = true
        searchInput.setText("")
        suppressSuggestions = false
        if (q.isEmpty()) return
        if (q.startsWith("http://") || q.startsWith("https://")) {
            openPlayer(VideoItem("Loading video...", q, "", "", "", 0L))
        } else {
            loadSearch(q)
        }
    }

    private fun loadHomeFeed() {
        val prefs = getSharedPreferences("yt_prefs", Context.MODE_PRIVATE)
        val lastSearch = prefs.getString("last_interest", null)
        val recent = HistoryStore.getAll(this).firstOrNull()
        val interest = when {
            !lastSearch.isNullOrBlank() -> lastSearch
            recent != null && recent.channel.isNotBlank() -> recent.channel
            recent != null && recent.title.isNotBlank() -> recent.title.split(" ").take(3).joinToString(" ")
            else -> "latest hindi 4k songs trailers"
        }
        loadSearch(interest)
    }

    private fun loadSearch(query: String) {
        currentQuery = query
        if (query != "#shorts" && query != "youtube shorts") {
            getSharedPreferences("yt_prefs", Context.MODE_PRIVATE).edit().putString("last_interest", query).apply()
        }
        progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(query)
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val videos = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .map { it.toVideoItem() }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    adapter.submitList(videos)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    Toast.makeText(this@MainActivity, "Search error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun StreamInfoItem.toVideoItem(): VideoItem {
        val thumb = thumbnails.lastOrNull()?.url ?: thumbnails.firstOrNull()?.url ?: ""
        val avatar = uploaderAvatars.firstOrNull()?.url ?: ""
        return VideoItem(
            title = name ?: "Untitled",
            url = url ?: "",
            channel = uploaderName ?: "",
            thumbnailUrl = thumb,
            avatarUrl = avatar,
            durationSec = duration
        )
    }

    private fun openPlayer(video: VideoItem) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra("video_url", video.url)
            putExtra("video_title", video.title)
            putExtra("channel_name", video.channel)
            putExtra("thumb_url", video.thumbnailUrl)
            putExtra("avatar_url", video.avatarUrl)
            putExtra("duration_sec", video.durationSec)
        }
        startActivity(intent)
    }
}
