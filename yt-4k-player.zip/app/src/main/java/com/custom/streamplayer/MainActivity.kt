package com.custom.streamplayer

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.transition.TransitionManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class MainActivity : AppCompatActivity() {

    private lateinit var mainRoot: LinearLayout
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var feedRecycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var searchBarLayout: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var searchDropdownContainer: LinearLayout
    private lateinit var searchHistoryHeader: LinearLayout
    private lateinit var suggestionsList: ListView
    private lateinit var historyHeaderBar: LinearLayout
    private lateinit var chipScroll: View
    private lateinit var adapter: VideoAdapter

    private var suggestJob: Job? = null
    private var feedJob: Job? = null
    private var suppressSuggestions = false
    private val currentSuggestions = mutableListOf<String>()
    private var showingSavedSearchHistory = false

    private val feedItems = mutableListOf<VideoItem>()
    private var currentQuery: String? = null
    private var nextPage: Page? = null
    private var isLoadingMore = false
    private var isHistoryMode = false
    private var isShortsMode = false
    private var refreshSeedIndex = 0

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) {
            val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                closeSearchBar()
                loadSearch(spoken)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mainRoot = findViewById(R.id.mainRoot)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        feedRecycler = findViewById(R.id.feedRecycler)
        progressBar = findViewById(R.id.progressBar)
        searchBarLayout = findViewById(R.id.searchBarLayout)
        searchInput = findViewById(R.id.searchInput)
        searchDropdownContainer = findViewById(R.id.searchDropdownContainer)
        searchHistoryHeader = findViewById(R.id.searchHistoryHeader)
        suggestionsList = findViewById(R.id.suggestionsList)
        historyHeaderBar = findViewById(R.id.historyHeaderBar)
        chipScroll = findViewById(R.id.chipScroll)

        adapter = VideoAdapter { video -> openPlayer(video) }
        val layoutMgr = LinearLayoutManager(this)
        feedRecycler.layoutManager = layoutMgr
        feedRecycler.adapter = adapter
        feedRecycler.setItemViewCacheSize(16)

        // Instant Home Feed from cache on APK open (0ms startup!)
        val cachedHome = HistoryStore.getHomeCache(this)
        if (cachedHome.isNotEmpty()) {
            feedItems.addAll(cachedHome)
            adapter.submitList(feedItems)
        }

        // Infinite scroll pagination
        feedRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy <= 0 || isLoadingMore || isHistoryMode || nextPage == null) return
                val total = layoutMgr.itemCount
                val lastVisible = layoutMgr.findLastVisibleItemPosition()
                if (lastVisible >= total - 4) {
                    loadMoreResults()
                }
            }
        })

        swipeRefresh.setColorSchemeColors(0xFFFF0000.toInt())
        swipeRefresh.setOnRefreshListener {
            refreshSeedIndex++
            loadHomeFeed(forceRotate = true, showSpinner = false)
        }

        findViewById<ImageButton>(R.id.settingsIconBtn).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<ImageButton>(R.id.searchIconBtn).setOnClickListener {
            if (searchBarLayout.visibility != View.VISIBLE) {
                openSearchBar()
            } else {
                closeSearchBar()
            }
        }

        findViewById<TextView>(R.id.clearSearchHistoryBtn).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear search history?")
                .setMessage("Remove all saved searches?")
                .setPositiveButton("Clear") { _, _ ->
                    HistoryStore.clearSearches(this)
                    showSavedSearchHistory()
                    Toast.makeText(this, "Search history cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<TextView>(R.id.clearWatchHistoryBtn).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear watch history?")
                .setMessage("Remove all watched videos from history?")
                .setPositiveButton("Clear") { _, _ ->
                    HistoryStore.clearWatchHistory(this)
                    feedItems.clear()
                    adapter.submitList(emptyList())
                    Toast.makeText(this, "Watch history cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<ImageButton>(R.id.voiceSearchBtn).setOnClickListener {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to search...")
                }
                voiceLauncher.launch(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Voice search not supported on device", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<ImageButton>(R.id.searchClearBtn).setOnClickListener {
            searchInput.setText("")
            showSavedSearchHistory()
        }

        findViewById<Button>(R.id.searchGoBtn).setOnClickListener {
            suggestJob?.cancel()
            closeSearchBar()
            runSearch()
        }

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                suggestJob?.cancel()
                closeSearchBar()
                runSearch()
                true
            } else false
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (suppressSuggestions) return
                val q = s?.toString()?.trim() ?: ""
                suggestJob?.cancel()
                if (q.isEmpty()) {
                    if (searchBarLayout.visibility == View.VISIBLE) {
                        showSavedSearchHistory()
                    }
                    return
                }
                if (q.length < 2 || q.startsWith("http")) {
                    searchDropdownContainer.visibility = View.GONE
                    return
                }
                suggestJob = CoroutineScope(Dispatchers.IO).launch {
                    delay(200)
                    try {
                        val list = ServiceList.YouTube.suggestionExtractor.suggestionList(q)
                        withContext(Dispatchers.Main) {
                            if (list.isNotEmpty() && searchBarLayout.visibility == View.VISIBLE) {
                                showingSavedSearchHistory = false
                                searchHistoryHeader.visibility = View.GONE
                                currentSuggestions.clear()
                                currentSuggestions.addAll(list.take(6))
                                suggestionsList.adapter = SearchSuggestionAdapter(
                                    items = currentSuggestions,
                                    isHistory = false,
                                    onDelete = null
                                )
                                searchDropdownContainer.visibility = View.VISIBLE
                            } else {
                                searchDropdownContainer.visibility = View.GONE
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        })

        suggestionsList.setOnItemClickListener { _, _, position, _ ->
            val selected = currentSuggestions.getOrNull(position) ?: return@setOnItemClickListener
            suggestJob?.cancel()
            suppressSuggestions = true
            searchInput.setText("")
            suppressSuggestions = false
            closeSearchBar()
            loadSearch(selected)
        }

        findViewById<ChipGroup>(R.id.chipGroup).setOnCheckedStateChangeListener { _, checkedIds ->
            hideSuggestionsAndKeyboard()
            animateFeedTransition()
            when (checkedIds.firstOrNull()) {
                R.id.chipAll -> loadHomeFeed(forceRotate = false, showSpinner = feedItems.isEmpty())
                R.id.chipMusic -> loadSearch("latest music 4k", saveSearch = false)
                R.id.chip4K -> loadSearch("4k 60fps hdr demo", saveSearch = false)
                R.id.chipGaming -> loadSearch("gaming 4k gameplay", saveSearch = false)
                R.id.chipTech -> loadSearch("tech review 4k", saveSearch = false)
                R.id.chipMovies -> loadSearch("new movie trailer 4k", saveSearch = false)
            }
        }

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            hideSuggestionsAndKeyboard()
            animateFeedTransition()
            when (item.itemId) {
                R.id.nav_home -> {
                    isShortsMode = false
                    historyHeaderBar.visibility = View.GONE
                    chipScroll.visibility = View.VISIBLE
                    loadHomeFeed(forceRotate = false, showSpinner = feedItems.isEmpty())
                }
                R.id.nav_shorts -> {
                    loadShortsFeed()
                }
                R.id.nav_subs -> {
                    isShortsMode = false
                    historyHeaderBar.visibility = View.GONE
                    chipScroll.visibility = View.VISIBLE
                    loadSearch("popular channels new videos", saveSearch = false)
                }
                R.id.nav_history -> loadHistory()
            }
            true
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (searchBarLayout.visibility == View.VISIBLE) {
                    closeSearchBar()
                    return
                }
                PlayerActivity.closePipIfActive()
                finish()
            }
        })

        // Refresh home feed silently in background if cache was already shown
        loadHomeFeed(forceRotate = false, showSpinner = cachedHome.isEmpty())
    }

    override fun onDestroy() {
        feedJob?.cancel()
        suggestJob?.cancel()
        if (isFinishing) {
            PlayerActivity.closePipIfActive()
        }
        super.onDestroy()
    }

    private fun openSearchBar() {
        TransitionManager.beginDelayedTransition(mainRoot)
        searchBarLayout.visibility = View.VISIBLE
        searchInput.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        if (searchInput.text.isNullOrBlank()) {
            showSavedSearchHistory()
        }
    }

    private fun closeSearchBar() {
        TransitionManager.beginDelayedTransition(mainRoot)
        searchBarLayout.visibility = View.GONE
        hideSuggestionsAndKeyboard()
    }

    private fun showSavedSearchHistory() {
        val saved = HistoryStore.getSearches(this)
        if (saved.isEmpty()) {
            searchDropdownContainer.visibility = View.GONE
            return
        }
        showingSavedSearchHistory = true
        searchHistoryHeader.visibility = View.VISIBLE
        currentSuggestions.clear()
        currentSuggestions.addAll(saved)
        suggestionsList.adapter = SearchSuggestionAdapter(
            items = currentSuggestions,
            isHistory = true,
            onDelete = { query ->
                HistoryStore.removeSearch(this, query)
                showSavedSearchHistory()
            }
        )
        searchDropdownContainer.visibility = View.VISIBLE
    }

    private fun hideSuggestionsAndKeyboard() {
        searchDropdownContainer.visibility = View.GONE
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
    }

    private fun animateFeedTransition() {
        feedRecycler.alpha = 0.65f
        feedRecycler.animate().alpha(1f).setDuration(180).start()
    }

    private fun loadShortsFeed() {
        isHistoryMode = false
        isShortsMode = true
        historyHeaderBar.visibility = View.GONE
        chipScroll.visibility = View.GONE
        currentQuery = "#shorts trending india"
        nextPage = null
        feedJob?.cancel()

        val cachedShorts = HistoryStore.getShortsCache(this)
        if (cachedShorts.isNotEmpty()) {
            feedItems.clear()
            feedItems.addAll(cachedShorts)
            adapter.submitList(feedItems)
            cachedShorts.take(3).forEach { InnertubeStreamResolver.prefetch(it.url) }
        } else {
            progressBar.visibility = View.VISIBLE
        }

        feedJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery("#shorts trending india")
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val all = info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toVideoItem() }
                val shorts = all.filter { it.url.contains("/shorts/") || it.durationSec in 1..90 }
                    .ifEmpty { all.take(20) }
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    if (shorts.isNotEmpty()) {
                        nextPage = info.nextPage
                        feedItems.clear()
                        feedItems.addAll(shorts)
                        adapter.submitList(feedItems)
                        HistoryStore.saveShortsCache(this@MainActivity, shorts)
                        shorts.take(3).forEach { InnertubeStreamResolver.prefetch(it.url) }
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                }
            }
        }
    }

    private fun loadHistory() {
        isShortsMode = false
        feedJob?.cancel()
        isHistoryMode = true
        nextPage = null
        progressBar.visibility = View.GONE
        chipScroll.visibility = View.GONE
        historyHeaderBar.visibility = View.VISIBLE
        val history = HistoryStore.getAll(this)
        if (history.isEmpty()) {
            Toast.makeText(this, "No watch history yet", Toast.LENGTH_SHORT).show()
        }
        feedItems.clear()
        feedItems.addAll(history)
        adapter.submitList(feedItems)
    }

    private fun runSearch() {
        val q = searchInput.text.toString().trim()
        suppressSuggestions = true
        searchInput.setText("")
        suppressSuggestions = false
        if (q.isEmpty()) return
        if (q.startsWith("http://") || q.startsWith("https://")) {
            openPlayer(VideoItem("Loading video...", q, "", "", "", 0L))
        } else {
            loadSearch(q, saveSearch = true)
        }
    }

    /**
     * Original YouTube-style Home Feed:
     * Mixes real YouTube Trending/New videos with diverse discovery topics
     * and at most a small (max 4 videos) slice from recent watch/search history,
     * so watching a single topic (like kids) never hijacks the entire home screen.
     */
    private fun loadHomeFeed(forceRotate: Boolean, showSpinner: Boolean = true) {
        isHistoryMode = false
        historyHeaderBar.visibility = View.GONE
        chipScroll.visibility = View.VISIBLE
        feedJob?.cancel()
        if (showSpinner && feedItems.isEmpty()) {
            progressBar.visibility = View.VISIBLE
        }

        val history = HistoryStore.getAll(this)
        val recentSearches = HistoryStore.getSearches(this)

        val discoveryPool = listOf(
            "latest hindi songs 2025 4k",
            "new tech review india",
            "trending gaming india",
            "new movie trailer 4k",
            "popular podcasts india",
            "cricket highlights india"
        )
        val discoveryQuery = discoveryPool[refreshSeedIndex % discoveryPool.size]
        val secondDiscovery = discoveryPool[(refreshSeedIndex + 2) % discoveryPool.size]

        // Small personalized query (from last watched or last search) — strictly capped to 4 items
        val personalQuery = recentSearches.firstOrNull()
            ?: history.firstOrNull()?.channel?.takeIf { it.isNotBlank() }

        currentQuery = discoveryQuery

        feedJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val (trendingList, discoveryPair, personalList) = coroutineScope {
                    val trendingDeferred = async {
                        try {
                            val kiosk = ServiceList.YouTube.kioskList.defaultKioskExtractor
                            val info = KioskInfo.getInfo(kiosk)
                            info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toVideoItem() }
                        } catch (_: Exception) {
                            emptyList()
                        }
                    }

                    val discoveryDeferred = async {
                        try {
                            val qh = ServiceList.YouTube.searchQHFactory.fromQuery(discoveryQuery)
                            val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                            val items = info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toVideoItem() }
                            Pair(items, info.nextPage)
                        } catch (_: Exception) {
                            Pair(emptyList<VideoItem>(), null as Page?)
                        }
                    }

                    val secondDeferred = async {
                        try {
                            val qh = ServiceList.YouTube.searchQHFactory.fromQuery(secondDiscovery)
                            SearchInfo.getInfo(ServiceList.YouTube, qh)
                                .relatedItems.filterIsInstance<StreamInfoItem>()
                                .take(5)
                                .map { it.toVideoItem() }
                        } catch (_: Exception) {
                            emptyList()
                        }
                    }

                    val personalDeferred = async {
                        if (personalQuery.isNullOrBlank()) emptyList()
                        else try {
                            val qh = ServiceList.YouTube.searchQHFactory.fromQuery(personalQuery)
                            SearchInfo.getInfo(ServiceList.YouTube, qh)
                                .relatedItems.filterIsInstance<StreamInfoItem>()
                                .take(4)
                                .map { it.toVideoItem() }
                        } catch (_: Exception) {
                            emptyList()
                        }
                    }

                    val t = trendingDeferred.await()
                    val d1 = discoveryDeferred.await()
                    val d2 = secondDeferred.await()
                    val p = personalDeferred.await()
                    Triple(t, Pair(d1.first + d2, d1.second), p)
                }

                // Interleave Trending + Diverse Discovery + small Personal slice (just like real YouTube Home)
                val blended = mutableListOf<VideoItem>()
                val seen = HashSet<String>()
                fun addUnique(v: VideoItem) {
                    if (v.url.isNotBlank() && v.title.isNotBlank() && seen.add(v.url)) {
                        blended.add(v)
                    }
                }

                val tList = if (forceRotate && trendingList.size > 4) trendingList.shuffled() else trendingList
                val dList = discoveryPair.first
                val pList = personalList

                val maxLen = maxOf(tList.size, dList.size, pList.size)
                var pIdx = 0
                for (i in 0 until maxLen) {
                    if (i < tList.size) addUnique(tList[i])
                    if (i < dList.size) addUnique(dList[i])
                    if (i % 3 == 1 && pIdx < pList.size) {
                        addUnique(pList[pIdx++])
                    }
                }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    if (blended.isNotEmpty()) {
                        nextPage = discoveryPair.second
                        feedItems.clear()
                        feedItems.addAll(blended)
                        adapter.submitList(feedItems)
                        HistoryStore.saveHomeCache(this@MainActivity, blended)
                        blended.take(2).forEach { InnertubeStreamResolver.prefetch(it.url) }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    if (feedItems.isEmpty()) {
                        Toast.makeText(this@MainActivity, "Feed error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun loadSearch(query: String, saveSearch: Boolean = true) {
        isHistoryMode = false
        historyHeaderBar.visibility = View.GONE
        chipScroll.visibility = View.VISIBLE
        currentQuery = query
        nextPage = null
        isLoadingMore = false
        if (saveSearch) {
            HistoryStore.addSearch(this, query)
        }
        feedJob?.cancel()
        progressBar.visibility = View.VISIBLE
        feedJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(query)
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val videos = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .map { it.toVideoItem() }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    nextPage = info.nextPage
                    feedItems.clear()
                    feedItems.addAll(videos)
                    adapter.submitList(feedItems)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    Toast.makeText(this@MainActivity, "Feed error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun loadMoreResults() {
        val q = currentQuery ?: return
        val page = nextPage ?: return
        isLoadingMore = true
        progressBar.visibility = View.VISIBLE
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(q)
                val more = SearchInfo.getMoreItems(ServiceList.YouTube, qh, page)
                val newVideos = more.items
                    .filterIsInstance<StreamInfoItem>()
                    .map { it.toVideoItem() }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    isLoadingMore = false
                    nextPage = more.nextPage
                    val existingUrls = feedItems.map { it.url }.toHashSet()
                    val uniqueNew = newVideos.filter { it.url !in existingUrls }
                    if (uniqueNew.isNotEmpty()) {
                        feedItems.addAll(uniqueNew)
                        adapter.submitList(feedItems)
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    isLoadingMore = false
                }
            }
        }
    }

    private fun StreamInfoItem.toVideoItem(): VideoItem {
        val thumb = thumbnails.lastOrNull()?.url ?: thumbnails.firstOrNull()?.url ?: ""
        val avatar = uploaderAvatars.firstOrNull()?.url ?: ""
        return VideoItem(
            title = name ?: "Untitled",
            url = url ?: "",
            channel = uploaderName ?: "",
            thumbnailUrl = thumb,
            avatarUrl = avatar,
            durationSec = duration
        )
    }

    private fun openPlayer(video: VideoItem) {
        if (isShortsMode || video.url.contains("/shorts/")) {
            PlayerActivity.closePipIfActive()
            val list = if (isShortsMode && feedItems.isNotEmpty()) feedItems else listOf(video)
            val idx = list.indexOfFirst { it.url == video.url }.coerceAtLeast(0)
            val intent = Intent(this, ShortsActivity::class.java).apply {
                putStringArrayListExtra("short_urls", ArrayList(list.map { it.url }))
                putStringArrayListExtra("short_titles", ArrayList(list.map { it.title }))
                putStringArrayListExtra("short_channels", ArrayList(list.map { it.channel }))
                putStringArrayListExtra("short_thumbs", ArrayList(list.map { it.thumbnailUrl }))
                putStringArrayListExtra("short_avatars", ArrayList(list.map { it.avatarUrl }))
                putExtra("start_index", idx)
            }
            startActivity(intent)
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.slide_in_up, R.anim.hold_fade)
            return
        }
        PlayerActivity.closePipIfActive()
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra("video_url", video.url)
            putExtra("video_title", video.title)
            putExtra("channel_name", video.channel)
            putExtra("thumb_url", video.thumbnailUrl)
            putExtra("avatar_url", video.avatarUrl)
            putExtra("duration_sec", video.durationSec)
        }
        startActivity(intent)
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_in_up, R.anim.hold_fade)
    }

    private inner class SearchSuggestionAdapter(
        private val items: List<String>,
        private val isHistory: Boolean,
        private val onDelete: ((String) -> Unit)?
    ) : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): String = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(parent.context)
                .inflate(R.layout.item_search_history, parent, false)
            val icon = view.findViewById<ImageView>(R.id.historyItemIcon)
            val text = view.findViewById<TextView>(R.id.historyItemText)
            val del = view.findViewById<ImageButton>(R.id.historyItemDelete)
            val query = items[position]

            text.text = query
            icon.setImageResource(
                if (isHistory) android.R.drawable.ic_menu_recent_history
                else android.R.drawable.ic_menu_search
            )
            if (isHistory && onDelete != null) {
                del.visibility = View.VISIBLE
                del.setOnClickListener { onDelete.invoke(query) }
            } else {
                del.visibility = View.GONE
            }
            return view
        }
    }
}
