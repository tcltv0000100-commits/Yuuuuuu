package com.custom.streamplayer

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import coil.load
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.Page
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

class MainActivity : AppCompatActivity() {

    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var feedRecycler: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var historyHeaderBar: LinearLayout
    private lateinit var chipScroll: View
    private lateinit var subsEmptyContainer: LinearLayout
    private lateinit var libraryContainer: LinearLayout
    private lateinit var localHistoryRecycler: RecyclerView
    private lateinit var libSignInBanner: LinearLayout
    private lateinit var bottomNav: BottomNavigationView

    private lateinit var adapter: VideoAdapter
    private val skeletonAdapter = SkeletonAdapter(4)
    private var lastAppliedTheme: Boolean = false

    private var feedJob: Job? = null
    private val feedItems = mutableListOf<VideoItem>()
    private var currentQuery: String? = null
    private var nextPage: Page? = null
    private var isLoadingMore = false
    private var isHistoryMode = false
    private var refreshSeedIndex = 0
    private var infinitePoolIndex = 0

    private val infiniteTopics = listOf(
        "latest hindi songs 4k",
        "trending music videos india",
        "new tech review 4k",
        "4k 60fps hdr nature",
        "gaming 4k gameplay",
        "new movie trailer 4k",
        "popular podcasts india",
        "cricket highlights india",
        "live news india",
        "comedy shows india"
    )

    private val searchLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) {
            val q = res.data?.getStringExtra("search_query")?.trim() ?: ""
            if (q.isNotEmpty()) {
                showFeedContainer()
                if (q.startsWith("http://") || q.startsWith("https://")) {
                    openPlayer(VideoItem("Loading video...", q, "", "", "", 0L))
                } else {
                    loadSearch(q, saveSearch = true)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val nowDark = ThemeHelper.isDark(this)
        if (nowDark != lastAppliedTheme) {
            lastAppliedTheme = nowDark
            ThemeHelper.applyTheme(this)
            recreate()
            return
        }
        if (libraryContainer.visibility == View.VISIBLE) {
            refreshLibraryUi()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        lastAppliedTheme = ThemeHelper.isDark(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        swipeRefresh = findViewById(R.id.swipeRefresh)
        feedRecycler = findViewById(R.id.feedRecycler)
        progressBar = findViewById(R.id.progressBar)
        historyHeaderBar = findViewById(R.id.historyHeaderBar)
        chipScroll = findViewById(R.id.chipScroll)
        subsEmptyContainer = findViewById(R.id.subsEmptyContainer)
        libraryContainer = findViewById(R.id.libraryContainer)
        localHistoryRecycler = findViewById(R.id.localHistoryRecycler)
        libSignInBanner = findViewById(R.id.libSignInBanner)
        bottomNav = findViewById(R.id.bottomNav)

        adapter = VideoAdapter { video -> openPlayer(video) }
        val layoutMgr = LinearLayoutManager(this)
        feedRecycler.layoutManager = layoutMgr
        feedRecycler.adapter = adapter
        feedRecycler.setItemViewCacheSize(16)

        localHistoryRecycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        // Instant Home Feed from cache on APK open
        val cachedHome = HistoryStore.getHomeCache(this)
        if (cachedHome.isNotEmpty()) {
            feedItems.addAll(cachedHome)
            adapter.submitList(feedItems)
        } else {
            feedRecycler.adapter = skeletonAdapter
        }

        // True Infinite Scroll Pagination (never stops at a dead end)
        feedRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy <= 0 || isLoadingMore || isHistoryMode) return
                if (feedRecycler.adapter !== adapter) return
                val total = layoutMgr.itemCount
                val lastVisible = layoutMgr.findLastVisibleItemPosition()
                if (total > 0 && lastVisible >= total - 4) {
                    loadMoreResults()
                }
            }
        })

        swipeRefresh.setColorSchemeColors(0xFFFF0000.toInt())
        swipeRefresh.setOnRefreshListener {
            refreshSeedIndex++
            feedRecycler.adapter = skeletonAdapter
            loadHomeFeed(forceRotate = true, showSpinner = false)
        }

        findViewById<ImageButton>(R.id.notifIconBtn).setOnClickListener {
            Toast.makeText(this, "No new notifications", Toast.LENGTH_SHORT).show()
        }

        findViewById<ImageButton>(R.id.searchIconBtn).setOnClickListener {
            searchLauncher.launch(Intent(this, SearchActivity::class.java))
        }

        findViewById<ImageButton>(R.id.profileIconBtn).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        findViewById<ImageButton>(R.id.historyBackBtn).setOnClickListener {
            showLibraryTab()
        }

        findViewById<TextView>(R.id.clearWatchHistoryBtn).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Clear watch history?")
                .setMessage("Remove all watched videos from history?")
                .setPositiveButton("Clear") { _, _ ->
                    HistoryStore.clearWatchHistory(this)
                    feedItems.clear()
                    adapter.submitList(emptyList())
                    Toast.makeText(this, "Watch history cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<Button>(R.id.subsSignInBtn).setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }

        findViewById<Button>(R.id.libSignInBtn).setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }

        setupLibraryRows()

        findViewById<ChipGroup>(R.id.chipGroup).setOnCheckedStateChangeListener { _, checkedIds ->
            showFeedContainer()
            animateFeedTransition()
            when (checkedIds.firstOrNull()) {
                R.id.chipAll -> loadHomeFeed(forceRotate = false, showSpinner = true)
                R.id.chipMusic -> loadSearch("latest music 4k", saveSearch = false)
                R.id.chipNews -> loadSearch("live news india today", saveSearch = false)
                R.id.chipLive -> loadSearch("live stream music gaming news", saveSearch = false)
                R.id.chipTalent -> loadSearch("talent shows performances", saveSearch = false)
                R.id.chipPodcasts -> loadSearch("popular podcasts india", saveSearch = false)
                R.id.chipGaming -> loadSearch("gaming 4k gameplay", saveSearch = false)
                R.id.chip4K -> loadSearch("4k 60fps hdr demo", saveSearch = false)
            }
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> {
                    showFeedContainer()
                    animateFeedTransition()
                    loadHomeFeed(forceRotate = false, showSpinner = feedItems.isEmpty())
                    true
                }
                R.id.nav_shorts -> {
                    launchShortsPlayer()
                    false
                }
                R.id.nav_subs -> {
                    showSubscriptionsTab()
                    true
                }
                R.id.nav_library -> {
                    showLibraryTab()
                    true
                }
                else -> false
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isHistoryMode) {
                    showLibraryTab()
                    return
                }
                if (bottomNav.selectedItemId != R.id.nav_home) {
                    bottomNav.selectedItemId = R.id.nav_home
                    return
                }
                PlayerActivity.closePipIfActive()
                finish()
            }
        })

        // Refresh home feed silently in background if cache was already shown
        loadHomeFeed(forceRotate = false, showSpinner = cachedHome.isEmpty())
    }

    override fun onDestroy() {
        feedJob?.cancel()
        if (isFinishing) {
            PlayerActivity.closePipIfActive()
        }
        super.onDestroy()
    }

    private fun showFeedContainer() {
        isHistoryMode = false
        subsEmptyContainer.visibility = View.GONE
        libraryContainer.visibility = View.GONE
        historyHeaderBar.visibility = View.GONE
        swipeRefresh.visibility = View.VISIBLE
        chipScroll.visibility = View.VISIBLE
    }

    private fun showSubscriptionsTab() {
        isHistoryMode = false
        libraryContainer.visibility = View.GONE
        historyHeaderBar.visibility = View.GONE
        if (YouTubeAuthStore.isLoggedIn(this)) {
            subsEmptyContainer.visibility = View.GONE
            swipeRefresh.visibility = View.VISIBLE
            chipScroll.visibility = View.VISIBLE
            loadSearch("popular channels new videos", saveSearch = false)
        } else {
            swipeRefresh.visibility = View.GONE
            chipScroll.visibility = View.GONE
            subsEmptyContainer.visibility = View.VISIBLE
        }
    }

    private fun showLibraryTab() {
        isHistoryMode = false
        subsEmptyContainer.visibility = View.GONE
        swipeRefresh.visibility = View.GONE
        chipScroll.visibility = View.GONE
        historyHeaderBar.visibility = View.GONE
        libraryContainer.visibility = View.VISIBLE
        refreshLibraryUi()
    }

    private fun refreshLibraryUi() {
        val loggedIn = YouTubeAuthStore.isLoggedIn(this)
        libSignInBanner.visibility = if (loggedIn) View.GONE else View.VISIBLE

        val history = HistoryStore.getAll(this)
        findViewById<TextView>(R.id.localHistoryTitle).visibility =
            if (history.isEmpty()) View.GONE else View.VISIBLE
        localHistoryRecycler.visibility =
            if (history.isEmpty()) View.GONE else View.VISIBLE
        if (history.isNotEmpty()) {
            localHistoryRecycler.adapter = LocalHistoryAdapter(history.take(15))
        }
    }

    private fun setupLibraryRows() {
        fun requireSignInOrOpen(label: String) {
            if (YouTubeAuthStore.isLoggedIn(this)) {
                loadLocalHistoryList()
            } else {
                AlertDialog.Builder(this)
                    .setMessage("Sign in to browse your $label")
                    .setNegativeButton("CANCEL", null)
                    .setPositiveButton("SIGN IN") { _, _ ->
                        startActivity(Intent(this, LoginActivity::class.java))
                    }
                    .show()
            }
        }

        findViewById<LinearLayout>(R.id.libRowHistory).setOnClickListener {
            if (HistoryStore.getAll(this).isNotEmpty() && YouTubeAuthStore.isLoggedIn(this)) {
                loadLocalHistoryList()
            } else {
                requireSignInOrOpen("History")
            }
        }
        findViewById<LinearLayout>(R.id.libRowWatchLater).setOnClickListener {
            requireSignInOrOpen("Watch later")
        }
        findViewById<LinearLayout>(R.id.libRowLiked).setOnClickListener {
            requireSignInOrOpen("Liked videos")
        }
        findViewById<LinearLayout>(R.id.libRowPlaylist).setOnClickListener {
            requireSignInOrOpen("Playlist")
        }
    }

    private fun loadLocalHistoryList() {
        feedJob?.cancel()
        isHistoryMode = true
        nextPage = null
        progressBar.visibility = View.GONE
        subsEmptyContainer.visibility = View.GONE
        libraryContainer.visibility = View.GONE
        chipScroll.visibility = View.GONE
        swipeRefresh.visibility = View.VISIBLE
        historyHeaderBar.visibility = View.VISIBLE

        val history = HistoryStore.getAll(this)
        feedItems.clear()
        feedItems.addAll(history)
        feedRecycler.adapter = adapter
        adapter.submitList(feedItems)
    }

    private fun animateFeedTransition() {
        feedRecycler.alpha = 0.65f
        feedRecycler.animate().alpha(1f).setDuration(180).start()
    }

    private fun launchShortsPlayer() {
        PlayerActivity.closePipIfActive()
        val prefs = getSharedPreferences("yt_prefs", MODE_PRIVATE)
        val launchCount = prefs.getInt("shorts_launch_count", 0)
        prefs.edit().putInt("shorts_launch_count", launchCount + 1).apply()

        val cachedShorts = HistoryStore.getShortsCache(this)
        val rotated = if (cachedShorts.size > 1) {
            val shift = (launchCount * 3) % cachedShorts.size
            cachedShorts.drop(shift) + cachedShorts.take(shift)
        } else {
            cachedShorts
        }

        val intent = Intent(this, ShortsActivity::class.java).apply {
            putExtra("query_offset", launchCount)
            if (rotated.isNotEmpty() && launchCount % 2 == 0) {
                putStringArrayListExtra("short_urls", ArrayList(rotated.map { it.url }))
                putStringArrayListExtra("short_titles", ArrayList(rotated.map { it.title }))
                putStringArrayListExtra("short_channels", ArrayList(rotated.map { it.channel }))
                putStringArrayListExtra("short_thumbs", ArrayList(rotated.map { it.thumbnailUrl }))
                putStringArrayListExtra("short_avatars", ArrayList(rotated.map { it.avatarUrl }))
                putExtra("start_index", 0)
            }
        }
        startActivity(intent)
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_in_up, R.anim.hold_fade)
    }

    private fun loadHomeFeed(forceRotate: Boolean, showSpinner: Boolean = true) {
        isHistoryMode = false
        historyHeaderBar.visibility = View.GONE
        chipScroll.visibility = View.VISIBLE
        feedJob?.cancel()
        if (showSpinner) {
            if (feedItems.isEmpty() || forceRotate) {
                feedRecycler.adapter = skeletonAdapter
            } else {
                progressBar.visibility = View.VISIBLE
            }
        }

        val history = HistoryStore.getAll(this)
        val recentSearches = HistoryStore.getSearches(this)

        val discoveryQuery = infiniteTopics[refreshSeedIndex % infiniteTopics.size]
        val secondDiscovery = infiniteTopics[(refreshSeedIndex + 2) % infiniteTopics.size]
        val personalQuery = recentSearches.firstOrNull()
            ?: history.firstOrNull()?.channel?.takeIf { it.isNotBlank() }

        currentQuery = discoveryQuery

        feedJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val (trendingList, discoveryPair, personalList) = coroutineScope {
                    val trendingDeferred = async {
                        try {
                            val kiosk = ServiceList.YouTube.kioskList.defaultKioskExtractor
                            val info = KioskInfo.getInfo(kiosk)
                            info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toVideoItem() }
                        } catch (_: Exception) {
                            emptyList()
                        }
                    }

                    val discoveryDeferred = async {
                        try {
                            val qh = ServiceList.YouTube.searchQHFactory.fromQuery(discoveryQuery)
                            val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                            val items = info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toVideoItem() }
                            Pair(items, info.nextPage)
                        } catch (_: Exception) {
                            Pair(emptyList<VideoItem>(), null as Page?)
                        }
                    }

                    val secondDeferred = async {
                        try {
                            val qh = ServiceList.YouTube.searchQHFactory.fromQuery(secondDiscovery)
                            SearchInfo.getInfo(ServiceList.YouTube, qh)
                                .relatedItems.filterIsInstance<StreamInfoItem>()
                                .take(6)
                                .map { it.toVideoItem() }
                        } catch (_: Exception) {
                            emptyList()
                        }
                    }

                    val personalDeferred = async {
                        if (personalQuery.isNullOrBlank()) emptyList()
                        else try {
                            val qh = ServiceList.YouTube.searchQHFactory.fromQuery(personalQuery)
                            SearchInfo.getInfo(ServiceList.YouTube, qh)
                                .relatedItems.filterIsInstance<StreamInfoItem>()
                                .take(4)
                                .map { it.toVideoItem() }
                        } catch (_: Exception) {
                            emptyList()
                        }
                    }

                    val t = trendingDeferred.await()
                    val d1 = discoveryDeferred.await()
                    val d2 = secondDeferred.await()
                    val p = personalDeferred.await()
                    Triple(t, Pair(d1.first + d2, d1.second), p)
                }

                val blended = mutableListOf<VideoItem>()
                val seen = HashSet<String>()
                fun addUnique(v: VideoItem) {
                    if (v.url.isNotBlank() && v.title.isNotBlank() && seen.add(v.url)) {
                        blended.add(v)
                    }
                }

                val tList = if (forceRotate && trendingList.size > 4) trendingList.shuffled() else trendingList
                val dList = discoveryPair.first
                val pList = personalList

                val maxLen = maxOf(tList.size, dList.size, pList.size)
                var pIdx = 0
                for (i in 0 until maxLen) {
                    if (i < tList.size) addUnique(tList[i])
                    if (i < dList.size) addUnique(dList[i])
                    if (i % 3 == 1 && pIdx < pList.size) {
                        addUnique(pList[pIdx++])
                    }
                }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    feedRecycler.adapter = adapter
                    if (blended.isNotEmpty()) {
                        nextPage = discoveryPair.second
                        feedItems.clear()
                        feedItems.addAll(blended)
                        adapter.submitList(feedItems)
                        HistoryStore.saveHomeCache(this@MainActivity, blended)
                        blended.take(2).forEach { InnertubeStreamResolver.prefetch(it.url) }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    feedRecycler.adapter = adapter
                    if (feedItems.isEmpty()) {
                        Toast.makeText(this@MainActivity, "Feed error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun loadSearch(query: String, saveSearch: Boolean = true) {
        isHistoryMode = false
        historyHeaderBar.visibility = View.GONE
        chipScroll.visibility = View.VISIBLE
        currentQuery = query
        nextPage = null
        isLoadingMore = false
        if (saveSearch) {
            HistoryStore.addSearch(this, query)
        }
        feedJob?.cancel()
        feedRecycler.adapter = skeletonAdapter
        feedJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val qh = ServiceList.YouTube.searchQHFactory.fromQuery(query)
                val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                val videos = info.relatedItems
                    .filterIsInstance<StreamInfoItem>()
                    .map { it.toVideoItem() }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    feedRecycler.adapter = adapter
                    nextPage = info.nextPage
                    feedItems.clear()
                    feedItems.addAll(videos)
                    adapter.submitList(feedItems)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                    feedRecycler.adapter = adapter
                    Toast.makeText(this@MainActivity, "Feed error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /**
     * Infinite scrolling:
     * Fetches nextPage if available; when nextPage is exhausted, seamlessly rotates to next discovery topic
     * so scrolling never stops!
     */
    private fun loadMoreResults() {
        if (isLoadingMore) return
        isLoadingMore = true
        progressBar.visibility = View.VISIBLE

        val q = currentQuery
        val page = nextPage

        CoroutineScope(Dispatchers.IO).launch {
            try {
                var newVideos: List<VideoItem> = emptyList()
                var newNextPage: Page? = null
                var updatedQuery = q

                if (q != null && page != null) {
                    val qh = ServiceList.YouTube.searchQHFactory.fromQuery(q)
                    val more = SearchInfo.getMoreItems(ServiceList.YouTube, qh, page)
                    newVideos = more.items.filterIsInstance<StreamInfoItem>().map { it.toVideoItem() }
                    newNextPage = more.nextPage
                }

                // Fallback to next infinite topic if current page ran out
                if (newVideos.isEmpty()) {
                    infinitePoolIndex++
                    val nextTopic = infiniteTopics[infinitePoolIndex % infiniteTopics.size]
                    updatedQuery = nextTopic
                    val qh = ServiceList.YouTube.searchQHFactory.fromQuery(nextTopic)
                    val info = SearchInfo.getInfo(ServiceList.YouTube, qh)
                    newVideos = info.relatedItems.filterIsInstance<StreamInfoItem>().map { it.toVideoItem() }
                    newNextPage = info.nextPage
                }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    isLoadingMore = false
                    currentQuery = updatedQuery
                    nextPage = newNextPage
                    val existingUrls = feedItems.map { it.url }.toHashSet()
                    val uniqueNew = newVideos.filter { it.url !in existingUrls }
                    if (uniqueNew.isNotEmpty()) {
                        feedItems.addAll(uniqueNew)
                        adapter.submitList(feedItems)
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    isLoadingMore = false
                }
            }
        }
    }

    private fun StreamInfoItem.toVideoItem(): VideoItem {
        val vidId = InnertubeStreamResolver.extractVideoId(url ?: "")
        val thumb = thumbnails.firstOrNull { it.height in 240..720 }?.url
            ?: thumbnails.lastOrNull()?.url
            ?: vidId?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" }
            ?: ""
        val avatar = uploaderAvatars.firstOrNull()?.url ?: ""
        return VideoItem(
            title = name ?: "Untitled",
            url = url ?: "",
            channel = uploaderName ?: "",
            thumbnailUrl = thumb,
            avatarUrl = avatar,
            durationSec = duration
        )
    }

    private fun openPlayer(video: VideoItem) {
        if (video.url.contains("/shorts/")) {
            PlayerActivity.closePipIfActive()
            val intent = Intent(this, ShortsActivity::class.java).apply {
                putStringArrayListExtra("short_urls", arrayListOf(video.url))
                putStringArrayListExtra("short_titles", arrayListOf(video.title))
                putStringArrayListExtra("short_channels", arrayListOf(video.channel))
                putStringArrayListExtra("short_thumbs", arrayListOf(video.thumbnailUrl))
                putStringArrayListExtra("short_avatars", arrayListOf(video.avatarUrl))
                putExtra("start_index", 0)
            }
            startActivity(intent)
            @Suppress("DEPRECATION")
            overridePendingTransition(R.anim.slide_in_up, R.anim.hold_fade)
            return
        }
        PlayerActivity.closePipIfActive()
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra("video_url", video.url)
            putExtra("video_title", video.title)
            putExtra("channel_name", video.channel)
            putExtra("thumb_url", video.thumbnailUrl)
            putExtra("avatar_url", video.avatarUrl)
            putExtra("duration_sec", video.durationSec)
        }
        startActivity(intent)
        @Suppress("DEPRECATION")
        overridePendingTransition(R.anim.slide_in_up, R.anim.hold_fade)
    }

    private inner class LocalHistoryAdapter(
        private val items: List<VideoItem>
    ) : RecyclerView.Adapter<LocalHistoryAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.localThumb)
            val duration: TextView = v.findViewById(R.id.localDuration)
            val title: TextView = v.findViewById(R.id.localTitle)
            val moreBtn: ImageButton = v.findViewById(R.id.localMoreBtn)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_local_history, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.title.text = item.title
            if (item.durationSec <= 0) {
                holder.duration.text = "• LIVE"
                holder.duration.setBackgroundResource(R.drawable.bg_live_badge)
            } else {
                val m = item.durationSec / 60
                val s = item.durationSec % 60
                holder.duration.text = String.format("%d:%02d", m, s)
                holder.duration.setBackgroundResource(R.drawable.bg_duration_badge)
            }
            val vidId = InnertubeStreamResolver.extractVideoId(item.url)
            val thumbUrl = item.thumbnailUrl.ifBlank {
                vidId?.let { "https://i.ytimg.com/vi/$it/hqdefault.jpg" } ?: ""
            }
            holder.thumb.load(thumbUrl) { crossfade(false) }
            holder.itemView.setOnClickListener { openPlayer(item) }
            holder.moreBtn.setOnClickListener { btn ->
                val popup = PopupMenu(btn.context, btn)
                popup.menu.add(0, 1, 0, "Remove from Local History")
                popup.setOnMenuItemClickListener {
                    HistoryStore.removeWatchItem(this@MainActivity, item.url)
                    refreshLibraryUi()
                    true
                }
                popup.show()
            }
        }

        override fun getItemCount(): Int = items.size
    }
}
