package com.custom.streamplayer

import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ResolvedVideoStream(
    val url: String,
    val height: Int,
    val fps: Int,
    val itag: Int,
    val codec: String,
    val formatName: String,
    val resolution: String,
    val bitrate: Int
)

data class ResolvedAudioStream(
    val url: String,
    val bitrateKbps: Int,
    val codec: String,
    val formatName: String,
    val langCode: String,
    val trackName: String,
    val isOriginal: Boolean,
    val isDubbed: Boolean,
    val isDescriptive: Boolean
)

data class ResolvedStreamResult(
    val clientName: String,
    val title: String,
    val author: String,
    val channelId: String,
    val viewCount: Long,
    val videoOnlyStreams: List<ResolvedVideoStream>,
    val muxedStreams: List<ResolvedVideoStream>,
    val audioStreams: List<ResolvedAudioStream>,
    val hlsUrl: String?,
    val dashUrl: String?,
    val userAgent: String
)

object InnertubeStreamResolver {

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    @Volatile
    private var lastResolutionDiagnostic: String = "No Innertube resolution attempt has run yet."

    /** A short, URL-free explanation of the most recent resolver run. */
    fun lastDiagnostic(): String = lastResolutionDiagnostic

    private class ResolverFailure(message: String) : Exception(message)

    private data class ClientProfile(
        val name: String,
        val clientName: String,
        val clientVersion: String,
        val userAgent: String,
        val clientId: String,
        val extraClientJson: JSONObject.() -> Unit = {},
        val extraRootJson: JSONObject.() -> Unit = {}
    )

    private val profiles = listOf(
        ClientProfile(
            name = "ANDROID_VR",
            clientName = "ANDROID_VR",
            clientVersion = "1.60.19",
            userAgent = "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            clientId = "28",
            extraClientJson = {
                put("deviceMake", "Oculus")
                put("deviceModel", "Quest 3")
                put("osName", "Android")
                put("osVersion", "12L")
                put("androidSdkVersion", 32)
                put("hl", "en")
                put("gl", "US")
            }
        ),
        ClientProfile(
            name = "IOS",
            clientName = "IOS",
            clientVersion = "20.10.4",
            userAgent = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            clientId = "5",
            extraClientJson = {
                put("deviceMake", "Apple")
                put("deviceModel", "iPhone16,2")
                put("osName", "iPhone")
                put("osVersion", "18.3.2.22D82")
                put("hl", "en")
                put("gl", "US")
            }
        ),
        ClientProfile(
            name = "TVHTML5",
            clientName = "TVHTML5",
            clientVersion = "7.20250219.16.00",
            userAgent = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            clientId = "7",
            extraClientJson = {
                put("hl", "en")
                put("gl", "US")
            },
            extraRootJson = {
                put("thirdParty", JSONObject().put("embedUrl", "https://www.youtube.com/"))
            }
        )
    )

    fun extractVideoId(url: String): String? {
        val trimmed = url.trim()
        if (Regex("^[a-zA-Z0-9_-]{11}$").matches(trimmed)) return trimmed
        val patterns = listOf(
            Regex("[?&]v=([a-zA-Z0-9_-]{11})"),
            Regex("youtu\\.be/([a-zA-Z0-9_-]{11})"),
            Regex("/shorts/([a-zA-Z0-9_-]{11})"),
            Regex("/embed/([a-zA-Z0-9_-]{11})"),
            Regex("/live/([a-zA-Z0-9_-]{11})")
        )
        for (p in patterns) {
            val m = p.find(trimmed)
            if (m != null) return m.groupValues[1]
        }
        return null
    }

    fun resolve(videoUrl: String, skipClients: Set<String> = emptySet()): ResolvedStreamResult? {
        val videoId = extractVideoId(videoUrl)
        if (videoId == null) {
            lastResolutionDiagnostic = "Invalid or unsupported YouTube URL."
            return null
        }

        val failures = mutableListOf<String>()
        var attempted = 0
        for (profile in profiles) {
            if (profile.name in skipClients) continue
            attempted++
            try {
                val result = fetchWithProfile(videoId, profile)
                if (result == null) {
                    failures += "${profile.name}: empty response"
                    continue
                }

                // DASH is a supported playback path in PlayerActivity. Do not reject
                // a response merely because it has no direct format URLs or HLS URL.
                val hasPlayableRoute = result.videoOnlyStreams.isNotEmpty() ||
                    result.muxedStreams.isNotEmpty() ||
                    !result.hlsUrl.isNullOrBlank() ||
                    !result.dashUrl.isNullOrBlank()

                if (hasPlayableRoute) {
                    val note = "Resolved via ${profile.name}: " +
                        "video=${result.videoOnlyStreams.size}, " +
                        "muxed=${result.muxedStreams.size}, " +
                        "audio=${result.audioStreams.size}, " +
                        "HLS=${!result.hlsUrl.isNullOrBlank()}, " +
                        "DASH=${!result.dashUrl.isNullOrBlank()}"
                    lastResolutionDiagnostic = note
                    Log.i(TAG, note)
                    return result
                }

                failures += "${profile.name}: no direct formats or HLS/DASH manifest"
            } catch (e: Exception) {
                val reason = e.message?.take(180).orEmpty().ifBlank { e.javaClass.simpleName }
                failures += "${profile.name}: ${e.javaClass.simpleName}: $reason"
            }
        }

        lastResolutionDiagnostic = if (attempted == 0) {
            "No unused Innertube clients remain."
        } else {
            failures.joinToString(" | ").take(700).ifBlank { "All Innertube clients failed without a response." }
        }
        Log.w(TAG, "Stream resolution failed: $lastResolutionDiagnostic")
        return null
    }

    private const val TAG = "YT4K.StreamResolver"

    private fun fetchWithProfile(videoId: String, profile: ClientProfile): ResolvedStreamResult? {
        val clientObj = JSONObject().apply {
            put("clientName", profile.clientName)
            put("clientVersion", profile.clientVersion)
            put("userAgent", profile.userAgent)
            profile.extraClientJson(this)
        }
        val contextObj = JSONObject().apply {
            put("client", clientObj)
            profile.extraRootJson(this)
        }
        val bodyObj = JSONObject().apply {
            put("videoId", videoId)
            put("context", contextObj)
            put("contentCheckOk", true)
            put("racyCheckOk", true)
        }

        val req = Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
            .post(bodyObj.toString().toRequestBody(jsonMediaType))
            .header("Content-Type", "application/json")
            .header("User-Agent", profile.userAgent)
            .header("X-YouTube-Client-Name", profile.clientId)
            .header("X-YouTube-Client-Version", profile.clientVersion)
            .header("Origin", "https://www.youtube.com")
            .build()

        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                // Do not include request URLs: stream and API URLs may contain tokens.
                throw ResolverFailure("HTTP ${resp.code} ${resp.message}")
            }
            val raw = resp.body?.string()
                ?: throw ResolverFailure("Empty HTTP response body")
            val root = try {
                JSONObject(raw)
            } catch (e: Exception) {
                throw ResolverFailure("Invalid JSON response: ${e.javaClass.simpleName}")
            }

            val playability = root.optJSONObject("playabilityStatus")
            val status = playability?.optString("status").orEmpty()
            if (status != "OK" && status != "LIVE_STREAM_OFFLINE") {
                val reason = playability?.optString("reason")?.takeIf { it.isNotBlank() }
                throw ResolverFailure("Playability status ${status.ifBlank { "missing" }}" +
                    (reason?.let { ": ${it.take(140)}" } ?: ""))
            }

            val details = root.optJSONObject("videoDetails")
            val title = details?.optString("title").orEmpty()
            val author = details?.optString("author").orEmpty()
            val channelId = details?.optString("channelId").orEmpty()
            val viewCount = details?.optString("viewCount")?.toLongOrNull() ?: 0L

            val streamingData = root.optJSONObject("streamingData")
                ?: throw ResolverFailure("streamingData missing (status=${status.ifBlank { "unknown" }})")
            val hlsUrl = streamingData.optString("hlsManifestUrl").takeIf { it.isNotBlank() }
            val dashUrl = streamingData.optString("dashManifestUrl").takeIf { it.isNotBlank() }

            val muxed = mutableListOf<ResolvedVideoStream>()
            var cipherOnlyFormats = 0
            val formats = streamingData.optJSONArray("formats")
            if (formats != null) {
                for (i in 0 until formats.length()) {
                    val format = formats.optJSONObject(i)
                    if (isCipherOnly(format)) cipherOnlyFormats++
                    parseVideoFormat(format)?.let { muxed.add(it) }
                }
            }

            val videoOnly = mutableListOf<ResolvedVideoStream>()
            val audios = mutableListOf<ResolvedAudioStream>()
            val adaptive = streamingData.optJSONArray("adaptiveFormats")
            if (adaptive != null) {
                for (i in 0 until adaptive.length()) {
                    val f = adaptive.optJSONObject(i) ?: continue
                    if (isCipherOnly(f)) cipherOnlyFormats++
                    val mime = f.optString("mimeType")
                    if (mime.startsWith("video/", ignoreCase = true)) {
                        parseVideoFormat(f)?.let { videoOnly.add(it) }
                    } else if (mime.startsWith("audio/", ignoreCase = true)) {
                        parseAudioFormat(f)?.let { audios.add(it) }
                    }
                }
            }

            if (cipherOnlyFormats > 0) {
                Log.w(TAG, "${profile.name} returned $cipherOnlyFormats cipher-only format(s); " +
                    "the custom direct-URL parser cannot decipher these. Rely on NewPipe or a manifest route when available.")
            }
            if (muxed.isEmpty() && videoOnly.isEmpty() && audios.isEmpty() &&
                hlsUrl.isNullOrBlank() && dashUrl.isNullOrBlank() && cipherOnlyFormats > 0) {
                throw ResolverFailure("Only cipher-encrypted formats were returned ($cipherOnlyFormats); " +
                    "the custom Innertube parser cannot decipher them")
            }

            return ResolvedStreamResult(
                clientName = profile.name,
                title = title,
                author = author,
                channelId = channelId,
                viewCount = viewCount,
                videoOnlyStreams = videoOnly,
                muxedStreams = muxed,
                audioStreams = audios,
                hlsUrl = hlsUrl,
                dashUrl = dashUrl,
                userAgent = profile.userAgent
            )
        }
    }

    private fun isCipherOnly(format: JSONObject?): Boolean {
        if (format == null || format.optString("url").isNotBlank()) return false
        return format.optString("signatureCipher").isNotBlank() ||
            format.optString("cipher").isNotBlank()
    }

    private fun parseVideoFormat(f: JSONObject?): ResolvedVideoStream? {
        if (f == null) return null
        val url = f.optString("url").takeIf { it.isNotBlank() } ?: return null
        val mime = f.optString("mimeType")
        val height = f.optInt("height", 0)
        if (height <= 0) return null
        val fps = f.optInt("fps", 30)
        val itag = f.optInt("itag", 0)
        val bitrate = f.optInt("bitrate", 0)
        val codecs = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.getOrNull(1) ?: ""
        val formatName = if (mime.contains("webm", ignoreCase = true)) "WebM" else "MPEG_4"
        val qualityLabel = f.optString("qualityLabel").takeIf { it.isNotBlank() } ?: "${height}p"
        return ResolvedVideoStream(
            url = url,
            height = height,
            fps = fps,
            itag = itag,
            codec = codecs,
            formatName = formatName,
            resolution = qualityLabel,
            bitrate = bitrate
        )
    }

    private fun parseAudioFormat(f: JSONObject?): ResolvedAudioStream? {
        if (f == null) return null
        val url = f.optString("url").takeIf { it.isNotBlank() } ?: return null
        val mime = f.optString("mimeType")
        val bitrateKbps = (f.optInt("averageBitrate", f.optInt("bitrate", 0)) / 1000).coerceAtLeast(1)
        val codecs = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.getOrNull(1) ?: ""
        val formatName = if (mime.contains("webm", ignoreCase = true)) "WebM" else "M4A"
        val track = f.optJSONObject("audioTrack")
        val trackId = track?.optString("id").orEmpty()
        val displayName = track?.optString("displayName").orEmpty()
        val isDefault = track?.optBoolean("audioIsDefault", false) ?: false
        val langCode = trackId.substringBefore(".").ifBlank { "und" }
        val isDubbed = displayName.contains("dub", ignoreCase = true)
        val isDesc = displayName.contains("descriptive", ignoreCase = true)
        val isOriginal = isDefault || (!isDubbed && !isDesc && displayName.contains("original", ignoreCase = true)) || track == null
        return ResolvedAudioStream(
            url = url,
            bitrateKbps = bitrateKbps,
            codec = codecs,
            formatName = formatName,
            langCode = langCode,
            trackName = displayName,
            isOriginal = isOriginal,
            isDubbed = isDubbed,
            isDescriptive = isDesc
        )
    }
}
