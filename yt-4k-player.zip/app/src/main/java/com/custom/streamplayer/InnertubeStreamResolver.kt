package com.custom.streamplayer

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ResolvedVideoStream(
    val url: String,
    val height: Int,
    val fps: Int,
    val itag: Int,
    val codec: String,
    val formatName: String,
    val resolution: String,
    val bitrate: Int
)

data class ResolvedAudioStream(
    val url: String,
    val bitrateKbps: Int,
    val codec: String,
    val formatName: String,
    val langCode: String,
    val trackName: String,
    val isOriginal: Boolean,
    val isDubbed: Boolean,
    val isDescriptive: Boolean
)

data class ResolvedStreamResult(
    val clientName: String,
    val title: String,
    val author: String,
    val channelId: String,
    val viewCount: Long,
    val videoOnlyStreams: List<ResolvedVideoStream>,
    val muxedStreams: List<ResolvedVideoStream>,
    val audioStreams: List<ResolvedAudioStream>,
    val hlsUrl: String?,
    val dashUrl: String?,
    val userAgent: String
)

object InnertubeStreamResolver {

    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    @Volatile
    private var cachedVisitorData: String? = null

    @Volatile
    var lastErrorDetail: String = ""
        private set

    private data class ClientProfile(
        val name: String,
        val clientName: String,
        val clientVersion: String,
        val userAgent: String,
        val clientId: String,
        val extraClientJson: JSONObject.() -> Unit = {},
        val extraRootJson: JSONObject.() -> Unit = {}
    )

    private val profiles = listOf(
        ClientProfile(
            name = "ANDROID_VR",
            clientName = "ANDROID_VR",
            clientVersion = "1.60.19",
            userAgent = "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            clientId = "28",
            extraClientJson = {
                put("deviceMake", "Oculus")
                put("deviceModel", "Quest 3")
                put("osName", "Android")
                put("osVersion", "12L")
                put("androidSdkVersion", 32)
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "IOS",
            clientName = "IOS",
            clientVersion = "20.10.4",
            userAgent = "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            clientId = "5",
            extraClientJson = {
                put("deviceMake", "Apple")
                put("deviceModel", "iPhone16,2")
                put("osName", "iPhone")
                put("osVersion", "18.3.2.22D82")
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "TVHTML5",
            clientName = "TVHTML5",
            clientVersion = "7.20250219.16.00",
            userAgent = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            clientId = "7",
            extraClientJson = {
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "ANDROID_KIDS",
            clientName = "ANDROID_KIDS",
            clientVersion = "9.45.2",
            userAgent = "com.google.android.apps.youtube.kids/9.45.2 (Linux; U; Android 14; Pixel 8) gzip",
            clientId = "26",
            extraClientJson = {
                put("deviceMake", "Google")
                put("deviceModel", "Pixel 8")
                put("osName", "Android")
                put("osVersion", "14")
                put("androidSdkVersion", 34)
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "ANDROID_CREATOR",
            clientName = "ANDROID_CREATOR",
            clientVersion = "24.48.100",
            userAgent = "com.google.android.apps.youtube.creator/24.48.100 (Linux; U; Android 14; Pixel 8) gzip",
            clientId = "14",
            extraClientJson = {
                put("deviceMake", "Google")
                put("deviceModel", "Pixel 8")
                put("osName", "Android")
                put("osVersion", "14")
                put("androidSdkVersion", 34)
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "MWEB",
            clientName = "MWEB",
            clientVersion = "2.20250219.01.00",
            userAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36",
            clientId = "2",
            extraClientJson = {
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "WEB",
            clientName = "WEB",
            clientVersion = "2.20250219.01.00",
            userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
            clientId = "1",
            extraClientJson = {
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
            clientName = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
            clientVersion = "2.0",
            userAgent = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            clientId = "85",
            extraClientJson = {
                put("hl", "en")
                put("gl", "IN")
            },
            extraRootJson = {
                put("thirdParty", JSONObject().put("embedUrl", "https://www.youtube.com/"))
            }
        ),
        ClientProfile(
            name = "WEB_EMBEDDED_PLAYER",
            clientName = "WEB_EMBEDDED_PLAYER",
            clientVersion = "1.20250219.00.00",
            userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",
            clientId = "56",
            extraClientJson = {
                put("hl", "en")
                put("gl", "IN")
            },
            extraRootJson = {
                put("thirdParty", JSONObject().put("embedUrl", "https://www.youtube.com/"))
            }
        )
    )

    val totalProfiles: Int get() = profiles.size

    fun extractVideoId(url: String): String? {
        val trimmed = url.trim()
        if (Regex("^[a-zA-Z0-9_-]{11}$").matches(trimmed)) return trimmed
        val patterns = listOf(
            Regex("[?&]v=([a-zA-Z0-9_-]{11})"),
            Regex("youtu\\.be/([a-zA-Z0-9_-]{11})"),
            Regex("/shorts/([a-zA-Z0-9_-]{11})"),
            Regex("/embed/([a-zA-Z0-9_-]{11})"),
            Regex("/live/([a-zA-Z0-9_-]{11})")
        )
        for (p in patterns) {
            val m = p.find(trimmed)
            if (m != null) return m.groupValues[1]
        }
        return null
    }

    private fun getOrFetchVisitorData(): String? {
        cachedVisitorData?.let { return it }
        return try {
            val body = JSONObject().apply {
                put(
                    "context",
                    JSONObject().put(
                        "client",
                        JSONObject()
                            .put("clientName", "WEB")
                            .put("clientVersion", "2.20250219.01.00")
                    )
                )
            }
            val req = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/visitor_id?prettyPrint=false")
                .post(body.toString().toRequestBody(jsonMediaType))
                .header("Content-Type", "application/json")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val json = JSONObject(resp.body?.string() ?: return null)
                val vd = json.optJSONObject("responseContext")?.optString("visitorData")
                    ?.takeIf { it.isNotBlank() }
                if (vd != null) cachedVisitorData = vd
                vd
            }
        } catch (_: Exception) {
            null
        }
    }

    fun resolve(videoUrl: String, skipClients: Set<String> = emptySet()): ResolvedStreamResult? {
        val videoId = extractVideoId(videoUrl)
        if (videoId == null) {
            lastErrorDetail = "Invalid YouTube URL"
            return null
        }

        val errors = mutableListOf<String>()
        val visitorData = getOrFetchVisitorData()

        for (profile in profiles) {
            if (profile.name in skipClients) continue
            try {
                val res = fetchWithProfile(videoId, profile, visitorData, errors)
                if (res != null && (
                        res.videoOnlyStreams.isNotEmpty() ||
                            res.muxedStreams.isNotEmpty() ||
                            !res.hlsUrl.isNullOrEmpty() ||
                            !res.dashUrl.isNullOrEmpty()
                        )
                ) {
                    lastErrorDetail = ""
                    return res
                }
            } catch (e: Exception) {
                errors.add("${profile.name}: ${e.localizedMessage ?: e.javaClass.simpleName}")
            }
        }
        if ("WATCH_HTML" !in skipClients) {
            try {
                val htmlRes = fetchViaWatchHtml(videoId, errors)
                if (htmlRes != null && (
                        htmlRes.videoOnlyStreams.isNotEmpty() ||
                            htmlRes.muxedStreams.isNotEmpty() ||
                            !htmlRes.hlsUrl.isNullOrEmpty() ||
                            !htmlRes.dashUrl.isNullOrEmpty()
                        )
                ) {
                    lastErrorDetail = ""
                    return htmlRes
                }
            } catch (e: Exception) {
                errors.add("WATCH_HTML: ${e.localizedMessage ?: e.javaClass.simpleName}")
            }
        }
        if ("MWEB_WEBVIEW" !in skipClients) {
            try {
                val wvRes = YouTubePoTokenProvider.resolveViaWebView(videoUrl)
                if (wvRes != null) {
                    lastErrorDetail = ""
                    return wvRes
                }
            } catch (e: Exception) {
                errors.add("MWEB_WEBVIEW: ${e.localizedMessage ?: e.javaClass.simpleName}")
            }
        }
        lastErrorDetail = errors.firstOrNull {
            it.contains("LOGIN_REQUIRED", true) || it.contains("Sign in", true) || it.contains("age", true)
        } ?: errors.firstOrNull() ?: "No playable formats returned"
        return null
    }

    private fun fetchWithProfile(
        videoId: String,
        profile: ClientProfile,
        visitorData: String?,
        errors: MutableList<String>
    ): ResolvedStreamResult? {
        val isWeb = profile.name in setOf("MWEB", "WEB", "TVHTML5", "WEB_EMBEDDED_PLAYER", "TVHTML5_SIMPLY_EMBEDDED_PLAYER")
        val clientObj = JSONObject().apply {
            put("clientName", profile.clientName)
            put("clientVersion", profile.clientVersion)
            put("userAgent", profile.userAgent)
            if (!visitorData.isNullOrBlank()) put("visitorData", visitorData)
            profile.extraClientJson(this)
        }
        val contextObj = JSONObject().apply {
            put("client", clientObj)
            profile.extraRootJson(this)
        }
        val bodyObj = JSONObject().apply {
            put("videoId", videoId)
            put("context", contextObj)
            put("contentCheckOk", true)
            put("racyCheckOk", true)
            val pot = if (isWeb) YouTubePoTokenProvider.cachedPoToken else null
            if (!pot.isNullOrBlank()) {
                put("serviceIntegrityDimensions", JSONObject().put("poToken", pot))
            }
        }

        val isWebClient = isWeb
        val reqBuilder = Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
            .post(bodyObj.toString().toRequestBody(jsonMediaType))
            .header("Content-Type", "application/json")
            .header("User-Agent", profile.userAgent)
            .header("X-YouTube-Client-Name", profile.clientId)
            .header("X-YouTube-Client-Version", profile.clientVersion)
        if (isWebClient) {
            reqBuilder.header("Origin", "https://www.youtube.com")
        }
        if (!visitorData.isNullOrBlank()) {
            reqBuilder.header("X-Goog-Visitor-Id", visitorData)
        }
        val authCookie = if (isWebClient) YouTubeAuthStore.getCookie() else null
        if (!authCookie.isNullOrBlank()) {
            reqBuilder.header("Cookie", authCookie)
            YouTubeAuthStore.buildSapisidHash(authCookie)?.let { auth ->
                reqBuilder.header("Authorization", auth)
                reqBuilder.header("X-Origin", "https://www.youtube.com")
            }
        }

        client.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                errors.add("${profile.name}: HTTP ${resp.code}")
                return null
            }
            val raw = resp.body?.string() ?: return null
            val root = JSONObject(raw)

            val playability = root.optJSONObject("playabilityStatus")
            val status = playability?.optString("status") ?: ""
            if (status != "OK" && status != "LIVE_STREAM_OFFLINE") {
                val reason = playability?.optString("reason").orEmpty()
                errors.add("${profile.name}: $status${if (reason.isNotBlank()) " ($reason)" else ""}")
                return null
            }

            val details = root.optJSONObject("videoDetails")
            val title = details?.optString("title").orEmpty()
            val author = details?.optString("author").orEmpty()
            val channelId = details?.optString("channelId").orEmpty()
            val viewCount = details?.optString("viewCount")?.toLongOrNull() ?: 0L

            val streamingData = root.optJSONObject("streamingData")
            if (streamingData == null) {
                errors.add("${profile.name}: missing streamingData")
                return null
            }
            val hlsUrl = streamingData.optString("hlsManifestUrl").takeIf { it.isNotBlank() }
            val dashUrl = streamingData.optString("dashManifestUrl").takeIf { it.isNotBlank() }

            val muxed = mutableListOf<ResolvedVideoStream>()
            val formats = streamingData.optJSONArray("formats")
            if (formats != null) {
                for (i in 0 until formats.length()) {
                    parseVideoFormat(formats.optJSONObject(i), videoId)?.let { muxed.add(it) }
                }
            }

            val videoOnly = mutableListOf<ResolvedVideoStream>()
            val audios = mutableListOf<ResolvedAudioStream>()
            val adaptive = streamingData.optJSONArray("adaptiveFormats")
            if (adaptive != null) {
                for (i in 0 until adaptive.length()) {
                    val f = adaptive.optJSONObject(i) ?: continue
                    val mime = f.optString("mimeType")
                    if (mime.startsWith("video/", ignoreCase = true)) {
                        parseVideoFormat(f, videoId)?.let { videoOnly.add(it) }
                    } else if (mime.startsWith("audio/", ignoreCase = true)) {
                        parseAudioFormat(f, videoId)?.let { audios.add(it) }
                    }
                }
            }

            if (muxed.isEmpty() && videoOnly.isEmpty() && hlsUrl == null && dashUrl == null) {
                errors.add("${profile.name}: no direct/cipher/HLS/DASH URLs")
            }

            return ResolvedStreamResult(
                clientName = profile.name,
                title = title,
                author = author,
                channelId = channelId,
                viewCount = viewCount,
                videoOnlyStreams = videoOnly,
                muxedStreams = muxed,
                audioStreams = audios,
                hlsUrl = hlsUrl,
                dashUrl = dashUrl,
                userAgent = profile.userAgent
            )
        }
    }

    private fun fetchViaWatchHtml(videoId: String, errors: MutableList<String>): ResolvedStreamResult? {
        val ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
        val reqBuilder = Request.Builder()
            .url("https://www.youtube.com/watch?v=$videoId&bpctr=9999999999&has_verified=1")
            .header("User-Agent", ua)
            .header("Accept-Language", "en-IN,en;q=0.9")
        val cookie = YouTubeAuthStore.getCookie()
        if (!cookie.isNullOrBlank()) {
            reqBuilder.header("Cookie", cookie)
        }
        client.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                errors.add("WATCH_HTML: HTTP ${resp.code}")
                return null
            }
            val html = resp.body?.string() ?: return null
            val marker = "var ytInitialPlayerResponse = "
            val idx = html.indexOf(marker)
            val startIdx = if (idx >= 0) {
                idx + marker.length
            } else {
                val alt = "ytInitialPlayerResponse = "
                val altIdx = html.indexOf(alt)
                if (altIdx < 0) return null
                altIdx + alt.length
            }
            var depth = 0
            var inStr = false
            var escape = false
            var endIdx = -1
            for (i in startIdx until html.length) {
                val c = html[i]
                if (escape) {
                    escape = false
                    continue
                }
                if (c == '\\' && inStr) {
                    escape = true
                    continue
                }
                if (c == '"') {
                    inStr = !inStr
                    continue
                }
                if (!inStr) {
                    if (c == '{') depth++
                    else if (c == '}') {
                        depth--
                        if (depth == 0) {
                            endIdx = i + 1
                            break
                        }
                    }
                }
            }
            if (endIdx <= startIdx) return null
            val json = JSONObject(html.substring(startIdx, endIdx))
            return parsePlayerResponseJson(json, videoId, "WATCH_HTML", ua)
        }
    }

    fun parsePlayerResponseJson(
        root: JSONObject,
        videoId: String,
        clientName: String,
        userAgent: String
    ): ResolvedStreamResult? {
        val playability = root.optJSONObject("playabilityStatus")
        val status = playability?.optString("status") ?: ""
        if (status != "OK" && status != "LIVE_STREAM_OFFLINE") {
            return null
        }

        val details = root.optJSONObject("videoDetails")
        val title = details?.optString("title").orEmpty()
        val author = details?.optString("author").orEmpty()
        val channelId = details?.optString("channelId").orEmpty()
        val viewCount = details?.optString("viewCount")?.toLongOrNull() ?: 0L

        val streamingData = root.optJSONObject("streamingData") ?: return null
        val hlsUrl = streamingData.optString("hlsManifestUrl").takeIf { it.isNotBlank() }
        val dashUrl = streamingData.optString("dashManifestUrl").takeIf { it.isNotBlank() }

        val muxed = mutableListOf<ResolvedVideoStream>()
        val formats = streamingData.optJSONArray("formats")
        if (formats != null) {
            for (i in 0 until formats.length()) {
                parseVideoFormat(formats.optJSONObject(i), videoId)?.let { muxed.add(it) }
            }
        }

        val videoOnly = mutableListOf<ResolvedVideoStream>()
        val audios = mutableListOf<ResolvedAudioStream>()
        val adaptive = streamingData.optJSONArray("adaptiveFormats")
        if (adaptive != null) {
            for (i in 0 until adaptive.length()) {
                val f = adaptive.optJSONObject(i) ?: continue
                val mime = f.optString("mimeType")
                if (mime.startsWith("video/", ignoreCase = true)) {
                    parseVideoFormat(f, videoId)?.let { videoOnly.add(it) }
                } else if (mime.startsWith("audio/", ignoreCase = true)) {
                    parseAudioFormat(f, videoId)?.let { audios.add(it) }
                }
            }
        }

        return ResolvedStreamResult(
            clientName = clientName,
            title = title,
            author = author,
            channelId = channelId,
            viewCount = viewCount,
            videoOnlyStreams = videoOnly,
            muxedStreams = muxed,
            audioStreams = audios,
            hlsUrl = hlsUrl,
            dashUrl = dashUrl,
            userAgent = userAgent
        )
    }

    private fun extractStreamUrl(f: JSONObject, videoId: String): String? {
        val direct = f.optString("url").takeIf { it.isNotBlank() }
        if (direct != null) return direct
        val cipher = f.optString("signatureCipher").takeIf { it.isNotBlank() }
            ?: f.optString("cipher").takeIf { it.isNotBlank() }
            ?: return null
        return YouTubeCipherDecryptor.decryptCipherUrl(cipher, videoId)
    }

    private fun parseVideoFormat(f: JSONObject?, videoId: String): ResolvedVideoStream? {
        if (f == null) return null
        val url = extractStreamUrl(f, videoId) ?: return null
        val mime = f.optString("mimeType")
        val height = f.optInt("height", 0)
        if (height <= 0) return null
        val fps = f.optInt("fps", 30)
        val itag = f.optInt("itag", 0)
        val bitrate = f.optInt("bitrate", 0)
        val codecs = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.getOrNull(1) ?: ""
        val formatName = if (mime.contains("webm", ignoreCase = true)) "WebM" else "MPEG_4"
        val qualityLabel = f.optString("qualityLabel").takeIf { it.isNotBlank() } ?: "${height}p"
        return ResolvedVideoStream(
            url = url,
            height = height,
            fps = fps,
            itag = itag,
            codec = codecs,
            formatName = formatName,
            resolution = qualityLabel,
            bitrate = bitrate
        )
    }

    private fun parseAudioFormat(f: JSONObject?, videoId: String): ResolvedAudioStream? {
        if (f == null) return null
        val url = extractStreamUrl(f, videoId) ?: return null
        val mime = f.optString("mimeType")
        val bitrateKbps = (f.optInt("averageBitrate", f.optInt("bitrate", 0)) / 1000).coerceAtLeast(1)
        val codecs = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.getOrNull(1) ?: ""
        val formatName = if (mime.contains("webm", ignoreCase = true)) "WebM" else "M4A"
        val track = f.optJSONObject("audioTrack")
        val trackId = track?.optString("id").orEmpty()
        val displayName = track?.optString("displayName").orEmpty()
        val isDefault = track?.optBoolean("audioIsDefault", false) ?: false
        val langCode = trackId.substringBefore(".").ifBlank { "und" }
        val isDubbed = displayName.contains("dub", ignoreCase = true)
        val isDesc = displayName.contains("descriptive", ignoreCase = true)
        val isOriginal = isDefault || (!isDubbed && !isDesc && displayName.contains("original", ignoreCase = true)) || track == null
        return ResolvedAudioStream(
            url = url,
            bitrateKbps = bitrateKbps,
            codec = codecs,
            formatName = formatName,
            langCode = langCode,
            trackName = displayName,
            isOriginal = isOriginal,
            isDubbed = isDubbed,
            isDescriptive = isDesc
        )
    }
}
