package com.custom.streamplayer

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

data class ResolvedVideoStream(
    val url: String,
    val height: Int,
    val fps: Int,
    val itag: Int,
    val codec: String,
    val formatName: String,
    val resolution: String,
    val bitrate: Int
)

data class ResolvedAudioStream(
    val url: String,
    val bitrateKbps: Int,
    val codec: String,
    val formatName: String,
    val langCode: String,
    val trackName: String,
    val isOriginal: Boolean,
    val isDubbed: Boolean,
    val isDescriptive: Boolean
)

data class ResolvedStreamResult(
    val clientName: String,
    val title: String,
    val author: String,
    val channelId: String,
    val viewCount: Long,
    val videoOnlyStreams: List<ResolvedVideoStream>,
    val muxedStreams: List<ResolvedVideoStream>,
    val audioStreams: List<ResolvedAudioStream>,
    val hlsUrl: String?,
    val dashUrl: String?,
    val userAgent: String
)

object InnertubeStreamResolver {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val probeClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .callTimeout(4, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val raceExecutor = Executors.newFixedThreadPool(4)
    private val prefetchExecutor = Executors.newSingleThreadExecutor()

    private data class CachedEntry(val result: ResolvedStreamResult, val timestampMs: Long)
    private val streamCache = ConcurrentHashMap<String, CachedEntry>()
    private const val CACHE_TTL_MS = 5 * 60 * 1000L

    @Volatile
    private var cachedVisitorData: String? = null

    @Volatile
    var lastErrorDetail: String = ""
        private set

    private data class ClientProfile(
        val name: String,
        val clientName: String,
        val clientVersion: String,
        val userAgent: String,
        val clientId: String,
        val extraClientJson: JSONObject.() -> Unit = {},
        val extraRootJson: JSONObject.() -> Unit = {}
    )

    // Updated 2026 Innertube clients (per yt-dlp master):
    // VISIONOS (101) & IOS_PRODUCER (92) do not require PO tokens or JS player decryption.
    // ANDROID_VR is removed from primary because YouTube 403s / caps it at 1 MiB without GVS PO token.
    private val profiles = listOf(
        ClientProfile(
            name = "VISIONOS",
            clientName = "VISIONOS",
            clientVersion = "1.02",
            userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15",
            clientId = "101",
            extraClientJson = {
                put("deviceMake", "Apple")
                put("deviceModel", "RealityDevice17,1")
                put("osName", "visionOS")
                put("osVersion", "26.5.23O471")
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "IOS_PRODUCER",
            clientName = "IOS_PRODUCER",
            clientVersion = "0.147.945",
            userAgent = "com.google.ios.youtubeproducer/0.147.945 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            clientId = "92",
            extraClientJson = {
                put("deviceMake", "Apple")
                put("deviceModel", "iPhone16,2")
                put("osName", "iPhone")
                put("osVersion", "18.3.2.22D82")
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "TVHTML5",
            clientName = "TVHTML5",
            clientVersion = "7.20260707.07.00",
            userAgent = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/25.lts.30.1034943-gold (unlike Gecko), Unknown_TV_Unknown_0/Unknown (Unknown, Unknown)",
            clientId = "7",
            extraClientJson = {
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "IOS",
            clientName = "IOS",
            clientVersion = "21.26.4",
            userAgent = "com.google.ios.youtube/21.26.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            clientId = "5",
            extraClientJson = {
                put("deviceMake", "Apple")
                put("deviceModel", "iPhone16,2")
                put("osName", "iPhone")
                put("osVersion", "18.3.2.22D82")
                put("hl", "en")
                put("gl", "IN")
            }
        ),
        ClientProfile(
            name = "WEB_EMBEDDED_PLAYER",
            clientName = "WEB_EMBEDDED_PLAYER",
            clientVersion = "2.20260708.00.00",
            userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Safari/605.1.15,gzip(gfe)",
            clientId = "56",
            extraClientJson = {
                put("hl", "en")
                put("gl", "IN")
            },
            extraRootJson = {
                put("thirdParty", JSONObject().put("embedUrl", "https://www.reddit.com/"))
            }
        ),
        ClientProfile(
            name = "TVHTML5_SIMPLY",
            clientName = "TVHTML5_SIMPLY",
            clientVersion = "1.0",
            userAgent = "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
            clientId = "75",
            extraClientJson = {
                put("hl", "en")
                put("gl", "IN")
            }
        )
    )

    val totalProfiles: Int get() = profiles.size

    fun extractVideoId(url: String): String? {
        val trimmed = url.trim()
        if (Regex("^[a-zA-Z0-9_-]{11}$").matches(trimmed)) return trimmed
        val patterns = listOf(
            Regex("[?&]v=([a-zA-Z0-9_-]{11})"),
            Regex("youtu\\.be/([a-zA-Z0-9_-]{11})"),
            Regex("/shorts/([a-zA-Z0-9_-]{11})"),
            Regex("/embed/([a-zA-Z0-9_-]{11})"),
            Regex("/live/([a-zA-Z0-9_-]{11})")
        )
        for (p in patterns) {
            val m = p.find(trimmed)
            if (m != null) return m.groupValues[1]
        }
        return null
    }

    fun getCached(videoUrl: String): ResolvedStreamResult? {
        val videoId = extractVideoId(videoUrl) ?: return null
        val entry = streamCache[videoId] ?: return null
        if (System.currentTimeMillis() - entry.timestampMs > CACHE_TTL_MS) {
            streamCache.remove(videoId)
            return null
        }
        return entry.result
    }

    fun cacheResult(videoUrl: String, res: ResolvedStreamResult) {
        val videoId = extractVideoId(videoUrl) ?: return
        if (streamCache.size >= 20) {
            val oldest = streamCache.entries.minByOrNull { it.value.timestampMs }?.key
            if (oldest != null) streamCache.remove(oldest)
        }
        streamCache[videoId] = CachedEntry(res, System.currentTimeMillis())
    }

    fun prefetch(videoUrl: String) {
        val videoId = extractVideoId(videoUrl) ?: return
        if (getCached(videoUrl) != null) return
        prefetchExecutor.execute {
            try {
                resolveFast(videoUrl)
            } catch (_: Exception) {}
        }
    }

    /**
     * Verifies with a bounded Range request (bytes=0-1023) that YouTube CDN returns 200/206 (not 403).
     */
    fun isStreamUrlReachable(streamUrl: String, userAgent: String): Boolean {
        return try {
            val reqBuilder = Request.Builder()
                .url(streamUrl)
                .header("User-Agent", userAgent)
                .header("Range", "bytes=0-1023")
            if (userAgent.startsWith("Mozilla/")) {
                reqBuilder.header("Origin", "https://www.youtube.com")
                reqBuilder.header("Referer", "https://www.youtube.com/")
            }
            probeClient.newCall(reqBuilder.build()).execute().use { resp ->
                resp.code in 200..299
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun isResultPlayable(res: ResolvedStreamResult): Boolean {
        val videoTest = res.videoOnlyStreams.firstOrNull()?.url
            ?: res.muxedStreams.firstOrNull()?.url
            ?: res.hlsUrl
            ?: return false
        if (!isStreamUrlReachable(videoTest, res.userAgent)) return false
        val audioTest = res.audioStreams.firstOrNull()?.url
        if (audioTest != null && !isStreamUrlReachable(audioTest, res.userAgent)) return false
        return true
    }

    /**
     * Instant parallel stream resolver: races VISIONOS, IOS_PRODUCER, and TVHTML5 concurrently
     * and verifies bounded Range HTTP 206 so ExoPlayer never hits ERROR_CODE_IO_BAD_HTTP_STATUS (403).
     */
    fun resolveFast(videoUrl: String, skipClients: Set<String> = emptySet()): ResolvedStreamResult? {
        val videoId = extractVideoId(videoUrl)
        if (videoId == null) {
            lastErrorDetail = "Invalid YouTube URL"
            return null
        }

        if (skipClients.isEmpty()) {
            getCached(videoUrl)?.let {
                lastErrorDetail = ""
                return it
            }
        }

        val errors = java.util.Collections.synchronizedList(mutableListOf<String>())
        val visitorData = cachedVisitorData

        val fastProfiles = profiles.filter { it.name !in skipClients }.take(3)
        if (fastProfiles.isNotEmpty()) {
            val completionService = ExecutorCompletionService<ResolvedStreamResult?>(raceExecutor)
            val futures = mutableListOf<Future<ResolvedStreamResult?>>()
            for (p in fastProfiles) {
                futures.add(
                    completionService.submit(Callable {
                        try {
                            val res = fetchWithProfile(videoId, p, visitorData, errors)
                            if (res != null && hasPlayableStreams(res) && isResultPlayable(res)) {
                                res
                            } else {
                                if (res != null) errors.add("${p.name}: HTTP 403 blocked")
                                null
                            }
                        } catch (e: Exception) {
                            errors.add("${p.name}: ${e.localizedMessage ?: e.javaClass.simpleName}")
                            null
                        }
                    })
                )
            }

            var winner: ResolvedStreamResult? = null
            for (i in fastProfiles.indices) {
                try {
                    val res = completionService.take().get()
                    if (res != null) {
                        winner = res
                        break
                    }
                } catch (_: Exception) {}
            }

            for (f in futures) {
                if (!f.isDone) f.cancel(true)
            }

            if (winner != null) {
                streamCache[videoId] = CachedEntry(winner, System.currentTimeMillis())
                lastErrorDetail = ""
                return winner
            }
        }

        // Remaining profiles with fresh visitorData
        val freshVisitorData = getOrFetchVisitorData()
        for (p in profiles) {
            if (p.name in skipClients || p in fastProfiles) continue
            try {
                val res = fetchWithProfile(videoId, p, freshVisitorData, errors)
                if (res != null && hasPlayableStreams(res) && isResultPlayable(res)) {
                    streamCache[videoId] = CachedEntry(res, System.currentTimeMillis())
                    lastErrorDetail = ""
                    return res
                }
            } catch (e: Exception) {
                errors.add("${p.name}: ${e.localizedMessage ?: e.javaClass.simpleName}")
            }
        }

        lastErrorDetail = errors.lastOrNull() ?: "No playable formats returned"
        return null
    }

    private fun hasPlayableStreams(res: ResolvedStreamResult): Boolean {
        return res.videoOnlyStreams.isNotEmpty() ||
            res.muxedStreams.isNotEmpty() ||
            !res.hlsUrl.isNullOrEmpty() ||
            !res.dashUrl.isNullOrEmpty()
    }

    private fun getOrFetchVisitorData(): String? {
        cachedVisitorData?.let { return it }
        return try {
            val body = JSONObject().apply {
                put(
                    "context",
                    JSONObject().put(
                        "client",
                        JSONObject()
                            .put("clientName", "WEB")
                            .put("clientVersion", "2.20260708.00.00")
                    )
                )
            }
            val req = Request.Builder()
                .url("https://www.youtube.com/youtubei/v1/visitor_id?prettyPrint=false")
                .post(body.toString().toRequestBody(jsonMediaType))
                .header("Content-Type", "application/json")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val json = JSONObject(resp.body?.string() ?: return null)
                val vd = json.optJSONObject("responseContext")?.optString("visitorData")
                    ?.takeIf { it.isNotBlank() }
                if (vd != null) cachedVisitorData = vd
                vd
            }
        } catch (_: Exception) {
            null
        }
    }

    fun resolve(videoUrl: String, skipClients: Set<String> = emptySet()): ResolvedStreamResult? {
        return resolveFast(videoUrl, skipClients)
    }

    private fun fetchWithProfile(
        videoId: String,
        profile: ClientProfile,
        visitorData: String?,
        errors: MutableList<String>
    ): ResolvedStreamResult? {
        val isWeb = profile.name in setOf("TVHTML5", "WEB_EMBEDDED_PLAYER", "TVHTML5_SIMPLY")
        val clientObj = JSONObject().apply {
            put("clientName", profile.clientName)
            put("clientVersion", profile.clientVersion)
            put("userAgent", profile.userAgent)
            if (!visitorData.isNullOrBlank()) put("visitorData", visitorData)
            profile.extraClientJson(this)
        }
        val contextObj = JSONObject().apply {
            put("client", clientObj)
            profile.extraRootJson(this)
        }
        val bodyObj = JSONObject().apply {
            put("videoId", videoId)
            put("context", contextObj)
            put("contentCheckOk", true)
            put("racyCheckOk", true)
            val pot = if (isWeb) YouTubePoTokenProvider.cachedPoToken else null
            if (!pot.isNullOrBlank()) {
                put("serviceIntegrityDimensions", JSONObject().put("poToken", pot))
            }
        }

        val reqBuilder = Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
            .post(bodyObj.toString().toRequestBody(jsonMediaType))
            .header("Content-Type", "application/json")
            .header("User-Agent", profile.userAgent)
            .header("X-YouTube-Client-Name", profile.clientId)
            .header("X-YouTube-Client-Version", profile.clientVersion)
        if (isWeb) {
            reqBuilder.header("Origin", "https://www.youtube.com")
        }
        if (!visitorData.isNullOrBlank()) {
            reqBuilder.header("X-Goog-Visitor-Id", visitorData)
        }
        val authCookie = if (isWeb) YouTubeAuthStore.getCookie() else null
        if (!authCookie.isNullOrBlank()) {
            reqBuilder.header("Cookie", authCookie)
            YouTubeAuthStore.buildSapisidHash(authCookie)?.let { auth ->
                reqBuilder.header("Authorization", auth)
                reqBuilder.header("X-Origin", "https://www.youtube.com")
            }
        }

        client.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                errors.add("${profile.name}: HTTP ${resp.code}")
                return null
            }
            val raw = resp.body?.string() ?: return null
            val root = JSONObject(raw)

            val playability = root.optJSONObject("playabilityStatus")
            val status = playability?.optString("status") ?: ""
            if (status != "OK" && status != "LIVE_STREAM_OFFLINE") {
                val reason = playability?.optString("reason").orEmpty()
                errors.add("${profile.name}: $status${if (reason.isNotBlank()) " ($reason)" else ""}")
                return null
            }

            val details = root.optJSONObject("videoDetails")
            val title = details?.optString("title").orEmpty()
            val author = details?.optString("author").orEmpty()
            val channelId = details?.optString("channelId").orEmpty()
            val viewCount = details?.optString("viewCount")?.toLongOrNull() ?: 0L

            val streamingData = root.optJSONObject("streamingData")
            if (streamingData == null) {
                errors.add("${profile.name}: missing streamingData")
                return null
            }
            val hlsUrl = streamingData.optString("hlsManifestUrl").takeIf { it.isNotBlank() }
            val dashUrl = streamingData.optString("dashManifestUrl").takeIf { it.isNotBlank() }

            val muxed = mutableListOf<ResolvedVideoStream>()
            val formats = streamingData.optJSONArray("formats")
            if (formats != null) {
                for (i in 0 until formats.length()) {
                    parseVideoFormat(formats.optJSONObject(i), videoId)?.let { muxed.add(it) }
                }
            }

            val videoOnly = mutableListOf<ResolvedVideoStream>()
            val audios = mutableListOf<ResolvedAudioStream>()
            val adaptive = streamingData.optJSONArray("adaptiveFormats")
            if (adaptive != null) {
                for (i in 0 until adaptive.length()) {
                    val f = adaptive.optJSONObject(i) ?: continue
                    val mime = f.optString("mimeType")
                    if (mime.startsWith("video/", ignoreCase = true)) {
                        parseVideoFormat(f, videoId)?.let { videoOnly.add(it) }
                    } else if (mime.startsWith("audio/", ignoreCase = true)) {
                        parseAudioFormat(f, videoId)?.let { audios.add(it) }
                    }
                }
            }

            if (muxed.isEmpty() && videoOnly.isEmpty() && hlsUrl == null && dashUrl == null) {
                errors.add("${profile.name}: no direct/cipher/HLS/DASH URLs")
            }

            return ResolvedStreamResult(
                clientName = profile.name,
                title = title,
                author = author,
                channelId = channelId,
                viewCount = viewCount,
                videoOnlyStreams = videoOnly,
                muxedStreams = muxed,
                audioStreams = audios,
                hlsUrl = hlsUrl,
                dashUrl = dashUrl,
                userAgent = profile.userAgent
            )
        }
    }

    fun parsePlayerResponseJson(
        root: JSONObject,
        videoId: String,
        clientName: String,
        userAgent: String
    ): ResolvedStreamResult? {
        val playability = root.optJSONObject("playabilityStatus")
        val status = playability?.optString("status") ?: ""
        if (status != "OK" && status != "LIVE_STREAM_OFFLINE") {
            return null
        }

        val details = root.optJSONObject("videoDetails")
        val title = details?.optString("title").orEmpty()
        val author = details?.optString("author").orEmpty()
        val channelId = details?.optString("channelId").orEmpty()
        val viewCount = details?.optString("viewCount")?.toLongOrNull() ?: 0L

        val streamingData = root.optJSONObject("streamingData") ?: return null
        val hlsUrl = streamingData.optString("hlsManifestUrl").takeIf { it.isNotBlank() }
        val dashUrl = streamingData.optString("dashManifestUrl").takeIf { it.isNotBlank() }

        val muxed = mutableListOf<ResolvedVideoStream>()
        val formats = streamingData.optJSONArray("formats")
        if (formats != null) {
            for (i in 0 until formats.length()) {
                parseVideoFormat(formats.optJSONObject(i), videoId)?.let { muxed.add(it) }
            }
        }

        val videoOnly = mutableListOf<ResolvedVideoStream>()
        val audios = mutableListOf<ResolvedAudioStream>()
        val adaptive = streamingData.optJSONArray("adaptiveFormats")
        if (adaptive != null) {
            for (i in 0 until adaptive.length()) {
                val f = adaptive.optJSONObject(i) ?: continue
                val mime = f.optString("mimeType")
                if (mime.startsWith("video/", ignoreCase = true)) {
                    parseVideoFormat(f, videoId)?.let { videoOnly.add(it) }
                } else if (mime.startsWith("audio/", ignoreCase = true)) {
                    parseAudioFormat(f, videoId)?.let { audios.add(it) }
                }
            }
        }

        return ResolvedStreamResult(
            clientName = clientName,
            title = title,
            author = author,
            channelId = channelId,
            viewCount = viewCount,
            videoOnlyStreams = videoOnly,
            muxedStreams = muxed,
            audioStreams = audios,
            hlsUrl = hlsUrl,
            dashUrl = dashUrl,
            userAgent = userAgent
        )
    }

    private fun extractStreamUrl(f: JSONObject, videoId: String): String? {
        val direct = f.optString("url").takeIf { it.isNotBlank() }
        if (direct != null) return direct
        val cipher = f.optString("signatureCipher").takeIf { it.isNotBlank() }
            ?: f.optString("cipher").takeIf { it.isNotBlank() }
            ?: return null
        return YouTubeCipherDecryptor.decryptCipherUrl(cipher, videoId)
    }

    private fun parseVideoFormat(f: JSONObject?, videoId: String): ResolvedVideoStream? {
        if (f == null) return null
        val url = extractStreamUrl(f, videoId) ?: return null
        val mime = f.optString("mimeType")
        val height = f.optInt("height", 0)
        if (height <= 0) return null
        val fps = f.optInt("fps", 30)
        val itag = f.optInt("itag", 0)
        val bitrate = f.optInt("bitrate", 0)
        val codecs = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.getOrNull(1) ?: ""
        val formatName = if (mime.contains("webm", ignoreCase = true)) "WebM" else "MPEG_4"
        val colorInfo = f.optJSONObject("colorInfo")
        val transfer = colorInfo?.optString("transferCharacteristics").orEmpty()
        val primaries = colorInfo?.optString("primaries").orEmpty()
        val isColorHdr = transfer.contains("SMPTEST2084", ignoreCase = true) ||
            transfer.contains("ARIB_STD_B67", ignoreCase = true) ||
            primaries.contains("BT2020", ignoreCase = true)
        val rawLabel = f.optString("qualityLabel").takeIf { it.isNotBlank() } ?: "${height}p"
        val qualityLabel = if (isColorHdr && !rawLabel.contains("HDR", ignoreCase = true)) "$rawLabel HDR" else rawLabel
        return ResolvedVideoStream(
            url = url,
            height = height,
            fps = fps,
            itag = itag,
            codec = codecs,
            formatName = formatName,
            resolution = qualityLabel,
            bitrate = bitrate
        )
    }

    private fun parseAudioFormat(f: JSONObject?, videoId: String): ResolvedAudioStream? {
        if (f == null) return null
        val url = extractStreamUrl(f, videoId) ?: return null
        val mime = f.optString("mimeType")
        val bitrateKbps = (f.optInt("averageBitrate", f.optInt("bitrate", 0)) / 1000).coerceAtLeast(1)
        val codecs = Regex("codecs=\"([^\"]+)\"").find(mime)?.groupValues?.getOrNull(1) ?: ""
        val formatName = if (mime.contains("webm", ignoreCase = true)) "WebM" else "M4A"
        val track = f.optJSONObject("audioTrack")
        val trackId = track?.optString("id").orEmpty()
        val displayName = track?.optString("displayName").orEmpty()
        val isDefault = track?.optBoolean("audioIsDefault", false) ?: false
        val langCode = trackId.substringBefore(".").ifBlank { "und" }
        val isDubbed = displayName.contains("dub", ignoreCase = true)
        val isDesc = displayName.contains("descriptive", ignoreCase = true)
        val isOriginal = isDefault || (!isDubbed && !isDesc && displayName.contains("original", ignoreCase = true)) || track == null
        return ResolvedAudioStream(
            url = url,
            bitrateKbps = bitrateKbps,
            codec = codecs,
            formatName = formatName,
            langCode = langCode,
            trackName = displayName,
            isOriginal = isOriginal,
            isDubbed = isDubbed,
            isDescriptive = isDesc
        )
    }
}
