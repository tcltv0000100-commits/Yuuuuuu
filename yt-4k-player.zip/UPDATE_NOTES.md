# YT 4K Player — extraction reliability update

This update keeps the existing app UI and Media3 playback controls. It is a targeted reliability patch, not a complete Vanced reimplementation.

## Included changes

- Fixed the Innertube resolver's acceptance check so DASH-manifest-only responses are treated as valid results.
- Added DASH as a fallback route in the main player when another route fails.
- Added DASH extraction and playback handling to Shorts, including one-shot fallback between muxed, HLS, and DASH routes.
- Replaced silent Innertube exception swallowing with URL-free diagnostics for HTTP errors, playability status/reason, missing streaming data, malformed JSON, and exhausted client attempts.
- Added diagnostics for cipher-only formats. The custom Innertube parser explicitly reports that it cannot decipher those formats rather than silently treating them as ordinary direct URLs.
- Kept NewPipe Extractor v0.27.1, which is already the latest tagged release in this project context; no speculative dependency bump was made.

## Not included / known limits

- This update does **not** implement YouTube's PoToken generation, signature deciphering, or a native SABR MediaSource/MediaPeriod implementation.
- Vanced's compiled APK components are not drop-in Gradle dependencies. Reusing their implementation would require a separately audited, legally compatible source/library and a complete integration effort.
- YouTube can restrict a video by region, age, account, DRM, client profile, or server-side changes. No extractor can guarantee every video will always play.
- A stream can resolve successfully and still fail at playback time (for example, an expired URL or HTTP 403). The updated player now attempts other available routes and surfaces more useful diagnostics.

## Build

Open the project root in Android Studio and sync Gradle. The project requests Android SDK 35 and Java 17 bytecode. This ZIP does not contain a Gradle wrapper. A local Android SDK/Gradle installation is required to build an APK.

## Verification status

Source-level checks were performed on the changed resolver and player paths. A full Android build was not run in this environment because no Android SDK, Gradle executable, or Gradle wrapper was present.
