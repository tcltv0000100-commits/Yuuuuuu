# StreamPlayer 4K (GitHub Actions Cloud Build)

Is project mein **Media3 (ExoPlayer)** aur **NewPipeExtractor** ka use karke 1080p, 1440p (2K), aur 2160p (4K) adaptive DASH streams play karne ka basic setup hai.

## Bina PC ke APK kaise banaye (GitHub se):
1. GitHub par ek naya repository banayein (e.g., `StreamPlayer4K`).
2. Is ZIP file ko extract karein aur saari files (`.github` folder samet) apne repository mein upload/push karein.
3. GitHub repo ke **Actions** tab mein jayein — `Build Android APK` workflow automatically run hoga (ya aap **Run workflow** button daba kar manually chala sakte hain).
4. Build complete hone par workflow ke andar **Artifacts -> `app-debug-apk`** se apna `.apk` download karke phone mein install karein.
