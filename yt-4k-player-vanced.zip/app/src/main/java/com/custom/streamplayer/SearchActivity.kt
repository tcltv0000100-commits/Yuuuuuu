package com.custom.streamplayer

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList

class SearchActivity : AppCompatActivity() {

    private lateinit var searchInput: EditText
    private lateinit var clearBtn: ImageButton
    private lateinit var trendingSection: LinearLayout
    private lateinit var suggestionsHeader: LinearLayout
    private lateinit var suggestionsList: ListView

    private var suggestJob: Job? = null
    private val currentSuggestions = mutableListOf<String>()

    private val trendingQueries = listOf(
        "bhojpuri song",
        "hanuman chalisa",
        "hindi song",
        "sad song",
        "dj song",
        "haryanvi song"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeHelper.applyTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        searchInput = findViewById(R.id.searchInput)
        clearBtn = findViewById(R.id.searchClearBtn)
        trendingSection = findViewById(R.id.trendingSection)
        suggestionsHeader = findViewById(R.id.suggestionsHeader)
        suggestionsList = findViewById(R.id.suggestionsList)

        findViewById<ImageButton>(R.id.searchBackBtn).setOnClickListener { finish() }

        clearBtn.setOnClickListener {
            searchInput.setText("")
            showDefaultState()
        }

        findViewById<ImageButton>(R.id.searchFilterBtn).setOnClickListener {
            val opts = arrayOf("All Videos", "4K / Ultra HD", "Live Streams", "Shorts Only")
            AlertDialog.Builder(this)
                .setTitle("Search Filter")
                .setItems(opts) { _, which ->
                    val q = searchInput.text.toString().trim()
                    val suffix = when (which) {
                        1 -> " 4k"
                        2 -> " live"
                        3 -> " #shorts"
                        else -> ""
                    }
                    if (q.isNotEmpty()) {
                        submitQuery(q + suffix)
                    } else {
                        Toast.makeText(this, "Filter: ${opts[which]}", Toast.LENGTH_SHORT).show()
                    }
                }
                .show()
        }

        findViewById<TextView>(R.id.clearSearchHistoryBtn).setOnClickListener {
            HistoryStore.clearSearches(this)
            showDefaultState()
            Toast.makeText(this, "Search history cleared", Toast.LENGTH_SHORT).show()
        }

        val trendingRv = findViewById<RecyclerView>(R.id.trendingRecycler)
        trendingRv.layoutManager = GridLayoutManager(this, 2)
        trendingRv.adapter = TrendingAdapter(trendingQueries) { q -> submitQuery(q) }

        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                val q = searchInput.text.toString().trim()
                if (q.isNotEmpty()) submitQuery(q)
                true
            } else false
        }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim() ?: ""
                clearBtn.visibility = if (q.isNotEmpty()) View.VISIBLE else View.GONE
                suggestJob?.cancel()
                if (q.isEmpty()) {
                    showDefaultState()
                    return
                }
                trendingSection.visibility = View.GONE
                suggestionsHeader.visibility = View.GONE
                if (q.length < 2 || q.startsWith("http")) {
                    suggestionsList.adapter = null
                    return
                }
                suggestJob = CoroutineScope(Dispatchers.IO).launch {
                    delay(180)
                    try {
                        val list = ServiceList.YouTube.suggestionExtractor.suggestionList(q)
                        withContext(Dispatchers.Main) {
                            currentSuggestions.clear()
                            currentSuggestions.addAll(list.take(8))
                            suggestionsList.adapter = SuggestionAdapter(currentSuggestions, isHistory = false)
                        }
                    } catch (_: Exception) {}
                }
            }
        })

        suggestionsList.setOnItemClickListener { _, _, position, _ ->
            val q = currentSuggestions.getOrNull(position) ?: return@setOnItemClickListener
            submitQuery(q)
        }

        showDefaultState()
        searchInput.requestFocus()
        searchInput.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
        }, 120)
    }

    private fun showDefaultState() {
        trendingSection.visibility = View.VISIBLE
        val saved = HistoryStore.getSearches(this)
        currentSuggestions.clear()
        currentSuggestions.addAll(saved)
        if (saved.isNotEmpty()) {
            suggestionsHeader.visibility = View.VISIBLE
            suggestionsList.adapter = SuggestionAdapter(currentSuggestions, isHistory = true)
        } else {
            suggestionsHeader.visibility = View.GONE
            suggestionsList.adapter = null
        }
    }

    private fun submitQuery(query: String) {
        val intent = Intent().apply { putExtra("search_query", query) }
        setResult(RESULT_OK, intent)
        finish()
    }

    override fun onDestroy() {
        suggestJob?.cancel()
        super.onDestroy()
    }

    private inner class TrendingAdapter(
        private val items: List<String>,
        private val onClick: (String) -> Unit
    ) : RecyclerView.Adapter<TrendingAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val text: TextView = v.findViewById(R.id.trendingText)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_trending_search, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val q = items[position]
            holder.text.text = q
            holder.itemView.setOnClickListener { onClick(q) }
        }

        override fun getItemCount(): Int = items.size
    }

    private inner class SuggestionAdapter(
        private val items: List<String>,
        private val isHistory: Boolean
    ) : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): String = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = convertView ?: LayoutInflater.from(parent.context)
                .inflate(R.layout.item_search_history, parent, false)
            val icon = view.findViewById<ImageView>(R.id.historyItemIcon)
            val text = view.findViewById<TextView>(R.id.historyItemText)
            val del = view.findViewById<ImageButton>(R.id.historyItemDelete)
            val query = items[position]

            text.text = query
            icon.setImageResource(
                if (isHistory) R.drawable.ic_vanced_history
                else R.drawable.ic_vanced_search
            )
            if (isHistory) {
                del.visibility = View.VISIBLE
                del.setOnClickListener {
                    HistoryStore.removeSearch(this@SearchActivity, query)
                    showDefaultState()
                }
            } else {
                del.visibility = View.GONE
            }
            view.setOnClickListener { submitQuery(query) }
            return view
        }
    }
}
