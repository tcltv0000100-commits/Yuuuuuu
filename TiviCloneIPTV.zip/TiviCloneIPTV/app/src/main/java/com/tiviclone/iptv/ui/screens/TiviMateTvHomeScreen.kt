package com.tiviclone.iptv.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.TiviCloneApp
import com.tiviclone.iptv.ui.ActivePlayback
import com.tiviclone.iptv.ui.player.IptvPlayerView
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TiviMateTvHomeScreen(
    channels: List<ChannelEntity>,
    epgPrograms: List<EpgProgramEntity>,
    activePlayback: ActivePlayback?,
    selectedGroup: String,
    showGroups: Boolean,
    onSelectGroup: (String) -> Unit,
    onSelectChannel: (ChannelEntity, Boolean) -> Unit,
    onToggleFavorite: (ChannelEntity) -> Unit,
    onHideChannel: (String) -> Unit,
    onBlockChannel: (String, Boolean) -> Unit,
    onAssignEpg: (String, String) -> Unit,
    onUnhideAll: () -> Unit,
    onUnblockAll: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onOpenMultiview: () -> Unit,
    onClosePlayer: () -> Unit,
    onPlayCatchup: (ChannelEntity, EpgProgramEntity) -> Unit,
    onSetReminder: (ChannelEntity, EpgProgramEntity) -> Unit,
    onRecordChannel: (ChannelEntity, String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onSaveProgress: (Long, Long) -> Unit
) {
    val context = LocalContext.current
    val settings = (context.applicationContext as TiviCloneApp).settingsStore
    val groupsSort = settings.getGroupsSorting()
    val channelsSort = settings.getChannelsSorting()
    val showChannelNumbers = settings.isShowChannelNumbers()
    val groups = remember(channels, groupsSort) {
        val base = channels.map { it.groupName }.distinct()
        val sorted = if (groupsSort == "By name") base.sorted() else base
        listOf("Favorites", "All channels") + sorted
    }
    var contextChannel by remember { mutableStateOf<ChannelEntity?>(null) }
    var infoDialog by remember { mutableStateOf<Pair<String, String>?>(null) }
    var assignEpgChannel by remember { mutableStateOf<ChannelEntity?>(null) }
    var liveResBadge by remember { mutableStateOf("") }
    var liveAudioBadge by remember { mutableStateOf("") }

    val now = System.currentTimeMillis()
    val groupedEpg = remember(epgPrograms) { epgPrograms.groupBy { it.channelTvgId } }
    val currentEpgMap = remember(epgPrograms, now) {
        epgPrograms.filter { it.startTimeMillis <= now && it.endTimeMillis >= now }
            .associateBy { it.channelTvgId }
    }

    val filtered = remember(channels, selectedGroup, channelsSort) {
        val list = when (selectedGroup) {
            "Favorites" -> channels.filter { it.isFavorite }
            "All channels" -> channels
            else -> channels.filter { it.groupName == selectedGroup }
        }
        if (channelsSort == "By name") list.sortedBy { it.name.lowercase() } else list
    }

    val activeChannel = remember(channels, activePlayback) {
        channels.firstOrNull { it.id == activePlayback?.itemId } ?: filtered.firstOrNull()
    }
    val activeProg = activeChannel?.let { currentEpgMap[it.tvgId] }
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val headerTimeFmt = remember { SimpleDateFormat("EEE, dd MMM, hh:mm a", Locale.getDefault()) }

    Box(modifier = Modifier.fillMaxSize().background(TiviColors.Background)) {
        Row(modifier = Modifier.fillMaxSize()) {
            if (showGroups) LazyColumn(
                modifier = Modifier
                    .width(195.dp)
                    .fillMaxHeight()
                    .background(TiviColors.SidebarBg)
                    .padding(horizontal = 10.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(groups, key = { it }) { grp ->
                    val sel = grp == selectedGroup
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (sel) TiviColors.AccentBlue.copy(alpha = 0.25f) else Color.Transparent)
                            .tvFocusableBorder(6)
                            .clickable { onSelectGroup(grp) }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Text(
                            grp,
                            color = if (sel) Color.White else TiviColors.TextSecondary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .background(Color.Black.copy(alpha = 0.45f))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(275.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black)
                    ) {
                        if (activePlayback != null && activePlayback.mediaType == "LIVE" && !activePlayback.isFullscreen) {
                            IptvPlayerView(
                                playback = activePlayback,
                                modifier = Modifier.fillMaxSize(),
                                onBack = onClosePlayer,
                                onToggleFullscreen = onToggleFullscreen,
                                onOpenMultiview = onOpenMultiview,
                                onSaveProgress = onSaveProgress,
                                onVideoInfoChanged = { res, aud ->
                                    liveResBadge = res
                                    liveAudioBadge = aud
                                }
                            )
                        } else if (activeChannel != null) {
                            Box(
                                modifier = Modifier.fillMaxSize().clickable { onSelectChannel(activeChannel, false) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Tap channel to preview", color = TiviColors.TextSecondary, fontSize = 13.sp)
                            }
                        }
                    }

                    val activeNextProg = activeChannel?.let { groupedEpg[it.tvgId]?.firstOrNull { p -> p.startTimeMillis > now } }
                    Column(modifier = Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Center) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (activeChannel != null) {
                                Text(
                                    "${activeChannel.number}  ${activeChannel.name}",
                                    color = TiviColors.AccentBlue,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                            }
                            if (liveResBadge.isNotBlank() && liveResBadge != "Auto") {
                                Box(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.14f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(liveResBadge, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                            if (liveAudioBadge.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.14f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(liveAudioBadge, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            activeProg?.title ?: "No information",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(5.dp))
                        if (activeProg != null) {
                            val span = (activeProg.endTimeMillis - activeProg.startTimeMillis).coerceAtLeast(1L)
                            val pct = ((now - activeProg.startTimeMillis).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                            val remMin = ((activeProg.endTimeMillis - now) / 60_000L).coerceAtLeast(0L)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("${timeFmt.format(Date(activeProg.startTimeMillis))} – ${timeFmt.format(Date(activeProg.endTimeMillis))}", color = TiviColors.TextSecondary, fontSize = 12.sp)
                                LinearProgressIndicator(progress = { pct }, modifier = Modifier.width(90.dp).height(3.dp), color = TiviColors.AccentBlue, trackColor = TiviColors.Divider)
                                Text("$remMin min", color = TiviColors.TextSecondary, fontSize = 12.sp)
                            }
                            if (activeNextProg != null) {
                                Spacer(Modifier.height(4.dp))
                                Text("Next: ${timeFmt.format(Date(activeNextProg.startTimeMillis))} ${activeNextProg.title}", color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            } else if (activeProg.description.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(activeProg.description, color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        } else {
                            Text("Tap to play • Hold anywhere for channel options", color = TiviColors.TextSecondary, fontSize = 12.sp)
                        }
                    }
                }

                // Header
                Row(
                    modifier = Modifier.fillMaxWidth().background(TiviColors.SidebarBg).padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(headerTimeFmt.format(Date(now)), color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.width(225.dp))
                    Text("Now", color = TiviColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("Next", color = TiviColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                }

                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No channels in this group", color = TiviColors.TextSecondary)
                    }
                } else {
                    // Smooth single-axis LazyColumn (no nested horizontalScroll conflict!)
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filtered, key = { it.id }) { ch ->
                            val isSelected = activePlayback?.itemId == ch.id
                            val progs = groupedEpg[ch.tvgId].orEmpty()
                            val nowProg = progs.firstOrNull { it.startTimeMillis <= now && it.endTimeMillis >= now } ?: progs.firstOrNull()
                            val nextProg = progs.firstOrNull { it.startTimeMillis > now }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .background(if (isSelected) TiviColors.CardFocused else TiviColors.PanelBg)
                                    .tvFocusableBorder(4)
                                    .combinedClickable(
                                        onClick = {
                                            if (ch.isBlocked) {
                                                infoDialog = "Blocked Channel" to "${ch.name} is blocked. Unblock it from Channel Options."
                                            } else {
                                                onSelectChannel(ch, isSelected)
                                            }
                                        },
                                        onLongClick = { contextChannel = ch }
                                    )
                                    .padding(horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (showChannelNumbers) Text("${ch.number}", color = TiviColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.width(30.dp))
                                if (ch.logoUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = ch.logoUrl,
                                        contentDescription = ch.name,
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.size(30.dp).padding(end = 8.dp)
                                    )
                                }
                                Row(modifier = Modifier.width(175.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        if (ch.isBlocked) "🔒 ${ch.name}" else ch.name,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (isSelected) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TiviColors.AccentBlue, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Row(
                                    modifier = Modifier.weight(1f),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    EpgSlotBox(
                                        title = nowProg?.title ?: "No information",
                                        isLive = true,
                                        modifier = Modifier.weight(1f),
                                        onClick = {
                                            if (nowProg != null && nowProg.endTimeMillis < now && ch.hasCatchup) onPlayCatchup(ch, nowProg)
                                            else if (ch.isBlocked) infoDialog = "Blocked Channel" to "${ch.name} is blocked."
                                            else onSelectChannel(ch, isSelected)
                                        },
                                        onLongClick = { contextChannel = ch }
                                    )
                                    EpgSlotBox(
                                        title = nextProg?.title ?: "No information",
                                        isLive = false,
                                        modifier = Modifier.weight(1f),
                                        onClick = {
                                            if (nextProg != null) onSetReminder(ch, nextProg)
                                            else if (ch.isBlocked) infoDialog = "Blocked Channel" to "${ch.name} is blocked."
                                            else onSelectChannel(ch, isSelected)
                                        },
                                        onLongClick = { contextChannel = ch }
                                    )
                                }

                                IconButton(onClick = { contextChannel = ch }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = TiviColors.TextSecondary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        contextChannel?.let { ch ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x77000000))
                    .clickable { contextChannel = null }
            ) {
                LazyColumn(
                    modifier = Modifier
                        .width(290.dp)
                        .fillMaxHeight()
                        .align(Alignment.CenterEnd)
                        .background(TiviColors.PanelBg)
                        .clickable(enabled = false) {}
                        .padding(vertical = 12.dp)
                ) {
                    item {
                        val ctxFocus = remember { FocusRequester() }
                        LaunchedEffect(ch.id) { runCatching { ctxFocus.requestFocus() } }
                        ContextRow(Icons.Default.Search, "Search", Modifier.focusRequester(ctxFocus)) { contextChannel = null; onOpenSearch() }
                        ContextRow(Icons.Default.Settings, "Settings") { contextChannel = null; onOpenSettings() }
                        HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 6.dp))
                        Text(currentEpgMap[ch.tvgId]?.title ?: "No information", color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
                        ContextRow(null, "Open in external player") {
                            contextChannel = null
                            if (ch.streamUrl.isNotBlank()) {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(Uri.parse(ch.streamUrl), "video/*") })
                                }
                            }
                        }
                        ContextRow(null, "Record") {
                            contextChannel = null
                            onRecordChannel(ch, currentEpgMap[ch.tvgId]?.title ?: ch.name)
                        }
                        HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 6.dp))
                        Text(ch.name, color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
                        ContextRow(null, if (ch.isFavorite) "Remove from Favorites" else "Add to Favorites") {
                            onToggleFavorite(ch); contextChannel = null
                        }
                        ContextRow(null, if (ch.isBlocked) "Unblock channel" else "Block channel") {
                            onBlockChannel(ch.id, !ch.isBlocked); contextChannel = null
                        }
                        ContextRow(null, "Hide channel") {
                            onHideChannel(ch.id); contextChannel = null
                        }
                        ContextRow(null, "Assign EPG") {
                            assignEpgChannel = ch; contextChannel = null
                        }
                        ContextRow(null, "Channel options") {
                            infoDialog = ch.name to "Group: ${ch.groupName}\nSource: ${ch.sourceType.name}\nCatch-up: ${if (ch.hasCatchup) "${ch.catchupDays} days" else "No"}\nTVG ID: ${ch.tvgId.ifBlank { "None" }}"
                            contextChannel = null
                        }
                        HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 6.dp))
                        Text(selectedGroup, color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
                        ContextRow(null, "Manage Favorites") { onSelectGroup("Favorites"); contextChannel = null }
                        ContextRow(null, "Unblock all channels") {
                            onUnblockAll(); infoDialog = "Manage blocking" to "All blocked channels unlocked."; contextChannel = null
                        }
                        ContextRow(null, "Restore hidden channels") {
                            onUnhideAll(); infoDialog = "Manage visibility" to "All hidden channels restored."; contextChannel = null
                        }
                    }
                }
            }
        }
    }

    assignEpgChannel?.let { ch ->
        var epgIdInput by remember { mutableStateOf(ch.tvgId) }
        AlertDialog(
            onDismissRequest = { assignEpgChannel = null },
            title = { Text("Assign EPG: ${ch.name}") },
            text = { OutlinedTextField(value = epgIdInput, onValueChange = { epgIdInput = it }, label = { Text("XMLTV Channel ID (tvg-id)") }, singleLine = true) },
            confirmButton = { Button(onClick = { onAssignEpg(ch.id, epgIdInput.trim()); assignEpgChannel = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { assignEpgChannel = null }) { Text("Cancel") } }
        )
    }

    infoDialog?.let { (title, body) ->
        AlertDialog(
            onDismissRequest = { infoDialog = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = { TextButton(onClick = { infoDialog = null }) { Text("OK") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EpgSlotBox(
    title: String,
    isLive: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (isLive) Color.White.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.03f))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(title, color = if (isLive) Color.White else TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ContextRow(icon: androidx.compose.ui.graphics.vector.ImageVector?, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier = modifier.fillMaxWidth().tvFocusableBorder(4).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}
