package com.tiviclone.iptv.data.parser

import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.VodMovieEntity
import com.tiviclone.iptv.data.model.MediaType
import com.tiviclone.iptv.data.model.SourceType
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

data class M3uParseResult(
    val channels: List<ChannelEntity>,
    val movies: List<VodMovieEntity>
)

object M3uParser {

    private val attrRegex = Regex("""([a-zA-Z0-9_-]+)="([^"]*)"""")

    fun parse(playlistId: String, input: InputStream): M3uParseResult {
        val channels = mutableListOf<ChannelEntity>()
        val movies = mutableListOf<VodMovieEntity>()

        var currentTitle = ""
        var currentGroup = "General"
        var currentLogo = ""
        var currentTvgId = ""
        var currentCatchupDays = 0
        var currentUserAgent = ""
        var index = 0

        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { reader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val trimmed = line!!.trim()
                if (trimmed.isEmpty()) continue
                when {
                    trimmed.startsWith("#EXTINF:", ignoreCase = true) -> {
                        val attrs = mutableMapOf<String, String>()
                        attrRegex.findAll(trimmed).forEach { m ->
                            attrs[m.groupValues[1].lowercase()] = m.groupValues[2]
                        }
                        currentGroup = attrs["group-title"]?.ifBlank { "General" } ?: "General"
                        currentLogo = attrs["tvg-logo"].orEmpty()
                        currentTvgId = attrs["tvg-id"].orEmpty()
                        currentCatchupDays = attrs["catchup-days"]?.toIntOrNull() ?: 0
                        val commaIdx = trimmed.lastIndexOf(',')
                        currentTitle = if (commaIdx >= 0 && commaIdx < trimmed.length - 1) {
                            trimmed.substring(commaIdx + 1).trim()
                        } else {
                            "Channel ${index + 1}"
                        }
                    }
                    trimmed.startsWith("#EXTVLCOPT:http-user-agent=", ignoreCase = true) -> {
                        currentUserAgent = trimmed.substringAfter("=").trim()
                    }
                    trimmed.startsWith("#") -> Unit
                    trimmed.startsWith("http", ignoreCase = true) || trimmed.startsWith("rtsp", ignoreCase = true) -> {
                        index++
                        val mediaType = classifyMediaType(currentGroup, trimmed)
                        if (mediaType == MediaType.MOVIES) {
                            movies.add(
                                VodMovieEntity(
                                    id = "${playlistId}_m3u_vod_$index",
                                    playlistId = playlistId,
                                    streamId = index.toString(),
                                    name = currentTitle.ifBlank { "Movie $index" },
                                    categoryName = currentGroup,
                                    posterUrl = currentLogo,
                                    streamUrl = trimmed,
                                    sourceType = SourceType.M3U
                                )
                            )
                        } else {
                            channels.add(
                                ChannelEntity(
                                    id = "${playlistId}_m3u_$index",
                                    playlistId = playlistId,
                                    number = index,
                                    name = currentTitle.ifBlank { "Channel $index" },
                                    groupName = currentGroup,
                                    logoUrl = currentLogo,
                                    streamUrl = trimmed,
                                    tvgId = currentTvgId.ifBlank { currentTitle },
                                    hasCatchup = currentCatchupDays > 0,
                                    catchupDays = currentCatchupDays,
                                    sourceType = SourceType.M3U,
                                    userAgent = currentUserAgent
                                )
                            )
                        }
                        currentTitle = ""
                        currentUserAgent = ""
                    }
                }
            }
        }
        return M3uParseResult(channels, movies)
    }

    private fun classifyMediaType(group: String, url: String): MediaType {
        val g = group.lowercase()
        val u = url.lowercase()
        return when {
            u.contains("/movie/") || u.endsWith(".mp4") || u.endsWith(".mkv") || g.contains("vod") || g.contains("movie") ->
                MediaType.MOVIES
            else -> MediaType.LIVE
        }
    }
}
