package com.tiviclone.iptv.recorder

import android.app.AlarmManager
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.tiviclone.iptv.TiviCloneApp
import com.tiviclone.iptv.data.db.RecordingEntity
import com.tiviclone.iptv.data.network.HttpClientProvider
import kotlinx.coroutines.*
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var activeJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            activeJob?.cancel()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val channelName = intent?.getStringExtra(EXTRA_CHANNEL_NAME) ?: "Stream"
        val channelId = intent?.getStringExtra(EXTRA_CHANNEL_ID) ?: ""
        val programTitle = intent?.getStringExtra(EXTRA_PROGRAM_TITLE) ?: channelName
        val streamUrl = intent?.getStringExtra(EXTRA_STREAM_URL) ?: return START_NOT_STICKY
        val durationMs = intent.getLongExtra(EXTRA_DURATION_MS, 0L)

        startForeground(NOTIF_ID, buildNotification("Recording: $programTitle"))
        startStreamCapture(channelId, channelName, programTitle, streamUrl, durationMs)
        return START_STICKY
    }

    private fun startStreamCapture(
        channelId: String,
        channelName: String,
        programTitle: String,
        streamUrl: String,
        durationMs: Long
    ) {
        activeJob?.cancel()
        activeJob = scope.launch {
            val app = applicationContext as TiviCloneApp
            val dir = File(
                getExternalFilesDir(Environment.DIRECTORY_MOVIES),
                "TiviCloneRecordings"
            ).apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val safeName = programTitle.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(32)
            val outFile = File(dir, "${safeName}_$stamp.ts")

            val recId = app.repository.addRecordingRecord(
                RecordingEntity(
                    channelId = channelId,
                    channelName = channelName,
                    programTitle = programTitle,
                    streamUrl = streamUrl,
                    filePath = outFile.absolutePath,
                    status = "RECORDING"
                )
            )

            try {
                val endTime = if (durationMs > 0L) System.currentTimeMillis() + durationMs else Long.MAX_VALUE
                val req = Request.Builder().url(streamUrl).build()
                HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) error("HTTP ${resp.code}")
                    val input = resp.body?.byteStream() ?: error("Empty stream")
                    FileOutputStream(outFile).use { fos ->
                        val buf = ByteArray(16 * 1024)
                        while (isActive && System.currentTimeMillis() < endTime) {
                            val read = input.read(buf)
                            if (read <= 0) break
                            fos.write(buf, 0, read)
                        }
                    }
                }
                app.repository.updateRecordingStatus(recId, "COMPLETED", outFile.absolutePath)
            } catch (_: CancellationException) {
                app.repository.updateRecordingStatus(recId, "COMPLETED", outFile.absolutePath)
            } catch (_: Exception) {
                app.repository.updateRecordingStatus(recId, "FAILED", outFile.absolutePath)
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, TiviCloneApp.CHANNEL_RECORDING)
            .setContentTitle("TiviClone DVR")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        activeJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.tiviclone.iptv.REC_START"
        const val ACTION_STOP = "com.tiviclone.iptv.REC_STOP"
        const val EXTRA_CHANNEL_ID = "channel_id"
        const val EXTRA_CHANNEL_NAME = "channel_name"
        const val EXTRA_PROGRAM_TITLE = "program_title"
        const val EXTRA_STREAM_URL = "stream_url"
        const val EXTRA_DURATION_MS = "duration_ms"
        private const val NOTIF_ID = 4001

        fun start(
            context: Context,
            channelId: String,
            channelName: String,
            programTitle: String,
            streamUrl: String,
            durationMs: Long = 0L
        ) {
            val intent = Intent(context, RecordingService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_CHANNEL_ID, channelId)
                putExtra(EXTRA_CHANNEL_NAME, channelName)
                putExtra(EXTRA_PROGRAM_TITLE, programTitle)
                putExtra(EXTRA_STREAM_URL, streamUrl)
                putExtra(EXTRA_DURATION_MS, durationMs)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(Intent(context, RecordingService::class.java).apply {
                action = ACTION_STOP
            })
        }
    }
}

class RecordingAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val chId = intent.getStringExtra(RecordingService.EXTRA_CHANNEL_ID).orEmpty()
        val chName = intent.getStringExtra(RecordingService.EXTRA_CHANNEL_NAME).orEmpty()
        val title = intent.getStringExtra(RecordingService.EXTRA_PROGRAM_TITLE).orEmpty()
        val url = intent.getStringExtra(RecordingService.EXTRA_STREAM_URL).orEmpty()
        val dur = intent.getLongExtra(RecordingService.EXTRA_DURATION_MS, 3600_000L)
        if (url.isNotBlank()) {
            RecordingService.start(context, chId, chName, title, url, dur)
        }
    }
}

class ReminderAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Program Starting"
        val channel = intent.getStringExtra("channel") ?: ""
        val nm = context.getSystemService(android.app.NotificationManager::class.java)
        val notif = NotificationCompat.Builder(context, TiviCloneApp.CHANNEL_REMINDER)
            .setContentTitle("Reminder: $title")
            .setContentText("Starting now on $channel")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notif)
    }

    companion object {
        fun schedule(context: Context, triggerAtMs: Long, channelName: String, title: String) {
            val am = context.getSystemService(AlarmManager::class.java)
            val intent = Intent(context, ReminderAlarmReceiver::class.java).apply {
                putExtra("title", title)
                putExtra("channel", channelName)
            }
            val pi = PendingIntent.getBroadcast(
                context,
                triggerAtMs.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            runCatching {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }.onFailure {
                am.set(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
            }
        }
    }
}
