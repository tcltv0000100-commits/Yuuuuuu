package com.tiviclone.iptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.ui.ActivePlayback
import com.tiviclone.iptv.ui.player.IptvPlayerView
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LiveTvScreen(
    channels: List<ChannelEntity>,
    epgPrograms: List<EpgProgramEntity>,
    activePlayback: ActivePlayback?,
    onSelectChannel: (ChannelEntity, Boolean) -> Unit,
    onToggleFavorite: (ChannelEntity) -> Unit,
    onToggleFullscreen: () -> Unit,
    onOpenMultiview: () -> Unit,
    onClosePlayer: () -> Unit,
    onPlayCatchup: (ChannelEntity, EpgProgramEntity) -> Unit,
    onSetReminder: (ChannelEntity, EpgProgramEntity) -> Unit,
    onRecordChannel: (ChannelEntity, String) -> Unit,
    onSaveProgress: (Long, Long) -> Unit
) {
    val groups = remember(channels) {
        listOf("All", "Favorites") + channels.map { it.groupName }.distinct()
    }
    var selectedGroup by remember { mutableStateOf("All") }
    var searchText by remember { mutableStateOf("") }

    val now = System.currentTimeMillis()
    val currentEpgMap = remember(epgPrograms, now) {
        epgPrograms.filter { it.startTimeMillis <= now && it.endTimeMillis >= now }
            .associateBy { it.channelTvgId }
    }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    val filtered = remember(channels, selectedGroup, searchText) {
        channels.filter { ch ->
            val groupMatch = when (selectedGroup) {
                "All" -> true
                "Favorites" -> ch.isFavorite
                else -> ch.groupName == selectedGroup
            }
            val searchMatch = searchText.isBlank() || ch.name.contains(searchText, ignoreCase = true)
            groupMatch && searchMatch
        }
    }

    val playingChannel = remember(channels, activePlayback) {
        channels.firstOrNull { it.id == activePlayback?.itemId }
    }
    val channelGuide = remember(playingChannel, epgPrograms) {
        if (playingChannel == null) emptyList()
        else epgPrograms.filter { it.channelTvgId == playingChannel.tvgId }
    }

    Row(modifier = Modifier.fillMaxSize().background(TiviColors.Background)) {
        // Groups column
        LazyColumn(
            modifier = Modifier
                .width(175.dp)
                .fillMaxHeight()
                .background(TiviColors.SidebarBg)
                .padding(8.dp)
        ) {
            items(groups) { grp ->
                val selected = grp == selectedGroup
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) TiviColors.AccentBlue else Color.Transparent)
                        .tvFocusableBorder()
                        .clickable { selectedGroup = grp }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(
                        grp,
                        color = if (selected) Color.White else TiviColors.TextSecondary,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Channels column
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(8.dp)
        ) {
            OutlinedTextField(
                value = searchText,
                onValueChange = { searchText = it },
                placeholder = { Text("Filter channels...", fontSize = 13.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            )
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No channels found. Add a playlist in Settings.", color = TiviColors.TextSecondary)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(filtered, key = { it.id }) { ch ->
                        val prog = currentEpgMap[ch.tvgId]
                        val isSelected = activePlayback?.itemId == ch.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) TiviColors.CardFocused else TiviColors.PanelBg)
                                .tvFocusableBorder()
                                .clickable { onSelectChannel(ch, isSelected) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${ch.number}",
                                color = TiviColors.TextSecondary,
                                fontSize = 12.sp,
                                modifier = Modifier.width(34.dp)
                            )
                            if (ch.logoUrl.isNotBlank()) {
                                AsyncImage(
                                    model = ch.logoUrl,
                                    contentDescription = ch.name,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.size(34.dp).padding(end = 8.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        ch.name,
                                        color = TiviColors.TextPrimary,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (ch.hasCatchup) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            "CATCHUP",
                                            color = TiviColors.CatchupGreen,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                if (prog != null) {
                                    Text(
                                        prog.title,
                                        color = TiviColors.TextSecondary,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val span = (prog.endTimeMillis - prog.startTimeMillis).coerceAtLeast(1L)
                                    val pct = ((now - prog.startTimeMillis).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                                    LinearProgressIndicator(
                                        progress = { pct },
                                        modifier = Modifier.fillMaxWidth().height(2.dp).padding(top = 2.dp),
                                        color = TiviColors.AccentBlue,
                                        trackColor = TiviColors.Divider
                                    )
                                }
                            }
                            IconButton(onClick = { onToggleFavorite(ch) }) {
                                Icon(
                                    if (ch.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                                    contentDescription = "Favorite",
                                    tint = if (ch.isFavorite) TiviColors.FavoriteGold else TiviColors.TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Right Panel: Mini-Player + Channel Guide directly below it
        if (activePlayback != null && activePlayback.mediaType == "LIVE" && !activePlayback.isFullscreen) {
            Column(
                modifier = Modifier
                    .width(340.dp)
                    .fillMaxHeight()
                    .background(Color.Black)
                    .padding(8.dp)
            ) {
                IptvPlayerView(
                    playback = activePlayback,
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                    onBack = onClosePlayer,
                    onToggleFullscreen = onToggleFullscreen,
                    onOpenMultiview = onOpenMultiview,
                    onSaveProgress = onSaveProgress
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(activePlayback.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(activePlayback.subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp)
                    }
                    Button(onClick = onToggleFullscreen) { Text("Fullscreen") }
                }
                Spacer(Modifier.height(10.dp))
                Text("Channel Guide (EPG)", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                if (channelGuide.isEmpty()) {
                    Text("No EPG schedule for this channel.", color = TiviColors.TextSecondary, fontSize = 12.sp)
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(channelGuide, key = { it.rowId }) { prog ->
                            val isLive = prog.startTimeMillis <= now && prog.endTimeMillis >= now
                            val isPast = prog.endTimeMillis < now
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isLive) TiviColors.CardFocused else TiviColors.PanelBg, RoundedCornerShape(6.dp))
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${timeFmt.format(Date(prog.startTimeMillis))} - ${timeFmt.format(Date(prog.endTimeMillis))}",
                                        color = if (isLive) TiviColors.CatchupGreen else TiviColors.TextSecondary,
                                        fontSize = 10.sp
                                    )
                                    Text(prog.title, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                if (playingChannel != null) {
                                    if (isPast && playingChannel.hasCatchup) {
                                        TextButton(onClick = { onPlayCatchup(playingChannel, prog) }) {
                                            Text("Catchup", fontSize = 11.sp, color = TiviColors.CatchupGreen)
                                        }
                                    } else if (prog.startTimeMillis > now) {
                                        IconButton(onClick = { onSetReminder(playingChannel, prog) }) {
                                            Icon(Icons.Default.Notifications, contentDescription = "Remind", tint = TiviColors.FavoriteGold, modifier = Modifier.size(18.dp))
                                        }
                                    } else if (isLive) {
                                        IconButton(onClick = { onRecordChannel(playingChannel, prog.title) }) {
                                            Icon(Icons.Default.FiberManualRecord, contentDescription = "Record", tint = TiviColors.DangerRed, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
