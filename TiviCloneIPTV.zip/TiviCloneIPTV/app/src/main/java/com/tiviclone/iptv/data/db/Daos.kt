package com.tiviclone.iptv.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY lastSyncedAt DESC")
    fun observeAll(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists")
    suspend fun getAll(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(playlist: PlaylistEntity)

    @Query("UPDATE playlists SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: String, enabled: Boolean)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface ChannelDao {
    @Query("SELECT * FROM channels WHERE isHidden = 0 AND playlistId IN (SELECT id FROM playlists WHERE isEnabled = 1) ORDER BY number ASC")
    fun observeAll(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE playlistId = :playlistId AND isHidden = 0 AND playlistId IN (SELECT id FROM playlists WHERE isEnabled = 1) ORDER BY number ASC")
    fun observeByPlaylist(playlistId: String): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE isFavorite = 1 AND isHidden = 0 ORDER BY name ASC")
    fun observeFavorites(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE name LIKE '%' || :query || '%' AND isHidden = 0 LIMIT 100")
    suspend fun search(query: String): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ChannelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ChannelEntity>)

    @Query("UPDATE channels SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: String, fav: Boolean)

    @Query("UPDATE channels SET isHidden = :hidden WHERE id = :id")
    suspend fun setHidden(id: String, hidden: Boolean)

    @Query("UPDATE channels SET isBlocked = :blocked WHERE id = :id")
    suspend fun setBlocked(id: String, blocked: Boolean)

    @Query("UPDATE channels SET tvgId = :tvgId WHERE id = :id")
    suspend fun setTvgId(id: String, tvgId: String)

    @Query("UPDATE channels SET isHidden = 0")
    suspend fun unhideAll()

    @Query("UPDATE channels SET isBlocked = 0")
    suspend fun unblockAll()

    @Query("UPDATE channels SET isHidden = :hidden WHERE playlistId = :playlistId AND groupName = :groupName")
    suspend fun setGroupHidden(playlistId: String, groupName: String, hidden: Boolean)

    @Query("DELETE FROM channels WHERE playlistId = :playlistId")
    suspend fun deleteByPlaylist(playlistId: String)
}

@Dao
interface VodDao {
    @Query("SELECT * FROM vod_movies WHERE playlistId IN (SELECT id FROM playlists WHERE isEnabled = 1) ORDER BY addedAt DESC, name ASC")
    fun observeAll(): Flow<List<VodMovieEntity>>

    @Query("SELECT * FROM vod_movies WHERE playlistId = :playlistId AND playlistId IN (SELECT id FROM playlists WHERE isEnabled = 1) ORDER BY addedAt DESC, name ASC")
    fun observeByPlaylist(playlistId: String): Flow<List<VodMovieEntity>>

    @Query("SELECT * FROM vod_movies WHERE isFavorite = 1 ORDER BY name ASC")
    fun observeFavorites(): Flow<List<VodMovieEntity>>

    @Query("SELECT * FROM vod_movies WHERE name LIKE '%' || :query || '%' LIMIT 100")
    suspend fun search(query: String): List<VodMovieEntity>

    @Query("SELECT * FROM vod_movies WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): VodMovieEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<VodMovieEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: VodMovieEntity)

    @Query("UPDATE vod_movies SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: String, fav: Boolean)

    @Query("DELETE FROM vod_movies WHERE playlistId = :playlistId")
    suspend fun deleteByPlaylist(playlistId: String)
}

@Dao
interface SeriesDao {
    @Query("SELECT * FROM series WHERE playlistId IN (SELECT id FROM playlists WHERE isEnabled = 1) ORDER BY name ASC")
    fun observeAll(): Flow<List<SeriesEntity>>

    @Query("SELECT * FROM series WHERE playlistId = :playlistId AND playlistId IN (SELECT id FROM playlists WHERE isEnabled = 1) ORDER BY name ASC")
    fun observeByPlaylist(playlistId: String): Flow<List<SeriesEntity>>

    @Query("SELECT * FROM series WHERE isFavorite = 1 ORDER BY name ASC")
    fun observeFavorites(): Flow<List<SeriesEntity>>

    @Query("SELECT * FROM series WHERE name LIKE '%' || :query || '%' LIMIT 100")
    suspend fun search(query: String): List<SeriesEntity>

    @Query("SELECT * FROM series WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): SeriesEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSeries(items: List<SeriesEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSeries(item: SeriesEntity)

    @Query("UPDATE series SET isFavorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: String, fav: Boolean)

    @Query("SELECT * FROM episodes WHERE seriesDbId = :seriesDbId ORDER BY seasonNumber ASC, episodeNumber ASC")
    fun observeEpisodes(seriesDbId: String): Flow<List<EpisodeEntity>>

    @Query("SELECT * FROM episodes WHERE seriesDbId = :seriesDbId ORDER BY seasonNumber ASC, episodeNumber ASC")
    suspend fun getEpisodes(seriesDbId: String): List<EpisodeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisodes(items: List<EpisodeEntity>)

    @Query("DELETE FROM episodes WHERE seriesDbId = :seriesDbId")
    suspend fun deleteEpisodesBySeries(seriesDbId: String)

    @Query("DELETE FROM episodes WHERE playlistId = :playlistId")
    suspend fun deleteEpisodesByPlaylist(playlistId: String)

    @Query("DELETE FROM series WHERE playlistId = :playlistId")
    suspend fun deleteByPlaylist(playlistId: String)
}

@Dao
interface EpgDao {
    @Query("SELECT * FROM epg_programs WHERE endTimeMillis >= :nowMs ORDER BY startTimeMillis ASC")
    fun observeUpcomingAndCurrent(nowMs: Long): Flow<List<EpgProgramEntity>>

    @Query("SELECT * FROM epg_programs WHERE channelTvgId = :tvgId ORDER BY startTimeMillis ASC")
    suspend fun getForChannel(tvgId: String): List<EpgProgramEntity>

    @Query("SELECT * FROM epg_programs WHERE title LIKE '%' || :query || '%' AND endTimeMillis >= :nowMs LIMIT 80")
    suspend fun search(query: String, nowMs: Long): List<EpgProgramEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<EpgProgramEntity>)

    @Query("DELETE FROM epg_programs WHERE playlistId = :playlistId")
    suspend fun deleteByPlaylist(playlistId: String)

    @Query("DELETE FROM epg_programs WHERE endTimeMillis < :olderThanMs")
    suspend fun pruneOld(olderThanMs: Long)
}

@Dao
interface WatchHistoryDao {
    @Query("SELECT * FROM watch_history WHERE isWatched = 0 AND positionMs > 5000 ORDER BY updatedAt DESC LIMIT 50")
    fun observeContinueWatching(): Flow<List<WatchHistoryEntity>>

    @Query("SELECT * FROM watch_history ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<WatchHistoryEntity>>

    @Query("SELECT * FROM watch_history WHERE itemId = :itemId LIMIT 1")
    suspend fun getById(itemId: String): WatchHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: WatchHistoryEntity)

    @Query("DELETE FROM watch_history WHERE itemId = :itemId")
    suspend fun deleteById(itemId: String)

    @Query("DELETE FROM watch_history")
    suspend fun clearAll()
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY startTimeMillis ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ReminderEntity): Long

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface RecordingDao {
    @Query("SELECT * FROM recordings ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<RecordingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: RecordingEntity): Long

    @Query("UPDATE recordings SET status = :status, filePath = :filePath WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, filePath: String)

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteById(id: Long)
}
