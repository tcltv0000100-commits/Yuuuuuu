package com.tiviclone.iptv.data.model

import androidx.media3.common.Tracks

data class XtreamConfig(
    val serverUrl: String,
    val username: String,
    val password: String
)

data class StalkerConfig(
    val portalUrl: String,
    val macAddress: String,
    val stbType: String = "MAG250",
    val portalMode: String = "Auto",
    val serialNumber: String = "",
    val deviceId: String = "",
    val deviceId2: String = "",
    val signature: String = ""
)

data class AccountInfo(
    val username: String = "",
    val status: String = "",
    val expDate: String = "",
    val activeCons: String = "0",
    val maxConnections: String = "1",
    val serverTimezone: String = ""
)

data class TrackOption(
    val trackType: Int,
    val group: Tracks.Group,
    val trackIndex: Int,
    val label: String,
    val isSelected: Boolean
)
