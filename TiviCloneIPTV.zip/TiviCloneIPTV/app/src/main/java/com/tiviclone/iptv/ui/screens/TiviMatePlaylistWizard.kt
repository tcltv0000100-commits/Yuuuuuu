package com.tiviclone.iptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.data.db.PlaylistEntity
import com.tiviclone.iptv.data.model.SourceType
import com.tiviclone.iptv.data.model.StalkerConfig
import com.tiviclone.iptv.data.network.StalkerClient
import com.tiviclone.iptv.ui.PlaylistProcessingState
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder

private enum class WizardStep {
    TYPE,
    M3U_PARAMS,
    XTREAM_PARAMS,
    STALKER_PARAMS
}

@Composable
fun TiviMatePlaylistWizard(
    editingPlaylist: PlaylistEntity? = null,
    processingState: PlaylistProcessingState?,
    onPickM3uFile: () -> Unit,
    onSubmitM3u: (name: String, url: String, epgUrl: String, editId: String?, includeVod: Boolean) -> Unit,
    onSubmitXtream: (name: String, server: String, user: String, pass: String, editId: String?, includeVod: Boolean, format: String) -> Unit,
    onSubmitStalker: (name: String, cfg: StalkerConfig, editId: String?, includeVod: Boolean) -> Unit,
    onDoneProcessing: () -> Unit,
    onCancel: () -> Unit
) {
    val initialStep = when (editingPlaylist?.type) {
        SourceType.M3U -> WizardStep.M3U_PARAMS
        SourceType.XTREAM -> WizardStep.XTREAM_PARAMS
        SourceType.STALKER -> WizardStep.STALKER_PARAMS
        null -> WizardStep.TYPE
    }
    var step by remember(editingPlaylist) { mutableStateOf(initialStep) }

    var name by remember(editingPlaylist) { mutableStateOf(editingPlaylist?.name.orEmpty()) }
    var m3uUrl by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.M3U) editingPlaylist.primaryUrl else "")
    }
    var epgUrl by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.M3U) editingPlaylist.epgUrl else "")
    }
    var xtreamServer by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.XTREAM) editingPlaylist.primaryUrl else "")
    }
    var xtreamUser by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.XTREAM) editingPlaylist.extra1 else "")
    }
    var xtreamPass by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.XTREAM) editingPlaylist.extra2 else "")
    }
    var stalkerPortal by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.STALKER) editingPlaylist.primaryUrl else "")
    }
    var stalkerMac by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.STALKER) editingPlaylist.extra1 else "")
    }
    var stbType by remember(editingPlaylist) {
        mutableStateOf(editingPlaylist?.stbType?.ifBlank { "MAG250" } ?: "MAG250")
    }
    var portalMode by remember(editingPlaylist) {
        mutableStateOf(editingPlaylist?.portalMode?.ifBlank { "Auto" } ?: "Auto")
    }
    var serialNumber by remember(editingPlaylist) {
        mutableStateOf(editingPlaylist?.serialNumber.orEmpty())
    }
    var deviceId by remember(editingPlaylist) {
        mutableStateOf(editingPlaylist?.deviceId.orEmpty())
    }
    var deviceId2 by remember(editingPlaylist) {
        mutableStateOf(editingPlaylist?.deviceId2.orEmpty())
    }
    var signature by remember(editingPlaylist) {
        mutableStateOf(editingPlaylist?.signature.orEmpty())
    }
    var includeVod by remember(editingPlaylist) { mutableStateOf(editingPlaylist?.includeVod ?: true) }
    var outputFormat by remember(editingPlaylist) { mutableStateOf(editingPlaylist?.outputFormat ?: "MPEG-TS") }

    if (processingState != null) {
        ProcessingWizardScreen(state = processingState, onDone = onDoneProcessing)
        return
    }

    Row(modifier = Modifier.fillMaxSize().background(TiviColors.Background)) {
        // Left Column
        Box(
            modifier = Modifier
                .weight(0.35f)
                .fillMaxHeight()
                .background(TiviColors.SidebarBg)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.PlaylistAdd, contentDescription = null, tint = TiviColors.AccentBlue, modifier = Modifier.size(48.dp))
                Column {
                    Text(
                        when (step) {
                            WizardStep.TYPE -> "Playlist type"
                            WizardStep.M3U_PARAMS -> "M3U playlist"
                            WizardStep.XTREAM_PARAMS -> "Xtream Codes"
                            WizardStep.STALKER_PARAMS -> "Stalker Portal"
                        },
                        color = Color.White,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Medium
                    )
                    if (editingPlaylist != null) {
                        Text("Edit parameters", color = TiviColors.TextSecondary, fontSize = 13.sp)
                    }
                }
            }
        }

        // Middle Column
        Column(
            modifier = Modifier
                .weight(0.47f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.Center
        ) {
            when (step) {
                WizardStep.TYPE -> {
                    WizardMenuOption("M3U playlist", "URL or local .m3u / .m3u8 file") { step = WizardStep.M3U_PARAMS }
                    WizardMenuOption("Xtream Codes", "Server URL, Username & Password") { step = WizardStep.XTREAM_PARAMS }
                    WizardMenuOption("Stalker Portal", "Portal URL, MAC, MAG Model & Auto IDs") { step = WizardStep.STALKER_PARAMS }
                }

                WizardStep.M3U_PARAMS -> {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Playlist name (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = m3uUrl, onValueChange = { m3uUrl = it }, label = { Text("Enter URL (http://...)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = epgUrl, onValueChange = { epgUrl = it }, label = { Text("XMLTV EPG URL (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Include VOD", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = includeVod, onCheckedChange = { includeVod = it })
                    }
                    if (editingPlaylist == null) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = onPickM3uFile, modifier = Modifier.fillMaxWidth()) {
                            Text("Or Select Local .m3u File")
                        }
                    }
                }

                WizardStep.XTREAM_PARAMS -> {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Playlist name (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = xtreamServer, onValueChange = { xtreamServer = it }, label = { Text("Server address (http://host:port)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = xtreamUser, onValueChange = { xtreamUser = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(value = xtreamPass, onValueChange = { xtreamPass = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Include VOD", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = includeVod, onCheckedChange = { includeVod = it })
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Output format:", color = TiviColors.TextSecondary, fontSize = 13.sp)
                        listOf("MPEG-TS", "HLS").forEach { fmt ->
                            FilterChip(selected = outputFormat == fmt, onClick = { outputFormat = fmt }, label = { Text(fmt) })
                        }
                    }
                }

                WizardStep.STALKER_PARAMS -> {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Playlist name (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = stalkerPortal,
                        onValueChange = { stalkerPortal = it },
                        label = { Text("Server address (http://.../c/)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = stalkerMac,
                        onValueChange = { newMac ->
                            stalkerMac = newMac
                            if (newMac.trim().length >= 11) {
                                val auto = StalkerClient.generateIdentityFromMac(newMac, stbType)
                                serialNumber = auto.sn
                                deviceId = auto.deviceId
                                deviceId2 = auto.deviceId2
                                signature = auto.signature
                            }
                        },
                        label = { Text("MAC address (Auto-fills SN, D1, D2, Sig)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("Portal Type / Path Mode", color = TiviColors.AccentBlue, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StalkerClient.PORTAL_MODES.forEach { mode ->
                            FilterChip(
                                selected = portalMode == mode,
                                onClick = { portalMode = mode },
                                label = { Text(mode, fontSize = 12.sp) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("STB / MAG Model", color = TiviColors.AccentBlue, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StalkerClient.MAG_MODELS.forEach { model ->
                            FilterChip(
                                selected = stbType == model,
                                onClick = { stbType = model },
                                label = { Text(model, fontSize = 12.sp) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = serialNumber,
                        onValueChange = { serialNumber = it },
                        label = { Text("Serial Number (SN)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = deviceId,
                        onValueChange = { deviceId = it },
                        label = { Text("Device ID 1") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = deviceId2,
                        onValueChange = { deviceId2 = it },
                        label = { Text("Device ID 2") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = signature,
                        onValueChange = { signature = it },
                        label = { Text("Signature") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Include VOD", color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = includeVod, onCheckedChange = { includeVod = it })
                    }
                }
            }
        }

        // Right Column
        Column(
            modifier = Modifier
                .weight(0.18f)
                .fillMaxHeight()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            if (step != WizardStep.TYPE) {
                Button(
                    onClick = {
                        val eid = editingPlaylist?.id
                        when (step) {
                            WizardStep.M3U_PARAMS -> if (m3uUrl.isNotBlank()) onSubmitM3u(name, m3uUrl, epgUrl, eid, includeVod)
                            WizardStep.XTREAM_PARAMS -> if (xtreamServer.isNotBlank() && xtreamUser.isNotBlank()) {
                                onSubmitXtream(name, xtreamServer, xtreamUser, xtreamPass, eid, includeVod, outputFormat)
                            }
                            WizardStep.STALKER_PARAMS -> if (stalkerPortal.isNotBlank() && stalkerMac.isNotBlank()) {
                                onSubmitStalker(
                                    name,
                                    StalkerConfig(
                                        portalUrl = stalkerPortal,
                                        macAddress = stalkerMac,
                                        stbType = stbType,
                                        portalMode = portalMode,
                                        serialNumber = serialNumber,
                                        deviceId = deviceId,
                                        deviceId2 = deviceId2,
                                        signature = signature
                                    ),
                                    eid,
                                    includeVod
                                )
                            }
                            else -> Unit
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Next") }
                Spacer(Modifier.height(10.dp))
                if (editingPlaylist == null) {
                    TextButton(onClick = { step = WizardStep.TYPE }) { Text("Back", color = Color.White) }
                }
            }
            TextButton(onClick = onCancel) { Text("Cancel", color = TiviColors.TextSecondary) }
        }
    }
}

@Composable
private fun ProcessingWizardScreen(
    state: PlaylistProcessingState,
    onDone: () -> Unit
) {
    Row(modifier = Modifier.fillMaxSize().background(TiviColors.Background)) {
        Box(
            modifier = Modifier.weight(0.35f).fillMaxHeight().background(TiviColors.SidebarBg).padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (state.isProcessing) {
                    CircularProgressIndicator(color = TiviColors.AccentBlue)
                } else {
                    Icon(
                        if (state.errorText != null) Icons.Default.Error else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (state.errorText != null) TiviColors.DangerRed else TiviColors.CatchupGreen,
                        modifier = Modifier.size(48.dp)
                    )
                }
                Text(state.statusText, color = Color.White, fontSize = 18.sp)
            }
        }

        Column(
            modifier = Modifier.weight(0.47f).fillMaxHeight().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            if (state.errorText != null) {
                Text("Error:", color = TiviColors.DangerRed, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Text(state.errorText, color = Color.White, fontSize = 14.sp)
            } else if (state.isProcessing) {
                Text("Fetching Live channels, Movies & Shows...", color = TiviColors.TextSecondary, fontSize = 15.sp)
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = TiviColors.AccentBlue)
            } else {
                Text("Playlist is processed", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(16.dp))
                Text("Channels processed: ${state.channelsProcessed}", color = TiviColors.TextPrimary, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                Text("Movies processed: ${state.moviesProcessed}", color = TiviColors.TextPrimary, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                Text("Shows processed: ${state.showsProcessed}", color = TiviColors.TextPrimary, fontSize = 15.sp)
            }
        }

        Box(modifier = Modifier.weight(0.18f).fillMaxHeight().padding(16.dp), contentAlignment = Alignment.CenterStart) {
            if (!state.isProcessing) {
                Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Done") }
            }
        }
    }
}

@Composable
private fun WizardMenuOption(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(TiviColors.PanelBg, RoundedCornerShape(8.dp))
            .tvFocusableBorder(8)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Text(subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp)
    }
}
