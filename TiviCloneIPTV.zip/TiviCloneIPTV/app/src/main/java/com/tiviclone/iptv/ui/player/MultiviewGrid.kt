package com.tiviclone.iptv.ui.player

import android.view.ViewGroup
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.ui.theme.TiviColors

@Composable
fun MultiviewGrid(
    channels: List<ChannelEntity>,
    initialChannel: ChannelEntity?,
    onResolveUrl: suspend (ChannelEntity) -> String,
    onExit: () -> Unit
) {
    val slots = remember {
        mutableStateListOf<ChannelEntity?>(initialChannel, null, null, null)
    }
    var activeAudioSlot by remember { mutableIntStateOf(0) }
    var pickingSlot by remember { mutableIntStateOf(-1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(TiviColors.SidebarBg)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Multiview (Tap screen for Audio)", color = Color.White, fontSize = 15.sp)
            Button(onClick = onExit) { Text("Exit Multiview") }
        }

        Column(modifier = Modifier.weight(1f)) {
            Row(modifier = Modifier.weight(1f)) {
                MultiviewSlot(
                    channel = slots[0],
                    hasAudio = activeAudioSlot == 0,
                    onResolveUrl = onResolveUrl,
                    onFocusAudio = { activeAudioSlot = 0 },
                    onPickChannel = { pickingSlot = 0 },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                MultiviewSlot(
                    channel = slots[1],
                    hasAudio = activeAudioSlot == 1,
                    onResolveUrl = onResolveUrl,
                    onFocusAudio = { activeAudioSlot = 1 },
                    onPickChannel = { pickingSlot = 1 },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            Row(modifier = Modifier.weight(1f)) {
                MultiviewSlot(
                    channel = slots[2],
                    hasAudio = activeAudioSlot == 2,
                    onResolveUrl = onResolveUrl,
                    onFocusAudio = { activeAudioSlot = 2 },
                    onPickChannel = { pickingSlot = 2 },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                MultiviewSlot(
                    channel = slots[3],
                    hasAudio = activeAudioSlot == 3,
                    onResolveUrl = onResolveUrl,
                    onFocusAudio = { activeAudioSlot = 3 },
                    onPickChannel = { pickingSlot = 3 },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
    }

    if (pickingSlot >= 0) {
        AlertDialog(
            onDismissRequest = { pickingSlot = -1 },
            title = { Text("Select Channel for Screen ${pickingSlot + 1}") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                    items(channels) { ch ->
                        TextButton(
                            onClick = {
                                slots[pickingSlot] = ch
                                activeAudioSlot = pickingSlot
                                pickingSlot = -1
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${ch.number}. ${ch.name}", color = Color.White)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { pickingSlot = -1 }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun MultiviewSlot(
    channel: ChannelEntity?,
    hasAudio: Boolean,
    onResolveUrl: suspend (ChannelEntity) -> String,
    onFocusAudio: () -> Unit,
    onPickChannel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var resolvedUrl by remember(channel) { mutableStateOf("") }

    LaunchedEffect(channel) {
        resolvedUrl = if (channel != null) onResolveUrl(channel) else ""
    }

    val player = remember(resolvedUrl) {
        if (resolvedUrl.isBlank()) null
        else ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(resolvedUrl))
            prepare()
            playWhenReady = true
        }
    }

    LaunchedEffect(player, hasAudio) {
        player?.volume = if (hasAudio) 1f else 0f
    }

    DisposableEffect(player) {
        onDispose { player?.release() }
    }

    Box(
        modifier = modifier
            .padding(2.dp)
            .border(
                BorderStroke(if (hasAudio) 2.dp else 1.dp, if (hasAudio) TiviColors.AccentBlue else TiviColors.Divider)
            )
            .background(TiviColors.PanelBg)
            .clickable {
                if (channel == null) onPickChannel() else onFocusAudio()
            }
    ) {
        if (player != null) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = false
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { it.player = player },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                "Empty Slot\n(Tap to add)",
                color = TiviColors.TextSecondary,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(Color(0x99000000))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(channel?.name ?: "Slot", color = Color.White, fontSize = 12.sp)
            TextButton(onClick = onPickChannel) { Text("Change", fontSize = 11.sp) }
        }
    }
}
