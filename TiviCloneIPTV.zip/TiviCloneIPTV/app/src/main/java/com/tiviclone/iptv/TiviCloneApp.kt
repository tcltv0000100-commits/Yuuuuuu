package com.tiviclone.iptv

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.tiviclone.iptv.data.db.AppDatabase
import com.tiviclone.iptv.data.repository.IptvRepository
import com.tiviclone.iptv.data.repository.SettingsStore
import com.tiviclone.iptv.worker.SyncScheduler

class TiviCloneApp : Application() {

    val database by lazy { AppDatabase.getInstance(this) }
    val settingsStore by lazy { SettingsStore(this) }
    val repository by lazy { IptvRepository(this, database, settingsStore) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        SyncScheduler.schedulePeriodicSync(this, settingsStore.getEpgIntervalHours())
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_RECORDING,
                    "Stream Recording",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_REMINDER,
                    "Program Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                )
            )
        }
    }

    companion object {
        const val CHANNEL_RECORDING = "tiviclone_recording"
        const val CHANNEL_REMINDER = "tiviclone_reminder"
    }
}
