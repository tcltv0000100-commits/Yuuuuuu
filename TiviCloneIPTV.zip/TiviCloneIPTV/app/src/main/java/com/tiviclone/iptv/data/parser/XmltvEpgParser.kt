package com.tiviclone.iptv.data.parser

import com.tiviclone.iptv.data.db.EpgProgramEntity
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale

object XmltvEpgParser {

    private val xmltvDateFormat = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
    private val xmltvShortFormat = SimpleDateFormat("yyyyMMddHHmmss", Locale.US)

    fun parse(playlistId: String, input: InputStream, onBatch: (List<EpgProgramEntity>) -> Unit) {
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(input, "UTF-8")

        val batch = ArrayList<EpgProgramEntity>(500)
        var event = parser.eventType
        var currentTag = ""
        var channelId = ""
        var startMs = 0L
        var stopMs = 0L
        var title = ""
        var desc = ""
        var inProgramme = false

        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    if (currentTag == "programme") {
                        inProgramme = true
                        channelId = parser.getAttributeValue(null, "channel").orEmpty()
                        startMs = parseDate(parser.getAttributeValue(null, "start"))
                        stopMs = parseDate(parser.getAttributeValue(null, "stop"))
                        title = ""
                        desc = ""
                    }
                }
                XmlPullParser.TEXT -> {
                    if (inProgramme) {
                        when (currentTag) {
                            "title" -> if (title.isEmpty()) title = parser.text.trim()
                            "desc" -> if (desc.isEmpty()) desc = parser.text.trim()
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "programme" && inProgramme) {
                        inProgramme = false
                        if (channelId.isNotBlank() && startMs > 0L && stopMs > 0L) {
                            batch.add(
                                EpgProgramEntity(
                                    playlistId = playlistId,
                                    channelTvgId = channelId,
                                    title = title.ifBlank { "No Title" },
                                    description = desc,
                                    startTimeMillis = startMs,
                                    endTimeMillis = stopMs
                                )
                            )
                            if (batch.size >= 500) {
                                onBatch(batch.toList())
                                batch.clear()
                            }
                        }
                    }
                    currentTag = ""
                }
            }
            event = parser.next()
        }
        if (batch.isNotEmpty()) {
            onBatch(batch.toList())
        }
    }

    private fun parseDate(raw: String?): Long {
        if (raw.isNullOrBlank()) return 0L
        return try {
            synchronized(xmltvDateFormat) {
                xmltvDateFormat.parse(raw.trim())?.time ?: 0L
            }
        } catch (_: Exception) {
            try {
                synchronized(xmltvShortFormat) {
                    xmltvShortFormat.parse(raw.trim().take(14))?.time ?: 0L
                }
            } catch (_: Exception) {
                0L
            }
        }
    }
}
