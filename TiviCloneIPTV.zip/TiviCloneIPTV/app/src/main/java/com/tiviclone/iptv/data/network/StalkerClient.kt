package com.tiviclone.iptv.data.network

import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.data.db.EpisodeEntity
import com.tiviclone.iptv.data.db.SeriesEntity
import com.tiviclone.iptv.data.db.VodMovieEntity
import com.tiviclone.iptv.data.model.SourceType
import com.tiviclone.iptv.data.model.StalkerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.MessageDigest

data class StalkerLoadResult(
    val activePortalUrl: String,
    val token: String,
    val accountStatus: String,
    val accountExpiry: String,
    val channels: List<ChannelEntity>,
    val movies: List<VodMovieEntity>,
    val series: List<SeriesEntity>,
    val epgPrograms: List<EpgProgramEntity> = emptyList()
)

data class StbIdentity(
    val mac: String,
    val stbType: String,
    val sn: String,
    val deviceId: String,
    val deviceId2: String,
    val signature: String,
    val hwVersion2: String
)

object StalkerClient {

    val MAG_MODELS = listOf("MAG250", "MAG254", "MAG270", "MAG275", "MAG322", "MAG324", "MAG420", "MAG524")
    val PORTAL_MODES = listOf("Auto", "portal.php", "server/load.php", "stalker_portal", "c/server/load.php")

    const val STB_USER_AGENT =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

    private val stalkerHttp by lazy { HttpClientProvider.createClient(STB_USER_AGENT) }

    fun fixScheme(raw: String): String {
        var s = raw.trim().trimStart('/')
        if (s.startsWith("http:/") && !s.startsWith("http://")) s = "http://" + s.removePrefix("http:/")
        if (s.startsWith("https:/") && !s.startsWith("https://")) s = "https://" + s.removePrefix("https:/")
        return if (s.startsWith("http://") || s.startsWith("https://")) s else "http://$s"
    }

    fun extractOrigin(url: String): String {
        return try {
            val u = URI(fixScheme(url))
            val port = if (u.port > 0) ":${u.port}" else ""
            "${u.scheme}://${u.host}$port"
        } catch (_: Exception) {
            fixScheme(url).trimEnd('/')
        }
    }

    fun buildPortalCandidates(rawUrl: String, portalMode: String = "Auto"): List<String> {
        val fixed = fixScheme(rawUrl).trimEnd('/')
        val origin = extractOrigin(fixed)
        val cleanBase = fixed.removeSuffix("/c").removeSuffix("/stalker_portal").trimEnd('/')
        return when (portalMode) {
            "portal.php" -> listOf("$cleanBase/portal.php", "$origin/portal.php").distinct()
            "server/load.php" -> listOf("$cleanBase/server/load.php", "$origin/server/load.php").distinct()
            "stalker_portal" -> listOf("$origin/stalker_portal/server/load.php", "$cleanBase/stalker_portal/server/load.php").distinct()
            "c/server/load.php" -> listOf("$origin/c/server/load.php", "$cleanBase/c/server/load.php").distinct()
            else -> {
                val list = mutableListOf<String>()
                if (fixed.endsWith(".php", ignoreCase = true)) list.add(fixed)
                list.addAll(
                    listOf(
                        "$cleanBase/server/load.php",
                        "$cleanBase/stalker_portal/server/load.php",
                        "$cleanBase/portal.php",
                        "$origin/stalker_portal/server/load.php",
                        "$origin/server/load.php",
                        "$origin/portal.php",
                        "$origin/c/server/load.php"
                    )
                )
                list.distinct()
            }
        }
    }

    private fun hashHex(algo: String, input: String): String {
        val md = MessageDigest.getInstance(algo).digest(input.toByteArray())
        return md.joinToString("") { "%02X".format(it) }
    }

    fun generateIdentityFromMac(mac: String, stbType: String = "MAG250"): StbIdentity {
        val cleanMac = mac.trim().uppercase()
        val sn = hashHex("MD5", cleanMac).take(13)
        val devId = hashHex("SHA-256", cleanMac)
        val devId2 = devId
        val sig = hashHex("SHA-256", "${cleanMac}_${sn}_${devId}")
        val hw2 = hashHex("MD5", cleanMac).lowercase()
        return StbIdentity(cleanMac, stbType.ifBlank { "MAG250" }, sn, devId, devId2, sig, hw2)
    }

    private fun resolveIdentity(cfg: StalkerConfig): StbIdentity {
        val auto = generateIdentityFromMac(cfg.macAddress, cfg.stbType)
        return auto.copy(
            stbType = cfg.stbType.ifBlank { auto.stbType },
            sn = cfg.serialNumber.trim().ifBlank { auto.sn },
            deviceId = cfg.deviceId.trim().ifBlank { auto.deviceId },
            deviceId2 = cfg.deviceId2.trim().ifBlank { cfg.deviceId.trim().ifBlank { auto.deviceId } },
            signature = cfg.signature.trim().ifBlank { auto.signature }
        )
    }

    private fun buildReferer(portal: String): String {
        return portal
            .replace("/server/load.php", "/c/")
            .replace("/portal.php", "/c/")
    }

    private fun buildStbHeaders(
        id: StbIdentity,
        token: String = "",
        portal: String = "",
        phpSessId: String = "",
        includeDeviceHeaders: Boolean = true,
        legacyHeaders: Boolean = false
    ): Map<String, String> {
        val encodedMac = if (legacyHeaders) id.mac else URLEncoder.encode(id.mac, "UTF-8")
        val cookieParts = mutableListOf(
            "mac=$encodedMac",
            "stb_lang=en",
            "timezone=GMT",
            "display_menu=true"
        )
        if (phpSessId.isNotBlank()) cookieParts.add("PHPSESSID=$phpSessId")
        val ua = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) ${id.stbType} stbapp ver: 2 rev: 250 Safari/533.3"
        val xUa = if (legacyHeaders) "Model: ${id.stbType}; Link: WiFi" else "model=${id.stbType}; gpsi=0.2.18-r22; runtime=qt;"
        val headers = mutableMapOf(
            "User-Agent" to ua,
            "X-User-Agent" to xUa,
            "Cookie" to cookieParts.joinToString("; "),
            "Accept" to "*/*",
            "Accept-Language" to "en-US,en;q=0.9",
            "Connection" to "keep-alive"
        )
        if (includeDeviceHeaders) {
            headers["SN"] = id.sn
            headers["Device-Id"] = id.deviceId
            headers["Device-Id2"] = id.deviceId2
            headers["Signature"] = id.signature
        }
        if (token.isNotBlank()) headers["Authorization"] = "Bearer $token"
        if (portal.isNotBlank()) headers["Referer"] = buildReferer(portal)
        return headers
    }

    private data class ProfileResult(
        val token: String,
        val sessId: String,
        val status: String,
        val expiry: String
    )

    private fun authenticateProfile(
        portal: String,
        id: StbIdentity,
        initialToken: String,
        sessId: String,
        hsRandom: String = ""
    ): ProfileResult {
        var curToken = initialToken
        var curSess = sessId
        val randVal = hsRandom.ifBlank { hashHex("MD5", "${id.mac}_${System.currentTimeMillis()}") }
        val metrics = URLEncoder.encode(
            JSONObject().apply {
                put("mac", id.mac)
                put("sn", id.sn)
                put("model", id.stbType)
                put("type", "STB")
                put("uid", id.deviceId)
                put("random", randVal)
            }.toString(),
            "UTF-8"
        )
        val (verRaw, imgVer, hwVer2, tiviPrehash) = when (id.stbType.uppercase()) {
            "MAG250" -> listOf(
                "ImageDescription: 0.2.18-r19-pub-250; ImageDate: Mon Jun 12 11:04:49 EEST 2017; PORTAL version: 5.6.8; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566",
                "218",
                "38250bbadc4503a19b1553bf26b090dee3c6e964",
                "868b80d5fa1f01394479e0948ba422cb58d87267"
            )
            "MAG254" -> listOf(
                "ImageDescription: 0.2.18-r23-pub-254; ImageDate: Wed Aug 29 10:49:26 EEST 2018; PORTAL version: 5.6.0; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566",
                "218",
                "38250bbadc4503a19b1553bf26b090dee3c6e964",
                "868b80d5fa1f01394479e0948ba422cb58d87267"
            )
            else -> listOf(
                "ImageDescription: 0.2.18-r22-pub-270; ImageDate: Tue Dec 19 11:33:53 EET 2017; PORTAL version: 5.6.1; API Version: JS API version: 328; STB API version: 134; Player Engine version: 0x566",
                "0.2.18",
                "ecf87650406bba50b0801a4347093864b89b38e6",
                "efd15c16dc497e0839ff5accfdc6ed99c32c4e2a"
            )
        }
        val verEnc = URLEncoder.encode(verRaw, "UTF-8")
        val sigEnc = URLEncoder.encode(id.signature, "UTF-8")
        val ts = System.currentTimeMillis() / 1000L

        val baseProfile = "$portal?type=stb&action=get_profile" +
            "&hd=1&ver=$verEnc&num_banks=2" +
            "&sn=${id.sn}&stb_type=${id.stbType}&client_type=STB&image_version=$imgVer&video_out=hdmi" +
            "&device_id=${id.deviceId}&device_id2=${id.deviceId2}&signature=$sigEnc" +
            "&hw_version=1.7-BD-00&not_valid_token=0&metrics=$metrics" +
            "&hw_version_2=$hwVer2&timestamp=$ts&api_signature=262&prehash=$tiviPrehash&JsHttpRequest=1-xml"

        var (json, newSess, _) = fetchJsonWithSession(
            "$baseProfile&auth_second_step=1",
            buildStbHeaders(id, curToken, portal, curSess)
        )
        if (newSess.isNotBlank()) curSess = newSess
        val js1 = json?.optJSONObject("js")
        val newTok1 = js1?.optString("token").orEmpty()
        if (newTok1.isNotBlank()) curToken = newTok1

        if (js1 == null) {
            val res2 = fetchJsonWithSession(
                "$baseProfile&auth_second_step=0",
                buildStbHeaders(id, curToken, portal, curSess)
            )
            if (res2.first != null) json = res2.first
            if (res2.second.isNotBlank()) curSess = res2.second
        }

        val js = json?.optJSONObject("js")
        val newTok2 = js?.optString("token").orEmpty()
        if (newTok2.isNotBlank()) curToken = newTok2

        val msg = js?.optString("msg").orEmpty()
        if (msg.contains("blocked", ignoreCase = true) || msg.contains("expired", ignoreCase = true)) {
            throw IllegalStateException("Portal message: $msg")
        }

        var expiry = js?.optString("expire_billing_date").orEmpty()
            .ifBlank { js?.optString("tariff_expired_date").orEmpty() }
            .ifBlank { js?.optString("end_date").orEmpty() }
        val status = if (js?.optInt("blocked", 0) == 1) "Blocked" else "Active"

        if (expiry.isBlank() || expiry == "0000-00-00" || expiry == "null") {
            val (accJson, _, _) = fetchJsonWithSession(
                "$portal?type=account_info&action=get_main_info&JsHttpRequest=1-xml",
                buildStbHeaders(id, curToken, portal, curSess)
            )
            val accJs = accJson?.optJSONObject("js")
            val accExp = accJs?.optString("end_date").orEmpty()
                .ifBlank { accJs?.optString("phone").orEmpty() }
            if (accExp.isNotBlank() && accExp != "null") expiry = accExp
        }

        return ProfileResult(curToken, curSess, status, expiry)
    }

    suspend fun loadAll(
        playlistId: String,
        cfg: StalkerConfig,
        maxVodPages: Int = 5000,
        fetchEpg: Boolean = true
    ): StalkerLoadResult =
        withContext(Dispatchers.IO) {
            val id = resolveIdentity(cfg)
            val candidates = buildPortalCandidates(cfg.portalUrl, cfg.portalMode)
            var activePortal = ""
            var token = ""
            var sessId = ""
            var hsRandom = ""
            var lastDiag = ""
            val prehash = hashHex("SHA-1", id.mac).lowercase()

            for (candidate in candidates) {
                val nowMs = System.currentTimeMillis()
                val urls = listOf(
                    "$candidate?type=stb&action=handshake&token=&prehash=13f0848280789b506aeb024ec95eb65cc07b6ce7&JsHttpRequest=${nowMs}-xml",
                    "$candidate?type=stb&action=handshake&prehash=false&JsHttpRequest=${nowMs}-xml",
                    "$candidate?type=stb&action=handshake&token=&JsHttpRequest=1-xml",
                    "$candidate?type=stb&action=handshake&token=&prehash=$prehash&JsHttpRequest=1-xml"
                )
                for (hsUrl in urls) {
                    val (hs, hsSess, rawInfo) = fetchJsonWithSession(hsUrl, buildStbHeaders(id, "", candidate, ""))
                    lastDiag = rawInfo
                    val jsObj = hs?.optJSONObject("js")
                    val t = jsObj?.optString("token").orEmpty()
                    if (t.isNotBlank()) {
                        activePortal = candidate
                        token = t
                        sessId = hsSess
                        hsRandom = jsObj?.optString("random").orEmpty()
                        break
                    }
                }
                if (token.isNotBlank()) break
            }

            if (token.isBlank() || activePortal.isBlank()) {
                throw IllegalStateException("Stalker handshake failed for ${cfg.portalUrl} ($lastDiag)")
            }

            val profile = authenticateProfile(activePortal, id, token, sessId, hsRandom)
            token = profile.token
            var headers = buildStbHeaders(id, token, activePortal, profile.sessId, includeDeviceHeaders = true)
            val origin = extractOrigin(activePortal)

            // 1. Live TV (if Authorization failed with device headers, retry with minimal headers)
            val tsMs = System.currentTimeMillis()
            var liveGenres = fetchGenreMap("$activePortal?type=itv&action=get_genres&JsHttpRequest=${tsMs}-xml", headers)
            var (chJson, _, chDiag) = fetchJsonWithSession(
                "$activePortal?type=itv&action=get_all_channels&force_ch_link_check=&JsHttpRequest=${tsMs}-xml",
                headers
            )
            if (chDiag.contains("Authorization failed", ignoreCase = true)) {
                val legHeaders = buildStbHeaders(id, "", activePortal, "", includeDeviceHeaders = false, legacyHeaders = true)
                val (hs2, sess2, _) = fetchJsonWithSession("$activePortal?type=stb&action=handshake&token=&JsHttpRequest=1-xml", legHeaders)
                val tok2 = hs2?.optJSONObject("js")?.optString("token").orEmpty().ifBlank { token }
                val s2 = sess2.ifBlank { profile.sessId }
                headers = buildStbHeaders(id, tok2, activePortal, s2, includeDeviceHeaders = false, legacyHeaders = true)
                fetchJsonWithSession("$activePortal?type=stb&action=get_profile&hd=1&auth_second_step=0&JsHttpRequest=1-xml", headers)
                token = tok2
                liveGenres = fetchGenreMap("$activePortal?type=itv&action=get_genres&JsHttpRequest=1-xml", headers)
                val retry = fetchJsonWithSession("$activePortal?type=itv&action=get_all_channels&force_ch_link_check=&JsHttpRequest=1-xml", headers)
                chJson = retry.first
                chDiag = retry.third
            }

            var chArr = extractDataArray(chJson)
            if (chArr.length() == 0) {
                val combined = JSONArray()
                var p = 1
                while (p <= 5000) {
                    val (pgJson, _, _) = fetchJsonWithSession(
                        "$activePortal?type=itv&action=get_ordered_list&genre=*&force_ch_link_check=&fav=0&sortby=number&hd=0&p=$p&JsHttpRequest=1-xml",
                        headers
                    )
                    val pageArr = extractDataArray(pgJson)
                    if (pageArr.length() == 0) break
                    for (k in 0 until pageArr.length()) combined.put(pageArr.get(k))
                    val jsObj = pgJson?.optJSONObject("js")
                    val total = jsObj?.optInt("total_items", 0) ?: 0
                    val maxPage = jsObj?.optInt("max_page_items", 0) ?: 0
                    if (total > 0 && combined.length() >= total) break
                    if (maxPage > 0 && pageArr.length() < maxPage) break
                    p++
                }
                chArr = combined
            }

            val channels = ArrayList<ChannelEntity>(chArr.length())
            for (i in 0 until chArr.length()) {
                val o = chArr.optJSONObject(i) ?: continue
                val cid = o.optString("id").ifBlank { "${i + 1}" }
                val cmd = extractCmd(o)
                if (cmd.isBlank()) continue
                val genreId = o.optString("tv_genre_id")
                channels.add(
                    ChannelEntity(
                        id = "${playlistId}_stalker_live_$cid",
                        playlistId = playlistId,
                        number = o.optString("number").toIntOrNull() ?: (i + 1),
                        name = o.optString("name", "Channel ${i + 1}"),
                        groupName = liveGenres[genreId] ?: "Live TV",
                        logoUrl = resolveLogo(origin, o.optString("logo")),
                        tvgId = o.optString("xmltv_id").ifBlank { cid },
                        hasCatchup = o.optInt("enable_tv_archive", 0) == 1,
                        catchupDays = o.optInt("tv_archive_duration", 0),
                        sourceType = SourceType.STALKER,
                        stalkerCmd = cmd,
                        streamId = cid
                    )
                )
            }

            // 2. Fetch VOD, Series & EPG in parallel for <1 min load
            val movies = mutableListOf<VodMovieEntity>()
            val seriesList = mutableListOf<SeriesEntity>()
            var epgList = emptyList<EpgProgramEntity>()

            coroutineScope {
                val vodJob = async(Dispatchers.IO) {
                    val vodCats = fetchGenreMap("$activePortal?type=vod&action=get_categories&JsHttpRequest=1-xml", headers)
                        .ifEmpty { fetchGenreMap("$activePortal?type=vod&action=get_genres&JsHttpRequest=1-xml", headers) }
                    val vodItems = fetchOrderedPages(activePortal, "vod", headers, vodCats.keys.toList(), maxVodPages)
                    vodCats to vodItems
                }
                val seriesJob = async(Dispatchers.IO) {
                    val seriesCats = fetchGenreMap("$activePortal?type=series&action=get_categories&JsHttpRequest=1-xml", headers)
                        .ifEmpty { fetchGenreMap("$activePortal?type=series&action=get_genres&JsHttpRequest=1-xml", headers) }
                    val sItems = fetchOrderedPages(activePortal, "series", headers, seriesCats.keys.toList(), maxVodPages)
                    seriesCats to sItems
                }
                val epgJob = async(Dispatchers.IO) {
                    if (fetchEpg) fetchStalkerEpg(activePortal, headers, playlistId, channels) else emptyList()
                }

                val (vodCats, vodItems) = vodJob.await()
                for (o in vodItems) {
                    val vid = o.optString("id")
                    if (vid.isBlank()) continue
                    val catId = o.optString("category_id")
                    val catName = vodCats[catId] ?: o.optString("genres_str", "Movies").ifBlank { "Movies" }
                    if (o.optInt("is_series", 0) == 1) {
                        seriesList.add(
                            SeriesEntity(
                                id = "${playlistId}_stalker_series_$vid",
                                playlistId = playlistId,
                                seriesId = vid,
                                name = o.optString("name", "Series"),
                                categoryName = catName,
                                posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                                sourceType = SourceType.STALKER,
                                stalkerCmd = extractCmd(o),
                                rating = o.optString("rating_imdb"),
                                releaseDate = o.optString("year"),
                                plot = o.optString("description"),
                                cast = o.optString("actors"),
                                director = o.optString("director")
                            )
                        )
                    } else {
                        movies.add(
                            VodMovieEntity(
                                id = "${playlistId}_stalker_vod_$vid",
                                playlistId = playlistId,
                                streamId = vid,
                                name = o.optString("name", "Movie"),
                                categoryName = catName,
                                posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                                stalkerCmd = extractCmd(o),
                                sourceType = SourceType.STALKER,
                                rating = o.optString("rating_imdb"),
                                releaseDate = o.optString("year"),
                                duration = o.optString("time"),
                                plot = o.optString("description"),
                                cast = o.optString("actors"),
                                director = o.optString("director"),
                                detailsFetched = true
                            )
                        )
                    }
                }

                val (seriesCats, sItems) = seriesJob.await()
                for (o in sItems) {
                    val sid = o.optString("id")
                    if (sid.isBlank()) continue
                    val catId = o.optString("category_id")
                    seriesList.add(
                        SeriesEntity(
                            id = "${playlistId}_stalker_series_$sid",
                            playlistId = playlistId,
                            seriesId = sid,
                            name = o.optString("name", "Series"),
                            categoryName = seriesCats[catId] ?: o.optString("genres_str", "Series").ifBlank { "Series" },
                            posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                            sourceType = SourceType.STALKER,
                            stalkerCmd = extractCmd(o),
                            rating = o.optString("rating_imdb"),
                            releaseDate = o.optString("year"),
                            plot = o.optString("description"),
                            cast = o.optString("actors"),
                            director = o.optString("director")
                        )
                    )
                }
                epgList = epgJob.await()
            }

            if (channels.isEmpty() && movies.isEmpty() && seriesList.isEmpty()) {
                val hint = if (chDiag.contains("Authorization failed", ignoreCase = true)) {
                    "MAC ${id.mac} rejected by portal (check if MAC is active/valid or locked to specific SN/Device ID)."
                } else chDiag
                throw IllegalStateException("Portal connected ($activePortal, ${id.stbType}) but returned 0 items: $hint")
            }
            StalkerLoadResult(
                activePortalUrl = activePortal,
                token = token,
                accountStatus = profile.status,
                accountExpiry = profile.expiry,
                channels = channels,
                movies = movies,
                series = seriesList.distinctBy { it.id },
                epgPrograms = epgList
            )
        }

    private suspend fun fetchOrderedPages(
        portal: String,
        type: String,
        headers: Map<String, String>,
        fallbackCategories: List<String>,
        maxPagesLimit: Int = 5000
    ): List<JSONObject> = coroutineScope {
        val out = mutableListOf<JSONObject>()
        var urlPattern = "$portal?type=$type&action=get_ordered_list&category=*&p=%d&sortby=added&JsHttpRequest=1-xml"
        var (json1, _, _) = fetchJsonWithSession(urlPattern.format(1), headers)
        var arr1 = extractDataArray(json1)
        if (arr1.length() == 0) {
            urlPattern = "$portal?type=$type&action=get_ordered_list&p=%d&JsHttpRequest=1-xml"
            json1 = fetchJsonWithSession(urlPattern.format(1), headers).first
            arr1 = extractDataArray(json1)
        }
        if (arr1.length() == 0) {
            urlPattern = "$portal?type=$type&action=get_ordered_list&movie_id=0&season_id=0&episode_id=0&p=%d&JsHttpRequest=1-xml"
            json1 = fetchJsonWithSession(urlPattern.format(1), headers).first
            arr1 = extractDataArray(json1)
        }

        val seenIds = HashSet<String>()
        fun addUnique(arr: JSONArray): Int {
            var added = 0
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val itemId = obj.optString("id").ifBlank { "${obj.optString("name")}_$i" }
                if (seenIds.add(itemId)) {
                    out.add(obj)
                    added++
                }
            }
            return added
        }

        if (arr1.length() > 0) {
            addUnique(arr1)
            val js1 = json1?.optJSONObject("js")
            val total = js1?.optInt("total_items", 0) ?: 0
            val maxPage = (js1?.optInt("max_page_items", 0) ?: 0).takeIf { it > 0 } ?: arr1.length()
            val totalPages = if (total > 0 && maxPage > 0) ((total + maxPage - 1) / maxPage).coerceAtMost(maxPagesLimit) else 0

            if (totalPages > 1) {
                for (start in 2..totalPages step 16) {
                    val end = (start + 15).coerceAtMost(totalPages)
                    val batch = (start..end).map { p ->
                        async(Dispatchers.IO) { extractDataArray(fetchJsonWithSession(urlPattern.format(p), headers).first) }
                    }.awaitAll()
                    var batchAdded = 0
                    var hitEmpty = false
                    for (arr in batch) {
                        if (arr.length() == 0) { hitEmpty = true; break }
                        batchAdded += addUnique(arr)
                    }
                    if (hitEmpty || batchAdded == 0) break
                }
            } else if (total == 0 && arr1.length() >= maxPage) {
                var start = 2
                while (start <= maxPagesLimit) {
                    val batch = (start until (start + 16).coerceAtMost(maxPagesLimit + 1)).map { p ->
                        async(Dispatchers.IO) { extractDataArray(fetchJsonWithSession(urlPattern.format(p), headers).first) }
                    }.awaitAll()
                    var batchAdded = 0
                    var done = false
                    for (arr in batch) {
                        if (arr.length() == 0) { done = true; break }
                        batchAdded += addUnique(arr)
                        if (arr.length() < maxPage) { done = true; break }
                    }
                    if (done || batchAdded == 0) break
                    start += 16
                }
            }
        }

        if (out.isEmpty() && fallbackCategories.isNotEmpty()) {
            val validCats = fallbackCategories.filter { it != "*" && it.isNotBlank() }
            val catsToLoad = if (maxPagesLimit < 100) validCats.take(6) else validCats
            for (chunk in catsToLoad.chunked(10)) {
                val catResults = chunk.map { cat ->
                    async(Dispatchers.IO) {
                        val list = mutableListOf<JSONObject>()
                        var cp = 1
                        while (cp <= maxPagesLimit.coerceAtMost(500)) {
                            val (json, _, _) = fetchJsonWithSession(
                                "$portal?type=$type&action=get_ordered_list&category=$cat&p=$cp&JsHttpRequest=1-xml",
                                headers
                            )
                            val arr = extractDataArray(json)
                            if (arr.length() == 0) break
                            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { list.add(it) }
                            val jsObj = json?.optJSONObject("js")
                            val total = jsObj?.optInt("total_items", 0) ?: 0
                            val maxPage = jsObj?.optInt("max_page_items", 0) ?: 0
                            if (total > 0 && list.size >= total) break
                            if (maxPage > 0 && arr.length() < maxPage) break
                            if (maxPage == 0 && arr.length() < 10) break
                            cp++
                        }
                        list
                    }
                }.awaitAll()
                catResults.forEach { out.addAll(it) }
            }
        }
        out
    }

    private fun extractCmd(o: JSONObject): String {
        val direct = o.optString("cmd")
        if (direct.isNotBlank()) return direct
        val cmds = o.optJSONArray("cmds") ?: return ""
        return cmds.optJSONObject(0)?.optString("url").orEmpty()
    }

    private fun stripStreamPrefix(raw: String): String {
        var s = raw.trim()
        for (prefix in listOf("ffmpeg ", "ffrt ", "ffrt2 ", "ffrt3 ", "ffrt4 ", "auto ")) {
            if (s.startsWith(prefix, ignoreCase = true)) {
                s = s.substring(prefix.length).trim()
            }
        }
        return s
    }

    private fun firstInt(s: String?): Int? {
        if (s.isNullOrBlank()) return null
        return Regex("\\d+").find(s)?.value?.toIntOrNull()
    }

    private fun fetchAllPages(urlTemplate: String, headers: Map<String, String>): JSONArray {
        val combined = JSONArray()
        var p = 1
        while (p <= 200) {
            val (json, _, _) = fetchJsonWithSession(urlTemplate.format(p), headers)
            val arr = extractDataArray(json)
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) combined.put(arr.get(i))
            val jsObj = json?.optJSONObject("js")
            val total = jsObj?.optInt("total_items", 0) ?: 0
            val maxPage = jsObj?.optInt("max_page_items", 0) ?: 0
            if (total > 0 && combined.length() >= total) break
            if (maxPage > 0 && arr.length() < maxPage) break
            if (maxPage == 0 && total == 0 && arr.length() < 14) break
            p++
        }
        return combined
    }

    suspend fun loadSeriesEpisodes(
        playlistId: String,
        cfg: StalkerConfig,
        token: String,
        series: SeriesEntity
    ): List<EpisodeEntity> = withContext(Dispatchers.IO) {
        val id = resolveIdentity(cfg)
        val portal = if (cfg.portalUrl.endsWith(".php", ignoreCase = true)) cfg.portalUrl else buildPortalCandidates(cfg.portalUrl, cfg.portalMode).first()
        var activeToken = token
        var headers = buildStbHeaders(id, activeToken, portal)
        var sJson = fetchJsonWithSession("$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&p=1&JsHttpRequest=${System.currentTimeMillis()}-xml", headers)
        if (sJson.third.contains("Authorization failed", ignoreCase = true)) {
            val hs = refreshToken(portal, id)
            if (hs.isNotBlank()) {
                activeToken = hs
                headers = buildStbHeaders(id, activeToken, portal)
            }
        }
        var seasons = fetchAllPages("$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&p=%d&JsHttpRequest=1-xml", headers)
        if (seasons.length() == 0) {
            seasons = fetchAllPages("$portal?type=vod&action=get_ordered_list&movie_id=${series.seriesId}&p=%d&JsHttpRequest=1-xml", headers)
        }
        if (seasons.length() == 0) {
            seasons = fetchAllPages("$portal?type=vod&action=get_ordered_list&movie_id=${series.seriesId}&season_id=0&episode_id=0&p=%d&JsHttpRequest=1-xml", headers)
        }

        val episodes = mutableListOf<EpisodeEntity>()
        for (i in 0 until seasons.length()) {
            val sObj = seasons.optJSONObject(i) ?: continue
            val seasonId = sObj.optString("id")
            val sName = sObj.optString("name")
            val seasonNum = firstInt(sObj.optString("season_number"))
                ?: firstInt(sName)
                ?: (i + 1)

            // Case A: Stalker season object embeds episode numbers in "season_series" or "series" JSONArray
            // Only short-circuit if > 1 episode is embedded; if length == 1 (e.g. [76] count), fall through to Case B FullEpisode check!
            val embeddedSeries = sObj.optJSONArray("series") ?: sObj.optJSONArray("season_series")
            if (embeddedSeries != null && embeddedSeries.length() > 1) {
                val rawBaseCmd = extractCmd(sObj)
                for (k in 0 until embeddedSeries.length()) {
                    val epNum = embeddedSeries.optInt(k, k + 1)
                    val epCmd = if (rawBaseCmd.isNotBlank()) rawBaseCmd else "auto /media/${seasonId}_${epNum}.mpg"
                    episodes.add(
                        EpisodeEntity(
                            id = "${series.id}_s${seasonNum}_e${epNum}",
                            seriesDbId = series.id,
                            playlistId = playlistId,
                            episodeId = epNum.toString(),
                            seasonNumber = seasonNum,
                            episodeNumber = epNum,
                            title = "Episode $epNum",
                            thumbnailUrl = series.posterUrl,
                            stalkerCmd = "$epCmd|$epNum|$seasonId|${series.seriesId}",
                            sourceType = SourceType.STALKER
                        )
                    )
                }
                continue
            }

            // Case A2: comma-separated "season_series" or "series" string
            val seriesStr = sObj.optString("season_series").ifBlank { sObj.optString("series") }
            if (seriesStr.isNotBlank() && !seriesStr.startsWith("[") && seriesStr.any { it.isDigit() }) {
                val baseCmd = extractCmd(sObj)
                val nums = seriesStr.split(",").mapNotNull { it.trim().toIntOrNull() }
                if (nums.isNotEmpty()) {
                    for (epNum in nums) {
                        val epCmd = if (baseCmd.isNotBlank()) baseCmd else "auto /media/${seasonId}_${epNum}.mpg"
                        episodes.add(
                            EpisodeEntity(
                                id = "${series.id}_s${seasonNum}_e${epNum}",
                                seriesDbId = series.id,
                                playlistId = playlistId,
                                episodeId = epNum.toString(),
                                seasonNumber = seasonNum,
                                episodeNumber = epNum,
                                title = "Episode $epNum",
                                thumbnailUrl = series.posterUrl,
                                stalkerCmd = "$epCmd|$epNum|$seasonId|${series.seriesId}",
                                sourceType = SourceType.STALKER
                            )
                        )
                    }
                    continue
                }
            }

            // Case B: Paginated episodes for this season_id (type=series then type=vod)
            var epArr = fetchAllPages(
                "$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&season_id=$seasonId&p=%d&JsHttpRequest=1-xml",
                headers
            )
            if (epArr.length() == 0) {
                epArr = fetchAllPages(
                    "$portal?type=vod&action=get_ordered_list&movie_id=${series.seriesId}&season_id=$seasonId&p=%d&JsHttpRequest=1-xml",
                    headers
                )
            }
            if (epArr.length() == 0 && sObj.optInt("is_season", 0) == 0 && extractCmd(sObj).isNotBlank()) {
                val epNum = firstInt(sObj.optString("series_number"))
                    ?: firstInt(sObj.optString("episode_number"))
                    ?: (i + 1)
                episodes.add(
                    EpisodeEntity(
                        id = "${series.id}_s1_e${epNum}_$seasonId",
                        seriesDbId = series.id,
                        playlistId = playlistId,
                        episodeId = seasonId,
                        seasonNumber = 1,
                        episodeNumber = epNum,
                        title = sName.ifBlank { "Episode $epNum" },
                        thumbnailUrl = series.posterUrl,
                        stalkerCmd = "${extractCmd(sObj)}||$seasonId|${series.seriesId}",
                        sourceType = SourceType.STALKER
                    )
                )
                continue
            }
            var addedFromB = 0
            for (j in 0 until epArr.length()) {
                val ep = epArr.optJSONObject(j) ?: continue
                if (ep.optInt("is_season", 0) == 1) continue
                val fullEpSeries = ep.optJSONArray("series")
                if (fullEpSeries != null && fullEpSeries.length() > 1) {
                    val baseCmd = extractCmd(ep).ifBlank { extractCmd(sObj) }
                    for (k in 0 until fullEpSeries.length()) {
                        val epNum = fullEpSeries.optInt(k, k + 1)
                        val epCmd = if (baseCmd.isNotBlank()) baseCmd else "auto /media/${seasonId}_${epNum}.mpg"
                        episodes.add(
                            EpisodeEntity(
                                id = "${series.id}_s${seasonNum}_e${epNum}",
                                seriesDbId = series.id,
                                playlistId = playlistId,
                                episodeId = epNum.toString(),
                                seasonNumber = seasonNum,
                                episodeNumber = epNum,
                                title = "Episode $epNum",
                                thumbnailUrl = series.posterUrl,
                                stalkerCmd = "$epCmd|$epNum|$seasonId|${series.seriesId}",
                                sourceType = SourceType.STALKER
                            )
                        )
                        addedFromB++
                    }
                    continue
                }
                val epName = ep.optString("name", "Episode ${j + 1}")
                if (epName.startsWith("Season ", ignoreCase = true)) continue
                val eid = ep.optString("id")
                val cmd = extractCmd(ep).ifBlank { "/media/file_${eid}.mpg" }
                val epNum = firstInt(ep.optString("series_number"))
                    ?: firstInt(ep.optString("episode_number"))
                    ?: (j + 1)
                episodes.add(
                    EpisodeEntity(
                        id = "${series.id}_s${seasonNum}_e${epNum}_$eid",
                        seriesDbId = series.id,
                        playlistId = playlistId,
                        episodeId = eid,
                        seasonNumber = seasonNum,
                        episodeNumber = epNum,
                        title = epName,
                        thumbnailUrl = series.posterUrl,
                        stalkerCmd = "$cmd|$epNum|$seasonId|${series.seriesId}",
                        sourceType = SourceType.STALKER
                    )
                )
                addedFromB++
            }
            if (addedFromB == 0 && embeddedSeries != null && embeddedSeries.length() == 1) {
                val epNum = embeddedSeries.optInt(0, 1)
                val rawBaseCmd = extractCmd(sObj)
                val epCmd = if (rawBaseCmd.isNotBlank()) rawBaseCmd else "auto /media/${seasonId}_${epNum}.mpg"
                episodes.add(
                    EpisodeEntity(
                        id = "${series.id}_s${seasonNum}_e${epNum}",
                        seriesDbId = series.id,
                        playlistId = playlistId,
                        episodeId = epNum.toString(),
                        seasonNumber = seasonNum,
                        episodeNumber = epNum,
                        title = "Episode $epNum",
                        thumbnailUrl = series.posterUrl,
                        stalkerCmd = "$epCmd|$epNum|$seasonId|${series.seriesId}",
                        sourceType = SourceType.STALKER
                    )
                )
            }
        }
        episodes.distinctBy { it.id }.sortedWith(compareBy({ it.seasonNumber }, { it.episodeNumber }))
    }

    private fun refreshToken(portal: String, id: StbIdentity): String {
        val prehash = hashHex("SHA-1", id.mac).lowercase()
        val (hs, sess, _) = fetchJsonWithSession(
            "$portal?type=stb&action=handshake&prehash=false&JsHttpRequest=${System.currentTimeMillis()}-xml",
            buildStbHeaders(id, "", portal, "")
        )
        val js = hs?.optJSONObject("js")
        val tok = js?.optString("token").orEmpty()
        if (tok.isBlank()) return ""
        return runCatching {
            authenticateProfile(portal, id, tok, sess, js?.optString("random").orEmpty()).token
        }.getOrDefault(tok)
    }

    suspend fun createStreamLink(
        portalUrl: String,
        cfg: StalkerConfig,
        token: String,
        cmd: String,
        type: String = "itv",
        streamId: String = ""
    ): String? = withContext(Dispatchers.IO) {
        val id = resolveIdentity(cfg)
        val portal = if (portalUrl.endsWith(".php", ignoreCase = true)) portalUrl else buildPortalCandidates(portalUrl, cfg.portalMode).first()
        var activeToken = token
        val parts = cmd.split("|")
        val rawCmd = parts[0].trim()
        val epSeriesParam = if (parts.size > 1) parts[1].trim() else ""
        val seasonIdParam = if (parts.size > 2) parts[2].trim() else ""
        val seriesIdParam = if (parts.size > 3) parts[3].trim() else ""

        // TiviMate 5.3.3 Stalker VOD & Series resolution
        val candidateCmds = mutableListOf<String>()
        if (rawCmd.isNotBlank()) candidateCmds.add(rawCmd)
        if (type == "vod" && epSeriesParam.isNotBlank()) {
            if (seasonIdParam.isNotBlank()) {
                candidateCmds.add("/media/file_${seasonIdParam}.mpg")
                candidateCmds.add("auto /media/${seasonIdParam}_${epSeriesParam}.mpg")
            }
            if (seriesIdParam.isNotBlank()) {
                candidateCmds.add("/media/file_${seriesIdParam}.mpg")
                candidateCmds.add("auto /media/${seriesIdParam}_${epSeriesParam}.mpg")
            }
        }
        if (type == "vod" && streamId.isNotBlank() && epSeriesParam.isBlank()) {
            val hdrs = buildStbHeaders(id, activeToken, portal)
            val (mJson, _, _) = fetchJsonWithSession(
                "$portal?type=vod&action=get_ordered_list&movie_id=$streamId&JsHttpRequest=${System.currentTimeMillis()}-xml",
                hdrs
            )
            val arr = extractDataArray(mJson)
            if (arr.length() > 0) {
                val first = arr.optJSONObject(0)
                if (first != null) {
                    val fCmd = extractCmd(first)
                    val fid = first.optString("id")
                    if (fCmd.isNotBlank()) candidateCmds.add(fCmd)
                    if (fid.isNotBlank()) {
                        candidateCmds.add("/media/file_${fid}.mpg")
                        candidateCmds.add("/media/${fid}.mpg")
                    }
                }
            }
            candidateCmds.add("/media/file_${streamId}.mpg")
            candidateCmds.add("/media/${streamId}.mpg")
        }
        val cmdsToTry = candidateCmds.distinct().ifEmpty { listOf(rawCmd) }

        val tryTypes = if (type == "vod" && epSeriesParam.isNotBlank()) listOf("vod", "series") else listOf(type)
        val originUrl = extractOrigin(portal)
        val portalHost = runCatching { URI(originUrl).host }.getOrNull().orEmpty()
        for (cCmd in cmdsToTry) {
            for (t in tryTypes) {
                val encCmd = URLEncoder.encode(cCmd, "UTF-8")
                val url = "$portal?type=$t&action=create_link&cmd=$encCmd&series=$epSeriesParam&sn=${id.sn}&device_id=${id.deviceId}&device_id2=${id.deviceId2}&forced_storage=0&disable_ad=0&download=0&JsHttpRequest=${System.currentTimeMillis()}-xml"
                var (res, _, diag) = fetchJsonWithSession(url, buildStbHeaders(id, activeToken, portal))
                if (res == null || diag.contains("Authorization failed", ignoreCase = true)) {
                    val newTok = refreshToken(portal, id)
                    if (newTok.isNotBlank()) {
                        activeToken = newTok
                        res = fetchJsonWithSession(url, buildStbHeaders(id, activeToken, portal)).first
                    }
                }
                val created = res?.optJSONObject("js")?.optString("cmd").orEmpty()
                    .ifBlank { res?.optString("js").orEmpty().takeIf { it.contains("http") } ?: "" }
                var resolved = stripStreamPrefix(created)
                if (resolved.contains("://localhost/", ignoreCase = true) && portalHost.isNotBlank()) {
                    resolved = resolved.replace("://localhost/", "://$portalHost/", ignoreCase = true)
                }
                if (resolved.startsWith("/")) {
                    resolved = "$originUrl$resolved"
                }
                if (resolved.startsWith("http://") || resolved.startsWith("https://")) {
                    return@withContext resolved
                }
            }
        }
        val fallback = stripStreamPrefix(rawCmd)
        fallback.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    private fun fetchStalkerEpg(
        portal: String,
        headers: Map<String, String>,
        playlistId: String,
        channels: List<ChannelEntity>
    ): List<EpgProgramEntity> {
        val out = mutableListOf<EpgProgramEntity>()
        val (json, _, _) = fetchJsonWithSession(
            "$portal?type=itv&action=get_epg_info&period=24&JsHttpRequest=${System.currentTimeMillis()}-xml",
            headers
        )
        val dataObj = json?.optJSONObject("js")?.optJSONObject("data") ?: return out
        val chTvgMap = channels.associate { it.streamId to it.tvgId }
        val dateFmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        fun parseStalkerTime(p: JSONObject, tsKey: String, strKey: String): Long {
            val ts = p.optLong(tsKey, 0L)
            if (ts > 0L) return ts * 1000L
            val s = p.optString(strKey)
            return if (s.isNotBlank()) runCatching { dateFmt.parse(s)?.time ?: 0L }.getOrDefault(0L) else 0L
        }
        val keys = dataObj.keys()
        while (keys.hasNext()) {
            val chId = keys.next()
            val arr = dataObj.optJSONArray(chId) ?: continue
            val tvgId = chTvgMap[chId]?.ifBlank { chId } ?: chId
            for (i in 0 until arr.length()) {
                val p = arr.optJSONObject(i) ?: continue
                val startMs = parseStalkerTime(p, "start_timestamp", "time")
                val stopMs = parseStalkerTime(p, "stop_timestamp", "time_to")
                if (startMs <= 0L || stopMs <= startMs) continue
                out.add(
                    EpgProgramEntity(
                        playlistId = playlistId,
                        channelTvgId = tvgId,
                        title = p.optString("name", "Program"),
                        description = p.optString("descr"),
                        startTimeMillis = startMs,
                        endTimeMillis = stopMs
                    )
                )
            }
        }
        return out
    }

    private fun extractDataArray(root: JSONObject?): JSONArray {
        val js = root?.opt("js") ?: return JSONArray()
        return when (js) {
            is JSONArray -> js
            is JSONObject -> js.optJSONArray("data") ?: JSONArray()
            else -> JSONArray()
        }
    }

    private fun resolveLogo(origin: String, logo: String): String {
        if (logo.isBlank()) return ""
        return if (logo.startsWith("http")) logo else "$origin/${logo.trimStart('/')}"
    }

    private fun fetchGenreMap(url: String, headers: Map<String, String>): Map<String, String> {
        val (obj, _, _) = fetchJsonWithSession(url, headers)
        val arr = extractDataArray(obj)
        val map = HashMap<String, String>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            map[o.optString("id")] = o.optString("title")
        }
        return map
    }

    private fun fetchJsonWithSession(url: String, headers: Map<String, String>): Triple<JSONObject?, String, String> {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        return try {
            stalkerHttp.newCall(builder.build()).execute().use { resp ->
                var phpSess = ""
                for (sc in resp.headers("Set-Cookie")) {
                    if (sc.contains("PHPSESSID=")) {
                        phpSess = sc.substringAfter("PHPSESSID=").substringBefore(";").trim()
                    }
                }
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return Triple(null, phpSess, "HTTP ${resp.code}")
                }
                val cleanRaw = raw.trim().trimStart('\uFEFF')
                val parsed = runCatching { JSONObject(cleanRaw) }.getOrNull()
                Triple(parsed, phpSess, cleanRaw.take(120))
            }
        } catch (e: Exception) {
            Triple(null, "", e.message ?: "Network error")
        }
    }
}
