package com.tiviclone.iptv.data.repository

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("tiviclone_settings", Context.MODE_PRIVATE)

    fun getActivePlaylistId(): String = prefs.getString(KEY_ACTIVE_PLAYLIST, "ALL").orEmpty()
    fun setActivePlaylistId(id: String) = prefs.edit().putString(KEY_ACTIVE_PLAYLIST, id).apply()

    fun getLastChannelId(): String = prefs.getString("last_channel_id", "").orEmpty()
    fun setLastChannelId(id: String) = prefs.edit().putString("last_channel_id", id).apply()

    // General
    fun isAutoStartBoot(): Boolean = prefs.getBoolean("auto_start_boot", false)
    fun setAutoStartBoot(v: Boolean) = prefs.edit().putBoolean("auto_start_boot", v).apply()

    fun isAutoStartWake(): Boolean = prefs.getBoolean("auto_start_wake", false)
    fun setAutoStartWake(v: Boolean) = prefs.edit().putBoolean("auto_start_wake", v).apply()

    fun isTurnOnLastChannel(): Boolean = prefs.getBoolean("turn_on_last_channel", true)
    fun setTurnOnLastChannel(v: Boolean) = prefs.edit().putBoolean("turn_on_last_channel", v).apply()

    fun isPipOnHome(): Boolean = prefs.getBoolean("pip_on_home", false)
    fun setPipOnHome(v: Boolean) = prefs.edit().putBoolean("pip_on_home", v).apply()

    fun isConfirmExitBack(): Boolean = prefs.getBoolean("confirm_exit_back", false)
    fun setConfirmExitBack(v: Boolean) = prefs.edit().putBoolean("confirm_exit_back", v).apply()

    fun getUserAgent(): String = prefs.getString("user_agent", "").orEmpty()
    fun setUserAgent(v: String) = prefs.edit().putString("user_agent", v).apply()

    fun getUdpProxy(): String = prefs.getString("udp_proxy", "").orEmpty()
    fun setUdpProxy(v: String) = prefs.edit().putString("udp_proxy", v).apply()

    // EPG
    fun getEpgPastDays(): Int = prefs.getInt("epg_past_days", 7)
    fun setEpgPastDays(v: Int) = prefs.edit().putInt("epg_past_days", v).apply()

    fun isStoreProgramDesc(): Boolean = prefs.getBoolean("store_epg_desc", true)
    fun setStoreProgramDesc(v: Boolean) = prefs.edit().putBoolean("store_epg_desc", v).apply()

    fun getEpgIntervalHours(): Int = prefs.getInt(KEY_EPG_INTERVAL, 24)
    fun setEpgIntervalHours(hours: Int) = prefs.edit().putInt(KEY_EPG_INTERVAL, hours).apply()

    fun isEpgUpdateOnStart(): Boolean = prefs.getBoolean("epg_update_start", false)
    fun setEpgUpdateOnStart(v: Boolean) = prefs.edit().putBoolean("epg_update_start", v).apply()

    fun isEpgUpdateOnPlaylistChange(): Boolean = prefs.getBoolean("epg_update_change", false)
    fun setEpgUpdateOnPlaylistChange(v: Boolean) = prefs.edit().putBoolean("epg_update_change", v).apply()

    fun getEpgLastUpdated(): Long = prefs.getLong(KEY_EPG_LAST_UPDATED, 0L)
    fun setEpgLastUpdated(ts: Long) = prefs.edit().putLong(KEY_EPG_LAST_UPDATED, ts).apply()

    // Appearance -> TV Guide, Player, Groups, Logos, Theme
    fun isTvGuidePreview(): Boolean = prefs.getBoolean("tv_guide_preview", true)
    fun setTvGuidePreview(v: Boolean) = prefs.edit().putBoolean("tv_guide_preview", v).apply()

    fun isAnimatedTvGuidePreview(): Boolean = prefs.getBoolean("animated_tv_guide_preview", true)
    fun setAnimatedTvGuidePreview(v: Boolean) = prefs.edit().putBoolean("animated_tv_guide_preview", v).apply()

    fun isAutoPlayOnTvGuide(): Boolean = prefs.getBoolean("auto_play_tv_guide", true)
    fun setAutoPlayOnTvGuide(v: Boolean) = prefs.edit().putBoolean("auto_play_tv_guide", v).apply()

    fun isShowChannelNumbers(): Boolean = prefs.getBoolean("show_channel_numbers", true)
    fun setShowChannelNumbers(v: Boolean) = prefs.edit().putBoolean("show_channel_numbers", v).apply()

    fun isHighlightCurrentChannel(): Boolean = prefs.getBoolean("highlight_current_channel", true)
    fun setHighlightCurrentChannel(v: Boolean) = prefs.edit().putBoolean("highlight_current_channel", v).apply()

    fun isDimPastPrograms(): Boolean = prefs.getBoolean("dim_past_programs", true)
    fun setDimPastPrograms(v: Boolean) = prefs.edit().putBoolean("dim_past_programs", v).apply()

    fun isPlayerClockEnabled(): Boolean = prefs.getBoolean("player_clock_enabled", true)
    fun setPlayerClockEnabled(v: Boolean) = prefs.edit().putBoolean("player_clock_enabled", v).apply()

    fun isInfoPanelCardStyle(): Boolean = prefs.getBoolean("info_panel_card_style", true)
    fun setInfoPanelCardStyle(v: Boolean) = prefs.edit().putBoolean("info_panel_card_style", v).apply()

    fun getFullscreenSwitchTimeoutSec(): Int = prefs.getInt("fullscreen_switch_timeout", 5)
    fun setFullscreenSwitchTimeoutSec(v: Int) = prefs.edit().putInt("fullscreen_switch_timeout", v).apply()

    fun getGroupsSorting(): String = prefs.getString("groups_sorting", "Playlist order").orEmpty()
    fun setGroupsSorting(v: String) = prefs.edit().putString("groups_sorting", v).apply()

    fun getChannelsSorting(): String = prefs.getString("channels_sorting", "Playlist order").orEmpty()
    fun setChannelsSorting(v: String) = prefs.edit().putString("channels_sorting", v).apply()

    fun isShowRecentChannels(): Boolean = prefs.getBoolean("show_recent_channels", true)
    fun setShowRecentChannels(v: Boolean) = prefs.edit().putBoolean("show_recent_channels", v).apply()

    fun getLogosPriority(): String = prefs.getString("logos_priority", "Playlist").orEmpty()
    fun setLogosPriority(v: String) = prefs.edit().putString("logos_priority", v).apply()

    fun isInexactLogos(): Boolean = prefs.getBoolean("inexact_logos", false)
    fun setInexactLogos(v: Boolean) = prefs.edit().putBoolean("inexact_logos", v).apply()

    fun getBackgroundTheme(): String = prefs.getString("bg_theme", "Dark").orEmpty()
    fun setBackgroundTheme(v: String) = prefs.edit().putString("bg_theme", v).apply()

    fun getAccentTheme(): String = prefs.getString("accent_theme", "Blue").orEmpty()
    fun setAccentTheme(v: String) = prefs.edit().putString("accent_theme", v).apply()

    fun getFontSize(): String = prefs.getString("font_size", "Medium").orEmpty()
    fun setFontSize(v: String) = prefs.edit().putString("font_size", v).apply()

    fun getUiTransparency(): Int = prefs.getInt("ui_transparency", 50)
    fun setUiTransparency(v: Int) = prefs.edit().putInt("ui_transparency", v).apply()

    // Playback
    fun getBufferSize(): String = prefs.getString("buffer_size", "Small").orEmpty()
    fun setBufferSize(v: String) = prefs.edit().putString("buffer_size", v).apply()

    fun getAudioDecoder(): String = prefs.getString("audio_decoder", "Hardware").orEmpty()
    fun setAudioDecoder(v: Boolean) = prefs.edit().putString("audio_decoder", if (v) "Software (FFmpeg)" else "Hardware").apply()
    fun setAudioDecoder(v: String) = prefs.edit().putString("audio_decoder", v).apply()

    fun getVideoDecoder(): String = prefs.getString("video_decoder", "Hardware").orEmpty()
    fun setVideoDecoder(v: String) = prefs.edit().putString("video_decoder", v).apply()

    fun isAfrEnabled(): Boolean = prefs.getBoolean("afr_enabled", false)
    fun setAfrEnabled(v: Boolean) = prefs.edit().putBoolean("afr_enabled", v).apply()

    fun isAfrForVod(): Boolean = prefs.getBoolean("afr_vod", false)
    fun setAfrForVod(v: Boolean) = prefs.edit().putBoolean("afr_vod", v).apply()

    fun isTunneledPlayback(): Boolean = prefs.getBoolean("tunneled_playback", false)
    fun setTunneledPlayback(v: Boolean) = prefs.edit().putBoolean("tunneled_playback", v).apply()

    fun isAmlogicFix(): Boolean = prefs.getBoolean("amlogic_fix", false)
    fun setAmlogicFix(v: Boolean) = prefs.edit().putBoolean("amlogic_fix", v).apply()

    fun isSurroundDefault(): Boolean = prefs.getBoolean("surround_default", false)
    fun setSurroundDefault(v: Boolean) = prefs.edit().putBoolean("surround_default", v).apply()

    fun isAudioPassthrough(): Boolean = prefs.getBoolean("audio_passthrough", false)
    fun setAudioPassthrough(v: Boolean) = prefs.edit().putBoolean("audio_passthrough", v).apply()

    fun getUseExternalPlayer(): String = prefs.getString("use_external_player_mode", "No").orEmpty()
    fun setUseExternalPlayer(v: String) = prefs.edit().putString("use_external_player_mode", v).apply()

    fun getSkipForwardSec(): Int = prefs.getInt("skip_forward_sec", 30)
    fun setSkipForwardSec(v: Int) = prefs.edit().putInt("skip_forward_sec", v).apply()

    fun getSkipBackwardSec(): Int = prefs.getInt("skip_backward_sec", 10)
    fun setSkipBackwardSec(v: Int) = prefs.edit().putInt("skip_backward_sec", v).apply()

    // Remote Control
    fun isSeekLeftRight(): Boolean = prefs.getBoolean("seek_left_right", true)
    fun setSeekLeftRight(v: Boolean) = prefs.edit().putBoolean("seek_left_right", v).apply()

    fun isSeekUpDown(): Boolean = prefs.getBoolean("seek_up_down", false)
    fun setSeekUpDown(v: Boolean) = prefs.edit().putBoolean("seek_up_down", v).apply()

    fun isRwFfInCatchup(): Boolean = prefs.getBoolean("rw_ff_catchup", true)
    fun setRwFfInCatchup(v: Boolean) = prefs.edit().putBoolean("rw_ff_catchup", v).apply()

    fun getRemoteAction(key: String, defaultAction: String): String =
        prefs.getString("remote_$key", defaultAction).orEmpty()

    fun setRemoteAction(key: String, action: String) =
        prefs.edit().putString("remote_$key", action).apply()

    // Parental Controls
    fun getParentalPin(): String = prefs.getString(KEY_PARENTAL_PIN, "").orEmpty()
    fun setParentalPin(pin: String) = prefs.edit().putString(KEY_PARENTAL_PIN, pin).apply()

    fun isPinForSettings(): Boolean = prefs.getBoolean("pin_for_settings", false)
    fun setPinForSettings(v: Boolean) = prefs.edit().putBoolean("pin_for_settings", v).apply()

    fun isPinForPlaylists(): Boolean = prefs.getBoolean("pin_for_playlists", false)
    fun setPinForPlaylists(v: Boolean) = prefs.edit().putBoolean("pin_for_playlists", v).apply()

    fun isPinForChannelOptions(): Boolean = prefs.getBoolean("pin_for_ch_opts", false)
    fun setPinForChannelOptions(v: Boolean) = prefs.edit().putBoolean("pin_for_ch_opts", v).apply()

    fun getPinUnlockTimeout(): String = prefs.getString("pin_unlock_timeout", "Until next app start").orEmpty()
    fun setPinUnlockTimeout(v: String) = prefs.edit().putString("pin_unlock_timeout", v).apply()

    // Other -> Recordings, Reminders, VOD, Search
    fun getRecordingStartOffsetMin(): Int = prefs.getInt("rec_start_offset", 0)
    fun setRecordingStartOffsetMin(v: Int) = prefs.edit().putInt("rec_start_offset", v).apply()

    fun getRecordingStopOffsetMin(): Int = prefs.getInt("rec_stop_offset", 0)
    fun setRecordingStopOffsetMin(v: Int) = prefs.edit().putInt("rec_stop_offset", v).apply()

    fun getReminderDefaultAction(): String = prefs.getString("reminder_default_action", "Watch").orEmpty()
    fun setReminderDefaultAction(v: String) = prefs.edit().putString("reminder_default_action", v).apply()

    fun getReminderPopupTimeoutSec(): Int = prefs.getInt("reminder_popup_timeout", 15)
    fun setReminderPopupTimeoutSec(v: Int) = prefs.edit().putInt("reminder_popup_timeout", v).apply()

    fun isAutoPlayNextEpisode(): Boolean = prefs.getBoolean("auto_next_episode", true)
    fun setAutoPlayNextEpisode(v: Boolean) = prefs.edit().putBoolean("auto_next_episode", v).apply()

    fun isShowFavFirstSearch(): Boolean = prefs.getBoolean("show_fav_first_search", true)
    fun setShowFavFirstSearch(v: Boolean) = prefs.edit().putBoolean("show_fav_first_search", v).apply()

    fun isShowSearchHistory(): Boolean = prefs.getBoolean("show_search_history", true)
    fun setShowSearchHistory(v: Boolean) = prefs.edit().putBoolean("show_search_history", v).apply()

    companion object {
        private const val KEY_ACTIVE_PLAYLIST = "active_playlist_id"
        private const val KEY_EPG_INTERVAL = "epg_interval_hours"
        private const val KEY_EPG_LAST_UPDATED = "epg_last_updated"
        private const val KEY_PARENTAL_PIN = "parental_pin"
    }
}
