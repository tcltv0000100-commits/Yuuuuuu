package com.tiviclone.iptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tiviclone.iptv.data.db.EpisodeEntity
import com.tiviclone.iptv.data.db.SeriesEntity
import com.tiviclone.iptv.data.db.VodMovieEntity
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder

@Composable
fun MoviesScreen(
    movies: List<VodMovieEntity>,
    selectedCat: String,
    showGroups: Boolean,
    onSelectCategory: (String) -> Unit,
    onSelectMovie: (VodMovieEntity) -> Unit
) {
    val categories = remember(movies) {
        listOf("All", "Favorites") + movies.map { it.categoryName }.distinct()
    }
    var filter by remember { mutableStateOf("") }

    val filtered = remember(movies, selectedCat, filter) {
        movies.filter { m ->
            val catOk = when (selectedCat) {
                "All" -> true
                "Favorites" -> m.isFavorite
                else -> m.categoryName == selectedCat
            }
            val searchOk = filter.isBlank() || m.name.contains(filter, ignoreCase = true)
            catOk && searchOk
        }
    }

    Row(modifier = Modifier.fillMaxSize().background(TiviColors.Background)) {
        if (showGroups) LazyColumn(
            modifier = Modifier.width(190.dp).fillMaxHeight().background(TiviColors.SidebarBg).padding(8.dp)
        ) {
            items(categories) { cat ->
                val sel = cat == selectedCat
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (sel) TiviColors.AccentBlue else Color.Transparent)
                        .tvFocusableBorder()
                        .clickable { onSelectCategory(cat) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(cat, color = if (sel) Color.White else TiviColors.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        Column(modifier = Modifier.weight(1f).fillMaxHeight().padding(12.dp)) {
            OutlinedTextField(
                value = filter,
                onValueChange = { filter = it },
                placeholder = { Text("Search movies...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            )
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No movies found", color = TiviColors.TextSecondary)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 135.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { movie ->
                        PosterCard(
                            title = movie.name,
                            posterUrl = movie.posterUrl,
                            rating = movie.rating,
                            onClick = { onSelectMovie(movie) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MovieDetailScreen(
    movie: VodMovieEntity,
    onPlay: (VodMovieEntity) -> Unit,
    onToggleFavorite: (VodMovieEntity) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            AsyncImage(
                model = movie.posterUrl,
                contentDescription = movie.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(170.dp)
                    .height(250.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(TiviColors.PanelBg)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(movie.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                val meta = listOfNotNull(
                    movie.releaseDate.takeIf { it.isNotBlank() },
                    movie.duration.takeIf { it.isNotBlank() },
                    movie.rating.takeIf { it.isNotBlank() }?.let { "★ $it" },
                    movie.genre.takeIf { it.isNotBlank() }
                ).joinToString("  •  ")
                if (meta.isNotBlank()) {
                    Text(meta, color = TiviColors.FavoriteGold, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                }
                Text(
                    movie.plot.ifBlank { "Loading details or no synopsis available." },
                    color = TiviColors.TextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
                if (movie.director.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Director: ${movie.director}", color = TiviColors.TextSecondary, fontSize = 12.sp)
                }
                if (movie.cast.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("Cast: ${movie.cast}", color = TiviColors.TextSecondary, fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { onPlay(movie) }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Play Movie")
                    }
                    OutlinedButton(onClick = { onToggleFavorite(movie) }) {
                        Icon(
                            if (movie.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = null,
                            tint = TiviColors.FavoriteGold
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(if (movie.isFavorite) "Favorited" else "Add Favorite")
                    }
                }
            }
        }
    }
}

@Composable
fun SeriesScreen(
    seriesList: List<SeriesEntity>,
    selectedCat: String,
    showGroups: Boolean,
    onSelectCategory: (String) -> Unit,
    onSelectSeries: (SeriesEntity) -> Unit
) {
    val categories = remember(seriesList) {
        listOf("All", "Favorites") + seriesList.map { it.categoryName }.distinct()
    }
    var filter by remember { mutableStateOf("") }

    val filtered = remember(seriesList, selectedCat, filter) {
        seriesList.filter { s ->
            val catOk = when (selectedCat) {
                "All" -> true
                "Favorites" -> s.isFavorite
                else -> s.categoryName == selectedCat
            }
            val searchOk = filter.isBlank() || s.name.contains(filter, ignoreCase = true)
            catOk && searchOk
        }
    }

    Row(modifier = Modifier.fillMaxSize().background(TiviColors.Background)) {
        if (showGroups) LazyColumn(
            modifier = Modifier.width(190.dp).fillMaxHeight().background(TiviColors.SidebarBg).padding(8.dp)
        ) {
            items(categories) { cat ->
                val sel = cat == selectedCat
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (sel) TiviColors.AccentBlue else Color.Transparent)
                        .tvFocusableBorder()
                        .clickable { onSelectCategory(cat) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(cat, color = if (sel) Color.White else TiviColors.TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        Column(modifier = Modifier.weight(1f).fillMaxHeight().padding(12.dp)) {
            OutlinedTextField(
                value = filter,
                onValueChange = { filter = it },
                placeholder = { Text("Search series...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            )
            if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No series found", color = TiviColors.TextSecondary)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 135.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { series ->
                        PosterCard(
                            title = series.name,
                            posterUrl = series.posterUrl,
                            rating = series.rating,
                            onClick = { onSelectSeries(series) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SeriesDetailScreen(
    series: SeriesEntity,
    episodes: List<EpisodeEntity>,
    isLoading: Boolean,
    onPlayEpisode: (SeriesEntity, EpisodeEntity) -> Unit,
    onToggleFavorite: (SeriesEntity) -> Unit,
    onBack: () -> Unit
) {
    val seasons = remember(episodes) { episodes.map { it.seasonNumber }.distinct().sorted() }
    var selectedSeason by remember(seasons) { mutableIntStateOf(seasons.firstOrNull() ?: 1) }
    val seasonEps = remember(episodes, selectedSeason) {
        episodes.filter { it.seasonNumber == selectedSeason }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.Background)
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(series.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { onToggleFavorite(series) }) {
                Icon(
                    if (series.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Favorite",
                    tint = TiviColors.FavoriteGold
                )
            }
        }

        if (series.plot.isNotBlank()) {
            Text(series.plot, color = TiviColors.TextSecondary, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(10.dp))
        }

        if (seasons.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                items(seasons) { s ->
                    FilterChip(
                        selected = s == selectedSeason,
                        onClick = { selectedSeason = s },
                        label = { Text("Season $s") }
                    )
                }
            }
        }

        if (isLoading && episodes.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (seasonEps.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No episodes found", color = TiviColors.TextSecondary)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(seasonEps, key = { it.id }) { ep ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(TiviColors.PanelBg)
                            .tvFocusableBorder()
                            .clickable { onPlayEpisode(series, ep) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = ep.thumbnailUrl,
                            contentDescription = ep.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .width(110.dp)
                                .height(64.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(TiviColors.SidebarBg)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "E${ep.episodeNumber}. ${ep.title}",
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (ep.plot.isNotBlank()) {
                                Text(ep.plot, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                            if (ep.duration.isNotBlank()) {
                                Text(ep.duration, color = TiviColors.AccentBlue, fontSize = 11.sp)
                            }
                        }
                        Icon(Icons.Default.PlayCircleOutline, contentDescription = "Play", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun PosterCard(
    title: String,
    posterUrl: String,
    rating: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(TiviColors.PanelBg)
            .tvFocusableBorder()
            .clickable(onClick = onClick)
            .padding(6.dp)
    ) {
        Box {
            AsyncImage(
                model = posterUrl,
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(2f / 3f)
                    .clip(RoundedCornerShape(6.dp))
                    .background(TiviColors.SidebarBg)
            )
            if (rating.isNotBlank() && rating != "0") {
                Text(
                    "★ $rating",
                    color = TiviColors.FavoriteGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .background(Color(0xBB000000), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            title,
            color = TiviColors.TextPrimary,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
