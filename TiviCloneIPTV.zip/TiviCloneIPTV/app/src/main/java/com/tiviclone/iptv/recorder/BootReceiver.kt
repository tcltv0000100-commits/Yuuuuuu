package com.tiviclone.iptv.recorder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.tiviclone.iptv.MainActivity
import com.tiviclone.iptv.TiviCloneApp

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON") {
            val app = context.applicationContext as TiviCloneApp
            if (app.settingsStore.isAutoStartBoot()) {
                val launch = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(launch)
            }
        }
    }
}
