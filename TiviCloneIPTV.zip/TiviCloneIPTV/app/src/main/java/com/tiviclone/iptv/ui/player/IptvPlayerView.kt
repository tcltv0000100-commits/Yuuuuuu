package com.tiviclone.iptv.ui.player

import androidx.activity.compose.BackHandler
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Rational
import android.view.KeyEvent as AndroidKeyEvent
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.tiviclone.iptv.TiviCloneApp
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.data.model.TrackOption
import com.tiviclone.iptv.data.model.VideoRatioMode
import com.tiviclone.iptv.data.network.HttpClientProvider
import com.tiviclone.iptv.recorder.RecordingService
import com.tiviclone.iptv.ui.ActivePlayback
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@kotlin.OptIn(ExperimentalFoundationApi::class)
@OptIn(UnstableApi::class)
@Composable
fun IptvPlayerView(
    playback: ActivePlayback,
    channels: List<ChannelEntity> = emptyList(),
    epgPrograms: List<EpgProgramEntity> = emptyList(),
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onOpenMultiview: () -> Unit,
    onOpenSearch: () -> Unit = {},
    onSaveProgress: (Long, Long) -> Unit,
    onSwitchChannel: (ChannelEntity) -> Unit = {},
    onZapByNumber: (Int) -> Unit = {},
    onNextEpisode: (() -> Unit)? = null,
    onVideoInfoChanged: (String, String) -> Unit = { _, _ -> }
) {
    val context = LocalContext.current
    val settings = (context.applicationContext as TiviCloneApp).settingsStore

    var ratioMode by remember { mutableStateOf(VideoRatioMode.FIT) }
    var showControls by remember { mutableStateOf(false) }
    var showEpgOverlay by remember { mutableStateOf(false) }
    var showTracksDialog by remember { mutableStateOf(false) }
    var showSleepDialog by remember { mutableStateOf(false) }
    var sleepMinutesLeft by remember { mutableIntStateOf(0) }
    var isRecording by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var tracks by remember { mutableStateOf<Tracks>(Tracks.EMPTY) }
    var retryKey by remember { mutableIntStateOf(0) }
    var zapDigits by remember { mutableStateOf("") }
    var videoResolution by remember { mutableStateOf("Auto") }
    var audioLabel by remember { mutableStateOf("Stereo") }
    var gestureHudText by remember { mutableStateOf<String?>(null) }
    var gestureHudProgress by remember { mutableFloatStateOf(0f) }
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var totalDurMs by remember { mutableLongStateOf(0L) }

    val player = remember(playback.streamUrl, retryKey) {
        val extMode = if (settings.getAudioDecoder().startsWith("Software")) {
            DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
        } else {
            DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
        }
        val rf = DefaultRenderersFactory(context)
            .setExtensionRendererMode(extMode)
            .setEnableDecoderFallback(true)
        val minBufMs = when (settings.getBufferSize()) {
            "None" -> 1500; "Small" -> 5000; "Medium" -> 15000; "Large" -> 30000; else -> 50000
        }
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minBufMs, minBufMs * 2, 1000, 2000)
            .build()
        val ua = playback.userAgent.ifBlank { HttpClientProvider.DEFAULT_USER_AGENT }
        val dsFactory = OkHttpDataSource.Factory(HttpClientProvider.createClient(ua))
        val extractors = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)

        ExoPlayer.Builder(context, rf)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory, extractors))
            .build().apply {
                setMediaItem(MediaItem.fromUri(playback.streamUrl))
                if (playback.resumePositionMs > 5000L) seekTo(playback.resumePositionMs)
                prepare()
                playWhenReady = true
            }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(t: Tracks) {
                tracks = t
                for (g in t.groups) {
                    for (i in 0 until g.length) {
                        if (g.isTrackSelected(i)) {
                            val fmt = g.getTrackFormat(i)
                            if (g.type == C.TRACK_TYPE_VIDEO && fmt.width > 0) {
                                val fps = if (fmt.frameRate > 1f) " ${fmt.frameRate.toInt()}fps" else ""
                                val tag = when {
                                    fmt.height >= 2160 -> "4K"
                                    fmt.height >= 1080 -> "FHD"
                                    fmt.height >= 720 -> "HD"
                                    else -> "SD"
                                }
                                videoResolution = "$tag ${fmt.width}×${fmt.height}$fps"
                            }
                            if (g.type == C.TRACK_TYPE_AUDIO) {
                                val ch = if (fmt.channelCount >= 6) "5.1" else "Stereo"
                                val codec = fmt.sampleMimeType?.substringAfter("/")?.uppercase().orEmpty()
                                audioLabel = if (codec.isNotBlank()) "$codec $ch" else ch
                            }
                        }
                    }
                }
                onVideoInfoChanged(videoResolution, audioLabel)
            }

            override fun onPlayerError(error: PlaybackException) {
                errorMessage = "Playback error (${error.errorCodeName})"
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) errorMessage = null
                if (playbackState == Player.STATE_ENDED && playback.mediaType == "SERIES") {
                    onNextEpisode?.invoke()
                }
            }
        }
        player.addListener(listener)
        onDispose {
            onSaveProgress(player.currentPosition, player.duration)
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(player, playback.itemId) {
        var tick = 0
        while (true) {
            delay(1000L)
            currentPosMs = player.currentPosition.coerceAtLeast(0L)
            totalDurMs = player.duration.coerceAtLeast(0L)
            tick++
            if (tick % 10 == 0 && player.isPlaying) onSaveProgress(currentPosMs, totalDurMs)
        }
    }
    LaunchedEffect(gestureHudText) {
        if (gestureHudText != null) {
            delay(1200L)
            gestureHudText = null
        }
    }

    LaunchedEffect(zapDigits) {
        if (zapDigits.isNotEmpty()) {
            delay(1400L)
            val num = zapDigits.toIntOrNull()
            zapDigits = ""
            if (num != null) onZapByNumber(num)
        }
    }

    LaunchedEffect(sleepMinutesLeft) {
        if (sleepMinutesLeft > 0) {
            delay(60_000L)
            sleepMinutesLeft -= 1
            if (sleepMinutesLeft == 0) {
                player.pause()
                onBack()
            }
        }
    }

    val clockFmt = remember { SimpleDateFormat("EEE, dd MMM, HH:mm", Locale.getDefault()) }

    BackHandler(enabled = playback.isFullscreen && (showEpgOverlay || showControls || showTracksDialog || showSleepDialog)) {
        when {
            showTracksDialog -> showTracksDialog = false
            showSleepDialog -> showSleepDialog = false
            showControls -> showControls = false
            showEpgOverlay -> showEpgOverlay = false
        }
    }

    Box(
        modifier = modifier
            .background(Color.Black)
            .focusable()
            .onPreviewKeyEvent { keyEvent ->
                val native = keyEvent.nativeKeyEvent
                if (native.action == AndroidKeyEvent.ACTION_DOWN && playback.isFullscreen) {
                    val code = native.keyCode
                    when {
                        code == AndroidKeyEvent.KEYCODE_MENU ||
                            (code == AndroidKeyEvent.KEYCODE_DPAD_CENTER && native.isLongPress) -> {
                            showControls = !showControls
                            true
                        }
                        playback.mediaType == "LIVE" && code in AndroidKeyEvent.KEYCODE_0..AndroidKeyEvent.KEYCODE_9 -> {
                            val digit = code - AndroidKeyEvent.KEYCODE_0
                            if (zapDigits.length < 5) zapDigits += digit.toString()
                            true
                        }
                        playback.mediaType == "LIVE" && (code == AndroidKeyEvent.KEYCODE_CHANNEL_UP || (code == AndroidKeyEvent.KEYCODE_DPAD_UP && !showEpgOverlay && !showControls)) -> {
                            val idx = channels.indexOfFirst { it.id == playback.itemId }
                            if (idx >= 0 && channels.isNotEmpty()) onSwitchChannel(channels[(idx + 1) % channels.size])
                            true
                        }
                        playback.mediaType == "LIVE" && (code == AndroidKeyEvent.KEYCODE_CHANNEL_DOWN || (code == AndroidKeyEvent.KEYCODE_DPAD_DOWN && !showEpgOverlay && !showControls)) -> {
                            val idx = channels.indexOfFirst { it.id == playback.itemId }
                            if (idx >= 0 && channels.isNotEmpty()) onSwitchChannel(channels[(idx - 1 + channels.size) % channels.size])
                            true
                        }
                        playback.mediaType == "LIVE" && (code == AndroidKeyEvent.KEYCODE_DPAD_LEFT || code == AndroidKeyEvent.KEYCODE_GUIDE) -> {
                            showEpgOverlay = !showEpgOverlay
                            true
                        }
                        else -> false
                    }
                } else false
            }
            .then(
                if (playback.isFullscreen) {
                    Modifier.pointerInput(playback.isFullscreen) {
                        detectVerticalDragGestures { change, dragAmount ->
                            change.consume()
                            val isLeft = change.position.x < size.width / 2f
                            val delta = -dragAmount / (size.height.coerceAtLeast(1) * 0.6f)
                            if (isLeft) {
                                val act = context as? Activity
                                val lp = act?.window?.attributes
                                if (lp != null) {
                                    val cur = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                    val next = (cur + delta).coerceIn(0.05f, 1f)
                                    lp.screenBrightness = next
                                    act.window.attributes = lp
                                    gestureHudProgress = next
                                    gestureHudText = "Brightness ${(next * 100).toInt()}%"
                                }
                            } else {
                                val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                                if (am != null) {
                                    val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                    val curV = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                                    val nextF = ((curV.toFloat() / maxV) + delta).coerceIn(0f, 1f)
                                    am.setStreamVolume(AudioManager.STREAM_MUSIC, (nextF * maxV).toInt(), 0)
                                    gestureHudProgress = nextF
                                    gestureHudText = "Volume ${(nextF * 100).toInt()}%"
                                }
                            }
                        }
                    }
                } else Modifier
            )
            .combinedClickable(
                onClick = {
                    if (!playback.isFullscreen) {
                        onToggleFullscreen()
                    } else if (showControls) {
                        showControls = false
                    } else if (playback.mediaType == "LIVE") {
                        showEpgOverlay = !showEpgOverlay
                    }
                },
                onLongClick = {
                    if (playback.isFullscreen) {
                        showEpgOverlay = false
                        showControls = !showControls
                    }
                }
            )
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { view ->
                view.player = player
                view.resizeMode = when (ratioMode) {
                    VideoRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    VideoRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    VideoRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (zapDigits.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp)
                    .background(Color(0xDD10151E), RoundedCornerShape(10.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text("CH $zapDigits", color = TiviColors.AccentBlue, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (showEpgOverlay && playback.isFullscreen && playback.mediaType == "LIVE") {
            val now = System.currentTimeMillis()
            val groupedEpgOv = remember(epgPrograms) { epgPrograms.groupBy { it.channelTvgId } }
            val ovTimeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.78f)
                    .fillMaxHeight()
                    .align(Alignment.CenterStart)
                    .background(Color(0xE80A0D12))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${channels.firstOrNull()?.groupName ?: "TV Guide"} (${channels.size})",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    IconButton(onClick = { showEpgOverlay = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(channels, key = { it.id }) { ch ->
                        val chProgs = groupedEpgOv[ch.tvgId].orEmpty()
                        val nowP = chProgs.firstOrNull { it.startTimeMillis <= now && it.endTimeMillis >= now } ?: chProgs.firstOrNull()
                        val nextP = chProgs.firstOrNull { it.startTimeMillis > now }
                        val active = ch.id == playback.itemId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (active) TiviColors.CardFocused else Color(0x88161D29))
                                .tvFocusableBorder(6)
                                .clickable {
                                    onSwitchChannel(ch)
                                    showEpgOverlay = false
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${ch.number}", color = TiviColors.TextSecondary, fontSize = 11.sp, modifier = Modifier.width(30.dp))
                            if (ch.logoUrl.isNotBlank()) {
                                AsyncImage(
                                    model = ch.logoUrl,
                                    contentDescription = ch.name,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.size(28.dp).padding(end = 8.dp)
                                )
                            }
                            Text(
                                ch.name,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.width(135.dp).padding(end = 8.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    nowP?.let { "${ovTimeFmt.format(Date(it.startTimeMillis))} ${it.title}" } ?: "No information",
                                    color = if (nowP != null) Color.White else TiviColors.TextSecondary,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (nowP != null) {
                                    val span = (nowP.endTimeMillis - nowP.startTimeMillis).coerceAtLeast(1L)
                                    val pct = ((now - nowP.startTimeMillis).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                                    LinearProgressIndicator(
                                        progress = { pct },
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).height(2.dp),
                                        color = TiviColors.AccentBlue,
                                        trackColor = TiviColors.Divider
                                    )
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(
                                nextP?.let { "${ovTimeFmt.format(Date(it.startTimeMillis))} ${it.title}" } ?: "",
                                color = TiviColors.TextSecondary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(0.8f)
                            )
                        }
                    }
                }
            }
        }

        if (errorMessage != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0xCC111622), RoundedCornerShape(12.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(errorMessage!!, color = TiviColors.DangerRed, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { errorMessage = null; retryKey++ }) { Text("Retry") }
                    OutlinedButton(onClick = {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(playback.streamUrl), "video/*")
                            })
                        }
                    }) { Text("External Player") }
                }
            }
        }

        if (gestureHudText != null && playback.isFullscreen) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .width(190.dp)
                    .background(Color(0xCC0D1117), RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(gestureHudText!!, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { gestureHudProgress }, modifier = Modifier.fillMaxWidth().height(4.dp), color = TiviColors.AccentBlue, trackColor = TiviColors.Divider)
            }
        }

        // TiviMate Fullscreen OSD (Hold to open) with EPG Now/Next + Resolution/Audio Badges + Touch Seekbar
        if (showControls && playback.isFullscreen) {
            val nowMs = System.currentTimeMillis()
            val curCh = channels.firstOrNull { it.id == playback.itemId }
            val nowEpg = curCh?.let { ch -> epgPrograms.firstOrNull { it.channelTvgId == ch.tvgId && it.startTimeMillis <= nowMs && it.endTimeMillis >= nowMs } }
            val nextEpg = curCh?.let { ch -> epgPrograms.firstOrNull { it.channelTvgId == ch.tvgId && it.startTimeMillis > nowMs } }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color(0x88000000))
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            if (curCh != null) "${curCh.number}  ${curCh.name}" else playback.title,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (videoResolution != "Auto") {
                            Box(modifier = Modifier.background(TiviColors.AccentBlue.copy(alpha = 0.35f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                Text(videoResolution, color = Color.White, fontSize = 10.sp)
                            }
                        }
                        Box(modifier = Modifier.background(Color.White.copy(alpha = 0.16f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                            Text(audioLabel, color = Color.White, fontSize = 10.sp)
                        }
                    }
                    if (nowEpg != null) {
                        Text("Now: ${nowEpg.title}", color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else if (playback.subtitle.isNotBlank()) {
                        Text(playback.subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (nextEpg != null) {
                        Text("Next: ${nextEpg.title}", color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (settings.isPlayerClockEnabled()) {
                    Text(clockFmt.format(Date()), color = Color.White, fontSize = 14.sp)
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color(0xBB000000))
            ) {
                if (playback.mediaType != "LIVE" && totalDurMs > 0L) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(onClick = { player.seekTo((currentPosMs - 10_000L).coerceAtLeast(0L)) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Replay10, contentDescription = "-10s", tint = Color.White)
                        }
                        IconButton(onClick = { if (player.isPlaying) player.pause() else player.play() }, modifier = Modifier.size(32.dp)) {
                            Icon(if (player.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Play/Pause", tint = Color.White)
                        }
                        IconButton(onClick = { player.seekTo((currentPosMs + 10_000L).coerceAtMost(totalDurMs)) }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Forward10, contentDescription = "+10s", tint = Color.White)
                        }
                        Slider(
                            value = (currentPosMs.toFloat() / totalDurMs.toFloat()).coerceIn(0f, 1f),
                            onValueChange = { pct -> player.seekTo((pct * totalDurMs).toLong()) },
                            modifier = Modifier.weight(1f),
                            colors = SliderDefaults.colors(thumbColor = TiviColors.AccentBlue, activeTrackColor = TiviColors.AccentBlue)
                        )
                        Text("${currentPosMs / 60000}:${((currentPosMs / 1000) % 60).toString().padStart(2, '0')} / ${totalDurMs / 60000}:${((totalDurMs / 1000) % 60).toString().padStart(2, '0')}", color = TiviColors.TextSecondary, fontSize = 11.sp)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                PlayerActionCircle(Icons.Default.Search, "Search") { onBack(); onOpenSearch() }
                if (playback.mediaType == "LIVE") {
                    PlayerActionCircle(Icons.Default.List, "Channels list") { showEpgOverlay = !showEpgOverlay }
                    PlayerActionCircle(
                        Icons.Default.Dvr,
                        if (isRecording) "Stop REC" else "Recordings",
                        tint = if (isRecording) TiviColors.DangerRed else Color.White
                    ) {
                        if (isRecording) {
                            RecordingService.stop(context); isRecording = false
                        } else {
                            RecordingService.start(context, playback.itemId, playback.title, playback.title, playback.streamUrl)
                            isRecording = true
                        }
                    }
                    PlayerActionCircle(Icons.Default.GridView, "Multiview") { onOpenMultiview() }
                }
                PlayerActionCircle(Icons.Default.PictureInPictureAlt, "Picture-in-picture") {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        (context as? Activity)?.enterPictureInPictureMode(
                            PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                        )
                    }
                }
                PlayerActionCircle(Icons.Default.Videocam, videoResolution) { showTracksDialog = true }
                PlayerActionCircle(Icons.Default.VolumeUp, audioLabel) { showTracksDialog = true }
                PlayerActionCircle(Icons.Default.ClosedCaption, "Subtitles") { showTracksDialog = true }
                PlayerActionCircle(Icons.Default.AspectRatio, ratioMode.label) {
                    val modes = VideoRatioMode.entries
                    ratioMode = modes[(modes.indexOf(ratioMode) + 1) % modes.size]
                }
                PlayerActionCircle(Icons.Default.Timer, if (sleepMinutesLeft > 0) "${sleepMinutesLeft}m" else "Off") {
                    showSleepDialog = true
                }
                if (playback.mediaType == "SERIES" && onNextEpisode != null) {
                    PlayerActionCircle(Icons.Default.SkipNext, "Next Ep") { onNextEpisode.invoke() }
                }
                PlayerActionCircle(Icons.Default.OpenInNew, "External") {
                    runCatching {
                        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(Uri.parse(playback.streamUrl), "video/*")
                        })
                    }
                }
                }
            }
        }
    }

    if (showTracksDialog) {
        TrackSelectorDialog(
            tracks = tracks,
            onSelect = { opt ->
                val builder = player.trackSelectionParameters.buildUpon()
                builder.setOverrideForType(TrackSelectionOverride(opt.group.mediaTrackGroup, opt.trackIndex))
                player.trackSelectionParameters = builder.build()
                showTracksDialog = false
            },
            onDisableSubtitles = {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showTracksDialog = false
            },
            onDismiss = { showTracksDialog = false }
        )
    }

    if (showSleepDialog) {
        AlertDialog(
            onDismissRequest = { showSleepDialog = false },
            title = { Text("Sleep Timer") },
            text = {
                Column {
                    listOf(0 to "Off", 15 to "15 minutes", 30 to "30 minutes", 60 to "60 minutes", 90 to "90 minutes")
                        .forEach { (mins, label) ->
                            TextButton(onClick = { sleepMinutesLeft = mins; showSleepDialog = false }) { Text(label) }
                        }
                }
            },
            confirmButton = { TextButton(onClick = { showSleepDialog = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun PlayerActionCircle(
    icon: ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .widthIn(min = 64.dp)
            .tvFocusableBorder(10)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TrackSelectorDialog(
    tracks: Tracks,
    onSelect: (TrackOption) -> Unit,
    onDisableSubtitles: () -> Unit,
    onDismiss: () -> Unit
) {
    val options = remember(tracks) {
        val list = mutableListOf<TrackOption>()
        for (g in tracks.groups) {
            if (g.type == C.TRACK_TYPE_AUDIO || g.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until g.length) {
                    val fmt = g.getTrackFormat(i)
                    val prefix = if (g.type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                    val lang = fmt.language ?: "und"
                    val label = "$prefix: ${fmt.label ?: lang} (${fmt.sampleMimeType ?: ""})"
                    list.add(TrackOption(g.type, g, i, label, g.isTrackSelected(i)))
                }
            }
        }
        list
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Audio & Subtitles") },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                item {
                    TextButton(onClick = onDisableSubtitles) { Text("Subtitles: Off", color = TiviColors.TextSecondary) }
                }
                items(options) { opt ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { onSelect(opt) }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = opt.isSelected, onClick = { onSelect(opt) })
                        Spacer(Modifier.width(8.dp))
                        Text(opt.label, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
