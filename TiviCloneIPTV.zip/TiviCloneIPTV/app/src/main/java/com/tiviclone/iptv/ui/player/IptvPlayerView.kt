package com.tiviclone.iptv.ui.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Rational
import android.view.KeyEvent as AndroidKeyEvent
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.tiviclone.iptv.TiviCloneApp
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.data.model.TrackOption
import com.tiviclone.iptv.data.model.VideoRatioMode
import com.tiviclone.iptv.data.network.HttpClientProvider
import com.tiviclone.iptv.recorder.RecordingService
import com.tiviclone.iptv.ui.ActivePlayback
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@kotlin.OptIn(ExperimentalFoundationApi::class)
@OptIn(UnstableApi::class)
@Composable
fun IptvPlayerView(
    playback: ActivePlayback,
    channels: List<ChannelEntity> = emptyList(),
    epgPrograms: List<EpgProgramEntity> = emptyList(),
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onOpenMultiview: () -> Unit,
    onOpenSearch: () -> Unit = {},
    onSaveProgress: (Long, Long) -> Unit,
    onSwitchChannel: (ChannelEntity) -> Unit = {},
    onZapByNumber: (Int) -> Unit = {},
    onNextEpisode: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val settings = (context.applicationContext as TiviCloneApp).settingsStore

    var ratioMode by remember { mutableStateOf(VideoRatioMode.FIT) }
    var showControls by remember { mutableStateOf(false) }
    var showEpgOverlay by remember { mutableStateOf(false) }
    var showTracksDialog by remember { mutableStateOf(false) }
    var showSleepDialog by remember { mutableStateOf(false) }
    var sleepMinutesLeft by remember { mutableIntStateOf(0) }
    var isRecording by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var tracks by remember { mutableStateOf<Tracks>(Tracks.EMPTY) }
    var retryKey by remember { mutableIntStateOf(0) }
    var zapDigits by remember { mutableStateOf("") }
    var videoResolution by remember { mutableStateOf("Auto") }
    var audioLabel by remember { mutableStateOf("Stereo") }

    val player = remember(playback.streamUrl, retryKey) {
        val extMode = if (settings.getAudioDecoder().startsWith("Software")) {
            DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
        } else {
            DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
        }
        val rf = DefaultRenderersFactory(context)
            .setExtensionRendererMode(extMode)
            .setEnableDecoderFallback(true)
        val minBufMs = when (settings.getBufferSize()) {
            "None" -> 1500; "Small" -> 5000; "Medium" -> 15000; "Large" -> 30000; else -> 50000
        }
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minBufMs, minBufMs * 2, 1000, 2000)
            .build()
        val ua = playback.userAgent.ifBlank { HttpClientProvider.DEFAULT_USER_AGENT }
        val dsFactory = OkHttpDataSource.Factory(HttpClientProvider.createClient(ua))
        val extractors = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)

        ExoPlayer.Builder(context, rf)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory, extractors))
            .build().apply {
                setMediaItem(MediaItem.fromUri(playback.streamUrl))
                if (playback.resumePositionMs > 5000L) seekTo(playback.resumePositionMs)
                prepare()
                playWhenReady = true
            }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(t: Tracks) {
                tracks = t
                for (g in t.groups) {
                    for (i in 0 until g.length) {
                        if (g.isTrackSelected(i)) {
                            val fmt = g.getTrackFormat(i)
                            if (g.type == C.TRACK_TYPE_VIDEO && fmt.width > 0) {
                                videoResolution = "${fmt.width} × ${fmt.height}"
                            }
                            if (g.type == C.TRACK_TYPE_AUDIO) {
                                audioLabel = if ((fmt.channelCount) >= 6) "5.1" else "Stereo"
                            }
                        }
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                errorMessage = "Playback error (${error.errorCodeName})"
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) errorMessage = null
                if (playbackState == Player.STATE_ENDED && playback.mediaType == "SERIES") {
                    onNextEpisode?.invoke()
                }
            }
        }
        player.addListener(listener)
        onDispose {
            onSaveProgress(player.currentPosition, player.duration)
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(player, playback.itemId) {
        while (true) {
            delay(10_000L)
            if (player.isPlaying) onSaveProgress(player.currentPosition, player.duration)
        }
    }

    LaunchedEffect(zapDigits) {
        if (zapDigits.isNotEmpty()) {
            delay(1400L)
            val num = zapDigits.toIntOrNull()
            zapDigits = ""
            if (num != null) onZapByNumber(num)
        }
    }

    LaunchedEffect(sleepMinutesLeft) {
        if (sleepMinutesLeft > 0) {
            delay(60_000L)
            sleepMinutesLeft -= 1
            if (sleepMinutesLeft == 0) {
                player.pause()
                onBack()
            }
        }
    }

    val clockFmt = remember { SimpleDateFormat("EEE, dd MMM, HH:mm", Locale.getDefault()) }

    Box(
        modifier = modifier
            .background(Color.Black)
            .focusable()
            .onPreviewKeyEvent { keyEvent ->
                val native = keyEvent.nativeKeyEvent
                if (native.action == AndroidKeyEvent.ACTION_DOWN && playback.isFullscreen) {
                    val code = native.keyCode
                    when {
                        code == AndroidKeyEvent.KEYCODE_MENU ||
                            (code == AndroidKeyEvent.KEYCODE_DPAD_CENTER && native.isLongPress) -> {
                            showControls = !showControls
                            true
                        }
                        playback.mediaType == "LIVE" && code in AndroidKeyEvent.KEYCODE_0..AndroidKeyEvent.KEYCODE_9 -> {
                            val digit = code - AndroidKeyEvent.KEYCODE_0
                            if (zapDigits.length < 5) zapDigits += digit.toString()
                            true
                        }
                        playback.mediaType == "LIVE" && (code == AndroidKeyEvent.KEYCODE_CHANNEL_UP || (code == AndroidKeyEvent.KEYCODE_DPAD_UP && !showEpgOverlay && !showControls)) -> {
                            val idx = channels.indexOfFirst { it.id == playback.itemId }
                            if (idx >= 0 && channels.isNotEmpty()) onSwitchChannel(channels[(idx + 1) % channels.size])
                            true
                        }
                        playback.mediaType == "LIVE" && (code == AndroidKeyEvent.KEYCODE_CHANNEL_DOWN || (code == AndroidKeyEvent.KEYCODE_DPAD_DOWN && !showEpgOverlay && !showControls)) -> {
                            val idx = channels.indexOfFirst { it.id == playback.itemId }
                            if (idx >= 0 && channels.isNotEmpty()) onSwitchChannel(channels[(idx - 1 + channels.size) % channels.size])
                            true
                        }
                        playback.mediaType == "LIVE" && (code == AndroidKeyEvent.KEYCODE_DPAD_LEFT || code == AndroidKeyEvent.KEYCODE_GUIDE) -> {
                            showEpgOverlay = !showEpgOverlay
                            true
                        }
                        else -> false
                    }
                } else false
            }
            .combinedClickable(
                onClick = { showControls = !showControls },
                onLongClick = { showControls = true }
            )
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = playback.mediaType != "LIVE"
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { view ->
                view.player = player
                view.resizeMode = when (ratioMode) {
                    VideoRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    VideoRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    VideoRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (zapDigits.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp)
                    .background(Color(0xDD10151E), RoundedCornerShape(10.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text("CH $zapDigits", color = TiviColors.AccentBlue, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (showEpgOverlay && playback.isFullscreen && playback.mediaType == "LIVE") {
            val now = System.currentTimeMillis()
            val epgMap = remember(epgPrograms, now) {
                epgPrograms.filter { it.startTimeMillis <= now && it.endTimeMillis >= now }
                    .associateBy { it.channelTvgId }
            }
            Column(
                modifier = Modifier
                    .width(320.dp)
                    .fillMaxHeight()
                    .align(Alignment.CenterStart)
                    .background(Color(0xE60A0D12))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Channels list", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(onClick = { showEpgOverlay = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(channels, key = { it.id }) { ch ->
                        val prog = epgMap[ch.tvgId]
                        val active = ch.id == playback.itemId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (active) TiviColors.CardFocused else Color(0x88161D29))
                                .tvFocusableBorder(6)
                                .clickable {
                                    onSwitchChannel(ch)
                                    showEpgOverlay = false
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${ch.number}", color = TiviColors.TextSecondary, fontSize = 11.sp, modifier = Modifier.width(28.dp))
                            if (ch.logoUrl.isNotBlank()) {
                                AsyncImage(
                                    model = ch.logoUrl,
                                    contentDescription = ch.name,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.size(26.dp).padding(end = 6.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ch.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (prog != null) {
                                    Text(prog.title, color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (errorMessage != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0xCC111622), RoundedCornerShape(12.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(errorMessage!!, color = TiviColors.DangerRed, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { errorMessage = null; retryKey++ }) { Text("Retry") }
                    OutlinedButton(onClick = {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(Uri.parse(playback.streamUrl), "video/*")
                            })
                        }
                    }) { Text("External Player") }
                }
            }
        }

        // TiviMate-exact Fullscreen Bottom Circular Action Bar + Minimal Top Header (Screenshot 1000244299.jpg)
        if (showControls && playback.isFullscreen) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color(0x66000000))
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(playback.subtitle.ifBlank { playback.title }, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(playback.title, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (settings.isPlayerClockEnabled()) {
                    Text(clockFmt.format(Date()), color = Color.White, fontSize = 14.sp)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color(0xAA000000))
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PlayerActionCircle(Icons.Default.Search, "Search") { onBack(); onOpenSearch() }
                if (playback.mediaType == "LIVE") {
                    PlayerActionCircle(Icons.Default.List, "Channels list") { showEpgOverlay = !showEpgOverlay }
                    PlayerActionCircle(
                        Icons.Default.Dvr,
                        if (isRecording) "Stop REC" else "Recordings",
                        tint = if (isRecording) TiviColors.DangerRed else Color.White
                    ) {
                        if (isRecording) {
                            RecordingService.stop(context); isRecording = false
                        } else {
                            RecordingService.start(context, playback.itemId, playback.title, playback.title, playback.streamUrl)
                            isRecording = true
                        }
                    }
                    PlayerActionCircle(Icons.Default.GridView, "Multiview") { onOpenMultiview() }
                }
                PlayerActionCircle(Icons.Default.PictureInPictureAlt, "Picture-in-picture") {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        (context as? Activity)?.enterPictureInPictureMode(
                            PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                        )
                    }
                }
                PlayerActionCircle(Icons.Default.Videocam, videoResolution) { showTracksDialog = true }
                PlayerActionCircle(Icons.Default.VolumeUp, audioLabel) { showTracksDialog = true }
                PlayerActionCircle(Icons.Default.ClosedCaption, "Subtitles") { showTracksDialog = true }
                PlayerActionCircle(Icons.Default.AspectRatio, ratioMode.label) {
                    val modes = VideoRatioMode.entries
                    ratioMode = modes[(modes.indexOf(ratioMode) + 1) % modes.size]
                }
                PlayerActionCircle(Icons.Default.Timer, if (sleepMinutesLeft > 0) "${sleepMinutesLeft}m" else "Off") {
                    showSleepDialog = true
                }
                if (playback.mediaType == "SERIES" && onNextEpisode != null) {
                    PlayerActionCircle(Icons.Default.SkipNext, "Next Ep") { onNextEpisode.invoke() }
                }
                PlayerActionCircle(Icons.Default.OpenInNew, "External") {
                    runCatching {
                        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(Uri.parse(playback.streamUrl), "video/*")
                        })
                    }
                }
            }
        }
    }

    if (showTracksDialog) {
        TrackSelectorDialog(
            tracks = tracks,
            onSelect = { opt ->
                val builder = player.trackSelectionParameters.buildUpon()
                builder.setOverrideForType(TrackSelectionOverride(opt.group.mediaTrackGroup, opt.trackIndex))
                player.trackSelectionParameters = builder.build()
                showTracksDialog = false
            },
            onDisableSubtitles = {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showTracksDialog = false
            },
            onDismiss = { showTracksDialog = false }
        )
    }

    if (showSleepDialog) {
        AlertDialog(
            onDismissRequest = { showSleepDialog = false },
            title = { Text("Sleep Timer") },
            text = {
                Column {
                    listOf(0 to "Off", 15 to "15 minutes", 30 to "30 minutes", 60 to "60 minutes", 90 to "90 minutes")
                        .forEach { (mins, label) ->
                            TextButton(onClick = { sleepMinutesLeft = mins; showSleepDialog = false }) { Text(label) }
                        }
                }
            },
            confirmButton = { TextButton(onClick = { showSleepDialog = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun PlayerActionCircle(
    icon: ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .widthIn(min = 64.dp)
            .tvFocusableBorder(10)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TrackSelectorDialog(
    tracks: Tracks,
    onSelect: (TrackOption) -> Unit,
    onDisableSubtitles: () -> Unit,
    onDismiss: () -> Unit
) {
    val options = remember(tracks) {
        val list = mutableListOf<TrackOption>()
        for (g in tracks.groups) {
            if (g.type == C.TRACK_TYPE_AUDIO || g.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until g.length) {
                    val fmt = g.getTrackFormat(i)
                    val prefix = if (g.type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                    val lang = fmt.language ?: "und"
                    val label = "$prefix: ${fmt.label ?: lang} (${fmt.sampleMimeType ?: ""})"
                    list.add(TrackOption(g.type, g, i, label, g.isTrackSelected(i)))
                }
            }
        }
        list
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Audio & Subtitles") },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                item {
                    TextButton(onClick = onDisableSubtitles) { Text("Subtitles: Off", color = TiviColors.TextSecondary) }
                }
                items(options) { opt ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { onSelect(opt) }.padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = opt.isSelected, onClick = { onSelect(opt) })
                        Spacer(Modifier.width(8.dp))
                        Text(opt.label, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
