package com.tiviclone.iptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.data.db.*
import com.tiviclone.iptv.data.model.SourceType
import com.tiviclone.iptv.data.repository.GlobalSearchResults
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder

@Composable
fun FavoritesScreen(
    channels: List<ChannelEntity>,
    movies: List<VodMovieEntity>,
    series: List<SeriesEntity>,
    onPlayChannel: (ChannelEntity) -> Unit,
    onOpenMovie: (VodMovieEntity) -> Unit,
    onOpenSeries: (SeriesEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(TiviColors.Background).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("My List / Favorites", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        if (channels.isEmpty() && movies.isEmpty() && series.isEmpty()) {
            item { Text("No favorites yet.", color = TiviColors.TextSecondary) }
        }
        if (channels.isNotEmpty()) {
            item { Text("Live Channels", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold) }
            items(channels, key = { it.id }) { ch ->
                SimpleListRow(ch.name, ch.groupName) { onPlayChannel(ch) }
            }
        }
        if (movies.isNotEmpty()) {
            item { Text("Movies", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold) }
            items(movies, key = { it.id }) { m ->
                SimpleListRow(m.name, m.categoryName) { onOpenMovie(m) }
            }
        }
        if (series.isNotEmpty()) {
            item { Text("Shows", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold) }
            items(series, key = { it.id }) { s ->
                SimpleListRow(s.name, s.categoryName) { onOpenSeries(s) }
            }
        }
    }
}

@Composable
fun RecordingsScreen(
    recordings: List<RecordingEntity>,
    onDelete: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(TiviColors.Background).padding(16.dp)) {
        Text("Recordings (DVR)", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (recordings.isEmpty()) {
            Text("No recordings yet.", color = TiviColors.TextSecondary)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(recordings, key = { it.id }) { rec ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TiviColors.PanelBg, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rec.programTitle, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${rec.channelName} • ${rec.status}", color = TiviColors.TextSecondary, fontSize = 12.sp)
                            Text(rec.filePath, color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { onDelete(rec.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TiviColors.DangerRed)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchScreen(
    results: GlobalSearchResults,
    onQueryChange: (String) -> Unit,
    onPlayChannel: (ChannelEntity) -> Unit,
    onOpenMovie: (VodMovieEntity) -> Unit,
    onOpenSeries: (SeriesEntity) -> Unit
) {
    var query by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().background(TiviColors.Background).padding(16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = {
                query = it
                onQueryChange(it)
            },
            label = { Text("Search Live, Movies, Shows, or EPG...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (results.channels.isNotEmpty()) {
                item { Text("Channels (${results.channels.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold) }
                items(results.channels, key = { it.id }) { ch ->
                    SimpleListRow(ch.name, ch.groupName) { onPlayChannel(ch) }
                }
            }
            if (results.movies.isNotEmpty()) {
                item { Text("Movies (${results.movies.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold) }
                items(results.movies, key = { it.id }) { m ->
                    SimpleListRow(m.name, m.categoryName) { onOpenMovie(m) }
                }
            }
            if (results.series.isNotEmpty()) {
                item { Text("Shows (${results.series.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold) }
                items(results.series, key = { it.id }) { s ->
                    SimpleListRow(s.name, s.categoryName) { onOpenSeries(s) }
                }
            }
            if (results.programs.isNotEmpty()) {
                item { Text("EPG Programs (${results.programs.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold) }
                items(results.programs, key = { it.rowId }) { p ->
                    SimpleListRow(p.title, p.description.take(80)) {}
                }
            }
        }
    }
}

@Composable
fun AddSourceDialog(
    initialTab: String = "Stalker",
    editingPlaylist: PlaylistEntity? = null,
    onAddM3uUrl: (String, String, String, String?) -> Unit,
    onPickM3uFile: () -> Unit,
    onAddXtream: (String, String, String, String, String?) -> Unit,
    onAddStalker: (String, String, String, String?) -> Unit,
    onDismiss: () -> Unit
) {
    val startTab = when (editingPlaylist?.type) {
        SourceType.XTREAM -> "Xtream"
        SourceType.M3U -> "M3U"
        SourceType.STALKER -> "Stalker"
        null -> initialTab
    }
    var tab by remember(editingPlaylist, initialTab) { mutableStateOf(startTab) }
    var name by remember(editingPlaylist) { mutableStateOf(editingPlaylist?.name.orEmpty()) }
    var m3uUrl by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.M3U) editingPlaylist.primaryUrl else "")
    }
    var epgUrl by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.M3U) editingPlaylist.epgUrl else "")
    }
    var xtreamHost by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.XTREAM) editingPlaylist.primaryUrl else "")
    }
    var xtreamUser by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.XTREAM) editingPlaylist.extra1 else "")
    }
    var xtreamPass by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.XTREAM) editingPlaylist.extra2 else "")
    }
    var stalkerUrl by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.STALKER) editingPlaylist.primaryUrl else "")
    }
    var stalkerMac by remember(editingPlaylist) {
        mutableStateOf(if (editingPlaylist?.type == SourceType.STALKER) editingPlaylist.extra1 else "")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (editingPlaylist != null) "Edit $tab" else "$tab Setup") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Playlist Name (Optional)") },
                    singleLine = true
                )
                when (tab) {
                    "Stalker" -> {
                        OutlinedTextField(
                            value = stalkerUrl,
                            onValueChange = { stalkerUrl = it },
                            label = { Text("Portal URL (http://.../c/)") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = stalkerMac,
                            onValueChange = { stalkerMac = it },
                            label = { Text("MAC Address (SN & DeviceID auto)") },
                            singleLine = true
                        )
                    }
                    "Xtream" -> {
                        OutlinedTextField(
                            value = xtreamHost,
                            onValueChange = { xtreamHost = it },
                            label = { Text("Server URL (http://host:port)") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = xtreamUser,
                            onValueChange = { xtreamUser = it },
                            label = { Text("Username") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = xtreamPass,
                            onValueChange = { xtreamPass = it },
                            label = { Text("Password") },
                            singleLine = true
                        )
                    }
                    "M3U" -> {
                        OutlinedTextField(
                            value = m3uUrl,
                            onValueChange = { m3uUrl = it },
                            label = { Text("M3U / M3U8 URL") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = epgUrl,
                            onValueChange = { epgUrl = it },
                            label = { Text("XMLTV EPG URL (Optional)") },
                            singleLine = true
                        )
                        if (editingPlaylist == null) {
                            OutlinedButton(onClick = { onPickM3uFile(); onDismiss() }) {
                                Text("Or Pick Local .m3u File")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val editId = editingPlaylist?.id
                when (tab) {
                    "Stalker" -> if (stalkerUrl.isNotBlank() && stalkerMac.isNotBlank()) {
                        onAddStalker(name, stalkerUrl, stalkerMac, editId)
                    }
                    "Xtream" -> if (xtreamHost.isNotBlank() && xtreamUser.isNotBlank()) {
                        onAddXtream(name, xtreamHost, xtreamUser, xtreamPass, editId)
                    }
                    "M3U" -> if (m3uUrl.isNotBlank()) {
                        onAddM3uUrl(name, m3uUrl, epgUrl, editId)
                    }
                }
                onDismiss()
            }) { Text(if (editingPlaylist != null) "Save & Sync" else "Connect") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun SimpleListRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(TiviColors.PanelBg)
            .tvFocusableBorder()
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium)
            if (subtitle.isNotBlank()) {
                Text(subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
