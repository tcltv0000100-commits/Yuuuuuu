package com.tiviclone.iptv.data.model

enum class SourceType {
    M3U,
    XTREAM,
    STALKER
}

enum class MediaType(val label: String) {
    LIVE("Live TV"),
    MOVIES("Movies"),
    SERIES("Series")
}

enum class AppSection(val label: String) {
    SEARCH("Search"),
    TV("TV"),
    MOVIES("Movies"),
    SHOWS("Shows"),
    RECORDINGS("Recordings"),
    MY_LIST("My list"),
    SETTINGS("Settings")
}

enum class VideoRatioMode(val label: String, val ratio: Float?) {
    FIT("Fit", null),
    FILL("Fill", null),
    ZOOM("Zoom", null),
    RATIO_16_9("16:9", 16f / 9f),
    RATIO_4_3("4:3", 4f / 3f),
    RATIO_20_9("20:9", 20f / 9f)
}
