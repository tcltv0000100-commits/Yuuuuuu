package com.tiviclone.iptv.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.imageLoader
import com.tiviclone.iptv.data.db.PlaylistEntity
import com.tiviclone.iptv.data.repository.SettingsStore
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SettingsPage(val title: String) {
    ROOT("Settings"),
    GENERAL("General"),
    PLAYLISTS("Playlists"),
    PLAYLIST_DETAIL("Playlist parameters"),
    EPG("EPG"),
    APPEARANCE("Appearance"),
    APP_TV_GUIDE("TV guide"),
    APP_PLAYER("Player"),
    APP_GROUPS("Groups"),
    APP_LOGOS("Logos"),
    COLOR_THEME("Color theme"),
    PLAYBACK("Playback"),
    PLAYBACK_AFR("Auto frame rate (AFR)"),
    PLAYBACK_SKIP("Skip steps"),
    REMOTE("Remote control"),
    REMOTE_TV_GUIDE("TV guide controls"),
    REMOTE_PLAYER("Player controls"),
    PARENTAL("Parental controls"),
    PARENTAL_REQUIRE("Require PIN for"),
    OTHER("Other"),
    OTHER_RECORDING("Recording"),
    OTHER_REMINDERS("Reminders"),
    OTHER_VOD("VOD"),
    OTHER_SEARCH("Search"),
    ABOUT("About")
}

@Composable
fun TiviMateSettingsDrawer(
    settings: SettingsStore,
    playlists: List<PlaylistEntity>,
    activePlaylistId: String,
    epgIntervalHours: Int,
    epgLastUpdated: Long,
    parentalPin: String,
    bgTheme: String,
    accentTheme: String,
    onUpdateTheme: (String, String) -> Unit,
    onSelectPlaylist: (String) -> Unit,
    onTogglePlaylistEnabled: (String, Boolean) -> Unit,
    onAddPlaylist: () -> Unit,
    onEditPlaylist: (PlaylistEntity) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onSyncAll: () -> Unit,
    onUpdateEpgInterval: (Int) -> Unit,
    onSetParentalPin: (String) -> Unit,
    onExportBackup: suspend () -> String,
    onImportBackup: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var page by remember { mutableStateOf(SettingsPage.ROOT) }
    var inspectedPlaylistId by remember { mutableStateOf<String?>(null) }
    val drawerFocusRequester = remember { FocusRequester() }
    LaunchedEffect(page) { runCatching { drawerFocusRequester.requestFocus() } }

    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var showBackupDialog by remember { mutableStateOf(false) }
    var backupText by remember { mutableStateOf("") }

    var autoBoot by remember { mutableStateOf(settings.isAutoStartBoot()) }
    var autoWake by remember { mutableStateOf(settings.isAutoStartWake()) }
    var turnOnLast by remember { mutableStateOf(settings.isTurnOnLastChannel()) }
    var pipHome by remember { mutableStateOf(settings.isPipOnHome()) }
    var confirmExit by remember { mutableStateOf(settings.isConfirmExitBack()) }
    var userAgent by remember { mutableStateOf(settings.getUserAgent()) }
    var udpProxy by remember { mutableStateOf(settings.getUdpProxy()) }

    var epgPastDays by remember { mutableIntStateOf(settings.getEpgPastDays()) }
    var storeEpgDesc by remember { mutableStateOf(settings.isStoreProgramDesc()) }
    var epgOnStart by remember { mutableStateOf(settings.isEpgUpdateOnStart()) }
    var epgOnChange by remember { mutableStateOf(settings.isEpgUpdateOnPlaylistChange()) }

    var tvPreview by remember { mutableStateOf(settings.isTvGuidePreview()) }
    var animTvPreview by remember { mutableStateOf(settings.isAnimatedTvGuidePreview()) }
    var autoPlayGuide by remember { mutableStateOf(settings.isAutoPlayOnTvGuide()) }
    var showChNumbers by remember { mutableStateOf(settings.isShowChannelNumbers()) }
    var highlightCh by remember { mutableStateOf(settings.isHighlightCurrentChannel()) }
    var dimPast by remember { mutableStateOf(settings.isDimPastPrograms()) }
    var playerClock by remember { mutableStateOf(settings.isPlayerClockEnabled()) }
    var infoCardStyle by remember { mutableStateOf(settings.isInfoPanelCardStyle()) }
    var fsTimeout by remember { mutableIntStateOf(settings.getFullscreenSwitchTimeoutSec()) }
    var groupsSort by remember { mutableStateOf(settings.getGroupsSorting()) }
    var channelsSort by remember { mutableStateOf(settings.getChannelsSorting()) }
    var showRecent by remember { mutableStateOf(settings.isShowRecentChannels()) }
    var logosPriority by remember { mutableStateOf(settings.getLogosPriority()) }
    var inexactLogos by remember { mutableStateOf(settings.isInexactLogos()) }
    var fontSize by remember { mutableStateOf(settings.getFontSize()) }
    var transparency by remember { mutableIntStateOf(settings.getUiTransparency()) }

    var bufferSize by remember { mutableStateOf(settings.getBufferSize()) }
    var audioDec by remember { mutableStateOf(settings.getAudioDecoder()) }
    var videoDec by remember { mutableStateOf(settings.getVideoDecoder()) }
    var afrEnabled by remember { mutableStateOf(settings.isAfrEnabled()) }
    var afrVod by remember { mutableStateOf(settings.isAfrForVod()) }
    var tunneled by remember { mutableStateOf(settings.isTunneledPlayback()) }
    var amlogicFix by remember { mutableStateOf(settings.isAmlogicFix()) }
    var surroundDef by remember { mutableStateOf(settings.isSurroundDefault()) }
    var passthrough by remember { mutableStateOf(settings.isAudioPassthrough()) }
    var extPlayerMode by remember { mutableStateOf(settings.getUseExternalPlayer()) }
    var skipFwd by remember { mutableIntStateOf(settings.getSkipForwardSec()) }
    var skipBwd by remember { mutableIntStateOf(settings.getSkipBackwardSec()) }

    var seekLR by remember { mutableStateOf(settings.isSeekLeftRight()) }
    var seekUD by remember { mutableStateOf(settings.isSeekUpDown()) }
    var rwFfCatchup by remember { mutableStateOf(settings.isRwFfInCatchup()) }

    var pinInput by remember(parentalPin) { mutableStateOf(parentalPin) }
    var pinForSettings by remember { mutableStateOf(settings.isPinForSettings()) }
    var pinForPlaylists by remember { mutableStateOf(settings.isPinForPlaylists()) }
    var pinForChOpts by remember { mutableStateOf(settings.isPinForChannelOptions()) }
    var pinTimeout by remember { mutableStateOf(settings.getPinUnlockTimeout()) }

    var recStartMin by remember { mutableIntStateOf(settings.getRecordingStartOffsetMin()) }
    var recStopMin by remember { mutableIntStateOf(settings.getRecordingStopOffsetMin()) }
    var remAction by remember { mutableStateOf(settings.getReminderDefaultAction()) }
    var remTimeout by remember { mutableIntStateOf(settings.getReminderPopupTimeoutSec()) }
    var autoNextEp by remember { mutableStateOf(settings.isAutoPlayNextEpisode()) }
    var favFirstSearch by remember { mutableStateOf(settings.isShowFavFirstSearch()) }
    var showSearchHist by remember { mutableStateOf(settings.isShowSearchHistory()) }

    var textEditDialog by remember { mutableStateOf<Triple<String, String, (String) -> Unit>?>(null) }

    val inspectedPlaylist = remember(playlists, inspectedPlaylistId) {
        playlists.firstOrNull { it.id == inspectedPlaylistId }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable { onClose() }
    ) {
        Column(
            modifier = Modifier
                .width(355.dp)
                .fillMaxHeight()
                .align(Alignment.CenterEnd)
                .background(TiviColors.PanelBg)
                .clickable(enabled = false) {}
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TiviColors.SidebarBg)
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (page != SettingsPage.ROOT) {
                    IconButton(
                        onClick = {
                            page = when (page) {
                                SettingsPage.PLAYLIST_DETAIL -> SettingsPage.PLAYLISTS
                                SettingsPage.APP_TV_GUIDE, SettingsPage.APP_PLAYER, SettingsPage.APP_GROUPS, SettingsPage.APP_LOGOS, SettingsPage.COLOR_THEME -> SettingsPage.APPEARANCE
                                SettingsPage.PLAYBACK_AFR, SettingsPage.PLAYBACK_SKIP -> SettingsPage.PLAYBACK
                                SettingsPage.REMOTE_TV_GUIDE, SettingsPage.REMOTE_PLAYER -> SettingsPage.REMOTE
                                SettingsPage.PARENTAL_REQUIRE -> SettingsPage.PARENTAL
                                SettingsPage.OTHER_RECORDING, SettingsPage.OTHER_REMINDERS, SettingsPage.OTHER_VOD, SettingsPage.OTHER_SEARCH -> SettingsPage.OTHER
                                else -> SettingsPage.ROOT
                            }
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    if (page == SettingsPage.PLAYLIST_DETAIL) (inspectedPlaylist?.name ?: "Playlist") else page.title,
                    color = Color.White,
                    fontSize = 19.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            LazyColumn(modifier = Modifier.weight(1f).padding(vertical = 8.dp)) {
                when (page) {
                    SettingsPage.ROOT -> {
                        val entries = listOf(
                            SettingsPage.GENERAL,
                            SettingsPage.PLAYLISTS,
                            SettingsPage.EPG,
                            SettingsPage.APPEARANCE,
                            SettingsPage.PLAYBACK,
                            SettingsPage.REMOTE,
                            SettingsPage.PARENTAL,
                            SettingsPage.OTHER,
                            SettingsPage.ABOUT
                        )
                        items(entries) { item ->
                            DrawerMenuRow(
                                item.title,
                                modifier = if (item == SettingsPage.GENERAL) Modifier.focusRequester(drawerFocusRequester) else Modifier
                            ) { page = item }
                        }
                    }

                    SettingsPage.GENERAL -> {
                        item {
                            DrawerSwitchRow("Auto start app on boot", null, autoBoot, Modifier.focusRequester(drawerFocusRequester)) { autoBoot = it; settings.setAutoStartBoot(it) }
                            DrawerSwitchRow("Auto start app on wake up from sleep mode", "May not work on all devices", autoWake) { autoWake = it; settings.setAutoStartWake(it) }
                            DrawerSwitchRow("Turn on last channel on app start", null, turnOnLast) { turnOnLast = it; settings.setTurnOnLastChannel(it) }
                            DrawerSwitchRow("Switch to picture-in-picture mode on press Home", null, pipHome) { pipHome = it; settings.setPipOnHome(it) }
                            DrawerSwitchRow("Confirm exit by second press Back", null, confirmExit) { confirmExit = it; settings.setConfirmExitBack(it) }
                            DrawerValueRow("User-Agent", userAgent.ifBlank { "Not set" }) {
                                textEditDialog = Triple("User-Agent", userAgent) { userAgent = it; settings.setUserAgent(it) }
                            }
                            DrawerValueRow("UDP proxy (address:port)", udpProxy.ifBlank { "Not set" }) {
                                textEditDialog = Triple("UDP proxy (address:port)", udpProxy) { udpProxy = it; settings.setUdpProxy(it) }
                            }
                            DrawerMenuRow("Back up data") {
                                scope.launch {
                                    backupText = onExportBackup()
                                    clipboard.setText(AnnotatedString(backupText))
                                    showBackupDialog = true
                                }
                            }
                            DrawerMenuRow("Restore data") { backupText = ""; showBackupDialog = true }
                        }
                    }

                    SettingsPage.PLAYLISTS -> {
                        item {
                            DrawerMenuRow("+ Add playlist", highlight = true, modifier = Modifier.focusRequester(drawerFocusRequester)) {
                                onClose()
                                onAddPlaylist()
                            }
                            DrawerValueRow("Active view", if (activePlaylistId == "ALL") "All enabled playlists" else "Single playlist") {
                                onSelectPlaylist("ALL")
                            }
                            DrawerMenuRow("Update all playlists") { onSyncAll() }
                        }
                        items(playlists, key = { it.id }) { pl ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .tvFocusableBorder(4)
                                    .clickable {
                                        inspectedPlaylistId = pl.id
                                        page = SettingsPage.PLAYLIST_DETAIL
                                    }
                                    .padding(horizontal = 20.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(pl.name, color = if (pl.isEnabled) Color.White else TiviColors.TextSecondary, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${pl.type.name} • ${pl.channelsCount} ch • ${pl.moviesCount} mov • ${pl.seriesCount} shows", color = TiviColors.TextSecondary, fontSize = 11.sp)
                                }
                                Switch(checked = pl.isEnabled, onCheckedChange = { onTogglePlaylistEnabled(pl.id, it) })
                            }
                        }
                    }

                    SettingsPage.PLAYLIST_DETAIL -> {
                        val pl = inspectedPlaylist
                        if (pl != null) {
                            val expText = formatExpiry(pl.accountExpiry)
                            item {
                                DrawerSwitchRow("Enable playlist", null, pl.isEnabled, Modifier.focusRequester(drawerFocusRequester)) {
                                    onTogglePlaylistEnabled(pl.id, it)
                                }
                                DrawerMenuRow("Use only this playlist") { onSelectPlaylist(pl.id); onClose() }
                                DrawerMenuRow("Update playlist") { onSyncAll() }
                                DrawerValueRow("Playlist name", pl.name) {}
                                DrawerValueRow("Playlist type", pl.type.name) {}
                                DrawerValueRow("Server / URL", pl.primaryUrl) {}
                                if (pl.accountStatus.isNotBlank()) DrawerValueRow("Account status", pl.accountStatus) {}
                                DrawerValueRow("Expiration date", expText) {}
                                DrawerValueRow("Max connections", "${pl.activeConnections} / ${pl.maxConnections}") {}
                                DrawerValueRow("Output format", pl.outputFormat) {}
                                DrawerValueRow("Include VOD", if (pl.includeVod) "Yes" else "No") {}
                                DrawerValueRow("Processed items", "${pl.channelsCount} channels, ${pl.moviesCount} movies, ${pl.seriesCount} shows") {}
                                DrawerMenuRow("Edit parameters", highlight = true) { onClose(); onEditPlaylist(pl) }
                                DrawerMenuRow("Delete playlist", danger = true) { onDeletePlaylist(pl.id); page = SettingsPage.PLAYLISTS }
                            }
                        }
                    }

                    SettingsPage.EPG -> {
                        val lastStr = if (epgLastUpdated <= 0L) "—"
                        else SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(epgLastUpdated))
                        item {
                            DrawerMenuRow("EPG sources", modifier = Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.PLAYLISTS }
                            DrawerValueRow("Past days to keep EPG", "$epgPastDays") {
                                val next = when (epgPastDays) { 3 -> 7; 7 -> 14; else -> 3 }
                                epgPastDays = next; settings.setEpgPastDays(next)
                            }
                            DrawerSwitchRow("Store program descriptions", null, storeEpgDesc) { storeEpgDesc = it; settings.setStoreProgramDesc(it) }
                            Text("Update options", color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                            DrawerValueRow("Update interval, hours", "$epgIntervalHours") {
                                val next = when (epgIntervalHours) { 4 -> 12; 12 -> 24; else -> 4 }
                                onUpdateEpgInterval(next)
                            }
                            DrawerSwitchRow("Update on app start", null, epgOnStart) { epgOnStart = it; settings.setEpgUpdateOnStart(it) }
                            DrawerSwitchRow("Update on playlists change", null, epgOnChange) { epgOnChange = it; settings.setEpgUpdateOnPlaylistChange(it) }
                            DrawerMenuRow("Update EPG") { onSyncAll() }
                            DrawerValueRow("Latest update status", lastStr) {}
                        }
                    }

                    SettingsPage.APPEARANCE -> {
                        item {
                            DrawerMenuRow("TV guide", modifier = Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.APP_TV_GUIDE }
                            DrawerMenuRow("Player") { page = SettingsPage.APP_PLAYER }
                            DrawerMenuRow("Groups") { page = SettingsPage.APP_GROUPS }
                            DrawerMenuRow("Logos") { page = SettingsPage.APP_LOGOS }
                            DrawerValueRow("Language", "System") {}
                            DrawerValueRow("Font size", fontSize) {
                                val next = when (fontSize) { "Small" -> "Medium"; "Medium" -> "Large"; "Large" -> "Very large"; else -> "Small" }
                                fontSize = next; settings.setFontSize(next)
                            }
                            DrawerValueRow("Color theme", "$bgTheme • $accentTheme") { page = SettingsPage.COLOR_THEME }
                            DrawerValueRow("User interface transparency, %", "$transparency") {
                                val next = (transparency + 25) % 100
                                transparency = next; settings.setUiTransparency(next)
                            }
                        }
                    }

                    SettingsPage.APP_TV_GUIDE -> {
                        item {
                            DrawerSwitchRow("Preview", "Show preview window in TV guide", tvPreview, Modifier.focusRequester(drawerFocusRequester)) {
                                tvPreview = it; settings.setTvGuidePreview(it)
                            }
                            DrawerSwitchRow("Animated preview", null, animTvPreview) { animTvPreview = it; settings.setAnimatedTvGuidePreview(it) }
                            DrawerSwitchRow("Auto-play channels on TV guide", null, autoPlayGuide) { autoPlayGuide = it; settings.setAutoPlayOnTvGuide(it) }
                            DrawerSwitchRow("Show channel numbers", null, showChNumbers) { showChNumbers = it; settings.setShowChannelNumbers(it) }
                            DrawerSwitchRow("Highlight current channel in color", null, highlightCh) { highlightCh = it; settings.setHighlightCurrentChannel(it) }
                            DrawerSwitchRow("Dim past programs", null, dimPast) { dimPast = it; settings.setDimPastPrograms(it) }
                        }
                    }

                    SettingsPage.APP_PLAYER -> {
                        item {
                            DrawerSwitchRow("Show clock in player", null, playerClock, Modifier.focusRequester(drawerFocusRequester)) {
                                playerClock = it; settings.setPlayerClockEnabled(it)
                            }
                            DrawerSwitchRow("Info panel card style", null, infoCardStyle) { infoCardStyle = it; settings.setInfoPanelCardStyle(it) }
                            DrawerValueRow("Fullscreen switching timeout", if (fsTimeout == 0) "Off" else "${fsTimeout}s") {
                                val next = when (fsTimeout) { 3 -> 5; 5 -> 10; 10 -> 0; else -> 3 }
                                fsTimeout = next; settings.setFullscreenSwitchTimeoutSec(next)
                            }
                        }
                    }

                    SettingsPage.APP_GROUPS -> {
                        item {
                            DrawerValueRow("Groups sorting", groupsSort, Modifier.focusRequester(drawerFocusRequester)) {
                                val next = if (groupsSort == "Playlist order") "By name" else "Playlist order"
                                groupsSort = next; settings.setGroupsSorting(next)
                            }
                            DrawerValueRow("Channels sorting", channelsSort) {
                                val next = if (channelsSort == "Playlist order") "By name" else "Playlist order"
                                channelsSort = next; settings.setChannelsSorting(next)
                            }
                            DrawerSwitchRow("Show recent channels", null, showRecent) { showRecent = it; settings.setShowRecentChannels(it) }
                        }
                    }

                    SettingsPage.APP_LOGOS -> {
                        item {
                            DrawerValueRow("Logos priority", logosPriority, Modifier.focusRequester(drawerFocusRequester)) {
                                val next = when (logosPriority) { "Playlist" -> "EPG"; "EPG" -> "Folder"; else -> "Playlist" }
                                logosPriority = next; settings.setLogosPriority(next)
                            }
                            DrawerSwitchRow("Inexact logos matching", null, inexactLogos) { inexactLogos = it; settings.setInexactLogos(it) }
                            DrawerMenuRow("Clear logos cache") { context.imageLoader.memoryCache?.clear() }
                        }
                    }

                    SettingsPage.COLOR_THEME -> {
                        item {
                            Text("Background color", color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                            listOf("Dark", "AMOLED Black", "Slate", "Deep Navy").forEachIndexed { idx, bg ->
                                DrawerRadioRow(bg, bgTheme == bg, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    onUpdateTheme(bg, accentTheme)
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("Accent color", color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                            listOf("Blue", "Teal", "Purple", "Amber", "Green", "Red").forEach { acc ->
                                DrawerRadioRow(acc, accentTheme == acc) { onUpdateTheme(bgTheme, acc) }
                            }
                        }
                    }

                    SettingsPage.PLAYBACK -> {
                        item {
                            DrawerValueRow("Buffer size", bufferSize, Modifier.focusRequester(drawerFocusRequester)) {
                                val next = when (bufferSize) {
                                    "None" -> "Small"; "Small" -> "Medium"; "Medium" -> "Large"; "Large" -> "Very large"; else -> "None"
                                }
                                bufferSize = next; settings.setBufferSize(next)
                            }
                            DrawerValueRow("Audio decoder", audioDec) {
                                val next = if (audioDec == "Hardware") "Software (FFmpeg)" else "Hardware"
                                audioDec = next; settings.setAudioDecoder(next)
                            }
                            DrawerValueRow("Video decoder", videoDec) {
                                val next = if (videoDec == "Hardware") "Software" else "Hardware"
                                videoDec = next; settings.setVideoDecoder(next)
                            }
                            DrawerMenuRow("Auto frame rate (AFR)") { page = SettingsPage.PLAYBACK_AFR }
                            DrawerSwitchRow("Select surround audio track by default", null, surroundDef) { surroundDef = it; settings.setSurroundDefault(it) }
                            DrawerSwitchRow("Audio passthrough", null, passthrough) { passthrough = it; settings.setAudioPassthrough(it) }
                            DrawerSwitchRow("Tunneled playback", null, tunneled) { tunneled = it; settings.setTunneledPlayback(it) }
                            DrawerSwitchRow("Amlogic fix", null, amlogicFix) { amlogicFix = it; settings.setAmlogicFix(it) }
                            DrawerValueRow("Use external player", extPlayerMode) {
                                val next = when (extPlayerMode) { "No" -> "Yes"; "Yes" -> "VOD only"; else -> "No" }
                                extPlayerMode = next; settings.setUseExternalPlayer(next)
                            }
                            DrawerMenuRow("Skip steps") { page = SettingsPage.PLAYBACK_SKIP }
                        }
                    }

                    SettingsPage.PLAYBACK_AFR -> {
                        item {
                            DrawerSwitchRow("Auto frame rate (AFR)", null, afrEnabled, Modifier.focusRequester(drawerFocusRequester)) {
                                afrEnabled = it; settings.setAfrEnabled(it)
                            }
                            DrawerSwitchRow("AFR for VOD", null, afrVod) { afrVod = it; settings.setAfrForVod(it) }
                        }
                    }

                    SettingsPage.PLAYBACK_SKIP -> {
                        item {
                            DrawerValueRow("Skip forward (sec)", "${skipFwd}s", Modifier.focusRequester(drawerFocusRequester)) {
                                val next = when (skipFwd) { 10 -> 30; 30 -> 60; else -> 10 }
                                skipFwd = next; settings.setSkipForwardSec(next)
                            }
                            DrawerValueRow("Skip backward (sec)", "${skipBwd}s") {
                                val next = when (skipBwd) { 10 -> 30; 30 -> 60; else -> 10 }
                                skipBwd = next; settings.setSkipBackwardSec(next)
                            }
                        }
                    }

                    SettingsPage.REMOTE -> {
                        item {
                            DrawerMenuRow("TV guide", modifier = Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.REMOTE_TV_GUIDE }
                            DrawerMenuRow("Player") { page = SettingsPage.REMOTE_PLAYER }
                            DrawerMenuRow("Restore to defaults") {
                                seekLR = true; settings.setSeekLeftRight(true)
                                seekUD = false; settings.setSeekUpDown(false)
                                rwFfCatchup = true; settings.setRwFfInCatchup(true)
                            }
                        }
                    }

                    SettingsPage.REMOTE_TV_GUIDE -> {
                        val actions = listOf("Open channel", "Toggle fullscreen", "Channel options", "Show info", "Go back")
                        val keys = listOf("OK" to "Open channel", "Long OK" to "Channel options", "Left" to "Go back", "Right" to "Show info", "Back" to "Go back")
                        items(keys) { (btn, def) ->
                            var cur by remember { mutableStateOf(settings.getRemoteAction(btn, def)) }
                            DrawerValueRow(btn, cur) {
                                val next = actions[(actions.indexOf(cur) + 1) % actions.size]
                                cur = next; settings.setRemoteAction(btn, next)
                            }
                        }
                    }

                    SettingsPage.REMOTE_PLAYER -> {
                        item {
                            DrawerSwitchRow("Use Left/Right for video seeking", null, seekLR, Modifier.focusRequester(drawerFocusRequester)) {
                                seekLR = it; settings.setSeekLeftRight(it)
                            }
                            DrawerSwitchRow("Use Down/Up for video seeking", null, seekUD) { seekUD = it; settings.setSeekUpDown(it) }
                            DrawerSwitchRow("Use RW/FF/Pause in catch-up", null, rwFfCatchup) { rwFfCatchup = it; settings.setRwFfInCatchup(it) }
                            DrawerValueRow("0–9 Number keys", "Channel zapping") {}
                            DrawerValueRow("DPAD Left / Guide", "Live Guide overlay") {}
                        }
                    }

                    SettingsPage.PARENTAL -> {
                        item {
                            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Parental Control PIN (blank = off)", color = Color.White, fontSize = 14.sp)
                                OutlinedTextField(
                                    value = pinInput,
                                    onValueChange = { if (it.length <= 6) pinInput = it },
                                    singleLine = true,
                                    label = { Text("PIN") },
                                    modifier = Modifier.focusRequester(drawerFocusRequester)
                                )
                                Button(onClick = { onSetParentalPin(pinInput.trim()) }) { Text("Save PIN") }
                            }
                            DrawerMenuRow("Require PIN for") { page = SettingsPage.PARENTAL_REQUIRE }
                            DrawerValueRow("Don't require PIN after unlocking", pinTimeout) {
                                val next = when (pinTimeout) {
                                    "Always require" -> "10 min"; "10 min" -> "30 min"; "30 min" -> "1 hour"; "1 hour" -> "Until next app start"; else -> "Always require"
                                }
                                pinTimeout = next; settings.setPinUnlockTimeout(next)
                            }
                        }
                    }

                    SettingsPage.PARENTAL_REQUIRE -> {
                        item {
                            DrawerSwitchRow("Settings", null, pinForSettings, Modifier.focusRequester(drawerFocusRequester)) {
                                pinForSettings = it; settings.setPinForSettings(it)
                            }
                            DrawerSwitchRow("Playlists", null, pinForPlaylists) { pinForPlaylists = it; settings.setPinForPlaylists(it) }
                            DrawerSwitchRow("Channel options", null, pinForChOpts) { pinForChOpts = it; settings.setPinForChannelOptions(it) }
                        }
                    }

                    SettingsPage.OTHER -> {
                        item {
                            DrawerMenuRow("Recording", modifier = Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.OTHER_RECORDING }
                            DrawerMenuRow("Reminders") { page = SettingsPage.OTHER_REMINDERS }
                            DrawerMenuRow("VOD") { page = SettingsPage.OTHER_VOD }
                            DrawerMenuRow("Search") { page = SettingsPage.OTHER_SEARCH }
                            DrawerMenuRow("Update all playlists & EPG") { onSyncAll() }
                        }
                    }

                    SettingsPage.OTHER_RECORDING -> {
                        item {
                            DrawerValueRow("Start recording before program start, min", "$recStartMin", Modifier.focusRequester(drawerFocusRequester)) {
                                val next = (recStartMin + 2) % 10
                                recStartMin = next; settings.setRecordingStartOffsetMin(next)
                            }
                            DrawerValueRow("Stop recording after program end, min", "$recStopMin") {
                                val next = (recStopMin + 5) % 20
                                recStopMin = next; settings.setRecordingStopOffsetMin(next)
                            }
                        }
                    }

                    SettingsPage.OTHER_REMINDERS -> {
                        item {
                            DrawerValueRow("Default action", remAction, Modifier.focusRequester(drawerFocusRequester)) {
                                val next = when (remAction) { "Watch" -> "Dismiss"; "Dismiss" -> "Watch later"; else -> "Watch" }
                                remAction = next; settings.setReminderDefaultAction(next)
                            }
                            DrawerValueRow("Popup timeout, sec", "$remTimeout") {
                                val next = when (remTimeout) { 10 -> 15; 15 -> 30; else -> 10 }
                                remTimeout = next; settings.setReminderPopupTimeoutSec(next)
                            }
                        }
                    }

                    SettingsPage.OTHER_VOD -> {
                        item {
                            DrawerSwitchRow("Auto-play next episode", null, autoNextEp, Modifier.focusRequester(drawerFocusRequester)) {
                                autoNextEp = it; settings.setAutoPlayNextEpisode(it)
                            }
                        }
                    }

                    SettingsPage.OTHER_SEARCH -> {
                        item {
                            DrawerSwitchRow("Show favorite channels first on search", null, favFirstSearch, Modifier.focusRequester(drawerFocusRequester)) {
                                favFirstSearch = it; settings.setShowFavFirstSearch(it)
                            }
                            DrawerSwitchRow("Show search history", null, showSearchHist) { showSearchHist = it; settings.setShowSearchHistory(it) }
                        }
                    }

                    SettingsPage.ABOUT -> {
                        item {
                            DrawerValueRow("TiviMate", "v4.0.0 (Clean Engine)", Modifier.focusRequester(drawerFocusRequester)) {}
                            DrawerValueRow("Device name", "${Build.MANUFACTURER} ${Build.MODEL}") {}
                            DrawerValueRow("Player Engine", "Media3 1.5.0 + FFmpeg") {}
                        }
                    }
                }
            }
        }
    }

    textEditDialog?.let { (title, current, onSave) ->
        var txt by remember { mutableStateOf(current) }
        AlertDialog(
            onDismissRequest = { textEditDialog = null },
            title = { Text(title) },
            text = { OutlinedTextField(value = txt, onValueChange = { txt = it }, singleLine = true) },
            confirmButton = { Button(onClick = { onSave(txt.trim()); textEditDialog = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { textEditDialog = null }) { Text("Cancel") } }
        )
    }

    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("Backup / Restore JSON") },
            text = { OutlinedTextField(value = backupText, onValueChange = { backupText = it }, modifier = Modifier.fillMaxWidth().height(200.dp)) },
            confirmButton = {
                Button(onClick = { if (backupText.isNotBlank()) onImportBackup(backupText); showBackupDialog = false }) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { showBackupDialog = false }) { Text("Close") } }
        )
    }
}

private fun formatExpiry(raw: String): String {
    val clean = raw.trim()
    if (clean.isBlank() || clean == "null" || clean == "0" || clean == "-1" || clean == "0000-00-00") return "Unlimited"
    val sec = clean.toLongOrNull() ?: return clean
    val millis = if (sec > 9_999_999_999L) sec else sec * 1000L
    return SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(millis))
}

@Composable
private fun DrawerMenuRow(label: String, highlight: Boolean = false, danger: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Text(
            label,
            color = when {
                danger -> TiviColors.DangerRed
                highlight -> TiviColors.AccentBlue
                else -> Color.White
            },
            fontSize = 15.sp
        )
    }
}

@Composable
private fun DrawerValueRow(label: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Text(value, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DrawerSwitchRow(label: String, subtitle: String?, checked: Boolean, modifier: Modifier = Modifier, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(label, color = Color.White, fontSize = 14.sp)
            if (!subtitle.isNullOrBlank()) Text(subtitle, color = TiviColors.TextSecondary, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun DrawerRadioRow(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Spacer(Modifier.width(10.dp))
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}
