package com.tiviclone.iptv.ui.screens

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.BuildConfig
import com.tiviclone.iptv.TiviCloneApp
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.PlaylistEntity
import com.tiviclone.iptv.data.db.SeriesEntity
import com.tiviclone.iptv.data.db.VodMovieEntity
import com.tiviclone.iptv.data.repository.SettingsStore
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SettingsPage(val title: String) {
    ROOT("Settings"),
    GENERAL("General"),
    PLAYLISTS("Playlists"),
    PLAYLIST_DETAIL("Playlist"),
    PLAYLIST_MANAGE_GROUPS("Manage groups"),
    PLAYLIST_MANAGE_TV("TV"),
    PLAYLIST_MANAGE_MOVIES("Movies"),
    PLAYLIST_MANAGE_SERIES("Series"),
    EPG("EPG"),
    APPEARANCE("Appearance"),
    APP_TV_GUIDE("TV guide"),
    APP_TV_GUIDE_SORTING("Channels sorting"),
    APP_TV_GUIDE_PREVIEW("Preview"),
    APP_PLAYER("Player"),
    APP_PLAYER_CHANNELS_LIST("Channels list"),
    APP_PLAYER_INFO_PANEL("Info panel"),
    APP_PLAYER_HISTORY("History / Recent channels"),
    APP_PLAYER_CLOCK("Clock"),
    APP_GROUPS("Groups"),
    APP_GROUPS_SORTING("Groups sorting"),
    APP_LOGOS("Logos"),
    APP_LOGOS_PRIORITY("Logos priority"),
    APP_FONT_SIZE("Font size"),
    COLOR_THEME("Color theme"),
    PLAYBACK("Playback"),
    PLAYBACK_BUFFER("Buffer size"),
    PLAYBACK_AUDIO_DEC("Audio decoder"),
    PLAYBACK_VIDEO_DEC("Video decoder"),
    PLAYBACK_AFR("Auto frame rate (AFR)"),
    PLAYBACK_AMLOGIC("Amlogic fix"),
    PLAYBACK_EXTERNAL("Use external player"),
    PLAYBACK_SKIP("Skip steps"),
    REMOTE("Remote control"),
    REMOTE_TV_GUIDE("TV guide"),
    REMOTE_PLAYER("Player"),
    PARENTAL("Parental controls"),
    PARENTAL_PIN_METHOD("PIN input method"),
    PARENTAL_REQUIRE("Don't require PIN after unlocking"),
    OTHER("Other"),
    OTHER_SEARCH("Search"),
    OTHER_REMINDERS("Reminders"),
    OTHER_REMINDERS_DEFAULT("Default action"),
    OTHER_RECORDING("Recording"),
    OTHER_VOD("VOD"),
    ABOUT("About")
}

@Composable
fun TiviMateSettingsDrawer(
    playlists: List<PlaylistEntity>,
    channels: List<ChannelEntity> = emptyList(),
    movies: List<VodMovieEntity> = emptyList(),
    seriesList: List<SeriesEntity> = emptyList(),
    activePlaylistId: String,
    epgIntervalHours: Int,
    epgLastUpdated: Long,
    epgCount: Int = 0,
    onSelectPlaylist: (String) -> Unit,
    onTogglePlaylistEnabled: (String, Boolean) -> Unit,
    onAddPlaylist: () -> Unit,
    onEditPlaylist: (PlaylistEntity) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onSyncAll: () -> Unit,
    onUpdateEpgInterval: (Int) -> Unit,
    onSetParentalPin: (String) -> Unit,
    onThemeChanged: () -> Unit = {},
    onExportBackup: suspend () -> String,
    onRestoreBackup: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val settings = (context.applicationContext as TiviCloneApp).settingsStore
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var page by remember { mutableStateOf(SettingsPage.ROOT) }
    var inspectedPlaylistId by remember { mutableStateOf<String?>(null) }

    val drawerFocusRequester = remember { FocusRequester() }
    LaunchedEffect(page) { runCatching { drawerFocusRequester.requestFocus() } }

    fun parentOf(p: SettingsPage): SettingsPage = when (p) {
        SettingsPage.PLAYLIST_DETAIL -> SettingsPage.PLAYLISTS
        SettingsPage.PLAYLIST_MANAGE_GROUPS -> SettingsPage.PLAYLIST_DETAIL
        SettingsPage.PLAYLIST_MANAGE_TV, SettingsPage.PLAYLIST_MANAGE_MOVIES, SettingsPage.PLAYLIST_MANAGE_SERIES -> SettingsPage.PLAYLIST_MANAGE_GROUPS
        SettingsPage.APP_TV_GUIDE, SettingsPage.APP_PLAYER, SettingsPage.APP_GROUPS, SettingsPage.APP_LOGOS, SettingsPage.APP_FONT_SIZE, SettingsPage.COLOR_THEME -> SettingsPage.APPEARANCE
        SettingsPage.APP_TV_GUIDE_SORTING, SettingsPage.APP_TV_GUIDE_PREVIEW -> SettingsPage.APP_TV_GUIDE
        SettingsPage.APP_PLAYER_CHANNELS_LIST, SettingsPage.APP_PLAYER_INFO_PANEL, SettingsPage.APP_PLAYER_HISTORY, SettingsPage.APP_PLAYER_CLOCK -> SettingsPage.APP_PLAYER
        SettingsPage.APP_GROUPS_SORTING -> SettingsPage.APP_GROUPS
        SettingsPage.APP_LOGOS_PRIORITY -> SettingsPage.APP_LOGOS
        SettingsPage.PLAYBACK_BUFFER, SettingsPage.PLAYBACK_AUDIO_DEC, SettingsPage.PLAYBACK_VIDEO_DEC, SettingsPage.PLAYBACK_AFR, SettingsPage.PLAYBACK_AMLOGIC, SettingsPage.PLAYBACK_EXTERNAL, SettingsPage.PLAYBACK_SKIP -> SettingsPage.PLAYBACK
        SettingsPage.REMOTE_TV_GUIDE, SettingsPage.REMOTE_PLAYER -> SettingsPage.REMOTE
        SettingsPage.PARENTAL_PIN_METHOD, SettingsPage.PARENTAL_REQUIRE -> SettingsPage.PARENTAL
        SettingsPage.OTHER_SEARCH, SettingsPage.OTHER_REMINDERS, SettingsPage.OTHER_RECORDING, SettingsPage.OTHER_VOD -> SettingsPage.OTHER
        SettingsPage.OTHER_REMINDERS_DEFAULT -> SettingsPage.OTHER_REMINDERS
        else -> SettingsPage.ROOT
    }

    BackHandler(enabled = true) {
        if (page != SettingsPage.ROOT) page = parentOf(page) else onClose()
    }

    // General state
    var autoBoot by remember { mutableStateOf(settings.isAutoStartBoot()) }
    var autoWake by remember { mutableStateOf(settings.isAutoStartWake()) }
    var turnOnLast by remember { mutableStateOf(settings.isTurnOnLastChannel()) }
    var pipHome by remember { mutableStateOf(settings.isPipOnHome()) }
    var confirmExit by remember { mutableStateOf(settings.isConfirmExitBack()) }
    var userAgent by remember { mutableStateOf(settings.getUserAgent()) }
    var udpProxy by remember { mutableStateOf(settings.getUdpProxy()) }

    // EPG state
    var epgPastDays by remember { mutableIntStateOf(settings.getEpgPastDays()) }
    var storeEpgDesc by remember { mutableStateOf(settings.isStoreProgramDesc()) }
    var epgOnStart by remember { mutableStateOf(settings.isEpgUpdateOnStart()) }
    var epgOnChange by remember { mutableStateOf(settings.isEpgUpdateOnPlaylistChange()) }

    // Appearance state
    var tvPreview by remember { mutableStateOf(settings.isTvGuidePreview()) }
    var animPreview by remember { mutableStateOf(settings.isAnimatedTvGuidePreview()) }
    var autoPlayTvGuide by remember { mutableStateOf(settings.isAutoPlayOnTvGuide()) }
    var switchTimeout by remember { mutableIntStateOf(settings.getFullscreenSwitchTimeoutSec()) }
    var showChNum by remember { mutableStateOf(settings.isShowChannelNumbers()) }
    var hiCurCh by remember { mutableStateOf(settings.isHighlightCurrentChannel()) }
    var dimPast by remember { mutableStateOf(settings.isDimPastPrograms()) }
    var playerClock by remember { mutableStateOf(settings.isPlayerClockEnabled()) }
    var infoCardStyle by remember { mutableStateOf(settings.isInfoPanelCardStyle()) }
    var groupsSort by remember { mutableStateOf(settings.getGroupsSorting()) }
    var channelsSort by remember { mutableStateOf(settings.getChannelsSorting()) }
    var logosPriority by remember { mutableStateOf(settings.getLogosPriority()) }
    var inexactLogos by remember { mutableStateOf(settings.isInexactLogos()) }
    var bgTheme by remember { mutableStateOf(settings.getBackgroundTheme()) }
    var accentTheme by remember { mutableStateOf(settings.getAccentTheme()) }
    var fontSize by remember { mutableStateOf(settings.getFontSize()) }
    var transparency by remember { mutableIntStateOf(settings.getUiTransparency()) }

    // Playback state
    var bufferSize by remember { mutableStateOf(settings.getBufferSize()) }
    var audioDecoder by remember { mutableStateOf(settings.getAudioDecoder()) }
    var videoDecoder by remember { mutableStateOf(settings.getVideoDecoder()) }
    var afrEnabled by remember { mutableStateOf(settings.isAfrEnabled()) }
    var afrVod by remember { mutableStateOf(settings.isAfrForVod()) }
    var tunneled by remember { mutableStateOf(settings.isTunneledPlayback()) }
    var amlogicFix by remember { mutableStateOf(settings.isAmlogicFix()) }
    var surroundDef by remember { mutableStateOf(settings.isSurroundDefault()) }
    var passthrough by remember { mutableStateOf(settings.isAudioPassthrough()) }
    var extPlayer by remember { mutableStateOf(settings.getUseExternalPlayer()) }
    var skipFwd by remember { mutableIntStateOf(settings.getSkipForwardSec()) }
    var skipBwd by remember { mutableIntStateOf(settings.getSkipBackwardSec()) }

    // Remote state
    var rwFfCatchup by remember { mutableStateOf(settings.isRwFfInCatchup()) }
    var seekLR by remember { mutableStateOf(settings.isSeekLeftRight()) }
    var seekUD by remember { mutableStateOf(settings.isSeekUpDown()) }

    // Parental state
    var pinUnlockTimeout by remember { mutableStateOf(settings.getPinUnlockTimeout()) }
    var pinSettings by remember { mutableStateOf(settings.isPinForSettings()) }
    var pinPlaylists by remember { mutableStateOf(settings.isPinForPlaylists()) }
    var pinChOpts by remember { mutableStateOf(settings.isPinForChannelOptions()) }

    // Other state
    var recStartOffset by remember { mutableIntStateOf(settings.getRecordingStartOffsetMin()) }
    var recStopOffset by remember { mutableIntStateOf(settings.getRecordingStopOffsetMin()) }
    var remDefAction by remember { mutableStateOf(settings.getReminderDefaultAction()) }
    var remTimeout by remember { mutableIntStateOf(settings.getReminderPopupTimeoutSec()) }
    var autoNextEp by remember { mutableStateOf(settings.isAutoPlayNextEpisode()) }
    var favFirstSearch by remember { mutableStateOf(settings.isShowFavFirstSearch()) }
    var showSearchHist by remember { mutableStateOf(settings.isShowSearchHistory()) }

    // Dialog states
    var showPinDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var backupText by remember { mutableStateOf("") }
    var textEditDialog by remember { mutableStateOf<Triple<String, String, (String) -> Unit>?>(null) }
    var infoToastDialog by remember { mutableStateOf<Pair<String, String>?>(null) }

    val inspectedPlaylist = remember(playlists, inspectedPlaylistId) {
        playlists.firstOrNull { it.id == inspectedPlaylistId }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable { onClose() }
    ) {
        Column(
            modifier = Modifier
                .width(360.dp)
                .fillMaxHeight()
                .align(Alignment.CenterEnd)
                .background(TiviColors.PanelBg)
                .clickable(enabled = false) {}
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(TiviColors.SidebarBg)
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (page != SettingsPage.ROOT) {
                    IconButton(onClick = { page = parentOf(page) }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    if (page == SettingsPage.PLAYLIST_DETAIL) (inspectedPlaylist?.name ?: "Playlist") else page.title,
                    color = Color.White,
                    fontSize = 19.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            LazyColumn(modifier = Modifier.weight(1f).padding(vertical = 8.dp)) {
                when (page) {
                    SettingsPage.ROOT -> {
                        val entries = listOf(
                            SettingsPage.GENERAL,
                            SettingsPage.PLAYLISTS,
                            SettingsPage.EPG,
                            SettingsPage.APPEARANCE,
                            SettingsPage.PLAYBACK,
                            SettingsPage.REMOTE,
                            SettingsPage.PARENTAL,
                            SettingsPage.OTHER,
                            SettingsPage.ABOUT
                        )
                        items(entries) { item ->
                            DrawerMenuRow(
                                item.title,
                                modifier = if (item == SettingsPage.GENERAL) Modifier.focusRequester(drawerFocusRequester) else Modifier
                            ) { page = item }
                        }
                    }

                    SettingsPage.GENERAL -> {
                        item {
                            DrawerSwitchRow("Auto start app on boot", null, autoBoot, Modifier.focusRequester(drawerFocusRequester)) { autoBoot = it; settings.setAutoStartBoot(it) }
                            DrawerSwitchRow("Auto start app on wake up from sleep mode", "May not work on all devices", autoWake) { autoWake = it; settings.setAutoStartWake(it) }
                            DrawerSwitchRow("Turn on last channel on app start", null, turnOnLast) { turnOnLast = it; settings.setTurnOnLastChannel(it) }
                            DrawerSwitchRow("Switch to picture-in-picture mode on press Home", null, pipHome) { pipHome = it; settings.setPipOnHome(it) }
                            DrawerSwitchRow("Confirm exit by second press Back", null, confirmExit) { confirmExit = it; settings.setConfirmExitBack(it) }
                            DrawerValueRow("User-Agent", userAgent.ifBlank { "Not set" }) {
                                textEditDialog = Triple("User-Agent", userAgent) { userAgent = it; settings.setUserAgent(it) }
                            }
                            DrawerValueRow("UDP proxy (address:port)", udpProxy.ifBlank { "Not set" }) {
                                textEditDialog = Triple("UDP proxy (address:port)", udpProxy) { udpProxy = it; settings.setUdpProxy(it) }
                            }
                            DrawerMenuRow("Back up data") {
                                scope.launch {
                                    backupText = onExportBackup()
                                    clipboard.setText(AnnotatedString(backupText))
                                    showBackupDialog = true
                                }
                            }
                            DrawerMenuRow("Restore data") { backupText = ""; showBackupDialog = true }
                        }
                    }

                    SettingsPage.PLAYLISTS -> {
                        item {
                            DrawerMenuRow("+ Add playlist", highlight = true, modifier = Modifier.focusRequester(drawerFocusRequester)) {
                                onClose()
                                onAddPlaylist()
                            }
                            DrawerValueRow("Active view", if (activePlaylistId == "ALL") "All enabled playlists" else "Single playlist") {
                                onSelectPlaylist("ALL")
                            }
                            DrawerMenuRow("Update all playlists") { onSyncAll() }
                        }
                        items(playlists, key = { it.id }) { pl ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .tvFocusableBorder(4)
                                    .clickable {
                                        inspectedPlaylistId = pl.id
                                        page = SettingsPage.PLAYLIST_DETAIL
                                    }
                                    .padding(horizontal = 20.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(pl.name, color = if (pl.isEnabled) Color.White else TiviColors.TextSecondary, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${pl.type.name} • ${pl.channelsCount} ch • ${pl.moviesCount} mov • ${pl.seriesCount} shows", color = TiviColors.TextSecondary, fontSize = 11.sp)
                                }
                                Switch(checked = pl.isEnabled, onCheckedChange = { onTogglePlaylistEnabled(pl.id, it) })
                            }
                        }
                    }

                    SettingsPage.PLAYLIST_DETAIL -> {
                        val pl = inspectedPlaylist
                        if (pl != null) {
                            val expText = formatExpiry(pl.accountExpiry)
                            val paramTitle = when (pl.type.name) {
                                "XTREAM" -> "Xtream Codes parameters"
                                "STALKER" -> "Stalker Portal parameters"
                                else -> "Playlist URL & parameters"
                            }
                            item {
                                var plLogos by remember(pl.id) { mutableStateOf(settings.getStr("pl_logos_${pl.id}", "Global")) }
                                var plCatchup by remember(pl.id) { mutableStateOf(settings.getStr("pl_catchup_${pl.id}", "Auto")) }
                                var plUa by remember(pl.id) { mutableStateOf(settings.getStr("pl_ua_${pl.id}", "")) }
                                var plInt by remember(pl.id) { mutableIntStateOf(settings.getIntVal("pl_int_${pl.id}", 24)) }
                                DrawerSwitchRow("Enable playlist", null, pl.isEnabled, Modifier.focusRequester(drawerFocusRequester)) {
                                    onTogglePlaylistEnabled(pl.id, it)
                                }
                                DrawerMenuRow("Use only this playlist") { onSelectPlaylist(pl.id); onClose() }
                                DrawerMenuRow("Update playlist") { onSyncAll() }
                                StoredSwitchRow(settings, "pl_upd_start_${pl.id}", "Update on app start", false)
                                DrawerValueRow("Update interval, hours", "$plInt") {
                                    plInt = when (plInt) { 4 -> 12; 12 -> 24; else -> 4 }
                                    settings.setIntVal("pl_int_${pl.id}", plInt)
                                }
                                DrawerValueRow("Playlist name", pl.name) { onClose(); onEditPlaylist(pl) }
                                DrawerMenuRow(paramTitle, highlight = true) { onClose(); onEditPlaylist(pl) }
                                DrawerMenuRow("Manage groups") { page = SettingsPage.PLAYLIST_MANAGE_GROUPS }
                                DrawerValueRow("Catch-up", plCatchup) {
                                    plCatchup = when (plCatchup) { "Auto" -> "Xtream Codes"; "Xtream Codes" -> "Shift"; "Shift" -> "None"; else -> "Auto" }
                                    settings.setStr("pl_catchup_${pl.id}", plCatchup)
                                }
                                DrawerValueRow("Logos priority", plLogos) {
                                    plLogos = when (plLogos) { "Global" -> "Playlist"; "Playlist" -> "EPG"; "EPG" -> "Folder"; else -> "Global" }
                                    settings.setStr("pl_logos_${pl.id}", plLogos)
                                }
                                DrawerValueRow("User-Agent", plUa.ifBlank { "Default" }) {
                                    textEditDialog = Triple("Playlist User-Agent", plUa) { plUa = it; settings.setStr("pl_ua_${pl.id}", it) }
                                }
                                DrawerValueRow("Playlist type", pl.type.name) {}
                                DrawerValueRow("Server / URL", pl.primaryUrl) {}
                                if (pl.accountStatus.isNotBlank()) DrawerValueRow("Account status", pl.accountStatus) {}
                                DrawerValueRow("Expiration date", expText) {}
                                DrawerValueRow("Max connections", "${pl.activeConnections} / ${pl.maxConnections}") {}
                                DrawerValueRow("Output format", pl.outputFormat) {}
                                DrawerValueRow("Include VOD", if (pl.includeVod) "Yes" else "No") {}
                                DrawerValueRow("Processed items", "${pl.channelsCount} channels, ${pl.moviesCount} movies, ${pl.seriesCount} shows") {}
                                DrawerMenuRow("Delete playlist", danger = true) { onDeletePlaylist(pl.id); page = SettingsPage.PLAYLISTS }
                            }
                        }
                    }

                    SettingsPage.PLAYLIST_MANAGE_GROUPS -> {
                        item {
                            DrawerMenuRow("TV", Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.PLAYLIST_MANAGE_TV }
                            DrawerMenuRow("Movies") { page = SettingsPage.PLAYLIST_MANAGE_MOVIES }
                            DrawerMenuRow("Series") { page = SettingsPage.PLAYLIST_MANAGE_SERIES }
                        }
                    }

                    SettingsPage.PLAYLIST_MANAGE_TV,
                    SettingsPage.PLAYLIST_MANAGE_MOVIES,
                    SettingsPage.PLAYLIST_MANAGE_SERIES -> {
                        val pl = inspectedPlaylist
                        if (pl != null) {
                            val typeKey = when (page) {
                                SettingsPage.PLAYLIST_MANAGE_TV -> "TV"
                                SettingsPage.PLAYLIST_MANAGE_MOVIES -> "MOVIES"
                                else -> "SERIES"
                            }
                            item {
                                val plGroups = remember(channels, movies, seriesList, pl.id, typeKey) {
                                    when (typeKey) {
                                        "TV" -> channels.filter { it.playlistId == pl.id }.map { it.groupName }.distinct()
                                        "MOVIES" -> movies.filter { it.playlistId == pl.id }.map { it.categoryName }.distinct()
                                        else -> seriesList.filter { it.playlistId == pl.id }.map { it.categoryName }.distinct()
                                    }
                                }
                                var hiddenSet by remember(pl.id, typeKey) { mutableStateOf(settings.getHiddenGroupsForType(pl.id, typeKey)) }
                                DrawerMenuRow("Show all groups", highlight = true, modifier = Modifier.focusRequester(drawerFocusRequester)) {
                                    settings.setAllGroupsHiddenForType(pl.id, typeKey, plGroups, false)
                                    hiddenSet = emptySet()
                                }
                                DrawerMenuRow("Hide all groups", danger = true) {
                                    settings.setAllGroupsHiddenForType(pl.id, typeKey, plGroups, true)
                                    hiddenSet = plGroups.toSet()
                                }
                                DrawerCategoryHeader("${page.title} groups (${plGroups.size})")
                                plGroups.forEach { grp ->
                                    val visible = grp !in hiddenSet
                                    DrawerSwitchRow(grp, null, visible) { show ->
                                        settings.setGroupHiddenForType(pl.id, typeKey, grp, !show)
                                        hiddenSet = settings.getHiddenGroupsForType(pl.id, typeKey)
                                    }
                                }
                            }
                        }
                    }

                    SettingsPage.EPG -> {
                        val lastStr = if (epgLastUpdated <= 0L) "—"
                        else SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(epgLastUpdated))
                        item {
                            DrawerMenuRow("EPG sources", modifier = Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.PLAYLISTS }
                            DrawerValueRow("Past days to keep EPG", "$epgPastDays") {
                                val next = when (epgPastDays) { 3 -> 7; 7 -> 14; else -> 3 }
                                epgPastDays = next; settings.setEpgPastDays(next)
                            }
                            DrawerSwitchRow("Store program descriptions", null, storeEpgDesc) { storeEpgDesc = it; settings.setStoreProgramDesc(it) }
                            DrawerCategoryHeader("Update options")
                            DrawerValueRow("Update interval, hours", "$epgIntervalHours") {
                                val next = when (epgIntervalHours) { 4 -> 12; 12 -> 24; else -> 4 }
                                onUpdateEpgInterval(next)
                            }
                            DrawerSwitchRow("Update on app start", null, epgOnStart) { epgOnStart = it; settings.setEpgUpdateOnStart(it) }
                            DrawerSwitchRow("Update on playlists change", null, epgOnChange) { epgOnChange = it; settings.setEpgUpdateOnPlaylistChange(it) }
                            DrawerMenuRow("Update EPG") { onSyncAll() }
                            DrawerValueRow("Latest update status", "$lastStr • $epgCount programs") {}
                            DrawerValueRow("Total EPG programs", "$epgCount") {}
                        }
                    }

                    SettingsPage.APPEARANCE -> {
                        item {
                            DrawerMenuRow("TV guide", modifier = Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.APP_TV_GUIDE }
                            DrawerMenuRow("Player") { page = SettingsPage.APP_PLAYER }
                            DrawerMenuRow("Groups") { page = SettingsPage.APP_GROUPS }
                            DrawerMenuRow("Logos") { page = SettingsPage.APP_LOGOS }
                            DrawerValueRow("Language", settings.getStr("app_language", "System")) {
                                val next = if (settings.getStr("app_language", "System") == "System") "English" else "System"
                                settings.setStr("app_language", next)
                            }
                            DrawerValueRow("Font size", fontSize) { page = SettingsPage.APP_FONT_SIZE }
                            DrawerValueRow("Color theme", "$bgTheme • $accentTheme") { page = SettingsPage.COLOR_THEME }
                            DrawerValueRow("User interface transparency, %", "$transparency") {
                                val next = (transparency + 25) % 100
                                transparency = next; settings.setUiTransparency(next)
                            }
                        }
                    }

                    SettingsPage.APP_TV_GUIDE -> {
                        item {
                            DrawerValueRow("Channels sorting", channelsSort, Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.APP_TV_GUIDE_SORTING }
                            DrawerValueRow("Preview", if (tvPreview) "On" else "Off") { page = SettingsPage.APP_TV_GUIDE_PREVIEW }
                            DrawerMenuRow("Channel names editor") { infoToastDialog = "Channel names editor" to "Use long-press on any channel row to rename or assign EPG." }
                            DrawerSwitchRow("Show channel numbers", null, showChNum) { showChNum = it; settings.setShowChannelNumbers(it) }
                            StoredSwitchRow(settings, "show_channel_names", "Show channel names", true)
                            StoredSwitchRow(settings, "two_line_channel_titles", "Two-line channel titles", false)
                            StoredSwitchRow(settings, "show_catchup_icon", "Show catch-up icon in channels list", true)
                            DrawerSwitchRow("Highlight current channel in color", null, hiCurCh) { hiCurCh = it; settings.setHighlightCurrentChannel(it) }
                            StoredSwitchRow(settings, "two_line_program_titles", "Two-line program titles", false)
                            StoredSwitchRow(settings, "highlight_current_programs", "Highlight current programs", true)
                            StoredSwitchRow(settings, "highlight_progress_only", "Highlight progress only", true)
                            StoredSwitchRow(settings, "show_time_indicator", "Show current time indicator", true)
                            StoredSwitchRow(settings, "animated_channels_scroll", "Animated channels scrolling", true)
                            StoredSwitchRow(settings, "stay_on_channels_list", "Stay on TV guide when switching channels in overlay mode", false)
                            StoredSwitchRow(settings, "back_quick_return", "Use Back to return to current programs", true)
                        }
                    }

                    SettingsPage.APP_TV_GUIDE_SORTING -> {
                        item {
                            listOf("By playlist order", "By name", "By date added", "By watch time").forEachIndexed { idx, opt ->
                                val cleanVal = opt.removePrefix("By ").replaceFirstChar { it.uppercase() }
                                DrawerRadioRow(
                                    opt,
                                    channelsSort.equals(cleanVal, ignoreCase = true) || channelsSort == opt,
                                    if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier
                                ) {
                                    channelsSort = opt
                                    settings.setChannelsSorting(opt)
                                }
                            }
                            StoredSwitchRow(settings, "show_fav_ch_first", "Show favorite channels first", false)
                            StoredSwitchRow(settings, "group_by_playlists_all", "Group channels by playlists in \"All playlists\"", true)
                            DrawerMenuRow("Reset watch time") { infoToastDialog = "Watch time" to "Channel watch time counters reset." }
                            DrawerHintRow("This setting sets global sorting for all groups. You can override sorting method for individual groups in group options.")
                        }
                    }

                    SettingsPage.APP_TV_GUIDE_PREVIEW -> {
                        item {
                            DrawerSwitchRow("Enable preview", null, tvPreview, Modifier.focusRequester(drawerFocusRequester)) { tvPreview = it; settings.setTvGuidePreview(it) }
                            DrawerSwitchRow("Animated transition", null, animPreview) { animPreview = it; settings.setAnimatedTvGuidePreview(it) }
                            DrawerSwitchRow("Auto-play channels", null, autoPlayTvGuide) { autoPlayTvGuide = it; settings.setAutoPlayOnTvGuide(it) }
                            StoredSwitchRow(settings, "stay_tv_guide_preview", "Stay on TV guide when switching channels", true)
                            DrawerValueRow("Full screen switching timeout, sec", "$switchTimeout") {
                                val next = when (switchTimeout) { 3 -> 5; 5 -> 10; else -> 3 }
                                switchTimeout = next; settings.setFullscreenSwitchTimeoutSec(next)
                            }
                        }
                    }

                    SettingsPage.APP_PLAYER -> {
                        item {
                            DrawerMenuRow("Channels list", Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.APP_PLAYER_CHANNELS_LIST }
                            DrawerMenuRow("Info panel") { page = SettingsPage.APP_PLAYER_INFO_PANEL }
                            DrawerMenuRow("History / Recent channels") { page = SettingsPage.APP_PLAYER_HISTORY }
                            DrawerMenuRow("Menu") { infoToastDialog = "Player Menu" to "Customize bottom circular player action bar from Fullscreen (Hold)." }
                            DrawerValueRow("Clock", if (playerClock) "On" else "Off") { page = SettingsPage.APP_PLAYER_CLOCK }
                            DrawerValueRow("Panels timeout, sec", "${settings.getIntVal("player_panels_timeout", 5)}") {
                                val cur = settings.getIntVal("player_panels_timeout", 5)
                                settings.setIntVal("player_panels_timeout", if (cur == 5) 10 else if (cur == 10) 15 else 5)
                            }
                            StoredSwitchRow(settings, "show_black_screen_switch", "Show black screen when switching channels", false)
                        }
                    }

                    SettingsPage.APP_PLAYER_CHANNELS_LIST -> {
                        item {
                            StoredSwitchRow(settings, "pl_hi_cur_prog", "Highlight current programs in color", true, Modifier.focusRequester(drawerFocusRequester))
                            DrawerSwitchRow("Dim past programs", null, dimPast) { dimPast = it; settings.setDimPastPrograms(it) }
                            DrawerCategoryHeader("Overlay mode")
                            StoredSwitchRow(settings, "pl_ov_show_prog", "Show programs", true)
                            StoredSwitchRow(settings, "pl_ov_show_desc", "Show program description", true)
                            StoredSwitchRow(settings, "pl_ov_autoplay", "Auto-play channels", false)
                            StoredSwitchRow(settings, "pl_ov_stay", "Stay on list when switching channels", false)
                            DrawerCategoryHeader("Preview mode")
                            StoredSwitchRow(settings, "pl_pv_anim", "Animated transition", true)
                            StoredSwitchRow(settings, "pl_pv_autoplay", "Auto-play channels", false)
                            StoredSwitchRow(settings, "pl_pv_stay", "Stay on list when switching channels", true)
                        }
                    }

                    SettingsPage.APP_PLAYER_INFO_PANEL -> {
                        item {
                            DrawerSwitchRow("Card style", null, infoCardStyle, Modifier.focusRequester(drawerFocusRequester)) { infoCardStyle = it; settings.setInfoPanelCardStyle(it) }
                            StoredSwitchRow(settings, "info_panel_bottom", "Show info panel at bottom when switching channels", false)
                            StoredSwitchRow(settings, "info_panel_clock", "Show clock", true)
                            StoredSwitchRow(settings, "info_panel_clock_date", "Show date on clock", true)
                            StoredSwitchRow(settings, "info_panel_pl_group", "Show playlist and group name", true)
                            StoredSwitchRow(settings, "info_panel_desc", "Show program description", true)
                            StoredSwitchRow(settings, "info_panel_desc_switch_only", "Show description when switching channels only", true)
                            StoredSwitchRow(settings, "info_panel_media_props", "Show media properties", true)
                            StoredSwitchRow(settings, "info_panel_video_res", "Show video resolution instead of labels", false, subtitle = "e.g. \"1920x1080\" instead of \"FHD\"")
                        }
                    }

                    SettingsPage.APP_PLAYER_HISTORY -> {
                        item {
                            StoredSwitchRow(settings, "show_tv_guide_btn", "Show \"TV guide\" button", true, Modifier.focusRequester(drawerFocusRequester))
                            StoredSwitchRow(settings, "show_history_btn", "Show \"History\" button", true)
                            DrawerCategoryHeader("History")
                            DrawerValueRow("History day count", "${settings.getIntVal("history_day_count", 7)}") {
                                val v = settings.getIntVal("history_day_count", 7)
                                settings.setIntVal("history_day_count", if (v == 7) 14 else 7)
                            }
                            DrawerValueRow("Delay before adding to history, sec", "${settings.getIntVal("history_delay_sec", 5)}") {
                                val v = settings.getIntVal("history_delay_sec", 5)
                                settings.setIntVal("history_delay_sec", if (v == 5) 10 else 5)
                            }
                            StoredSwitchRow(settings, "show_cur_prog_history", "Show current programs in history", true)
                            StoredSwitchRow(settings, "show_past_no_catchup_history", "Show past programs without catch-up", false)
                            DrawerCategoryHeader("Recent channels")
                            DrawerValueRow("Recent channel count", "${settings.getIntVal("recent_ch_count", 15)}") {
                                val v = settings.getIntVal("recent_ch_count", 15)
                                settings.setIntVal("recent_ch_count", if (v == 15) 30 else 15)
                            }
                            DrawerValueRow("Delay before adding to recent channels, sec", "${settings.getIntVal("recent_delay_sec", 3)}") {
                                val v = settings.getIntVal("recent_delay_sec", 3)
                                settings.setIntVal("recent_delay_sec", if (v == 3) 5 else 3)
                            }
                            StoredSwitchRow(settings, "show_ch_names_recent", "Show channel names", false)
                        }
                    }

                    SettingsPage.APP_PLAYER_CLOCK -> {
                        item {
                            var pos by remember { mutableStateOf(settings.getStr("clock_pos", "Top right")) }
                            var sz by remember { mutableStateOf(settings.getStr("clock_size", "Medium")) }
                            var tr by remember { mutableStateOf(settings.getStr("clock_transp", "Low")) }
                            DrawerSwitchRow("Enable clock", null, playerClock, Modifier.focusRequester(drawerFocusRequester)) { playerClock = it; settings.setPlayerClockEnabled(it) }
                            DrawerValueRow("Position", pos) {
                                pos = when (pos) { "Top right" -> "Top left"; "Top left" -> "Bottom left"; "Bottom left" -> "Bottom right"; else -> "Top right" }
                                settings.setStr("clock_pos", pos)
                            }
                            DrawerValueRow("Size", sz) {
                                sz = when (sz) { "Small" -> "Medium"; "Medium" -> "Large"; else -> "Small" }
                                settings.setStr("clock_size", sz)
                            }
                            DrawerValueRow("Transparency", tr) {
                                tr = when (tr) { "No" -> "Low"; "Low" -> "Medium"; "Medium" -> "High"; else -> "No" }
                                settings.setStr("clock_transp", tr)
                            }
                        }
                    }

                    SettingsPage.APP_GROUPS -> {
                        item {
                            DrawerValueRow("Groups sorting", groupsSort, Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.APP_GROUPS_SORTING }
                            StoredSwitchRow(settings, "show_all_playlists_cat", "Show \"All playlists\" category", true)
                            StoredSwitchRow(settings, "show_favorites_cat", "Show \"Favorites\" category", true)
                            StoredSwitchRow(settings, "show_all_channels_cat", "Show \"All channels\" category", true)
                        }
                    }

                    SettingsPage.APP_GROUPS_SORTING -> {
                        item {
                            DrawerRadioRow("By playlist order", groupsSort == "Playlist order" || groupsSort == "By playlist order", Modifier.focusRequester(drawerFocusRequester)) {
                                groupsSort = "Playlist order"; settings.setGroupsSorting("Playlist order")
                            }
                            DrawerRadioRow("By name", groupsSort == "By name") {
                                groupsSort = "By name"; settings.setGroupsSorting("By name")
                            }
                            DrawerHintRow("This setting sets global sorting for all playlists. You can override sorting method for individual playlists in playlist settings.")
                        }
                    }

                    SettingsPage.APP_LOGOS -> {
                        item {
                            DrawerValueRow("Logos priority", logosPriority, Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.APP_LOGOS_PRIORITY }
                            DrawerValueRow("Logos folder", settings.getStr("logos_folder", "Not set")) {
                                textEditDialog = Triple("Logos folder", settings.getStr("logos_folder", "")) { settings.setStr("logos_folder", it) }
                            }
                            DrawerSwitchRow("Inexact matching for logo files", null, inexactLogos) { inexactLogos = it; settings.setInexactLogos(it) }
                            DrawerMenuRow("Clear logos cache") { infoToastDialog = "Logos cache" to "Channel logos cache cleared." }
                        }
                    }

                    SettingsPage.APP_LOGOS_PRIORITY -> {
                        item {
                            listOf("Prefer logos from playlist", "Prefer logos from EPG", "Prefer logos from folder").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, logosPriority == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    logosPriority = opt; settings.setLogosPriority(opt)
                                }
                            }
                            DrawerHintRow("Select whether to prefer logos specified in playlists, logos from local folder, or logos specified in EPG.")
                        }
                    }

                    SettingsPage.APP_FONT_SIZE -> {
                        item {
                            listOf("Small", "Medium", "Large", "Very large").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, fontSize == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    fontSize = opt; settings.setFontSize(opt)
                                }
                            }
                        }
                    }

                    SettingsPage.COLOR_THEME -> {
                        item {
                            DrawerCategoryHeader("Background color")
                            listOf("Dark", "AMOLED Black", "Slate", "Deep Navy").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, bgTheme == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    bgTheme = opt; settings.setBackgroundTheme(opt); onThemeChanged()
                                }
                            }
                            DrawerCategoryHeader("Accent color")
                            listOf("Blue", "Teal", "Purple", "Amber", "Green", "Red").forEach { opt ->
                                DrawerRadioRow(opt, accentTheme == opt) {
                                    accentTheme = opt; settings.setAccentTheme(opt); onThemeChanged()
                                }
                            }
                        }
                    }

                    SettingsPage.PLAYBACK -> {
                        item {
                            DrawerValueRow("Buffer size", bufferSize, Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.PLAYBACK_BUFFER }
                            DrawerValueRow("Audio decoder", audioDecoder) { page = SettingsPage.PLAYBACK_AUDIO_DEC }
                            DrawerValueRow("Video decoder", videoDecoder) { page = SettingsPage.PLAYBACK_VIDEO_DEC }
                            DrawerValueRow("Auto frame rate (AFR)", if (afrEnabled) "On" else "Off") { page = SettingsPage.PLAYBACK_AFR }
                            DrawerSwitchRow("Select surround audio track by default", null, surroundDef) { surroundDef = it; settings.setSurroundDefault(it) }
                            DrawerSwitchRow("Audio passthrough", null, passthrough) { passthrough = it; settings.setAudioPassthrough(it) }
                            DrawerSwitchRow("Tunneled playback", null, tunneled) { tunneled = it; settings.setTunneledPlayback(it) }
                            DrawerValueRow("Amlogic fix", if (amlogicFix) "On" else "Off") { page = SettingsPage.PLAYBACK_AMLOGIC }
                            DrawerValueRow("Use external player", extPlayer) { page = SettingsPage.PLAYBACK_EXTERNAL }
                            DrawerValueRow("Skip steps", "-${skipBwd}s / +${skipFwd}s") { page = SettingsPage.PLAYBACK_SKIP }
                        }
                    }

                    SettingsPage.PLAYBACK_BUFFER -> {
                        item {
                            listOf("None", "Small", "Medium", "Large", "Very large").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, bufferSize == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    bufferSize = opt; settings.setBufferSize(opt)
                                }
                            }
                            DrawerHintRow("Buffer size determines video duration downloaded before playback starts. Increase if you experience frequent buffering.")
                        }
                    }

                    SettingsPage.PLAYBACK_AUDIO_DEC -> {
                        item {
                            listOf("Hardware", "Software (FFmpeg)").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, audioDecoder == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    audioDecoder = opt; settings.setAudioDecoder(opt)
                                }
                            }
                            DrawerHintRow("Try software audio decoder if your device has issues decoding audio using hardware decoder.")
                        }
                    }

                    SettingsPage.PLAYBACK_VIDEO_DEC -> {
                        item {
                            listOf("Hardware", "Software").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, videoDecoder == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    videoDecoder = opt; settings.setVideoDecoder(opt)
                                }
                            }
                            DrawerHintRow("Try software video decoder if your device has issues decoding video using hardware decoder.")
                        }
                    }

                    SettingsPage.PLAYBACK_AFR -> {
                        item {
                            DrawerSwitchRow("Enable for TV", null, afrEnabled, Modifier.focusRequester(drawerFocusRequester)) { afrEnabled = it; settings.setAfrEnabled(it) }
                            DrawerSwitchRow("Enable for VOD", null, afrVod) { afrVod = it; settings.setAfrForVod(it) }
                            StoredSwitchRow(settings, "afr_refresh_rate", "Switch screen refresh rate", true)
                            StoredSwitchRow(settings, "afr_high_fps_only", "Switch rate for 50/60 FPS only", false)
                            StoredSwitchRow(settings, "afr_resolution", "Switch screen resolution", false)
                            DrawerValueRow("Delay before switching, sec", "${settings.getIntVal("afr_delay_sec", 0)}") {
                                val v = settings.getIntVal("afr_delay_sec", 0)
                                settings.setIntVal("afr_delay_sec", if (v == 0) 2 else if (v == 2) 5 else 0)
                            }
                            DrawerHintRow("Enable this setting to switch TV refresh rate to match video frame rate for smoother playback.")
                        }
                    }

                    SettingsPage.PLAYBACK_AMLOGIC -> {
                        item {
                            DrawerSwitchRow("Enable Amlogic fix", null, amlogicFix, Modifier.focusRequester(drawerFocusRequester)) { amlogicFix = it; settings.setAmlogicFix(it) }
                            DrawerHintRow("Some Amlogic-based devices may have poor picture quality during playback (stuttering, freezing). Enabling this may improve playback.")
                        }
                    }

                    SettingsPage.PLAYBACK_EXTERNAL -> {
                        item {
                            listOf("Yes", "No", "For VOD only").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, extPlayer == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    extPlayer = opt; settings.setUseExternalPlayer(opt)
                                }
                            }
                        }
                    }

                    SettingsPage.PLAYBACK_SKIP -> {
                        item {
                            DrawerValueRow("Time bar (backward), sec", "$skipBwd", Modifier.focusRequester(drawerFocusRequester)) {
                                skipBwd = when (skipBwd) { 10 -> 20; 20 -> 30; 30 -> 60; else -> 10 }
                                settings.setSkipBackwardSec(skipBwd)
                            }
                            DrawerValueRow("Time bar (forward), sec", "$skipFwd") {
                                skipFwd = when (skipFwd) { 10 -> 30; 30 -> 60; 60 -> 120; else -> 10 }
                                settings.setSkipForwardSec(skipFwd)
                            }
                            DrawerValueRow("Rewind button, sec", "${settings.getIntVal("skip_rw_sec", 10)}") {
                                val v = settings.getIntVal("skip_rw_sec", 10)
                                settings.setIntVal("skip_rw_sec", if (v == 10) 30 else 10)
                            }
                            DrawerValueRow("Fast forward button, sec", "${settings.getIntVal("skip_ff_sec", 30)}") {
                                val v = settings.getIntVal("skip_ff_sec", 30)
                                settings.setIntVal("skip_ff_sec", if (v == 30) 60 else 30)
                            }
                        }
                    }

                    SettingsPage.REMOTE -> {
                        item {
                            DrawerMenuRow("TV guide", Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.REMOTE_TV_GUIDE }
                            DrawerMenuRow("Player") { page = SettingsPage.REMOTE_PLAYER }
                            DrawerCategoryHeader("Seek options")
                            DrawerSwitchRow("Use RW/FF/Pause for seeking/pausing while watching catch-up", null, rwFfCatchup) { rwFfCatchup = it; settings.setRwFfInCatchup(it) }
                            StoredSwitchRow(settings, "use_rw_in_live", "Use RW to rewind live stream with catch-up", false)
                            DrawerSwitchRow("Use Left/Right for seeking while watching catch-up", null, seekLR) { seekLR = it; settings.setSeekLeftRight(it) }
                            StoredSwitchRow(settings, "use_left_in_live", "Use Left to rewind live stream with catch-up", false)
                            DrawerSwitchRow("Use Down/Up for seeking while watching catch-up", null, seekUD) { seekUD = it; settings.setSeekUpDown(it) }
                            StoredSwitchRow(settings, "use_down_in_live", "Use Down to rewind live stream with catch-up", false)
                        }
                    }

                    SettingsPage.REMOTE_TV_GUIDE -> {
                        val keys = listOf(
                            "OK" to "Select / Play", "Long OK" to "Channel options",
                            "Back" to "Previous level", "Long Back" to "Exit / Return",
                            "Left" to "Groups", "Right" to "Programs",
                            "Pg+ (Ch+)" to "Page up", "Pg- (Ch-)" to "Page down",
                            "Menu" to "Channel options", "Long Menu" to "Settings",
                            "Play/Pause" to "Play / Pause", "Record" to "Record",
                            "Info" to "Program info", "Guide" to "TV guide"
                        )
                        items(keys) { (btn, def) ->
                            var act by remember(btn) { mutableStateOf(settings.getRemoteAction("tvg_$btn", def)) }
                            DrawerValueRow(btn, act) {
                                val opts = listOf("Select / Play", "Channel options", "Settings", "Groups", "TV guide", "Record", "Search", "None")
                                val next = opts[(opts.indexOf(act) + 1) % opts.size]
                                act = next; settings.setRemoteAction("tvg_$btn", next)
                            }
                        }
                        item {
                            DrawerMenuRow("Restore to defaults", danger = true) {
                                keys.forEach { (b, d) -> settings.setRemoteAction("tvg_$b", d) }
                                page = SettingsPage.REMOTE
                            }
                        }
                    }

                    SettingsPage.REMOTE_PLAYER -> {
                        val keys = listOf(
                            "OK" to "Channels list", "Long OK" to "Player menu",
                            "Back" to "TV guide", "Long Back" to "Close player",
                            "Left" to "Channels list", "Right" to "Recent channels",
                            "Up" to "Next channel", "Down" to "Previous channel",
                            "Pg+ (Ch+)" to "Channel +", "Pg- (Ch-)" to "Channel -",
                            "Menu" to "Player menu", "Play/Pause" to "Play / Pause",
                            "Record" to "Record", "Info" to "Info panel", "Guide" to "TV guide"
                        )
                        items(keys) { (btn, def) ->
                            var act by remember(btn) { mutableStateOf(settings.getRemoteAction("ply_$btn", def)) }
                            DrawerValueRow(btn, act) {
                                val opts = listOf("Channels list", "Player menu", "Next channel", "Previous channel", "TV guide", "Info panel", "Record", "Multiview", "None")
                                val next = opts[(opts.indexOf(act) + 1) % opts.size]
                                act = next; settings.setRemoteAction("ply_$btn", next)
                            }
                        }
                        item {
                            DrawerMenuRow("Restore to defaults", danger = true) {
                                keys.forEach { (b, d) -> settings.setRemoteAction("ply_$b", d) }
                                page = SettingsPage.REMOTE
                            }
                        }
                    }

                    SettingsPage.PARENTAL -> {
                        val pinSet = settings.getParentalPin().isNotBlank()
                        item {
                            DrawerSwitchRow("Enable parental controls", null, pinSet, Modifier.focusRequester(drawerFocusRequester)) { enabled ->
                                if (enabled) showPinDialog = true else onSetParentalPin("")
                            }
                            DrawerMenuRow("Change PIN") { showPinDialog = true }
                            DrawerValueRow("PIN input method", settings.getStr("pin_input_method", "Keyboard")) { page = SettingsPage.PARENTAL_PIN_METHOD }
                            DrawerValueRow("Don't require PIN after unlocking", pinUnlockTimeout) { page = SettingsPage.PARENTAL_REQUIRE }
                            StoredSwitchRow(settings, "pin_dont_req_ch_only", "Don't require for channels only", false)
                            DrawerCategoryHeader("Require PIN for")
                            DrawerSwitchRow("Settings", null, pinSettings) { pinSettings = it; settings.setPinForSettings(it) }
                            DrawerSwitchRow("Playlists", null, pinPlaylists) { pinPlaylists = it; settings.setPinForPlaylists(it) }
                            StoredSwitchRow(settings, "pin_for_epg", "EPG", false)
                            DrawerSwitchRow("Channel options", null, pinChOpts) { pinChOpts = it; settings.setPinForChannelOptions(it) }
                            StoredSwitchRow(settings, "pin_for_group_opts", "Group options", false)
                        }
                    }

                    SettingsPage.PARENTAL_PIN_METHOD -> {
                        item {
                            var m by remember { mutableStateOf(settings.getStr("pin_input_method", "Keyboard")) }
                            listOf("Picker", "Keyboard").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, m == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    m = opt; settings.setStr("pin_input_method", opt)
                                }
                            }
                        }
                    }

                    SettingsPage.PARENTAL_REQUIRE -> {
                        item {
                            listOf("Always require", "Until next app start", "Until switching to not blocked channel", "During 10 min", "During 30 min", "During 1 h", "During 2 h").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, pinUnlockTimeout == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    pinUnlockTimeout = opt; settings.setPinUnlockTimeout(opt)
                                }
                            }
                        }
                    }

                    SettingsPage.OTHER -> {
                        item {
                            DrawerMenuRow("Search", Modifier.focusRequester(drawerFocusRequester)) { page = SettingsPage.OTHER_SEARCH }
                            DrawerMenuRow("Reminders") { page = SettingsPage.OTHER_REMINDERS }
                            DrawerMenuRow("Recording") { page = SettingsPage.OTHER_RECORDING }
                            DrawerMenuRow("VOD") { page = SettingsPage.OTHER_VOD }
                        }
                    }

                    SettingsPage.OTHER_SEARCH -> {
                        item {
                            StoredSwitchRow(settings, "prefer_voice_search", "Prefer voice search", true, Modifier.focusRequester(drawerFocusRequester))
                            DrawerSwitchRow("Show search history", null, showSearchHist) { showSearchHist = it; settings.setShowSearchHistory(it) }
                            DrawerSwitchRow("Show favorite channels first", null, favFirstSearch) { favFirstSearch = it; settings.setShowFavFirstSearch(it) }
                            StoredSwitchRow(settings, "search_past_no_catchup", "Show past programs without catch-up", false)
                            StoredSwitchRow(settings, "stay_on_search", "Stay on search screen when switching channels", false)
                        }
                    }

                    SettingsPage.OTHER_REMINDERS -> {
                        item {
                            DrawerValueRow("Remind before program start, min", "${settings.getIntVal("rem_before_min", 1)}", Modifier.focusRequester(drawerFocusRequester)) {
                                val v = settings.getIntVal("rem_before_min", 1)
                                settings.setIntVal("rem_before_min", if (v == 1) 5 else if (v == 5) 10 else 1)
                            }
                            DrawerValueRow("Popup timeout, sec", "$remTimeout") {
                                remTimeout = when (remTimeout) { 10 -> 15; 15 -> 30; else -> 10 }
                                settings.setReminderPopupTimeoutSec(remTimeout)
                            }
                            DrawerValueRow("Default action", remDefAction) { page = SettingsPage.OTHER_REMINDERS_DEFAULT }
                            StoredSwitchRow(settings, "wake_up_on_reminder", "Wake up from sleep mode", false, subtitle = "May not work on all devices")
                        }
                    }

                    SettingsPage.OTHER_REMINDERS_DEFAULT -> {
                        item {
                            listOf("Watch", "Watch later", "Dismiss").forEachIndexed { idx, opt ->
                                DrawerRadioRow(opt, remDefAction == opt, if (idx == 0) Modifier.focusRequester(drawerFocusRequester) else Modifier) {
                                    remDefAction = opt; settings.setReminderDefaultAction(opt)
                                }
                            }
                        }
                    }

                    SettingsPage.OTHER_RECORDING -> {
                        item {
                            DrawerValueRow("Recordings folder", "App Movies/TiviMate_Recordings", Modifier.focusRequester(drawerFocusRequester)) {}
                            DrawerValueRow("Start recording before program start, min", "$recStartOffset") {
                                recStartOffset = (recStartOffset + 2) % 12; settings.setRecordingStartOffsetMin(recStartOffset)
                            }
                            DrawerValueRow("Stop recording after program end, min", "$recStopOffset") {
                                recStopOffset = (recStopOffset + 5) % 20; settings.setRecordingStopOffsetMin(recStopOffset)
                            }
                        }
                    }

                    SettingsPage.OTHER_VOD -> {
                        item {
                            DrawerSwitchRow("Auto-play next episode", null, autoNextEp, Modifier.focusRequester(drawerFocusRequester)) {
                                autoNextEp = it; settings.setAutoPlayNextEpisode(it)
                            }
                        }
                    }

                    SettingsPage.ABOUT -> {
                        item {
                            StoredSwitchRow(settings, "send_anon_stats", "Send anonymous statistics", true, Modifier.focusRequester(drawerFocusRequester))
                            StoredSwitchRow(settings, "auto_update_app", "Auto update app", true)
                            StoredSwitchRow(settings, "join_beta", "Join Beta testing", false)
                            DrawerMenuRow("Check for new version") { infoToastDialog = "Version" to "You are using v${BuildConfig.VERSION_NAME}." }
                            DrawerMenuRow("Send logs") { infoToastDialog = "Logs" to "Local diagnostics ready." }
                            DrawerMenuRow("Terms of use") { infoToastDialog = "Terms of use" to "User-provided playlists only. No built-in streams." }
                            DrawerMenuRow("Privacy policy") { infoToastDialog = "Privacy policy" to "All playlists and settings are stored locally on your device." }
                            DrawerValueRow("Device name", "${Build.MANUFACTURER} ${Build.MODEL}") {}
                            DrawerValueRow("Version", BuildConfig.VERSION_NAME) {}
                        }
                    }
                }
            }
        }
    }

    if (showPinDialog) {
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            title = { Text("Set Parental PIN") },
            text = { OutlinedTextField(value = pin, onValueChange = { pin = it }, label = { Text("4-digit PIN (blank to disable)") }, singleLine = true) },
            confirmButton = { Button(onClick = { onSetParentalPin(pin.trim()); showPinDialog = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showPinDialog = false }) { Text("Cancel") } }
        )
    }

    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text(if (backupText.isNotBlank()) "Backup Copied" else "Restore Data") },
            text = {
                OutlinedTextField(
                    value = backupText,
                    onValueChange = { backupText = it },
                    label = { Text("Backup JSON") },
                    modifier = Modifier.fillMaxWidth().height(150.dp)
                )
            },
            confirmButton = {
                Button(onClick = { if (backupText.isNotBlank()) onRestoreBackup(backupText); showBackupDialog = false }) {
                    Text(if (backupText.isNotBlank()) "Apply / Close" else "Restore")
                }
            },
            dismissButton = { TextButton(onClick = { showBackupDialog = false }) { Text("Close") } }
        )
    }

    textEditDialog?.let { (title, initVal, onSave) ->
        var value by remember { mutableStateOf(initVal) }
        AlertDialog(
            onDismissRequest = { textEditDialog = null },
            title = { Text(title) },
            text = { OutlinedTextField(value = value, onValueChange = { value = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
            confirmButton = { Button(onClick = { onSave(value.trim()); textEditDialog = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { textEditDialog = null }) { Text("Cancel") } }
        )
    }

    infoToastDialog?.let { (title, body) ->
        AlertDialog(
            onDismissRequest = { infoToastDialog = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = { TextButton(onClick = { infoToastDialog = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun DrawerCategoryHeader(title: String) {
    Text(title, color = TiviColors.AccentBlue, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
}

@Composable
private fun DrawerHintRow(text: String) {
    Text(text, color = TiviColors.TextSecondary, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
}

@Composable
private fun StoredSwitchRow(
    settings: SettingsStore,
    key: String,
    title: String,
    defaultVal: Boolean,
    modifier: Modifier = Modifier,
    subtitle: String? = null
) {
    var checked by remember(key) { mutableStateOf(settings.getBool(key, defaultVal)) }
    DrawerSwitchRow(title, subtitle, checked, modifier) {
        checked = it
        settings.setBool(key, it)
    }
}

@Composable
private fun DrawerMenuRow(
    title: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false,
    danger: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Text(
            title,
            color = when {
                danger -> TiviColors.DangerRed
                highlight -> TiviColors.AccentBlue
                else -> Color.White
            },
            fontSize = 15.sp,
            fontWeight = if (highlight) FontWeight.Medium else FontWeight.Normal
        )
    }
}

@Composable
private fun DrawerValueRow(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(title, color = Color.White, fontSize = 15.sp)
        Spacer(Modifier.height(2.dp))
        Text(value, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun DrawerSwitchRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onChecked: (Boolean) -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable { onChecked(!checked) }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            if (!subtitle.isNullOrBlank()) {
                Text(subtitle, color = TiviColors.TextSecondary, fontSize = 11.sp)
            }
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun DrawerRadioRow(
    title: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Spacer(Modifier.width(8.dp))
        Text(title, color = Color.White, fontSize = 14.sp)
    }
}

private fun formatExpiry(raw: String): String {
    if (raw.isBlank() || raw == "null") return "Unlimited / Unknown"
    val secs = raw.toLongOrNull()
    return if (secs != null && secs > 1_000_000_000L) {
        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(secs * 1000L))
    } else raw
}
