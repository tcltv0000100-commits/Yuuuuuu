# TiviClone IPTV v4.0 (TiviMate-Style Engine)

## GitHub Actions se APK Build Kaise Karein
1. Is folder ke saare files apne GitHub repository ke root me upload/push karein.
2. GitHub repo ke **Actions** tab me jaayein.
3. **"Build TiviCloneIPTV APK"** workflow automatically run hoga (ya aap **Run workflow** button dabaa kar manually chala sakte hain).
4. Build complete hone ke baad workflow summary ke niche **Artifacts -> TiviCloneIPTV-v4-debug-apk** se `app-debug.apk` download kar lein.
