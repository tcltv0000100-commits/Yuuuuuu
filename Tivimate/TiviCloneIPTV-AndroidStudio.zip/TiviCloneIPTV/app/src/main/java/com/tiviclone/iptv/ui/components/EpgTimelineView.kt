package com.tiviclone.iptv.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.EpgProgram
import com.tiviclone.iptv.ui.theme.TiviColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EpgTimelineView(
    channels: List<Channel>,
    epgMap: Map<String, List<EpgProgram>>,
    onSelectChannel: (Channel) -> Unit,
    onPlayCatchup: (Channel, EpgProgram) -> Unit,
    onClose: () -> Unit
) {
    val hScroll = rememberScrollState()
    val now = remember { System.currentTimeMillis() }
    val slotStart = remember(now) { now - (now % 1800_000L) - 3600_000L } // 1 hour back
    val slotCount = 8 // 4 hours total in 30-min blocks
    val dpPerMin = 4.dp
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.Background)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TV Guide (EPG Timeline)",
                color = TiviColors.AccentBlue,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233044))
            ) {
                Text("Back to Player", color = TiviColors.TextPrimary, fontSize = 12.sp)
            }
        }

        // Time Header Row
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .width(150.dp)
                    .height(32.dp)
                    .background(TiviColors.SidebarBg)
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text("Channels", color = TiviColors.TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Row(modifier = Modifier.horizontalScroll(hScroll)) {
                for (i in 0 until slotCount) {
                    val slotTs = slotStart + i * 1800_000L
                    Box(
                        modifier = Modifier
                            .width(dpPerMin * 30)
                            .height(32.dp)
                            .background(TiviColors.SidebarBg)
                            .border(0.5.dp, TiviColors.Divider)
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = timeFmt.format(Date(slotTs)),
                            color = TiviColors.TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Channel Rows + Horizontal Programs
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(channels.take(150), key = { it.id }) { ch ->
                val progs = epgMap[ch.tvgId].orEmpty().filter {
                    it.endTimeMillis > slotStart && it.startTimeMillis < slotStart + slotCount * 1800_000L
                }
                Row(modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    // Channel Name Cell
                    Row(
                        modifier = Modifier
                            .width(150.dp)
                            .height(54.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(TiviColors.PanelBg)
                            .clickable { onSelectChannel(ch) }
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${ch.number}. ${ch.name}",
                            color = TiviColors.TextPrimary,
                            fontSize = 12.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Programs Timeline
                    Row(modifier = Modifier.horizontalScroll(hScroll)) {
                        if (progs.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .width(dpPerMin * 120)
                                    .height(54.dp)
                                    .background(Color(0xFF141B26))
                                    .border(0.5.dp, TiviColors.Divider)
                                    .clickable { onSelectChannel(ch) }
                                    .padding(horizontal = 10.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text("No EPG Data", color = TiviColors.TextSecondary, fontSize = 11.sp)
                            }
                        } else {
                            progs.forEach { prog ->
                                val durMins = ((prog.endTimeMillis - prog.startTimeMillis) / 60000L).coerceIn(15L, 180L).toInt()
                                val isNow = prog.startTimeMillis <= now && prog.endTimeMillis >= now
                                val isPast = prog.endTimeMillis < now
                                val canCatchup = isPast && ch.hasCatchup

                                Column(
                                    modifier = Modifier
                                        .width(dpPerMin * durMins)
                                        .height(54.dp)
                                        .background(if (isNow) TiviColors.CardFocused else Color(0xFF161E2B))
                                        .border(0.5.dp, if (isNow) TiviColors.AccentBlue else TiviColors.Divider)
                                        .clickable {
                                            if (canCatchup) onPlayCatchup(ch, prog)
                                            else onSelectChannel(ch)
                                        }
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = prog.title,
                                        color = TiviColors.TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = if (isNow) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val sub = when {
                                        isNow -> "LIVE NOW"
                                        canCatchup -> "▶ Catch-up"
                                        else -> timeFmt.format(Date(prog.startTimeMillis))
                                    }
                                    Text(
                                        text = sub,
                                        color = if (canCatchup) TiviColors.CatchupGreen else TiviColors.TextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
