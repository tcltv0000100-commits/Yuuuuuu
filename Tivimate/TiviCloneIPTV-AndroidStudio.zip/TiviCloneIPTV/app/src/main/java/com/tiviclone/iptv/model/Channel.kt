package com.tiviclone.iptv.model

data class Channel(
    val id: String,
    val number: Int,
    val name: String,
    val streamUrl: String,
    val group: String = "Uncategorized",
    val logoUrl: String = "",
    val tvgId: String = "",
    val isFavorite: Boolean = false
)

data class EpgProgram(
    val channelId: String,
    val title: String,
    val description: String,
    val startTimeMillis: Long,
    val endTimeMillis: Long
)
