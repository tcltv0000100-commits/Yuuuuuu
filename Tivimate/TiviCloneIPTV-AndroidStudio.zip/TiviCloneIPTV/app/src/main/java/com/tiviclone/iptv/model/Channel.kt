package com.tiviclone.iptv.model

enum class SourceType {
    M3U,
    XTREAM,
    STALKER
}

enum class MediaType(val label: String) {
    LIVE("Live TV"),
    MOVIES("Movies"),
    SERIES("Series")
}

data class Channel(
    val id: String,
    val number: Int,
    val name: String,
    val streamUrl: String,
    val group: String = "General",
    val logoUrl: String = "",
    val tvgId: String = "",
    val isFavorite: Boolean = false,
    val hasCatchup: Boolean = false,
    val catchupDays: Int = 0,
    val streamId: String = "",
    val sourceType: SourceType = SourceType.M3U,
    val mediaType: MediaType = MediaType.LIVE,
    val stalkerCmd: String = "",
    val userAgent: String = ""
)

data class EpgProgram(
    val channelId: String,
    val title: String,
    val description: String,
    val startTimeMillis: Long,
    val endTimeMillis: Long
)

data class XtreamConfig(
    val serverUrl: String,
    val username: String,
    val password: String
)

data class StalkerConfig(
    val portalUrl: String,
    val macAddress: String
)

data class EpisodeItem(
    val id: String,
    val season: String,
    val episodeNum: String,
    val title: String,
    val streamUrl: String,
    val stalkerCmd: String = ""
)

data class SavedPlaylist(
    val id: String,
    val name: String,
    val type: SourceType,
    val primaryUrl: String,
    val extra1: String = "",
    val extra2: String = ""
)
