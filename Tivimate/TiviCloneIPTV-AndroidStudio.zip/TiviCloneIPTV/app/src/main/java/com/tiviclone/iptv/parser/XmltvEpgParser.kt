package com.tiviclone.iptv.parser

import android.util.Xml
import com.tiviclone.iptv.model.EpgProgram
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.text.SimpleDateFormat
import java.util.Locale

object XmltvEpgParser {
    private val xmltvDateFormat = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)

    fun parse(xmlContent: String): Map<String, List<EpgProgram>> {
        val programsByChannel = mutableMapOf<String, MutableList<EpgProgram>>()
        val parser = Xml.newPullParser()
        parser.setInput(StringReader(xmlContent))

        var eventType = parser.eventType
        var currentChannel = ""
        var currentStart = 0L
        var currentStop = 0L
        var currentTitle = ""
        var currentDesc = ""
        var currentTag = ""

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name
                    if (currentTag == "programme") {
                        currentChannel = parser.getAttributeValue(null, "channel").orEmpty()
                        currentStart = parseDate(parser.getAttributeValue(null, "start"))
                        currentStop = parseDate(parser.getAttributeValue(null, "stop"))
                        currentTitle = ""
                        currentDesc = ""
                    }
                }
                XmlPullParser.TEXT -> {
                    val text = parser.text?.trim().orEmpty()
                    if (text.isNotEmpty()) {
                        when (currentTag) {
                            "title" -> currentTitle = text
                            "desc" -> currentDesc = text
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "programme" && currentChannel.isNotEmpty()) {
                        val list = programsByChannel.getOrPut(currentChannel) { mutableListOf() }
                        list.add(
                            EpgProgram(
                                channelId = currentChannel,
                                title = currentTitle.ifBlank { "Program Info Unavailable" },
                                description = currentDesc,
                                startTimeMillis = currentStart,
                                endTimeMillis = currentStop
                            )
                        )
                    }
                    currentTag = ""
                }
            }
            eventType = parser.next()
        }
        return programsByChannel
    }

    private fun parseDate(raw: String?): Long {
        if (raw.isNullOrBlank()) return 0L
        return try {
            xmltvDateFormat.parse(raw)?.time ?: 0L
        } catch (_: Exception) {
            0L
        }
    }
}
