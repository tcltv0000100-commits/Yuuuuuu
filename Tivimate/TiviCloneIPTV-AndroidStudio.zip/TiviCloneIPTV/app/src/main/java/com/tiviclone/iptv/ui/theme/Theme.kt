package com.tiviclone.iptv.ui.theme

import androidx.compose.ui.graphics.Color

object TiviColors {
    val Background = Color(0xFF0D1117)
    val SidebarBg = Color(0xFF121822)
    val PanelBg = Color(0xFF161E2B)
    val CardFocused = Color(0xFF1E3A5F)
    val AccentBlue = Color(0xFF38BDF8)
    val TextPrimary = Color(0xFFF1F5F9)
    val TextSecondary = Color(0xFF94A3B8)
    val FavoriteGold = Color(0xFFFACC15)
    val Divider = Color(0xFF233044)
}
