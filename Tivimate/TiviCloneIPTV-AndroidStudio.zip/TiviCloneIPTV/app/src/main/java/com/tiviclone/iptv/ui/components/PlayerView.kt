package com.tiviclone.iptv.ui.components

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.network.HttpClientProvider
import com.tiviclone.iptv.ui.theme.TiviColors

enum class VideoRatioMode(val label: String, val ratio: Float?) {
    FIT("Fit", null),
    RATIO_16_9("16:9", 16f / 9f),
    RATIO_20_9("20:9", 20f / 9f),
    RATIO_4_3("4:3", 4f / 3f),
    FILL("Fill", null),
    ZOOM("Zoom", null)
}

@OptIn(UnstableApi::class)
@Composable
fun IptvVideoPlayer(
    channel: Channel?,
    overrideStreamUrl: String?,
    isFullscreen: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var isBuffering by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var retryCounter by remember { mutableIntStateOf(0) }
    var ratioMode by remember { mutableStateOf(VideoRatioMode.FIT) }

    val activeUrl = overrideStreamUrl ?: channel?.streamUrl

    val exoPlayer = remember {
        val dataSourceFactory = OkHttpDataSource.Factory(HttpClientProvider.sharedClient)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(5000, 30000, 1500, 3000)
            .build()

        ExoPlayer.Builder(context, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .build().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                        .build(),
                    true
                )
                playWhenReady = true
            }
    }

    // Pause immediately when leaving app / switching tasks; resume when returning
    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> {
                    exoPlayer.playWhenReady = false
                    exoPlayer.pause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    if (!activeUrl.isNullOrBlank()) {
                        exoPlayer.playWhenReady = true
                        exoPlayer.play()
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) {
                    errorMessage = null
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                errorMessage = "Playback error (${error.errorCodeName})"
                isBuffering = false
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.stop()
            exoPlayer.release()
        }
    }

    LaunchedEffect(activeUrl, retryCounter) {
        errorMessage = null
        if (!activeUrl.isNullOrBlank()) {
            exoPlayer.setMediaItem(MediaItem.fromUri(activeUrl))
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        }
    }

    val playerResizeMode = when (ratioMode) {
        VideoRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        VideoRatioMode.FILL, VideoRatioMode.RATIO_16_9, VideoRatioMode.RATIO_20_9, VideoRatioMode.RATIO_4_3 ->
            AspectRatioFrameLayout.RESIZE_MODE_FILL
        VideoRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    }

    val videoModifier = if (ratioMode.ratio != null) {
        Modifier.aspectRatio(ratioMode.ratio!!)
    } else {
        Modifier.fillMaxSize()
    }

    Box(
        modifier = modifier.background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = videoModifier,
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = isFullscreen
                        keepScreenOn = true
                        resizeMode = playerResizeMode
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                update = { view ->
                    view.useController = isFullscreen
                    view.resizeMode = playerResizeMode
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        if (isBuffering) {
            CircularProgressIndicator(color = TiviColors.AccentBlue)
        }

        if (errorMessage != null) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .background(Color(0xDD000000))
                    .padding(16.dp)
            ) {
                Text(
                    text = errorMessage ?: "",
                    color = Color(0xFFF87171),
                    fontSize = 13.sp
                )
                Button(
                    onClick = { retryCounter++ },
                    colors = ButtonDefaults.buttonColors(containerColor = TiviColors.AccentBlue)
                ) {
                    Text("Retry Stream", color = Color(0xFF0D1117), fontWeight = FontWeight.Bold)
                }
            }
        }

        if (channel != null && isFullscreen) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val all = VideoRatioMode.entries
                        ratioMode = all[(ratioMode.ordinal + 1) % all.size]
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xAA0D1117))
                ) {
                    Text("Size: ${ratioMode.label}", color = TiviColors.TextPrimary, fontSize = 12.sp)
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(24.dp)
                    .background(Color(0xAA0D1117))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Column {
                    Text(
                        text = "${channel.number}  ${channel.name}",
                        color = TiviColors.TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${channel.group} • Press Back for Guide",
                        color = TiviColors.TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
