package com.tiviclone.iptv.ui.components

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.network.HttpClientProvider
import com.tiviclone.iptv.ui.theme.TiviColors

@Composable
fun MultiviewGrid(
    channels: List<Channel>,
    initialChannel: Channel?,
    onClose: () -> Unit
) {
    val slots = remember {
        mutableStateListOf<Channel?>().apply {
            add(initialChannel ?: channels.getOrNull(0))
            add(channels.getOrNull(1))
            add(channels.getOrNull(2))
            add(channels.getOrNull(3))
        }
    }
    var activeAudioSlot by remember { mutableIntStateOf(0) }
    var pickingSlot by remember { mutableStateOf<Int?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .padding(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Multiview (Tap screen for Audio)",
                color = TiviColors.AccentBlue,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233044))
            ) {
                Text("Exit Multiview", color = TiviColors.TextPrimary, fontSize = 12.sp)
            }
        }

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MultiviewSlot(
                    channel = slots[0],
                    hasAudio = activeAudioSlot == 0,
                    onFocusAudio = { activeAudioSlot = 0 },
                    onPickChannel = { pickingSlot = 0 },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                MultiviewSlot(
                    channel = slots[1],
                    hasAudio = activeAudioSlot == 1,
                    onFocusAudio = { activeAudioSlot = 1 },
                    onPickChannel = { pickingSlot = 1 },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
            Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MultiviewSlot(
                    channel = slots[2],
                    hasAudio = activeAudioSlot == 2,
                    onFocusAudio = { activeAudioSlot = 2 },
                    onPickChannel = { pickingSlot = 2 },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                MultiviewSlot(
                    channel = slots[3],
                    hasAudio = activeAudioSlot == 3,
                    onFocusAudio = { activeAudioSlot = 3 },
                    onPickChannel = { pickingSlot = 3 },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        }
    }

    if (pickingSlot != null) {
        val idx = pickingSlot!!
        AlertDialog(
            onDismissRequest = { pickingSlot = null },
            containerColor = TiviColors.PanelBg,
            title = { Text("Select Channel for Screen ${idx + 1}", color = TiviColors.TextPrimary, fontSize = 15.sp) },
            text = {
                LazyColumn(modifier = Modifier.height(260.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(channels.take(200), key = { it.id }) { ch ->
                        Text(
                            text = "${ch.number}. ${ch.name}",
                            color = TiviColors.TextPrimary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF1A2332))
                                .clickable {
                                    slots[idx] = ch
                                    activeAudioSlot = idx
                                    pickingSlot = null
                                }
                                .padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { pickingSlot = null }) {
                    Text("Cancel", color = TiviColors.TextSecondary)
                }
            }
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun MultiviewSlot(
    channel: Channel?,
    hasAudio: Boolean,
    onFocusAudio: () -> Unit,
    onPickChannel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val player = remember {
        val dsFactory = OkHttpDataSource.Factory(HttpClientProvider.sharedClient)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
            .build().apply { playWhenReady = true }
    }

    DisposableEffect(player) {
        onDispose {
            player.stop()
            player.release()
        }
    }

    LaunchedEffect(hasAudio) {
        player.volume = if (hasAudio) 1f else 0f
    }

    LaunchedEffect(channel?.streamUrl) {
        val url = channel?.streamUrl
        if (!url.isNullOrBlank()) {
            player.setMediaItem(MediaItem.fromUri(url))
            player.prepare()
            player.playWhenReady = true
        }
    }

    Box(
        modifier = modifier
            .border(
                width = if (hasAudio) 2.dp else 1.dp,
                color = if (hasAudio) TiviColors.AccentBlue else TiviColors.Divider
            )
            .clickable { onFocusAudio() }
    ) {
        if (channel != null && channel.streamUrl.isNotBlank()) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = false
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Empty Slot", color = TiviColors.TextSecondary, fontSize = 12.sp)
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .background(Color(0x99000000))
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = (if (hasAudio) "🔊 " else "🔇 ") + (channel?.name ?: "None"),
                color = TiviColors.TextPrimary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "Change",
                color = TiviColors.AccentBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onPickChannel() }.padding(start = 6.dp)
            )
        }
    }
}
