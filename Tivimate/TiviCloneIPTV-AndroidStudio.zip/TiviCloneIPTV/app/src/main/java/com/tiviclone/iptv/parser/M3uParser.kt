package com.tiviclone.iptv.parser

import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.SourceType

object M3uParser {
    private val attrRegex = Regex("""([a-zA-Z0-9_-]+)="([^"]*)"""")

    fun parse(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()

        var currentName = ""
        var currentGroup = "General"
        var currentLogo = ""
        var currentTvgId = ""
        var currentCatchupDays = 0
        var currentUserAgent = ""
        var number = 1

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#EXTM3U")) continue

            if (line.startsWith("#EXTINF:")) {
                val attrs = mutableMapOf<String, String>()
                attrRegex.findAll(line).forEach { match ->
                    attrs[match.groupValues[1].lowercase()] = match.groupValues[2]
                }
                currentGroup = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: "General"
                currentLogo = attrs["tvg-logo"].orEmpty()
                currentTvgId = attrs["tvg-id"].orEmpty()
                currentCatchupDays = attrs["catchup-days"]?.toIntOrNull()
                    ?: attrs["tvg-rec"]?.toIntOrNull()
                    ?: 0
                val commaIndex = line.lastIndexOf(',')
                currentName = if (commaIndex != -1 && commaIndex + 1 < line.length) {
                    line.substring(commaIndex + 1).trim()
                } else {
                    attrs["tvg-name"]?.takeIf { it.isNotBlank() } ?: "Channel $number"
                }
            } else if (line.startsWith("#EXTVLCOPT:http-user-agent=")) {
                currentUserAgent = line.substringAfter("http-user-agent=").trim()
            } else if (!line.startsWith("#")) {
                val cleanUrl = line.substringBefore("|").trim()
                val pipeUa = if (line.contains("user-agent=", ignoreCase = true)) {
                    line.substringAfter("user-agent=", "").substringBefore("&").trim()
                } else ""

                channels.add(
                    Channel(
                        id = "${number}_${currentName.hashCode()}",
                        number = number,
                        name = currentName.ifBlank { "Channel $number" },
                        streamUrl = cleanUrl,
                        group = currentGroup,
                        logoUrl = currentLogo,
                        tvgId = currentTvgId,
                        hasCatchup = currentCatchupDays > 0,
                        catchupDays = currentCatchupDays,
                        sourceType = SourceType.M3U,
                        userAgent = pipeUa.ifBlank { currentUserAgent }
                    )
                )
                number++
                currentName = ""
                currentGroup = "General"
                currentLogo = ""
                currentTvgId = ""
                currentCatchupDays = 0
                currentUserAgent = ""
            }
        }
        return channels
    }

    val SAMPLE_PLAYLIST = """
        #EXTM3U
        #EXTINF:-1 tvg-id="bbb" group-title="Demo Streams",Big Buck Bunny (HLS)
        https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8
        #EXTINF:-1 tvg-id="sintel" group-title="Demo Streams",Sintel 4K (MP4)
        https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4
        #EXTINF:-1 tvg-id="elephants" group-title="Demo Streams",Elephants Dream (MP4)
        https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4
    """.trimIndent()
}
