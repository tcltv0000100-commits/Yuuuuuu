package com.tiviclone.iptv.parser

import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.MediaType
import com.tiviclone.iptv.model.SourceType

object M3uParser {
    private val attrRegex = Regex("""([a-zA-Z0-9_-]+)="([^"]*)"""")

    fun parse(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()

        var currentName = ""
        var currentGroup = "General"
        var currentLogo = ""
        var currentTvgId = ""
        var currentCatchupDays = 0
        var currentUserAgent = ""
        var number = 1

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#EXTM3U")) continue

            if (line.startsWith("#EXTINF:")) {
                val attrs = mutableMapOf<String, String>()
                attrRegex.findAll(line).forEach { match ->
                    attrs[match.groupValues[1].lowercase()] = match.groupValues[2]
                }
                currentGroup = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: "General"
                currentLogo = attrs["tvg-logo"].orEmpty()
                currentTvgId = attrs["tvg-id"].orEmpty()
                currentCatchupDays = attrs["catchup-days"]?.toIntOrNull()
                    ?: attrs["tvg-rec"]?.toIntOrNull()
                    ?: 0
                val commaIndex = line.lastIndexOf(',')
                currentName = if (commaIndex != -1 && commaIndex + 1 < line.length) {
                    line.substring(commaIndex + 1).trim()
                } else {
                    attrs["tvg-name"]?.takeIf { it.isNotBlank() } ?: "Channel $number"
                }
            } else if (line.startsWith("#EXTVLCOPT:http-user-agent=")) {
                currentUserAgent = line.substringAfter("http-user-agent=").trim()
            } else if (!line.startsWith("#")) {
                val cleanUrl = line.substringBefore("|").trim()
                val pipeUa = if (line.contains("user-agent=", ignoreCase = true)) {
                    line.substringAfter("user-agent=", "").substringBefore("&").trim()
                } else ""

                val mediaType = classifyMediaType(currentGroup, currentName, cleanUrl)

                channels.add(
                    Channel(
                        id = "${number}_${currentName.hashCode()}",
                        number = number,
                        name = currentName.ifBlank { "Channel $number" },
                        streamUrl = cleanUrl,
                        group = currentGroup,
                        logoUrl = currentLogo,
                        tvgId = currentTvgId,
                        hasCatchup = currentCatchupDays > 0,
                        catchupDays = currentCatchupDays,
                        sourceType = SourceType.M3U,
                        mediaType = mediaType,
                        userAgent = pipeUa.ifBlank { currentUserAgent }
                    )
                )
                number++
                currentName = ""
                currentGroup = "General"
                currentLogo = ""
                currentTvgId = ""
                currentCatchupDays = 0
                currentUserAgent = ""
            }
        }
        return channels
    }

    private fun classifyMediaType(group: String, name: String, url: String): MediaType {
        val g = group.lowercase()
        val n = name.lowercase()
        val u = url.lowercase()
        return when {
            g.contains("series") || u.contains("/series/") || Regex("s\\d{1,2}e\\d{1,2}").containsMatchIn(n) -> MediaType.SERIES
            g.contains("movie") || g.contains("vod") || u.contains("/movie/") || u.endsWith(".mkv") || u.endsWith(".mp4") -> MediaType.MOVIES
            else -> MediaType.LIVE
        }
    }

    val SAMPLE_PLAYLIST = """
        #EXTM3U
        #EXTINF:-1 tvg-id="bbb" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/c/c5/Big_buck_bunny_poster_big.jpg" group-title="Demo Live",Big Buck Bunny (HLS)
        https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8
        #EXTINF:-1 tvg-id="sintel" group-title="Movies",Sintel 4K (Movie)
        https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4
        #EXTINF:-1 tvg-id="elephants" group-title="Series",Elephants Dream S01E01
        https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4
    """.trimIndent()
}
