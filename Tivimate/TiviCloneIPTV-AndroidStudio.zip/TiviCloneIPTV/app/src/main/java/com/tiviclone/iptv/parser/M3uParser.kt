package com.tiviclone.iptv.parser

import com.tiviclone.iptv.model.Channel

object M3uParser {
    private val attrRegex = Regex("""([a-zA-Z0-9_-]+)="([^"]*)"""")

    fun parse(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()

        var currentName = ""
        var currentGroup = "General"
        var currentLogo = ""
        var currentTvgId = ""
        var number = 1

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#EXTM3U")) continue

            if (line.startsWith("#EXTINF:")) {
                val attrs = mutableMapOf<String, String>()
                attrRegex.findAll(line).forEach { match ->
                    attrs[match.groupValues[1].lowercase()] = match.groupValues[2]
                }
                currentGroup = attrs["group-title"]?.takeIf { it.isNotBlank() } ?: "General"
                currentLogo = attrs["tvg-logo"].orEmpty()
                currentTvgId = attrs["tvg-id"].orEmpty()
                val commaIndex = line.lastIndexOf(',')
                currentName = if (commaIndex != -1 && commaIndex + 1 < line.length) {
                    line.substring(commaIndex + 1).trim()
                } else {
                    attrs["tvg-name"]?.takeIf { it.isNotBlank() } ?: "Channel $number"
                }
            } else if (!line.startsWith("#")) {
                channels.add(
                    Channel(
                        id = "${number}_${currentName.hashCode()}",
                        number = number,
                        name = currentName.ifBlank { "Channel $number" },
                        streamUrl = line,
                        group = currentGroup,
                        logoUrl = currentLogo,
                        tvgId = currentTvgId
                    )
                )
                number++
                currentName = ""
                currentGroup = "General"
                currentLogo = ""
                currentTvgId = ""
            }
        }
        return channels
    }

    val SAMPLE_PLAYLIST = """
        #EXTM3U
        #EXTINF:-1 tvg-id="demo1" group-title="Demo Streams",Big Buck Bunny (HLS)
        https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8
        #EXTINF:-1 tvg-id="demo2" group-title="Demo Streams",Sintel 4K Test (HLS)
        https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8
        #EXTINF:-1 tvg-id="demo3" group-title="News & Docs",Tears of Steel (HLS)
        https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8
    """.trimIndent()
}
