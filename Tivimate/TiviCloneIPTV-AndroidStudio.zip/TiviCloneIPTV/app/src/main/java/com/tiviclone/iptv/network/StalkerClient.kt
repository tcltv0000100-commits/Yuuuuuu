package com.tiviclone.iptv.network

import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.MediaType
import com.tiviclone.iptv.model.SourceType
import com.tiviclone.iptv.model.StalkerConfig
import okhttp3.Request
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.MessageDigest

object StalkerClient {

    private fun md5Upper(input: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return bytes.joinToString("") { "%02X".format(it) }
    }

    private fun sha256Upper(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02X".format(it) }
    }

    fun loadAll(config: StalkerConfig): Pair<String, List<Channel>> {
        val basePortal = normalizePortal(config.portalUrl)
        val rootOrigin = extractOrigin(basePortal)
        val macUpper = config.macAddress.trim().uppercase()

        val sn = md5Upper(macUpper)
        val snCut = sn.take(13)
        val devEnc = sha256Upper(macUpper)

        // 1. Handshake
        val handshakeUrl = "$basePortal?type=stb&action=handshake&token=&JsHttpRequest=1-xml"
        val handshakeJson = fetchJson(handshakeUrl, macUpper, null, snCut, devEnc)
            ?: throw IllegalStateException("Stalker handshake failed")
        val token = handshakeJson.optJSONObject("js")?.optString("token").orEmpty()
        if (token.isBlank()) throw IllegalStateException("Empty Stalker token")

        // 2. Auto-send Device Profile (sn, device_id, device_id2, signature)
        val profileUrl = "$basePortal?type=stb&action=get_profile&hd=1&ver=ImageDescription:0.2.18-r14-pub-250;ImageDate:Fri%20Jan%2015%2015:20:44%20EET%202016;PORTAL%20version:5.1.0;API%20Version:JS%20API%20version:328;STB%20API%20version:134;Player%20Engine%20version:0x566&num_banks=2&sn=$snCut&stb_type=MAG250&image_version=218&video_out=hdmi&device_id=$devEnc&device_id2=$devEnc&signature=$devEnc&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0&client_type=STB&hw_version_2=$snCut&timestamp=${System.currentTimeMillis() / 1000}&api_signature=263&metrics=${URLEncoder.encode("{\"mac\":\"$macUpper\",\"sn\":\"$snCut\",\"model\":\"MAG250\",\"type\":\"STB\",\"uid\":\"\"}", "UTF-8")}&JsHttpRequest=1-xml"
        runCatching { fetchJson(profileUrl, macUpper, token, snCut, devEnc) }

        val allItems = mutableListOf<Channel>()

        // 3. Live TV Genres & Channels
        val genreMap = mutableMapOf<String, String>()
        fetchJson("$basePortal?type=itv&action=get_genres&JsHttpRequest=1-xml", macUpper, token, snCut, devEnc)
            ?.optJSONArray("js")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val g = arr.optJSONObject(i) ?: continue
                    genreMap[g.optString("id")] = g.optString("title", "Live TV")
                }
            }

        fetchJson("$basePortal?type=itv&action=get_all_channels&JsHttpRequest=1-xml", macUpper, token, snCut, devEnc)
            ?.optJSONObject("js")?.optJSONArray("data")?.let { dataArr ->
                for (i in 0 until dataArr.length()) {
                    val obj = dataArr.optJSONObject(i) ?: continue
                    val id = obj.optString("id")
                    val cmd = obj.optString("cmd")
                    val logo = resolveLogo(rootOrigin, obj.optString("logo"))
                    allItems.add(
                        Channel(
                            id = "stalker_live_$id",
                            number = obj.optString("number").toIntOrNull() ?: (i + 1),
                            name = obj.optString("name", "Channel ${i + 1}"),
                            streamUrl = cmd.removePrefix("ffmpeg ").trim(),
                            group = genreMap[obj.optString("tv_genre_id")] ?: "Live TV",
                            logoUrl = logo,
                            tvgId = obj.optString("xmltv_id"),
                            hasCatchup = obj.optInt("enable_tv_archive", 0) == 1,
                            streamId = id,
                            sourceType = SourceType.STALKER,
                            mediaType = MediaType.LIVE,
                            stalkerCmd = cmd
                        )
                    )
                }
            }

        // 4. VOD Movies (Page 1)
        fetchJson("$basePortal?type=vod&action=get_ordered_list&p=1&JsHttpRequest=1-xml", macUpper, token, snCut, devEnc)
            ?.optJSONObject("js")?.optJSONArray("data")?.let { vodArr ->
                for (i in 0 until vodArr.length()) {
                    val obj = vodArr.optJSONObject(i) ?: continue
                    val id = obj.optString("id")
                    val cmd = obj.optString("cmd")
                    val logo = resolveLogo(rootOrigin, obj.optString("screenshot_uri"))
                    allItems.add(
                        Channel(
                            id = "stalker_vod_$id",
                            number = i + 1,
                            name = obj.optString("name", "Movie ${i + 1}"),
                            streamUrl = cmd.removePrefix("ffmpeg ").trim(),
                            group = "Movies",
                            logoUrl = logo,
                            streamId = id,
                            sourceType = SourceType.STALKER,
                            mediaType = MediaType.MOVIES,
                            stalkerCmd = cmd
                        )
                    )
                }
            }

        // 5. Series (Page 1)
        fetchJson("$basePortal?type=series&action=get_ordered_list&p=1&JsHttpRequest=1-xml", macUpper, token, snCut, devEnc)
            ?.optJSONObject("js")?.optJSONArray("data")?.let { seriesArr ->
                for (i in 0 until seriesArr.length()) {
                    val obj = seriesArr.optJSONObject(i) ?: continue
                    val id = obj.optString("id")
                    val cmd = obj.optString("cmd")
                    val logo = resolveLogo(rootOrigin, obj.optString("screenshot_uri"))
                    allItems.add(
                        Channel(
                            id = "stalker_series_$id",
                            number = i + 1,
                            name = obj.optString("name", "Series ${i + 1}"),
                            streamUrl = cmd.removePrefix("ffmpeg ").trim(),
                            group = "Series",
                            logoUrl = logo,
                            streamId = id,
                            sourceType = SourceType.STALKER,
                            mediaType = MediaType.SERIES,
                            stalkerCmd = cmd
                        )
                    )
                }
            }

        return token to allItems
    }

    fun createStreamLink(config: StalkerConfig, token: String, cmd: String, mediaType: MediaType): String? {
        val basePortal = normalizePortal(config.portalUrl)
        val macUpper = config.macAddress.trim().uppercase()
        val snCut = md5Upper(macUpper).take(13)
        val devEnc = sha256Upper(macUpper)
        val encodedCmd = URLEncoder.encode(cmd, "UTF-8")
        val type = if (mediaType == MediaType.MOVIES) "vod" else "itv"
        val url = "$basePortal?type=$type&action=create_link&cmd=$encodedCmd&series=&forced_storage=0&disable_ad=0&download=0&JsHttpRequest=1-xml"
        val json = fetchJson(url, macUpper, token, snCut, devEnc) ?: return null
        val rawLink = json.optJSONObject("js")?.optString("cmd").orEmpty()
        return rawLink.removePrefix("ffmpeg ").trim().takeIf { it.startsWith("http") }
    }

    private fun resolveLogo(origin: String, raw: String): String {
        if (raw.isBlank()) return ""
        if (raw.startsWith("http")) return raw
        return "$origin/${raw.trimStart('/')}"
    }

    private fun extractOrigin(portalUrl: String): String {
        return try {
            val uri = URI(portalUrl)
            "${uri.scheme}://${uri.authority}"
        } catch (_: Exception) {
            portalUrl.substringBefore("/portal.php")
        }
    }

    private fun normalizePortal(url: String): String {
        val trimmed = url.trim().trimEnd('/')
        return when {
            trimmed.endsWith(".php") -> trimmed
            trimmed.endsWith("/c") -> "${trimmed.dropLast(2)}/portal.php"
            else -> "$trimmed/portal.php"
        }
    }

    private fun fetchJson(
        url: String,
        macUpper: String,
        token: String?,
        snCut: String,
        devEnc: String
    ): JSONObject? {
        val builder = Request.Builder()
            .url(url)
            .header("Cookie", "mac=$macUpper; stb_lang=en; timezone=UTC")
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("SN", snCut)
            .header("Device-Id", devEnc)
        if (!token.isNullOrBlank()) {
            builder.header("Authorization", "Bearer $token")
        }
        return try {
            HttpClientProvider.sharedClient.newCall(builder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val body = resp.body?.string().orEmpty().trim()
                if (!body.startsWith("{")) return null
                JSONObject(body)
            }
        } catch (_: Exception) {
            null
        }
    }
}
