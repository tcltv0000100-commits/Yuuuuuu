package com.tiviclone.iptv.network

import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.MediaType
import com.tiviclone.iptv.model.SourceType
import com.tiviclone.iptv.model.StalkerConfig
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

object StalkerClient {

    private const val STB_USER_AGENT =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

    private val stalkerHttp: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    private fun md5Upper(input: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return bytes.joinToString("") { "%02X".format(it) }
    }

    private fun sha256Upper(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02X".format(it) }
    }

    fun loadAll(config: StalkerConfig): Pair<String, List<Channel>> {
        val rawUrl = fixScheme(config.portalUrl)
        val macUpper = config.macAddress.trim().uppercase()

        val sn = md5Upper(macUpper)
        val snCut = sn.take(13)
        val devEnc = sha256Upper(macUpper)

        // Try common Stalker / Ministra endpoints in order
        val candidates = buildPortalCandidates(rawUrl)
        var workingPortal = ""
        var token = ""
        var lastError = "Unknown error"

        for (candidate in candidates) {
            val handshakeUrl = "$candidate?type=stb&action=handshake&token=&JsHttpRequest=1-xml"
            val (json, err) = fetchJsonDetailed(candidate, handshakeUrl, macUpper, null, snCut, devEnc)
            val t = json?.optJSONObject("js")?.optString("token").orEmpty()
            if (t.isNotBlank()) {
                workingPortal = candidate
                token = t
                break
            } else if (err != null) {
                lastError = err
            }
        }

        if (workingPortal.isBlank() || token.isBlank()) {
            throw IllegalStateException("Stalker handshake failed ($lastError)")
        }

        val rootOrigin = extractOrigin(workingPortal)

        // 2. Auto-send Device Profile (sn, device_id, device_id2, signature)
        val metricsJson = JSONObject().apply {
            put("mac", macUpper)
            put("sn", snCut)
            put("model", "MAG250")
            put("type", "STB")
            put("uid", "")
        }.toString()
        val metrics = URLEncoder.encode(metricsJson, "UTF-8")
        val profileUrl = "$workingPortal?type=stb&action=get_profile&hd=1&ver=ImageDescription:0.2.18-r14-pub-250;ImageDate:Fri%20Jan%2015%2015:20:44%20EET%202016;PORTAL%20version:5.1.0;API%20Version:JS%20API%20version:328;STB%20API%20version:134;Player%20Engine%20version:0x566&num_banks=2&sn=$snCut&stb_type=MAG250&image_version=218&video_out=hdmi&device_id=$devEnc&device_id2=$devEnc&signature=$devEnc&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0&client_type=STB&hw_version_2=$snCut&timestamp=${System.currentTimeMillis() / 1000}&api_signature=263&metrics=$metrics&JsHttpRequest=1-xml"
        runCatching { fetchJsonDetailed(workingPortal, profileUrl, macUpper, token, snCut, devEnc) }

        val allItems = mutableListOf<Channel>()

        // 3. Live TV Genres & Channels
        val genreMap = mutableMapOf<String, String>()
        fetchJsonDetailed(workingPortal, "$workingPortal?type=itv&action=get_genres&JsHttpRequest=1-xml", macUpper, token, snCut, devEnc)
            .first?.optJSONArray("js")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val g = arr.optJSONObject(i) ?: continue
                    genreMap[g.optString("id")] = g.optString("title", "Live TV")
                }
            }

        fetchJsonDetailed(workingPortal, "$workingPortal?type=itv&action=get_all_channels&JsHttpRequest=1-xml", macUpper, token, snCut, devEnc)
            .first?.optJSONObject("js")?.optJSONArray("data")?.let { dataArr ->
                for (i in 0 until dataArr.length()) {
                    val obj = dataArr.optJSONObject(i) ?: continue
                    val id = obj.optString("id")
                    val cmd = obj.optString("cmd")
                    val logo = resolveLogo(rootOrigin, obj.optString("logo"))
                    allItems.add(
                        Channel(
                            id = "stalker_live_$id",
                            number = obj.optString("number").toIntOrNull() ?: (i + 1),
                            name = obj.optString("name", "Channel ${i + 1}"),
                            streamUrl = cmd.removePrefix("ffmpeg ").trim(),
                            group = genreMap[obj.optString("tv_genre_id")] ?: "Live TV",
                            logoUrl = logo,
                            tvgId = obj.optString("xmltv_id"),
                            hasCatchup = obj.optInt("enable_tv_archive", 0) == 1,
                            streamId = id,
                            sourceType = SourceType.STALKER,
                            mediaType = MediaType.LIVE,
                            stalkerCmd = cmd
                        )
                    )
                }
            }

        // 4. VOD Movies (Page 1)
        fetchJsonDetailed(workingPortal, "$workingPortal?type=vod&action=get_ordered_list&p=1&JsHttpRequest=1-xml", macUpper, token, snCut, devEnc)
            .first?.optJSONObject("js")?.optJSONArray("data")?.let { vodArr ->
                for (i in 0 until vodArr.length()) {
                    val obj = vodArr.optJSONObject(i) ?: continue
                    val id = obj.optString("id")
                    val cmd = obj.optString("cmd")
                    val logo = resolveLogo(rootOrigin, obj.optString("screenshot_uri"))
                    allItems.add(
                        Channel(
                            id = "stalker_vod_$id",
                            number = i + 1,
                            name = obj.optString("name", "Movie ${i + 1}"),
                            streamUrl = cmd.removePrefix("ffmpeg ").trim(),
                            group = "Movies",
                            logoUrl = logo,
                            streamId = id,
                            sourceType = SourceType.STALKER,
                            mediaType = MediaType.MOVIES,
                            stalkerCmd = cmd
                        )
                    )
                }
            }

        // 5. Series (Page 1)
        fetchJsonDetailed(workingPortal, "$workingPortal?type=series&action=get_ordered_list&p=1&JsHttpRequest=1-xml", macUpper, token, snCut, devEnc)
            .first?.optJSONObject("js")?.optJSONArray("data")?.let { seriesArr ->
                for (i in 0 until seriesArr.length()) {
                    val obj = seriesArr.optJSONObject(i) ?: continue
                    val id = obj.optString("id")
                    val cmd = obj.optString("cmd")
                    val logo = resolveLogo(rootOrigin, obj.optString("screenshot_uri"))
                    allItems.add(
                        Channel(
                            id = "stalker_series_$id",
                            number = i + 1,
                            name = obj.optString("name", "Series ${i + 1}"),
                            streamUrl = cmd.removePrefix("ffmpeg ").trim(),
                            group = "Series",
                            logoUrl = logo,
                            streamId = id,
                            sourceType = SourceType.STALKER,
                            mediaType = MediaType.SERIES,
                            stalkerCmd = cmd
                        )
                    )
                }
            }

        return "$workingPortal|$token" to allItems
    }

    fun createStreamLink(config: StalkerConfig, tokenAndPortal: String, cmd: String, mediaType: MediaType): String? {
        val parts = tokenAndPortal.split("|", limit = 2)
        val workingPortal = if (parts.size == 2) parts[0] else buildPortalCandidates(fixScheme(config.portalUrl)).first()
        val token = if (parts.size == 2) parts[1] else tokenAndPortal

        val macUpper = config.macAddress.trim().uppercase()
        val snCut = md5Upper(macUpper).take(13)
        val devEnc = sha256Upper(macUpper)
        val encodedCmd = URLEncoder.encode(cmd, "UTF-8")
        val type = if (mediaType == MediaType.MOVIES) "vod" else "itv"
        val url = "$workingPortal?type=$type&action=create_link&cmd=$encodedCmd&series=&forced_storage=0&disable_ad=0&download=0&JsHttpRequest=1-xml"
        val json = fetchJsonDetailed(workingPortal, url, macUpper, token, snCut, devEnc).first ?: return null
        val rawLink = json.optJSONObject("js")?.optString("cmd").orEmpty()
        return rawLink.removePrefix("ffmpeg ").trim().takeIf { it.startsWith("http") }
    }

    private fun fixScheme(url: String): String {
        val t = url.trim().trimEnd('/')
        return when {
            t.lowercase().startsWith("http://") -> "http://" + t.substring(7)
            t.lowercase().startsWith("https://") -> "https://" + t.substring(8)
            else -> "http://$t"
        }
    }

    private fun buildPortalCandidates(url: String): List<String> {
        if (url.endsWith(".php")) return listOf(url)
        val origin = extractOrigin(url)
        val list = mutableListOf<String>()
        if (url.contains("stalker_portal", ignoreCase = true)) {
            val base = url.substringBefore("/c").trimEnd('/')
            list.add("$base/server/load.php")
            list.add("$base/portal.php")
        } else if (url.endsWith("/c")) {
            val base = url.dropLast(2).trimEnd('/')
            list.add("$base/server/load.php")
            list.add("$base/portal.php")
            list.add("$base/stalker_portal/server/load.php")
        } else {
            list.add("$url/server/load.php")
            list.add("$url/portal.php")
            list.add("$origin/stalker_portal/server/load.php")
            list.add("$origin/portal.php")
        }
        return list.distinct()
    }

    private fun resolveLogo(origin: String, raw: String): String {
        if (raw.isBlank()) return ""
        if (raw.startsWith("http")) return raw
        return "$origin/${raw.trimStart('/')}"
    }

    private fun extractOrigin(portalUrl: String): String {
        return try {
            val uri = URI(portalUrl)
            "${uri.scheme}://${uri.authority}"
        } catch (_: Exception) {
            portalUrl.substringBefore("/portal.php").substringBefore("/server/")
        }
    }

    private fun fetchJsonDetailed(
        portalEndpoint: String,
        url: String,
        macUpper: String,
        token: String?,
        snCut: String,
        devEnc: String
    ): Pair<JSONObject?, String?> {
        val referer = portalEndpoint
            .replace("/server/load.php", "/c/")
            .replace("/portal.php", "/c/")
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", STB_USER_AGENT)
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("Referer", referer)
            .header("Cookie", "mac=$macUpper; stb_lang=en; timezone=UTC")
            .header("SN", snCut)
            .header("Device-Id", devEnc)
        if (!token.isNullOrBlank()) {
            builder.header("Authorization", "Bearer $token")
        }
        return try {
            stalkerHttp.newCall(builder.build()).execute().use { resp ->
                val body = resp.body?.string().orEmpty().trim()
                if (!resp.isSuccessful) {
                    return null to "HTTP ${resp.code}"
                }
                if (!body.startsWith("{")) {
                    return null to "Invalid response"
                }
                JSONObject(body) to null
            }
        } catch (e: Exception) {
            null to (e.localizedMessage ?: "Network error")
        }
    }
}
