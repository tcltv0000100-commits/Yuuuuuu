package com.tiviclone.iptv.network

import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.SourceType
import com.tiviclone.iptv.model.StalkerConfig
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

object StalkerClient {

    fun loadChannels(config: StalkerConfig): Pair<String, List<Channel>> {
        val basePortal = normalizePortal(config.portalUrl)
        val mac = config.macAddress.trim()

        // 1. Handshake
        val handshakeUrl = "$basePortal?type=stb&action=handshake&token=&JsHttpRequest=1-xml"
        val handshakeJson = fetchJson(handshakeUrl, mac, null)
            ?: throw IllegalStateException("Stalker handshake failed")
        val token = handshakeJson.optJSONObject("js")?.optString("token").orEmpty()
        if (token.isBlank()) throw IllegalStateException("Empty Stalker token")

        // 2. Genres
        val genreMap = mutableMapOf<String, String>()
        val genresUrl = "$basePortal?type=itv&action=get_genres&JsHttpRequest=1-xml"
        fetchJson(genresUrl, mac, token)?.optJSONArray("js")?.let { arr ->
            for (i in 0 until arr.length()) {
                val g = arr.optJSONObject(i) ?: continue
                genreMap[g.optString("id")] = g.optString("title", "General")
            }
        }

        // 3. All Channels
        val channelsUrl = "$basePortal?type=itv&action=get_all_channels&JsHttpRequest=1-xml"
        val chJson = fetchJson(channelsUrl, mac, token)
            ?: throw IllegalStateException("Failed to fetch Stalker channels")
        val dataArr = chJson.optJSONObject("js")?.optJSONArray("data")
            ?: return token to emptyList()

        val channels = mutableListOf<Channel>()
        for (i in 0 until dataArr.length()) {
            val obj = dataArr.optJSONObject(i) ?: continue
            val id = obj.optString("id")
            val name = obj.optString("name", "Channel ${i + 1}")
            val cmd = obj.optString("cmd")
            val genreId = obj.optString("tv_genre_id")
            val number = obj.optString("number").toIntOrNull() ?: (i + 1)
            val logo = obj.optString("logo")

            channels.add(
                Channel(
                    id = "stalker_$id",
                    number = number,
                    name = name,
                    streamUrl = cmd.removePrefix("ffmpeg ").trim(),
                    group = genreMap[genreId] ?: "Stalker TV",
                    logoUrl = logo,
                    tvgId = obj.optString("xmltv_id"),
                    hasCatchup = obj.optInt("enable_tv_archive", 0) == 1,
                    streamId = id,
                    sourceType = SourceType.STALKER,
                    stalkerCmd = cmd
                )
            )
        }
        return token to channels
    }

    fun createStreamLink(config: StalkerConfig, token: String, cmd: String): String? {
        val basePortal = normalizePortal(config.portalUrl)
        val encodedCmd = URLEncoder.encode(cmd, "UTF-8")
        val url = "$basePortal?type=itv&action=create_link&cmd=$encodedCmd&series=&forced_storage=0&disable_ad=0&download=0&JsHttpRequest=1-xml"
        val json = fetchJson(url, config.macAddress.trim(), token) ?: return null
        val rawLink = json.optJSONObject("js")?.optString("cmd").orEmpty()
        return rawLink.removePrefix("ffmpeg ").trim().takeIf { it.startsWith("http") }
    }

    private fun normalizePortal(url: String): String {
        val trimmed = url.trim().trimEnd('/')
        return when {
            trimmed.endsWith(".php") -> trimmed
            trimmed.endsWith("/c") -> "${trimmed.dropLast(2)}/portal.php"
            else -> "$trimmed/portal.php"
        }
    }

    private fun fetchJson(url: String, mac: String, token: String?): JSONObject? {
        val builder = Request.Builder()
            .url(url)
            .header("Cookie", "mac=$mac; stb_lang=en; timezone=UTC")
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
        if (!token.isNullOrBlank()) {
            builder.header("Authorization", "Bearer $token")
        }
        HttpClientProvider.sharedClient.newCall(builder.build()).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string().orEmpty().trim()
            if (!body.startsWith("{")) return null
            return JSONObject(body)
        }
    }
}
