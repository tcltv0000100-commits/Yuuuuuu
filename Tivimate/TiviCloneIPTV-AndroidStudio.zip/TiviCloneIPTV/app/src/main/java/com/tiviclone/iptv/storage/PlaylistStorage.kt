package com.tiviclone.iptv.storage

import android.content.SharedPreferences
import com.tiviclone.iptv.model.SavedPlaylist
import com.tiviclone.iptv.model.SourceType
import org.json.JSONArray
import org.json.JSONObject

object PlaylistStorage {
    private const val KEY_PLAYLISTS = "saved_playlists_json"
    private const val KEY_EPG_URL = "saved_epg_url"
    private const val KEY_EPG_INTERVAL_HOURS = "epg_interval_hours"
    private const val KEY_EPG_LAST_UPDATED = "epg_last_updated"

    fun getPlaylists(prefs: SharedPreferences): List<SavedPlaylist> {
        val raw = prefs.getString(KEY_PLAYLISTS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<SavedPlaylist>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                list.add(
                    SavedPlaylist(
                        id = obj.optString("id"),
                        name = obj.optString("name"),
                        type = SourceType.valueOf(obj.optString("type", "M3U")),
                        primaryUrl = obj.optString("primaryUrl"),
                        extra1 = obj.optString("extra1"),
                        extra2 = obj.optString("extra2")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun savePlaylist(prefs: SharedPreferences, item: SavedPlaylist): List<SavedPlaylist> {
        val existing = getPlaylists(prefs).filterNot { it.id == item.id }.toMutableList()
        existing.add(0, item)
        persistList(prefs, existing)
        return existing
    }

    fun deletePlaylist(prefs: SharedPreferences, id: String): List<SavedPlaylist> {
        val updated = getPlaylists(prefs).filterNot { it.id == id }
        persistList(prefs, updated)
        return updated
    }

    private fun persistList(prefs: SharedPreferences, list: List<SavedPlaylist>) {
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("type", item.type.name)
                    put("primaryUrl", item.primaryUrl)
                    put("extra1", item.extra1)
                    put("extra2", item.extra2)
                }
            )
        }
        prefs.edit().putString(KEY_PLAYLISTS, arr.toString()).apply()
    }

    fun getEpgUrl(prefs: SharedPreferences): String = prefs.getString(KEY_EPG_URL, "") ?: ""
    fun setEpgUrl(prefs: SharedPreferences, url: String) {
        prefs.edit().putString(KEY_EPG_URL, url).apply()
    }

    fun getEpgIntervalHours(prefs: SharedPreferences): Int = prefs.getInt(KEY_EPG_INTERVAL_HOURS, 12)
    fun setEpgIntervalHours(prefs: SharedPreferences, hours: Int) {
        prefs.edit().putInt(KEY_EPG_INTERVAL_HOURS, hours).apply()
    }

    fun getEpgLastUpdated(prefs: SharedPreferences): Long = prefs.getLong(KEY_EPG_LAST_UPDATED, 0L)
    fun setEpgLastUpdated(prefs: SharedPreferences, ts: Long) {
        prefs.edit().putLong(KEY_EPG_LAST_UPDATED, ts).apply()
    }

    fun saveStalkerToken(prefs: SharedPreferences, key: String, token: String) {
        prefs.edit().putString("stalker_tok_$key", token).apply()
    }

    fun getStalkerToken(prefs: SharedPreferences, key: String): String? {
        return prefs.getString("stalker_tok_$key", null)
    }

    fun saveCachedChannels(prefs: SharedPreferences, list: List<com.tiviclone.iptv.model.Channel>) {
        val arr = JSONArray()
        list.take(3000).forEach { ch ->
            arr.put(
                JSONObject().apply {
                    put("id", ch.id)
                    put("num", ch.number)
                    put("name", ch.name)
                    put("url", ch.streamUrl)
                    put("grp", ch.group)
                    put("logo", ch.logoUrl)
                    put("tvg", ch.tvgId)
                    put("fav", ch.isFavorite)
                    put("cu", ch.hasCatchup)
                    put("cud", ch.catchupDays)
                    put("sid", ch.streamId)
                    put("st", ch.sourceType.name)
                    put("mt", ch.mediaType.name)
                    put("cmd", ch.stalkerCmd)
                }
            )
        }
        prefs.edit().putString("cached_channels_json", arr.toString()).apply()
    }

    fun loadCachedChannels(prefs: SharedPreferences): List<com.tiviclone.iptv.model.Channel> {
        val raw = prefs.getString("cached_channels_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<com.tiviclone.iptv.model.Channel>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(
                    com.tiviclone.iptv.model.Channel(
                        id = o.optString("id"),
                        number = o.optInt("num", i + 1),
                        name = o.optString("name"),
                        streamUrl = o.optString("url"),
                        group = o.optString("grp", "General"),
                        logoUrl = o.optString("logo"),
                        tvgId = o.optString("tvg"),
                        isFavorite = o.optBoolean("fav", false),
                        hasCatchup = o.optBoolean("cu", false),
                        catchupDays = o.optInt("cud", 0),
                        streamId = o.optString("sid"),
                        sourceType = SourceType.valueOf(o.optString("st", "M3U")),
                        mediaType = com.tiviclone.iptv.model.MediaType.valueOf(o.optString("mt", "LIVE")),
                        stalkerCmd = o.optString("cmd")
                    )
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun clearCache(prefs: SharedPreferences) {
        prefs.edit().remove("cached_channels_json").apply()
    }
}
