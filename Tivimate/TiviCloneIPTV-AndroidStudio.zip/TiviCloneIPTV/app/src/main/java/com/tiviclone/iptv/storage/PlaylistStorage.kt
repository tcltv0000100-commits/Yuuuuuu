package com.tiviclone.iptv.storage

import android.content.SharedPreferences
import com.tiviclone.iptv.model.SavedPlaylist
import com.tiviclone.iptv.model.SourceType
import org.json.JSONArray
import org.json.JSONObject

object PlaylistStorage {
    private const val KEY_PLAYLISTS = "saved_playlists_json"
    private const val KEY_EPG_URL = "saved_epg_url"
    private const val KEY_EPG_INTERVAL_HOURS = "epg_interval_hours"
    private const val KEY_EPG_LAST_UPDATED = "epg_last_updated"

    fun getPlaylists(prefs: SharedPreferences): List<SavedPlaylist> {
        val raw = prefs.getString(KEY_PLAYLISTS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<SavedPlaylist>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                list.add(
                    SavedPlaylist(
                        id = obj.optString("id"),
                        name = obj.optString("name"),
                        type = SourceType.valueOf(obj.optString("type", "M3U")),
                        primaryUrl = obj.optString("primaryUrl"),
                        extra1 = obj.optString("extra1"),
                        extra2 = obj.optString("extra2")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun savePlaylist(prefs: SharedPreferences, item: SavedPlaylist): List<SavedPlaylist> {
        val existing = getPlaylists(prefs).filterNot { it.id == item.id }.toMutableList()
        existing.add(0, item)
        persistList(prefs, existing)
        return existing
    }

    fun deletePlaylist(prefs: SharedPreferences, id: String): List<SavedPlaylist> {
        val updated = getPlaylists(prefs).filterNot { it.id == id }
        persistList(prefs, updated)
        return updated
    }

    private fun persistList(prefs: SharedPreferences, list: List<SavedPlaylist>) {
        val arr = JSONArray()
        list.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("name", item.name)
                    put("type", item.type.name)
                    put("primaryUrl", item.primaryUrl)
                    put("extra1", item.extra1)
                    put("extra2", item.extra2)
                }
            )
        }
        prefs.edit().putString(KEY_PLAYLISTS, arr.toString()).apply()
    }

    fun getEpgUrl(prefs: SharedPreferences): String = prefs.getString(KEY_EPG_URL, "") ?: ""
    fun setEpgUrl(prefs: SharedPreferences, url: String) {
        prefs.edit().putString(KEY_EPG_URL, url).apply()
    }

    fun getEpgIntervalHours(prefs: SharedPreferences): Int = prefs.getInt(KEY_EPG_INTERVAL_HOURS, 12)
    fun setEpgIntervalHours(prefs: SharedPreferences, hours: Int) {
        prefs.edit().putInt(KEY_EPG_INTERVAL_HOURS, hours).apply()
    }

    fun getEpgLastUpdated(prefs: SharedPreferences): Long = prefs.getLong(KEY_EPG_LAST_UPDATED, 0L)
    fun setEpgLastUpdated(prefs: SharedPreferences, ts: Long) {
        prefs.edit().putLong(KEY_EPG_LAST_UPDATED, ts).apply()
    }
}
