package com.tiviclone.iptv.network

import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.MediaType
import com.tiviclone.iptv.model.SourceType
import com.tiviclone.iptv.model.XtreamConfig
import okhttp3.Request
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object XtreamClient {

    fun loadAll(config: XtreamConfig): List<Channel> {
        val base = config.serverUrl.trimEnd('/')
        val user = config.username.trim()
        val pass = config.password.trim()
        val all = mutableListOf<Channel>()

        // 1. Live TV
        val liveCats = fetchCategoryMap("$base/player_api.php?username=$user&password=$pass&action=get_live_categories")
        fetchJsonArray("$base/player_api.php?username=$user&password=$pass&action=get_live_streams")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val streamId = obj.optString("stream_id")
                if (streamId.isBlank()) continue
                all.add(
                    Channel(
                        id = "xtream_live_$streamId",
                        number = obj.optInt("num", i + 1),
                        name = obj.optString("name", "Channel ${i + 1}"),
                        streamUrl = "$base/live/$user/$pass/$streamId.ts",
                        group = liveCats[obj.optString("category_id")] ?: "Live TV",
                        logoUrl = obj.optString("stream_icon"),
                        tvgId = obj.optString("epg_channel_id"),
                        hasCatchup = obj.optInt("tv_archive", 0) == 1,
                        catchupDays = obj.optInt("tv_archive_duration", 0),
                        streamId = streamId,
                        sourceType = SourceType.XTREAM,
                        mediaType = MediaType.LIVE
                    )
                )
            }
        }

        // 2. VOD Movies
        val vodCats = fetchCategoryMap("$base/player_api.php?username=$user&password=$pass&action=get_vod_categories")
        fetchJsonArray("$base/player_api.php?username=$user&password=$pass&action=get_vod_streams")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val streamId = obj.optString("stream_id")
                if (streamId.isBlank()) continue
                val ext = obj.optString("container_extension", "mp4").ifBlank { "mp4" }
                all.add(
                    Channel(
                        id = "xtream_vod_$streamId",
                        number = i + 1,
                        name = obj.optString("name", "Movie ${i + 1}"),
                        streamUrl = "$base/movie/$user/$pass/$streamId.$ext",
                        group = vodCats[obj.optString("category_id")] ?: "Movies",
                        logoUrl = obj.optString("stream_icon"),
                        streamId = streamId,
                        sourceType = SourceType.XTREAM,
                        mediaType = MediaType.MOVIES
                    )
                )
            }
        }

        // 3. Series
        val seriesCats = fetchCategoryMap("$base/player_api.php?username=$user&password=$pass&action=get_series_categories")
        fetchJsonArray("$base/player_api.php?username=$user&password=$pass&action=get_series")?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val seriesId = obj.optString("series_id")
                if (seriesId.isBlank()) continue
                all.add(
                    Channel(
                        id = "xtream_series_$seriesId",
                        number = i + 1,
                        name = obj.optString("name", "Series ${i + 1}"),
                        streamUrl = "",
                        group = seriesCats[obj.optString("category_id")] ?: "Series",
                        logoUrl = obj.optString("cover"),
                        streamId = seriesId,
                        sourceType = SourceType.XTREAM,
                        mediaType = MediaType.SERIES
                    )
                )
            }
        }

        return all
    }

    fun loadSeriesEpisodes(config: XtreamConfig, seriesId: String): List<com.tiviclone.iptv.model.EpisodeItem> {
        val base = config.serverUrl.trimEnd('/')
        val user = config.username.trim()
        val pass = config.password.trim()
        val url = "$base/player_api.php?username=$user&password=$pass&action=get_series_info&series_id=$seriesId"
        val req = Request.Builder().url(url).build()
        val out = mutableListOf<com.tiviclone.iptv.model.EpisodeItem>()
        try {
            HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return emptyList()
                val body = resp.body?.string().orEmpty().trim()
                if (!body.startsWith("{")) return emptyList()
                val root = org.json.JSONObject(body)
                val episodesObj = root.optJSONObject("episodes") ?: return emptyList()
                val keys = episodesObj.keys()
                while (keys.hasNext()) {
                    val seasonKey = keys.next()
                    val epArr = episodesObj.optJSONArray(seasonKey) ?: continue
                    for (i in 0 until epArr.length()) {
                        val ep = epArr.optJSONObject(i) ?: continue
                        val epId = ep.optString("id")
                        if (epId.isBlank()) continue
                        val ext = ep.optString("container_extension", "mp4").ifBlank { "mp4" }
                        out.add(
                            com.tiviclone.iptv.model.EpisodeItem(
                                id = epId,
                                season = seasonKey,
                                episodeNum = ep.optString("episode_num", "${i + 1}"),
                                title = ep.optString("title", "Episode ${i + 1}"),
                                streamUrl = "$base/series/$user/$pass/$epId.$ext"
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) { }
        return out
    }

    fun buildCatchupUrl(
        config: XtreamConfig,
        streamId: String,
        startTimeMillis: Long,
        endTimeMillis: Long
    ): String {
        val base = config.serverUrl.trimEnd('/')
        val durationMin = ((endTimeMillis - startTimeMillis) / 60000L).coerceAtLeast(1L)
        val fmt = SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US)
        val startStr = fmt.format(Date(startTimeMillis))
        return "$base/timeshift/${config.username}/${config.password}/$durationMin/$startStr/$streamId.ts"
    }

    fun getXmltvUrl(config: XtreamConfig): String {
        val base = config.serverUrl.trimEnd('/')
        return "$base/xmltv.php?username=${config.username}&password=${config.password}"
    }

    private fun fetchCategoryMap(url: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        fetchJsonArray(url)?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                map[obj.optString("category_id")] = obj.optString("category_name", "General")
            }
        }
        return map
    }

    private fun fetchJsonArray(url: String): JSONArray? {
        val req = Request.Builder().url(url).build()
        return try {
            HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val body = resp.body?.string().orEmpty().trim()
                if (!body.startsWith("[")) return null
                JSONArray(body)
            }
        } catch (_: Exception) {
            null
        }
    }
}
