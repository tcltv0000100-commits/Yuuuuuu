package com.tiviclone.iptv.network

import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.SourceType
import com.tiviclone.iptv.model.XtreamConfig
import okhttp3.Request
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object XtreamClient {

    fun loadChannels(config: XtreamConfig): List<Channel> {
        val base = config.serverUrl.trimEnd('/')
        val user = config.username.trim()
        val pass = config.password.trim()

        // 1. Fetch Live Categories
        val catMap = mutableMapOf<String, String>()
        val catUrl = "$base/player_api.php?username=$user&password=$pass&action=get_live_categories"
        fetchJsonArray(catUrl)?.let { arr ->
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                catMap[obj.optString("category_id")] = obj.optString("category_name", "Live TV")
            }
        }

        // 2. Fetch Live Streams
        val channels = mutableListOf<Channel>()
        val streamsUrl = "$base/player_api.php?username=$user&password=$pass&action=get_live_streams"
        val streamsArr = fetchJsonArray(streamsUrl) ?: return emptyList()

        for (i in 0 until streamsArr.length()) {
            val obj = streamsArr.optJSONObject(i) ?: continue
            val streamId = obj.optString("stream_id")
            if (streamId.isBlank()) continue
            val name = obj.optString("name", "Channel ${i + 1}")
            val catId = obj.optString("category_id")
            val group = catMap[catId] ?: "Live TV"
            val logo = obj.optString("stream_icon")
            val epgId = obj.optString("epg_channel_id")
            val tvArchive = obj.optInt("tv_archive", 0) == 1
            val archiveDuration = obj.optInt("tv_archive_duration", 0)

            channels.add(
                Channel(
                    id = "xtream_$streamId",
                    number = obj.optInt("num", i + 1),
                    name = name,
                    streamUrl = "$base/live/$user/$pass/$streamId.ts",
                    group = group,
                    logoUrl = logo,
                    tvgId = epgId,
                    hasCatchup = tvArchive,
                    catchupDays = archiveDuration,
                    streamId = streamId,
                    sourceType = SourceType.XTREAM
                )
            )
        }
        return channels
    }

    fun buildCatchupUrl(
        config: XtreamConfig,
        streamId: String,
        startTimeMillis: Long,
        endTimeMillis: Long
    ): String {
        val base = config.serverUrl.trimEnd('/')
        val durationMin = ((endTimeMillis - startTimeMillis) / 60000L).coerceAtLeast(1L)
        val fmt = SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US)
        val startStr = fmt.format(Date(startTimeMillis))
        return "$base/timeshift/${config.username}/${config.password}/$durationMin/$startStr/$streamId.ts"
    }

    fun getXmltvUrl(config: XtreamConfig): String {
        val base = config.serverUrl.trimEnd('/')
        return "$base/xmltv.php?username=${config.username}&password=${config.password}"
    }

    private fun fetchJsonArray(url: String): JSONArray? {
        val req = Request.Builder().url(url).build()
        HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            val body = resp.body?.string().orEmpty().trim()
            if (!body.startsWith("[")) return null
            return JSONArray(body)
        }
    }
}
