package com.tiviclone.iptv.recorder

import android.content.Context
import android.os.Environment
import com.tiviclone.iptv.network.HttpClientProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StreamRecorder(private val context: Context) {
    private var recordJob: Job? = null
    var isRecording: Boolean = false
        private set
    var currentFile: File? = null
        private set

    fun startRecording(
        scope: CoroutineScope,
        channelName: String,
        streamUrl: String,
        onError: (String) -> Unit
    ) {
        if (isRecording) return
        val dir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            "TivmateRecordings"
        ).apply { mkdirs() }
        val safeName = channelName.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(24)
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outFile = File(dir, "${safeName}_$ts.ts")
        currentFile = outFile
        isRecording = true

        recordJob = scope.launch(Dispatchers.IO) {
            try {
                if (streamUrl.contains(".m3u8", ignoreCase = true)) {
                    recordHls(streamUrl, outFile)
                } else {
                    recordDirect(streamUrl, outFile)
                }
            } catch (e: Exception) {
                if (isActive) {
                    onError(e.localizedMessage ?: "Recording error")
                }
            } finally {
                isRecording = false
            }
        }
    }

    fun stopRecording(): File? {
        recordJob?.cancel()
        recordJob = null
        isRecording = false
        return currentFile
    }

    private suspend fun recordDirect(url: String, outFile: File) {
        val req = Request.Builder().url(url).build()
        HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            val input = resp.body?.byteStream() ?: throw IllegalStateException("Empty stream")
            FileOutputStream(outFile, true).use { fos ->
                val buf = ByteArray(16 * 1024)
                while (recordJob?.isActive == true) {
                    val read = input.read(buf)
                    if (read == -1) break
                    fos.write(buf, 0, read)
                }
            }
        }
    }

    private suspend fun recordHls(m3u8Url: String, outFile: File) {
        val seenSegments = LinkedHashSet<String>()
        FileOutputStream(outFile, true).use { fos ->
            while (recordJob?.isActive == true) {
                val playlistText = fetchText(m3u8Url) ?: break
                val lines = playlistText.lines().map { it.trim() }.filter { it.isNotEmpty() }
                // If master playlist, pick first variant stream
                val variant = lines.firstOrNull { !it.startsWith("#") && it.contains(".m3u8", ignoreCase = true) }
                if (variant != null) {
                    val resolvedVariant = resolveUrl(m3u8Url, variant)
                    recordHls(resolvedVariant, outFile)
                    return
                }
                val segments = lines.filter { !it.startsWith("#") }
                for (seg in segments) {
                    if (recordJob?.isActive != true) break
                    val segUrl = resolveUrl(m3u8Url, seg)
                    if (seenSegments.add(segUrl)) {
                        val req = Request.Builder().url(segUrl).build()
                        runCatching {
                            HttpClientProvider.sharedClient.newCall(req).execute().use { r ->
                                if (r.isSuccessful) {
                                    r.body?.bytes()?.let { fos.write(it) }
                                }
                            }
                        }
                    }
                }
                delay(2500)
            }
        }
    }

    private fun fetchText(url: String): String? {
        val req = Request.Builder().url(url).build()
        return HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) null else resp.body?.string()
        }
    }

    private fun resolveUrl(baseUrl: String, rel: String): String {
        if (rel.startsWith("http://") || rel.startsWith("https://")) return rel
        val baseDir = baseUrl.substringBeforeLast("/")
        return "$baseDir/${rel.trimStart('/')}"
    }
}
