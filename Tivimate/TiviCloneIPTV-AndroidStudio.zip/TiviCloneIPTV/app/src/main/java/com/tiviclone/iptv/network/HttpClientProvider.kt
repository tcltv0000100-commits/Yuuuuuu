package com.tiviclone.iptv.network

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object HttpClientProvider {
    const val DEFAULT_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 13; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    fun createClient(userAgent: String = DEFAULT_USER_AGENT): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("User-Agent", userAgent.ifBlank { DEFAULT_USER_AGENT })
                    .build()
                chain.proceed(request)
            }
            .build()
    }

    val sharedClient: OkHttpClient by lazy { createClient() }
}
