package com.tiviclone.iptv.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.ui.components.IptvVideoPlayer
import com.tiviclone.iptv.ui.theme.TiviColors

@Composable
fun MainTvScreen(
    channels: List<Channel>,
    selectedChannel: Channel?,
    isFullscreen: Boolean,
    isLoading: Boolean,
    onSelectChannel: (Channel) -> Unit,
    onToggleFavorite: (Channel) -> Unit,
    onLoadPlaylistUrl: (String) -> Unit,
    onToggleFullscreen: (Boolean) -> Unit
) {
    val groups = remember(channels) {
        listOf("All Channels", "Favorites") + channels.map { it.group }.distinct()
    }
    var selectedGroup by remember { mutableStateOf("All Channels") }
    var showUrlDialog by remember { mutableStateOf(false) }

    val filteredChannels = remember(channels, selectedGroup) {
        when (selectedGroup) {
            "All Channels" -> channels
            "Favorites" -> channels.filter { it.isFavorite }
            else -> channels.filter { it.group == selectedGroup }
        }
    }

    if (isFullscreen && selectedChannel != null) {
        Box(modifier = Modifier.fillMaxSize()) {
            IptvVideoPlayer(
                channel = selectedChannel,
                isFullscreen = true,
                modifier = Modifier.fillMaxSize()
            )
        }
        return
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.Background)
    ) {
        // Left Sidebar: Groups / Categories
        Column(
            modifier = Modifier
                .width(210.dp)
                .fillMaxHeight()
                .background(TiviColors.SidebarBg)
                .padding(12.dp)
        ) {
            Text(
                text = "TiviClone",
                color = TiviColors.AccentBlue,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp)
            )

            FocusableItem(
                label = "+ Add M3U URL",
                isSelected = false,
                onClick = { showUrlDialog = true }
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(groups) { group ->
                    FocusableItem(
                        label = group,
                        isSelected = group == selectedGroup,
                        onClick = { selectedGroup = group }
                    )
                }
            }
        }

        // Middle Column: Channel List
        Column(
            modifier = Modifier
                .width(320.dp)
                .fillMaxHeight()
                .background(TiviColors.PanelBg)
                .padding(12.dp)
        ) {
            Text(
                text = if (isLoading) "Loading playlist..." else "$selectedGroup (${filteredChannels.size})",
                color = TiviColors.TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 8.dp, start = 6.dp)
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(filteredChannels, key = { it.id }) { channel ->
                    ChannelRow(
                        channel = channel,
                        isPlaying = channel.id == selectedChannel?.id,
                        onClick = {
                            if (channel.id == selectedChannel?.id) {
                                onToggleFullscreen(true)
                            } else {
                                onSelectChannel(channel)
                            }
                        },
                        onToggleFavorite = { onToggleFavorite(channel) }
                    )
                }
            }
        }

        // Right Pane: Live Preview + Channel Details
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, TiviColors.Divider, RoundedCornerShape(10.dp))
                    .clickable(enabled = selectedChannel != null) {
                        onToggleFullscreen(true)
                    }
            ) {
                IptvVideoPlayer(
                    channel = selectedChannel,
                    isFullscreen = false,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (selectedChannel != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${selectedChannel.number}. ${selectedChannel.name}",
                            color = TiviColors.TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Group: ${selectedChannel.group}",
                            color = TiviColors.TextSecondary,
                            fontSize = 13.sp
                        )
                    }

                    Button(
                        onClick = { onToggleFullscreen(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = TiviColors.AccentBlue)
                    ) {
                        Text("Fullscreen", color = Color(0xFF0D1117), fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Text(
                    text = "Select a channel from the list to start watching.",
                    color = TiviColors.TextSecondary,
                    fontSize = 14.sp
                )
            }
        }
    }

    if (showUrlDialog) {
        AddPlaylistDialog(
            onDismiss = { showUrlDialog = false },
            onConfirm = { url ->
                showUrlDialog = false
                onLoadPlaylistUrl(url)
            }
        )
    }
}

@Composable
private fun FocusableItem(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val bgColor = when {
        isFocused -> TiviColors.CardFocused
        isSelected -> Color(0xFF1B2638)
        else -> Color.Transparent
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .then(
                if (isFocused) Modifier.border(BorderStroke(1.5.dp, TiviColors.AccentBlue), RoundedCornerShape(6.dp))
                else Modifier
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected || isFocused) TiviColors.TextPrimary else TiviColors.TextSecondary,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ChannelRow(
    channel: Channel,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val bgColor = when {
        isFocused -> TiviColors.CardFocused
        isPlaying -> Color(0xFF1A2940)
        else -> Color.Transparent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .then(
                if (isFocused) Modifier.border(BorderStroke(1.5.dp, TiviColors.AccentBlue), RoundedCornerShape(6.dp))
                else Modifier
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "${channel.number}",
            color = TiviColors.TextSecondary,
            fontSize = 13.sp,
            modifier = Modifier.width(32.dp)
        )
        Text(
            text = channel.name,
            color = if (isPlaying || isFocused) TiviColors.TextPrimary else Color(0xFFCBD5E1),
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = if (channel.isFavorite) "★" else "☆",
            color = if (channel.isFavorite) TiviColors.FavoriteGold else TiviColors.TextSecondary,
            fontSize = 16.sp,
            modifier = Modifier
                .clickable(onClick = onToggleFavorite)
                .padding(horizontal = 6.dp)
        )
    }
}

@Composable
private fun AddPlaylistDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var urlText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TiviColors.PanelBg,
        title = { Text("Load M3U Playlist URL", color = TiviColors.TextPrimary) },
        text = {
            OutlinedTextField(
                value = urlText,
                onValueChange = { urlText = it },
                placeholder = { Text("https://example.com/playlist.m3u") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { if (urlText.isNotBlank()) onConfirm(urlText.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = TiviColors.AccentBlue)
            ) {
                Text("Load", color = Color(0xFF0D1117))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TiviColors.TextSecondary)
            }
        }
    )
}
