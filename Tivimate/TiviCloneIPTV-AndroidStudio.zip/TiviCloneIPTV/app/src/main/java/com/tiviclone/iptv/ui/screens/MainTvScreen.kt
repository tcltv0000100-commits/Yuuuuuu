package com.tiviclone.iptv.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.EpgProgram
import com.tiviclone.iptv.model.MediaType
import com.tiviclone.iptv.model.SavedPlaylist
import com.tiviclone.iptv.model.StalkerConfig
import com.tiviclone.iptv.model.XtreamConfig
import com.tiviclone.iptv.ui.components.IptvVideoPlayer
import com.tiviclone.iptv.ui.theme.TiviColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun darkFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    cursorColor = TiviColors.AccentBlue,
    focusedBorderColor = TiviColors.AccentBlue,
    unfocusedBorderColor = TiviColors.Divider,
    focusedLabelColor = TiviColors.AccentBlue,
    unfocusedLabelColor = TiviColors.TextSecondary,
    focusedPlaceholderColor = TiviColors.TextSecondary,
    unfocusedPlaceholderColor = TiviColors.TextSecondary
)

@Composable
fun MainTvScreen(
    channels: List<Channel>,
    selectedChannel: Channel?,
    resolvedStreamUrl: String?,
    epgMap: Map<String, List<EpgProgram>>,
    savedPlaylists: List<SavedPlaylist>,
    epgIntervalHours: Int,
    epgLastUpdated: Long,
    isFullscreen: Boolean,
    isLoading: Boolean,
    statusMessage: String?,
    onSelectChannel: (Channel) -> Unit,
    onToggleFavorite: (Channel) -> Unit,
    onLoadM3uUrl: (String) -> Unit,
    onPickM3uFile: () -> Unit,
    onLoadXtream: (XtreamConfig) -> Unit,
    onLoadStalker: (StalkerConfig) -> Unit,
    onLoadEpgUrl: (String) -> Unit,
    onSelectSavedPlaylist: (SavedPlaylist) -> Unit,
    onDeleteSavedPlaylist: (String) -> Unit,
    onUpdateEpgInterval: (Int) -> Unit,
    onRefreshEpgNow: () -> Unit,
    onPlayCatchup: (Channel, EpgProgram) -> Unit,
    onToggleFullscreen: (Boolean) -> Unit
) {
    var selectedMediaType by remember { mutableStateOf(MediaType.LIVE) }
    val mediaFiltered = remember(channels, selectedMediaType) {
        channels.filter { it.mediaType == selectedMediaType }
    }
    val groups = remember(mediaFiltered) {
        listOf("All", "Favorites") + mediaFiltered.map { it.group }.distinct()
    }
    var selectedGroup by remember(selectedMediaType) { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var showSourceDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val filteredChannels = remember(mediaFiltered, selectedGroup, searchQuery) {
        val base = when (selectedGroup) {
            "All" -> mediaFiltered
            "Favorites" -> mediaFiltered.filter { it.isFavorite }
            else -> mediaFiltered.filter { it.group == selectedGroup }
        }
        if (searchQuery.isBlank()) base
        else base.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    if (isFullscreen && selectedChannel != null) {
        Box(modifier = Modifier.fillMaxSize()) {
            IptvVideoPlayer(
                channel = selectedChannel,
                overrideStreamUrl = resolvedStreamUrl,
                isFullscreen = true,
                modifier = Modifier.fillMaxSize()
            )
        }
        return
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.Background)
    ) {
        // Left Sidebar: Media Sections + Categories + Settings
        Column(
            modifier = Modifier
                .width(210.dp)
                .fillMaxHeight()
                .background(TiviColors.SidebarBg)
                .padding(10.dp)
        ) {
            Text(
                text = "TiviClone",
                color = TiviColors.AccentBlue,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
            )

            // Live TV / Movies / Series tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                MediaType.entries.forEach { mType ->
                    val active = selectedMediaType == mType
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (active) TiviColors.AccentBlue else Color(0xFF1B2638))
                            .clickable { selectedMediaType = mType }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (mType == MediaType.LIVE) "Live" else mType.label,
                            color = if (active) Color(0xFF0D1117) else TiviColors.TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            FocusableItem(
                label = "+ Add Playlist / Portal",
                isSelected = false,
                onClick = { showSourceDialog = true }
            )
            FocusableItem(
                label = "⚙ Settings",
                isSelected = false,
                onClick = { showSettingsDialog = true }
            )

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(groups) { group ->
                    FocusableItem(
                        label = group,
                        isSelected = group == selectedGroup,
                        onClick = { selectedGroup = group }
                    )
                }
            }
        }

        // Middle Column: Search + Channel List with Logos
        Column(
            modifier = Modifier
                .width(305.dp)
                .fillMaxHeight()
                .background(TiviColors.PanelBg)
                .padding(10.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search...", fontSize = 12.sp) },
                singleLine = true,
                colors = darkFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            Text(
                text = if (isLoading) (statusMessage ?: "Loading...") else "${selectedMediaType.label} • $selectedGroup (${filteredChannels.size})",
                color = TiviColors.TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 6.dp, start = 4.dp)
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(filteredChannels, key = { it.id }) { channel ->
                    val nowProgram = remember(channel.tvgId, epgMap) {
                        val now = System.currentTimeMillis()
                        epgMap[channel.tvgId]?.firstOrNull {
                            it.startTimeMillis <= now && it.endTimeMillis >= now
                        }
                    }
                    ChannelRow(
                        channel = channel,
                        nowTitle = nowProgram?.title,
                        isPlaying = channel.id == selectedChannel?.id,
                        onClick = {
                            if (channel.id == selectedChannel?.id) {
                                onToggleFullscreen(true)
                            } else {
                                onSelectChannel(channel)
                            }
                        },
                        onToggleFavorite = { onToggleFavorite(channel) }
                    )
                }
            }
        }

        // Right Pane: Live Preview + EPG / Catch-up Guide
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.55f)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, TiviColors.Divider, RoundedCornerShape(10.dp))
                    .clickable(enabled = selectedChannel != null) {
                        onToggleFullscreen(true)
                    }
            ) {
                IptvVideoPlayer(
                    channel = selectedChannel,
                    overrideStreamUrl = resolvedStreamUrl,
                    isFullscreen = false,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (selectedChannel != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ChannelLogoBox(logoUrl = selectedChannel.logoUrl, name = selectedChannel.name)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "${selectedChannel.number}. ${selectedChannel.name}",
                                color = TiviColors.TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val catchupBadge = if (selectedChannel.hasCatchup) " • Catch-up Ready" else ""
                            Text(
                                text = "${selectedChannel.group}$catchupBadge",
                                color = if (selectedChannel.hasCatchup) TiviColors.CatchupGreen else TiviColors.TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Button(
                        onClick = { onToggleFullscreen(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = TiviColors.AccentBlue)
                    ) {
                        Text("Fullscreen", color = Color(0xFF0D1117), fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                val programs = epgMap[selectedChannel.tvgId].orEmpty()
                val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.45f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TiviColors.SidebarBg)
                        .padding(10.dp)
                ) {
                    Text(
                        text = if (programs.isEmpty()) "EPG Guide (Add EPG URL in + Add Playlist)" else "EPG Guide & Catch-up",
                        color = TiviColors.TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(programs.take(20)) { prog ->
                            val now = System.currentTimeMillis()
                            val isPast = prog.endTimeMillis < now
                            val canCatchup = isPast && selectedChannel.hasCatchup

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF1A2332))
                                    .clickable(enabled = canCatchup) {
                                        onPlayCatchup(selectedChannel, prog)
                                    }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${timeFmt.format(Date(prog.startTimeMillis))} - ${prog.title}",
                                    color = TiviColors.TextPrimary,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                if (canCatchup) {
                                    Text(
                                        text = "▶ Catch-up",
                                        color = TiviColors.CatchupGreen,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSourceDialog) {
        AddSourceDialog(
            onDismiss = { showSourceDialog = false },
            onLoadM3uUrl = {
                showSourceDialog = false
                onLoadM3uUrl(it)
            },
            onPickM3uFile = {
                showSourceDialog = false
                onPickM3uFile()
            },
            onLoadXtream = {
                showSourceDialog = false
                onLoadXtream(it)
            },
            onLoadStalker = {
                showSourceDialog = false
                onLoadStalker(it)
            },
            onLoadEpgUrl = {
                showSourceDialog = false
                onLoadEpgUrl(it)
            }
        )
    }

    if (showSettingsDialog) {
        SettingsDialog(
            savedPlaylists = savedPlaylists,
            epgIntervalHours = epgIntervalHours,
            epgLastUpdated = epgLastUpdated,
            onDismiss = { showSettingsDialog = false },
            onSelectPlaylist = {
                showSettingsDialog = false
                onSelectSavedPlaylist(it)
            },
            onDeletePlaylist = onDeleteSavedPlaylist,
            onUpdateEpgInterval = onUpdateEpgInterval,
            onRefreshEpgNow = {
                showSettingsDialog = false
                onRefreshEpgNow()
            }
        )
    }
}

@Composable
private fun ChannelLogoBox(logoUrl: String, name: String) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF233044)),
        contentAlignment = Alignment.Center
    ) {
        if (logoUrl.isNotBlank()) {
            AsyncImage(
                model = logoUrl,
                contentDescription = name,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                text = name.take(2).uppercase(),
                color = TiviColors.AccentBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun FocusableItem(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val bgColor = when {
        isFocused -> TiviColors.CardFocused
        isSelected -> Color(0xFF1B2638)
        else -> Color.Transparent
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .then(
                if (isFocused) Modifier.border(BorderStroke(1.5.dp, TiviColors.AccentBlue), RoundedCornerShape(6.dp))
                else Modifier
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected || isFocused) TiviColors.TextPrimary else TiviColors.TextSecondary,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ChannelRow(
    channel: Channel,
    nowTitle: String?,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    val bgColor = when {
        isFocused -> TiviColors.CardFocused
        isPlaying -> Color(0xFF1A2940)
        else -> Color.Transparent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .then(
                if (isFocused) Modifier.border(BorderStroke(1.5.dp, TiviColors.AccentBlue), RoundedCornerShape(6.dp))
                else Modifier
            )
            .onFocusChanged { isFocused = it.isFocused }
            .focusable()
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "${channel.number}",
            color = TiviColors.TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.width(28.dp)
        )
        ChannelLogoBox(logoUrl = channel.logoUrl, name = channel.name)
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = channel.name,
                color = if (isPlaying || isFocused) TiviColors.TextPrimary else Color(0xFFCBD5E1),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!nowTitle.isNullOrBlank()) {
                Text(
                    text = nowTitle,
                    color = TiviColors.TextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Text(
            text = if (channel.isFavorite) "★" else "☆",
            color = if (channel.isFavorite) TiviColors.FavoriteGold else TiviColors.TextSecondary,
            fontSize = 16.sp,
            modifier = Modifier
                .clickable(onClick = onToggleFavorite)
                .padding(horizontal = 6.dp)
        )
    }
}

@Composable
private fun AddSourceDialog(
    onDismiss: () -> Unit,
    onLoadM3uUrl: (String) -> Unit,
    onPickM3uFile: () -> Unit,
    onLoadXtream: (XtreamConfig) -> Unit,
    onLoadStalker: (StalkerConfig) -> Unit,
    onLoadEpgUrl: (String) -> Unit
) {
    var tab by remember { mutableStateOf("M3U") }
    var m3uUrl by remember { mutableStateOf("") }
    var xtreamHost by remember { mutableStateOf("") }
    var xtreamUser by remember { mutableStateOf("") }
    var xtreamPass by remember { mutableStateOf("") }
    var stalkerUrl by remember { mutableStateOf("") }
    var stalkerMac by remember { mutableStateOf("00:1A:79:00:00:01") }
    var epgUrl by remember { mutableStateOf("") }
    val fieldColors = darkFieldColors()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TiviColors.PanelBg,
        title = { Text("Add IPTV Source", color = TiviColors.TextPrimary, fontSize = 18.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("M3U", "Xtream", "Stalker", "EPG").forEach { item ->
                        Button(
                            onClick = { tab = item },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tab == item) TiviColors.AccentBlue else Color(0xFF233044)
                            )
                        ) {
                            Text(
                                text = item,
                                color = if (tab == item) Color(0xFF0D1117) else TiviColors.TextPrimary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                when (tab) {
                    "M3U" -> {
                        OutlinedTextField(
                            value = m3uUrl,
                            onValueChange = { m3uUrl = it },
                            label = { Text("M3U / M3U8 URL") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = onPickM3uFile,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233044))
                        ) {
                            Text("Or Pick Local .m3u File", color = TiviColors.TextPrimary)
                        }
                    }
                    "Xtream" -> {
                        OutlinedTextField(
                            value = xtreamHost,
                            onValueChange = { xtreamHost = it },
                            label = { Text("Server URL (http://host:port)") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = xtreamUser,
                            onValueChange = { xtreamUser = it },
                            label = { Text("Username") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = xtreamPass,
                            onValueChange = { xtreamPass = it },
                            label = { Text("Password") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    "Stalker" -> {
                        OutlinedTextField(
                            value = stalkerUrl,
                            onValueChange = { stalkerUrl = it },
                            label = { Text("Portal URL (http://.../c/)") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = stalkerMac,
                            onValueChange = { stalkerMac = it },
                            label = { Text("MAC Address (SN & DeviceID auto)") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    "EPG" -> {
                        OutlinedTextField(
                            value = epgUrl,
                            onValueChange = { epgUrl = it },
                            label = { Text("XMLTV EPG URL") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when (tab) {
                        "M3U" -> if (m3uUrl.isNotBlank()) onLoadM3uUrl(m3uUrl.trim())
                        "Xtream" -> if (xtreamHost.isNotBlank()) {
                            onLoadXtream(XtreamConfig(xtreamHost.trim(), xtreamUser.trim(), xtreamPass.trim()))
                        }
                        "Stalker" -> if (stalkerUrl.isNotBlank()) {
                            onLoadStalker(StalkerConfig(stalkerUrl.trim(), stalkerMac.trim()))
                        }
                        "EPG" -> if (epgUrl.isNotBlank()) onLoadEpgUrl(epgUrl.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TiviColors.AccentBlue)
            ) {
                Text("Load", color = Color(0xFF0D1117), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TiviColors.TextSecondary)
            }
        }
    )
}

@Composable
private fun SettingsDialog(
    savedPlaylists: List<SavedPlaylist>,
    epgIntervalHours: Int,
    epgLastUpdated: Long,
    onDismiss: () -> Unit,
    onSelectPlaylist: (SavedPlaylist) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onUpdateEpgInterval: (Int) -> Unit,
    onRefreshEpgNow: () -> Unit
) {
    val lastUpdateText = remember(epgLastUpdated) {
        if (epgLastUpdated == 0L) "Never"
        else SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(epgLastUpdated))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TiviColors.PanelBg,
        title = { Text("Settings", color = TiviColors.TextPrimary, fontSize = 18.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Developer Info
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1A2332))
                        .padding(10.dp)
                ) {
                    Column {
                        Text("Developer: mrbeats 7.8", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("TiviClone IPTV v3.0.0", color = TiviColors.TextSecondary, fontSize = 12.sp)
                    }
                }

                // EPG Auto-Update Schedule
                Text("EPG Update Schedule (Last: $lastUpdateText)", color = TiviColors.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(6 to "6h", 12 to "12h", 24 to "24h", 0 to "Off").forEach { (hrs, lbl) ->
                        Button(
                            onClick = { onUpdateEpgInterval(hrs) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (epgIntervalHours == hrs) TiviColors.AccentBlue else Color(0xFF233044)
                            )
                        ) {
                            Text(lbl, color = if (epgIntervalHours == hrs) Color(0xFF0D1117) else TiviColors.TextPrimary, fontSize = 11.sp)
                        }
                    }
                }
                Button(
                    onClick = onRefreshEpgNow,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF233044))
                ) {
                    Text("Update EPG Now", color = TiviColors.TextPrimary, fontSize = 12.sp)
                }

                // Saved Playlists
                Text("Saved Playlists (${savedPlaylists.size})", color = TiviColors.TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                if (savedPlaylists.isEmpty()) {
                    Text("No saved playlists yet.", color = TiviColors.TextSecondary, fontSize = 12.sp)
                } else {
                    LazyColumn(
                        modifier = Modifier.height(140.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(savedPlaylists, key = { it.id }) { pl ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1A2332))
                                    .clickable { onSelectPlaylist(pl) }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(pl.name, color = TiviColors.TextPrimary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${pl.type.name} • ${pl.primaryUrl}", color = TiviColors.TextSecondary, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text(
                                    text = "✕",
                                    color = Color(0xFFF87171),
                                    fontSize = 14.sp,
                                    modifier = Modifier
                                        .clickable { onDeletePlaylist(pl.id) }
                                        .padding(horizontal = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TiviColors.AccentBlue)
            ) {
                Text("Close", color = Color(0xFF0D1117), fontWeight = FontWeight.Bold)
            }
        }
    )
}
