package com.tiviclone.iptv

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.EpgProgram
import com.tiviclone.iptv.model.EpisodeItem
import com.tiviclone.iptv.model.MediaType
import com.tiviclone.iptv.model.SavedPlaylist
import com.tiviclone.iptv.model.SourceType
import com.tiviclone.iptv.model.StalkerConfig
import com.tiviclone.iptv.model.XtreamConfig
import com.tiviclone.iptv.network.HttpClientProvider
import com.tiviclone.iptv.network.StalkerClient
import com.tiviclone.iptv.network.XtreamClient
import com.tiviclone.iptv.parser.M3uParser
import com.tiviclone.iptv.parser.XmltvEpgParser
import com.tiviclone.iptv.storage.PlaylistStorage
import com.tiviclone.iptv.ui.screens.MainTvScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("tiviclone_prefs", Context.MODE_PRIVATE)

        setContent {
            val scope = rememberCoroutineScope()
            var channels by remember {
                val cached = PlaylistStorage.loadCachedChannels(prefs)
                if (cached.isNotEmpty()) {
                    mutableStateOf(cached)
                } else {
                    val savedM3u = prefs.getString("last_m3u", null)
                    val initial = if (!savedM3u.isNullOrBlank()) M3uParser.parse(savedM3u)
                    else M3uParser.parse(M3uParser.SAMPLE_PLAYLIST)
                    mutableStateOf(initial.ifEmpty { M3uParser.parse(M3uParser.SAMPLE_PLAYLIST) })
                }
            }
            var seriesEpisodes by remember { mutableStateOf<List<EpisodeItem>>(emptyList()) }
            var activeSeriesTitle by remember { mutableStateOf<String?>(null) }
            var selectedChannel by remember { mutableStateOf(channels.firstOrNull()) }
            var resolvedStreamUrl by remember { mutableStateOf<String?>(null) }
            var epgMap by remember { mutableStateOf<Map<String, List<EpgProgram>>>(emptyMap()) }
            var savedPlaylists by remember { mutableStateOf(PlaylistStorage.getPlaylists(prefs)) }
            var epgIntervalHours by remember { mutableIntStateOf(PlaylistStorage.getEpgIntervalHours(prefs)) }
            var epgLastUpdated by remember { mutableLongStateOf(PlaylistStorage.getEpgLastUpdated(prefs)) }

            var isFullscreen by remember { mutableStateOf(false) }
            var isLoading by remember { mutableStateOf(false) }
            var statusMessage by remember { mutableStateOf<String?>(null) }

            var activeXtreamConfig by remember { mutableStateOf<XtreamConfig?>(null) }
            var activeStalkerConfig by remember { mutableStateOf<StalkerConfig?>(null) }
            var activeStalkerToken by remember { mutableStateOf<String?>(null) }

            fun selectAndResolveChannel(ch: Channel) {
                if (ch.mediaType == MediaType.SERIES && ch.sourceType == SourceType.XTREAM && activeXtreamConfig != null) {
                    scope.launch {
                        isLoading = true
                        statusMessage = "Loading episodes..."
                        val eps = withContext(Dispatchers.IO) {
                            XtreamClient.loadSeriesEpisodes(activeXtreamConfig!!, ch.streamId)
                        }
                        isLoading = false
                        statusMessage = null
                        if (eps.isNotEmpty()) {
                            activeSeriesTitle = ch.name
                            seriesEpisodes = eps
                        } else {
                            Toast.makeText(this@MainActivity, "No episodes found", Toast.LENGTH_SHORT).show()
                        }
                    }
                    return
                }
                selectedChannel = ch
                if (ch.sourceType == SourceType.STALKER && activeStalkerConfig != null) {
                    val cfg = activeStalkerConfig!!
                    val tokKey = "${cfg.portalUrl.hashCode()}_${cfg.macAddress}"
                    val tok = activeStalkerToken ?: PlaylistStorage.getStalkerToken(prefs, tokKey)
                    if (tok != null) {
                        scope.launch {
                            val link = withContext(Dispatchers.IO) {
                                StalkerClient.createStreamLink(cfg, tok, ch.stalkerCmd, ch.mediaType)
                            }
                            resolvedStreamUrl = link ?: ch.streamUrl
                        }
                    }
                } else {
                    resolvedStreamUrl = null
                }
            }

            fun loadEpgFromUrl(url: String, silent: Boolean = false) {
                if (url.isBlank()) return
                scope.launch {
                    if (!silent) {
                        isLoading = true
                        statusMessage = "Updating EPG..."
                    }
                    try {
                        val xml = withContext(Dispatchers.IO) {
                            val req = Request.Builder().url(url).build()
                            HttpClientProvider.sharedClient.newCall(req).execute().use { it.body?.string().orEmpty() }
                        }
                        if (xml.isNotBlank()) {
                            epgMap = withContext(Dispatchers.Default) { XmltvEpgParser.parse(xml) }
                            val now = System.currentTimeMillis()
                            PlaylistStorage.setEpgUrl(prefs, url)
                            PlaylistStorage.setEpgLastUpdated(prefs, now)
                            epgLastUpdated = now
                            if (!silent) Toast.makeText(this@MainActivity, "EPG Updated!", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        if (!silent) Toast.makeText(this@MainActivity, "EPG error: ${e.message}", Toast.LENGTH_LONG).show()
                    } finally {
                        if (!silent) {
                            isLoading = false
                            statusMessage = null
                        }
                    }
                }
            }

            // Scheduled EPG Auto-Update Check on Startup
            LaunchedEffect(Unit) {
                val epgUrl = PlaylistStorage.getEpgUrl(prefs)
                if (epgUrl.isNotBlank() && epgIntervalHours > 0) {
                    val elapsedMs = System.currentTimeMillis() - epgLastUpdated
                    if (elapsedMs >= epgIntervalHours * 3600_000L) {
                        loadEpgFromUrl(epgUrl, silent = true)
                    }
                }
            }

            fun loadM3uUrl(url: String, saveItem: Boolean = true) {
                scope.launch {
                    isLoading = true
                    statusMessage = "Downloading M3U..."
                    try {
                        val raw = withContext(Dispatchers.IO) {
                            val req = Request.Builder().url(url).build()
                            HttpClientProvider.sharedClient.newCall(req).execute().use { it.body?.string().orEmpty() }
                        }
                        val parsed = M3uParser.parse(raw)
                        if (parsed.isNotEmpty()) {
                            prefs.edit().putString("last_m3u", raw).apply()
                            if (saveItem) {
                                savedPlaylists = PlaylistStorage.savePlaylist(
                                    prefs,
                                    SavedPlaylist(
                                        id = "m3u_${url.hashCode()}",
                                        name = url.substringAfterLast("/").take(24).ifBlank { "M3U Playlist" },
                                        type = SourceType.M3U,
                                        primaryUrl = url
                                    )
                                )
                            }
                            channels = parsed
                            PlaylistStorage.saveCachedChannels(prefs, parsed)
                            selectAndResolveChannel(parsed.first())
                        } else {
                            Toast.makeText(this@MainActivity, "No channels found in M3U", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "M3U error: ${e.message}", Toast.LENGTH_LONG).show()
                    } finally {
                        isLoading = false
                        statusMessage = null
                    }
                }
            }

            fun loadXtream(config: XtreamConfig, saveItem: Boolean = true) {
                scope.launch {
                    isLoading = true
                    statusMessage = "Connecting to Xtream..."
                    try {
                        val loaded = withContext(Dispatchers.IO) { XtreamClient.loadAll(config) }
                        if (loaded.isNotEmpty()) {
                            activeXtreamConfig = config
                            if (saveItem) {
                                savedPlaylists = PlaylistStorage.savePlaylist(
                                    prefs,
                                    SavedPlaylist(
                                        id = "xtream_${config.serverUrl.hashCode()}_${config.username}",
                                        name = "Xtream: ${config.username}",
                                        type = SourceType.XTREAM,
                                        primaryUrl = config.serverUrl,
                                        extra1 = config.username,
                                        extra2 = config.password
                                    )
                                )
                            }
                            channels = loaded
                            PlaylistStorage.saveCachedChannels(prefs, loaded)
                            selectAndResolveChannel(loaded.first())
                            loadEpgFromUrl(XtreamClient.getXmltvUrl(config), silent = true)
                        } else {
                            Toast.makeText(this@MainActivity, "Xtream returned 0 items", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Xtream error: ${e.message}", Toast.LENGTH_LONG).show()
                    } finally {
                        isLoading = false
                        statusMessage = null
                    }
                }
            }

            fun loadStalker(config: StalkerConfig, saveItem: Boolean = true) {
                scope.launch {
                    isLoading = true
                    statusMessage = "Connecting to Stalker Portal..."
                    try {
                        val (token, loaded) = withContext(Dispatchers.IO) { StalkerClient.loadAll(config) }
                        if (loaded.isNotEmpty()) {
                            activeStalkerConfig = config
                            activeStalkerToken = token
                            PlaylistStorage.saveStalkerToken(prefs, "${config.portalUrl.hashCode()}_${config.macAddress}", token)
                            if (saveItem) {
                                savedPlaylists = PlaylistStorage.savePlaylist(
                                    prefs,
                                    SavedPlaylist(
                                        id = "stalker_${config.portalUrl.hashCode()}_${config.macAddress}",
                                        name = "Stalker: ${config.macAddress.takeLast(8)}",
                                        type = SourceType.STALKER,
                                        primaryUrl = config.portalUrl,
                                        extra1 = config.macAddress
                                    )
                                )
                            }
                            channels = loaded
                            PlaylistStorage.saveCachedChannels(prefs, loaded)
                            selectAndResolveChannel(loaded.first())
                        } else {
                            Toast.makeText(this@MainActivity, "Stalker returned 0 items", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Stalker error: ${e.message}", Toast.LENGTH_LONG).show()
                    } finally {
                        isLoading = false
                        statusMessage = null
                    }
                }
            }

            val filePickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    scope.launch {
                        isLoading = true
                        statusMessage = "Reading M3U file..."
                        try {
                            val raw = withContext(Dispatchers.IO) {
                                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                            }
                            val parsed = M3uParser.parse(raw)
                            if (parsed.isNotEmpty()) {
                                prefs.edit().putString("last_m3u", raw).apply()
                                channels = parsed
                                selectAndResolveChannel(parsed.first())
                            } else {
                                Toast.makeText(this@MainActivity, "No channels found in file", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "File error: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isLoading = false
                            statusMessage = null
                        }
                    }
                }
            }

            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (isFullscreen) {
                        isFullscreen = false
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            })

            MainTvScreen(
                channels = channels,
                selectedChannel = selectedChannel,
                resolvedStreamUrl = resolvedStreamUrl,
                epgMap = epgMap,
                savedPlaylists = savedPlaylists,
                epgIntervalHours = epgIntervalHours,
                epgLastUpdated = epgLastUpdated,
                seriesEpisodes = seriesEpisodes,
                activeSeriesTitle = activeSeriesTitle,
                isFullscreen = isFullscreen,
                isLoading = isLoading,
                statusMessage = statusMessage,
                onSelectChannel = { selectAndResolveChannel(it) },
                onToggleFavorite = { target ->
                    channels = channels.map {
                        if (it.id == target.id) it.copy(isFavorite = !it.isFavorite) else it
                    }
                    if (selectedChannel?.id == target.id) {
                        selectedChannel = selectedChannel?.copy(isFavorite = !target.isFavorite)
                    }
                },
                onLoadM3uUrl = { loadM3uUrl(it, true) },
                onPickM3uFile = { filePickerLauncher.launch(arrayOf("*/*")) },
                onLoadXtream = { loadXtream(it, true) },
                onLoadStalker = { loadStalker(it, true) },
                onLoadEpgUrl = { loadEpgFromUrl(it, silent = false) },
                onSelectSavedPlaylist = { item ->
                    when (item.type) {
                        SourceType.M3U -> loadM3uUrl(item.primaryUrl, false)
                        SourceType.XTREAM -> loadXtream(XtreamConfig(item.primaryUrl, item.extra1, item.extra2), false)
                        SourceType.STALKER -> loadStalker(StalkerConfig(item.primaryUrl, item.extra1), false)
                    }
                },
                onDeleteSavedPlaylist = { id ->
                    savedPlaylists = PlaylistStorage.deletePlaylist(prefs, id)
                },
                onUpdateEpgInterval = { hrs ->
                    epgIntervalHours = hrs
                    PlaylistStorage.setEpgIntervalHours(prefs, hrs)
                },
                onRefreshEpgNow = {
                    val url = PlaylistStorage.getEpgUrl(prefs)
                    if (url.isNotBlank()) loadEpgFromUrl(url, silent = false)
                    else Toast.makeText(this@MainActivity, "Add an EPG URL first", Toast.LENGTH_SHORT).show()
                },
                onClearCache = {
                    PlaylistStorage.clearCache(prefs)
                    Toast.makeText(this@MainActivity, "Cache cleared!", Toast.LENGTH_SHORT).show()
                },
                onSelectEpisode = { ep ->
                    seriesEpisodes = emptyList()
                    activeSeriesTitle = null
                    selectedChannel = Channel(
                        id = "ep_${ep.id}",
                        number = ep.episodeNum.toIntOrNull() ?: 1,
                        name = "${ep.title} (S${ep.season}E${ep.episodeNum})",
                        streamUrl = ep.streamUrl,
                        group = "Series",
                        mediaType = MediaType.SERIES
                    )
                    resolvedStreamUrl = ep.streamUrl
                    isFullscreen = true
                },
                onDismissEpisodes = {
                    seriesEpisodes = emptyList()
                    activeSeriesTitle = null
                },
                onPlayCatchup = { ch, prog ->
                    if (ch.sourceType == SourceType.XTREAM && activeXtreamConfig != null) {
                        resolvedStreamUrl = XtreamClient.buildCatchupUrl(
                            activeXtreamConfig!!,
                            ch.streamId,
                            prog.startTimeMillis,
                            prog.endTimeMillis
                        )
                        isFullscreen = true
                    } else {
                        Toast.makeText(this@MainActivity, "Catch-up works with Xtream TV Archive channels", Toast.LENGTH_SHORT).show()
                    }
                },
                onToggleFullscreen = { isFullscreen = it }
            )
        }
    }
}
