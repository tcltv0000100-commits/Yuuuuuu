package com.tiviclone.iptv

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.parser.M3uParser
import com.tiviclone.iptv.ui.screens.MainTvScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val scope = rememberCoroutineScope()
            var channels by remember { mutableStateOf(M3uParser.parse(M3uParser.SAMPLE_PLAYLIST)) }
            var selectedChannel by remember { mutableStateOf(channels.firstOrNull()) }
            var isFullscreen by remember { mutableStateOf(false) }
            var isLoading by remember { mutableStateOf(false) }

            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (isFullscreen) {
                        isFullscreen = false
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            })

            MainTvScreen(
                channels = channels,
                selectedChannel = selectedChannel,
                isFullscreen = isFullscreen,
                isLoading = isLoading,
                onSelectChannel = { selectedChannel = it },
                onToggleFavorite = { target ->
                    channels = channels.map {
                        if (it.id == target.id) it.copy(isFavorite = !it.isFavorite) else it
                    }
                    if (selectedChannel?.id == target.id) {
                        selectedChannel = selectedChannel?.copy(isFavorite = !target.isFavorite)
                    }
                },
                onLoadPlaylistUrl = { url ->
                    scope.launch {
                        isLoading = true
                        try {
                            val raw = withContext(Dispatchers.IO) {
                                URL(url).readText()
                            }
                            val parsed = M3uParser.parse(raw)
                            if (parsed.isNotEmpty()) {
                                channels = parsed
                                selectedChannel = parsed.first()
                            } else {
                                Toast.makeText(this@MainActivity, "No channels found in M3U", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "Failed to load: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isLoading = false
                        }
                    }
                },
                onToggleFullscreen = { isFullscreen = it }
            )
        }
    }
}
