package com.tiviclone.iptv

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import com.tiviclone.iptv.model.Channel
import com.tiviclone.iptv.model.EpgProgram
import com.tiviclone.iptv.model.SourceType
import com.tiviclone.iptv.model.StalkerConfig
import com.tiviclone.iptv.model.XtreamConfig
import com.tiviclone.iptv.network.HttpClientProvider
import com.tiviclone.iptv.network.StalkerClient
import com.tiviclone.iptv.network.XtreamClient
import com.tiviclone.iptv.parser.M3uParser
import com.tiviclone.iptv.parser.XmltvEpgParser
import com.tiviclone.iptv.ui.screens.MainTvScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("tiviclone_prefs", Context.MODE_PRIVATE)

        setContent {
            val scope = rememberCoroutineScope()
            var channels by remember {
                val savedM3u = prefs.getString("last_m3u", null)
                val initial = if (!savedM3u.isNullOrBlank()) M3uParser.parse(savedM3u)
                else M3uParser.parse(M3uParser.SAMPLE_PLAYLIST)
                mutableStateOf(initial.ifEmpty { M3uParser.parse(M3uParser.SAMPLE_PLAYLIST) })
            }
            var selectedChannel by remember { mutableStateOf(channels.firstOrNull()) }
            var resolvedStreamUrl by remember { mutableStateOf<String?>(null) }
            var epgMap by remember { mutableStateOf<Map<String, List<EpgProgram>>>(emptyMap()) }
            var isFullscreen by remember { mutableStateOf(false) }
            var isLoading by remember { mutableStateOf(false) }
            var statusMessage by remember { mutableStateOf<String?>(null) }

            var activeXtreamConfig by remember { mutableStateOf<XtreamConfig?>(null) }
            var activeStalkerConfig by remember { mutableStateOf<StalkerConfig?>(null) }
            var activeStalkerToken by remember { mutableStateOf<String?>(null) }

            val filePickerLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    scope.launch {
                        isLoading = true
                        statusMessage = "Reading M3U file..."
                        try {
                            val raw = withContext(Dispatchers.IO) {
                                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                            }
                            val parsed = M3uParser.parse(raw)
                            if (parsed.isNotEmpty()) {
                                prefs.edit().putString("last_m3u", raw).apply()
                                channels = parsed
                                selectedChannel = parsed.first()
                                resolvedStreamUrl = null
                            } else {
                                Toast.makeText(this@MainActivity, "No channels found in file", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "File error: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isLoading = false
                            statusMessage = null
                        }
                    }
                }
            }

            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (isFullscreen) {
                        isFullscreen = false
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            })

            fun selectAndResolveChannel(ch: Channel) {
                selectedChannel = ch
                if (ch.sourceType == SourceType.STALKER && activeStalkerConfig != null && activeStalkerToken != null) {
                    scope.launch {
                        val link = withContext(Dispatchers.IO) {
                            StalkerClient.createStreamLink(activeStalkerConfig!!, activeStalkerToken!!, ch.stalkerCmd)
                        }
                        resolvedStreamUrl = link ?: ch.streamUrl
                    }
                } else {
                    resolvedStreamUrl = null
                }
            }

            MainTvScreen(
                channels = channels,
                selectedChannel = selectedChannel,
                resolvedStreamUrl = resolvedStreamUrl,
                epgMap = epgMap,
                isFullscreen = isFullscreen,
                isLoading = isLoading,
                statusMessage = statusMessage,
                onSelectChannel = { selectAndResolveChannel(it) },
                onToggleFavorite = { target ->
                    channels = channels.map {
                        if (it.id == target.id) it.copy(isFavorite = !it.isFavorite) else it
                    }
                    if (selectedChannel?.id == target.id) {
                        selectedChannel = selectedChannel?.copy(isFavorite = !target.isFavorite)
                    }
                },
                onLoadM3uUrl = { url ->
                    scope.launch {
                        isLoading = true
                        statusMessage = "Downloading M3U..."
                        try {
                            val raw = withContext(Dispatchers.IO) {
                                val req = Request.Builder().url(url).build()
                                HttpClientProvider.sharedClient.newCall(req).execute().use { it.body?.string().orEmpty() }
                            }
                            val parsed = M3uParser.parse(raw)
                            if (parsed.isNotEmpty()) {
                                prefs.edit().putString("last_m3u", raw).apply()
                                channels = parsed
                                selectAndResolveChannel(parsed.first())
                            } else {
                                Toast.makeText(this@MainActivity, "No channels found in M3U", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "M3U error: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isLoading = false
                            statusMessage = null
                        }
                    }
                },
                onPickM3uFile = {
                    filePickerLauncher.launch(arrayOf("*/*"))
                },
                onLoadXtream = { config ->
                    scope.launch {
                        isLoading = true
                        statusMessage = "Connecting to Xtream..."
                        try {
                            val loaded = withContext(Dispatchers.IO) {
                                XtreamClient.loadChannels(config)
                            }
                            if (loaded.isNotEmpty()) {
                                activeXtreamConfig = config
                                channels = loaded
                                selectAndResolveChannel(loaded.first())
                                // Auto-fetch XMLTV EPG in background
                                launch {
                                    val xml = withContext(Dispatchers.IO) {
                                        val req = Request.Builder().url(XtreamClient.getXmltvUrl(config)).build()
                                        runCatching {
                                            HttpClientProvider.sharedClient.newCall(req).execute().use { it.body?.string().orEmpty() }
                                        }.getOrDefault("")
                                    }
                                    if (xml.isNotBlank()) {
                                        epgMap = withContext(Dispatchers.Default) { XmltvEpgParser.parse(xml) }
                                    }
                                }
                            } else {
                                Toast.makeText(this@MainActivity, "Xtream returned 0 channels", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "Xtream error: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isLoading = false
                            statusMessage = null
                        }
                    }
                },
                onLoadStalker = { config ->
                    scope.launch {
                        isLoading = true
                        statusMessage = "Connecting to Stalker Portal..."
                        try {
                            val (token, loaded) = withContext(Dispatchers.IO) {
                                StalkerClient.loadChannels(config)
                            }
                            if (loaded.isNotEmpty()) {
                                activeStalkerConfig = config
                                activeStalkerToken = token
                                channels = loaded
                                selectAndResolveChannel(loaded.first())
                            } else {
                                Toast.makeText(this@MainActivity, "Stalker returned 0 channels", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "Stalker error: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isLoading = false
                            statusMessage = null
                        }
                    }
                },
                onLoadEpgUrl = { url ->
                    scope.launch {
                        isLoading = true
                        statusMessage = "Loading EPG..."
                        try {
                            val xml = withContext(Dispatchers.IO) {
                                val req = Request.Builder().url(url).build()
                                HttpClientProvider.sharedClient.newCall(req).execute().use { it.body?.string().orEmpty() }
                            }
                            if (xml.isNotBlank()) {
                                epgMap = withContext(Dispatchers.Default) { XmltvEpgParser.parse(xml) }
                                Toast.makeText(this@MainActivity, "EPG loaded!", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "EPG error: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isLoading = false
                            statusMessage = null
                        }
                    }
                },
                onPlayCatchup = { ch, prog ->
                    if (ch.sourceType == SourceType.XTREAM && activeXtreamConfig != null) {
                        resolvedStreamUrl = XtreamClient.buildCatchupUrl(
                            activeXtreamConfig!!,
                            ch.streamId,
                            prog.startTimeMillis,
                            prog.endTimeMillis
                        )
                        isFullscreen = true
                    } else {
                        Toast.makeText(this@MainActivity, "Catch-up works with Xtream TV Archive channels", Toast.LENGTH_SHORT).show()
                    }
                },
                onToggleFullscreen = { isFullscreen = it }
            )
        }
    }
}
