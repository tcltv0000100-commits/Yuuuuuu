# TiviClone IPTV — Developer: mrbeats 7.8

TiviMate-inspired Android TV & Mobile IPTV Player built with **Kotlin**, **Jetpack Compose**, **Coil**, **OkHttp**, and **AndroidX Media3 (ExoPlayer)**.

## Features
- **Live TV, Movies & Series Sections:** Dedicated tabs for Live TV, VOD Movies, and Series.
- **M3U URL, Local `.m3u` File, Xtream Codes & Stalker Portal:** Auto-generates Stalker `sn` (MD5 13-char) and `device_id` (SHA-256) from MAC address.
- **Saved Playlists & EPG Schedule:** Persists added playlists/portals and supports scheduled XMLTV EPG updates.
- **Channel Logos & Aspect Ratios:** Displays channel logos via Coil and supports Fit, 16:9, 20:9, 4:3, Fill, and Zoom.
- **Background Audio Fix:** Automatically pauses playback when switching away from the app.
