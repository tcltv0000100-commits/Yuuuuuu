# TiviClone IPTV — Full Multi-Protocol Android TV & Mobile Player

A TiviMate-inspired IPTV Player built with **Kotlin**, **Jetpack Compose**, **OkHttp**, and **AndroidX Media3 (ExoPlayer)**.

## Features
- **Universal Stream Playback:** HLS (`.m3u8`), MPEG-TS (`.ts`), DASH (`.mpd`), RTSP, MP4/MKV, HTTP/HTTPS cross-protocol redirects, and custom User-Agent via `OkHttpDataSource`.
- **M3U URL & Local File Picker:** Load M3U/M3U8 from any URL or pick a `.m3u`/`.m3u8` file directly from device storage.
- **Xtream Codes API:** Login with Server URL, Username, and Password to load Live TV, VOD, XMLTV EPG, and Catch-up/Timeshift streams.
- **Stalker / Ministra Portal:** Connect using Portal URL and MAC Address (`handshake` + `get_all_channels` + `create_link`).
- **EPG & Catch-up Guide:** Displays current program ("Now Playing") and allows playing archived/catch-up programs where supported.
- **Saved Playlists & Favorites:** Automatically persists your last loaded playlist and favorite channels.
