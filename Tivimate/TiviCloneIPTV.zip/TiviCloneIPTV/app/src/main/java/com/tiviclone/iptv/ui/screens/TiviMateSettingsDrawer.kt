package com.tiviclone.iptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.data.db.PlaylistEntity
import com.tiviclone.iptv.data.repository.SettingsStore
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SettingsPage(val title: String) {
    ROOT("Settings"),
    GENERAL("General"),
    PLAYLISTS("Playlists"),
    EPG("EPG"),
    APPEARANCE("Appearance"),
    PLAYBACK("Playback"),
    REMOTE("Remote control"),
    PARENTAL("Parental controls"),
    OTHER("Other"),
    ABOUT("About")
}

@Composable
fun TiviMateSettingsDrawer(
    settings: SettingsStore,
    playlists: List<PlaylistEntity>,
    activePlaylistId: String,
    epgIntervalHours: Int,
    epgLastUpdated: Long,
    parentalPin: String,
    onSelectPlaylist: (String) -> Unit,
    onAddPlaylist: () -> Unit,
    onEditPlaylist: (PlaylistEntity) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onSyncAll: () -> Unit,
    onUpdateEpgInterval: (Int) -> Unit,
    onSetParentalPin: (String) -> Unit,
    onExportBackup: suspend () -> String,
    onImportBackup: (String) -> Unit,
    onClose: () -> Unit
) {
    var page by remember { mutableStateOf(SettingsPage.ROOT) }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var showBackupDialog by remember { mutableStateOf(false) }
    var backupText by remember { mutableStateOf("") }

    // Reactive toggles backed by SettingsStore
    var autoBoot by remember { mutableStateOf(settings.isAutoStartBoot()) }
    var autoWake by remember { mutableStateOf(settings.isAutoStartWake()) }
    var turnOnLast by remember { mutableStateOf(settings.isTurnOnLastChannel()) }
    var pipHome by remember { mutableStateOf(settings.isPipOnHome()) }
    var confirmExit by remember { mutableStateOf(settings.isConfirmExitBack()) }
    var userAgent by remember { mutableStateOf(settings.getUserAgent()) }
    var udpProxy by remember { mutableStateOf(settings.getUdpProxy()) }

    var epgPastDays by remember { mutableIntStateOf(settings.getEpgPastDays()) }
    var storeEpgDesc by remember { mutableStateOf(settings.isStoreProgramDesc()) }
    var epgOnStart by remember { mutableStateOf(settings.isEpgUpdateOnStart()) }
    var epgOnChange by remember { mutableStateOf(settings.isEpgUpdateOnPlaylistChange()) }

    var fontSize by remember { mutableStateOf(settings.getFontSize()) }
    var transparency by remember { mutableIntStateOf(settings.getUiTransparency()) }

    var bufferSize by remember { mutableStateOf(settings.getBufferSize()) }
    var audioDec by remember { mutableStateOf(settings.getAudioDecoder()) }
    var videoDec by remember { mutableStateOf(settings.getVideoDecoder()) }
    var afrEnabled by remember { mutableStateOf(settings.isAfrEnabled()) }
    var surroundDef by remember { mutableStateOf(settings.isSurroundDefault()) }
    var passthrough by remember { mutableStateOf(settings.isAudioPassthrough()) }
    var useExtPlayer by remember { mutableStateOf(settings.isUseExternalPlayer()) }

    var pinInput by remember(parentalPin) { mutableStateOf(parentalPin) }
    var textEditDialog by remember { mutableStateOf<Triple<String, String, (String) -> Unit>?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x88000000))
            .clickable { onClose() }
    ) {
        Column(
            modifier = Modifier
                .width(340.dp)
                .fillMaxHeight()
                .align(Alignment.CenterEnd)
                .background(Color(0xFF1A1D21))
                .clickable(enabled = false) {}
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF262A30))
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (page != SettingsPage.ROOT) {
                    IconButton(onClick = { page = SettingsPage.ROOT }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                }
                Text(page.title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Normal)
            }

            LazyColumn(
                modifier = Modifier.weight(1f).padding(vertical = 8.dp)
            ) {
                when (page) {
                    SettingsPage.ROOT -> {
                        val entries = listOf(
                            SettingsPage.GENERAL,
                            SettingsPage.PLAYLISTS,
                            SettingsPage.EPG,
                            SettingsPage.APPEARANCE,
                            SettingsPage.PLAYBACK,
                            SettingsPage.REMOTE,
                            SettingsPage.PARENTAL,
                            SettingsPage.OTHER,
                            SettingsPage.ABOUT
                        )
                        items(entries) { item ->
                            DrawerMenuRow(item.title) { page = item }
                        }
                    }

                    SettingsPage.GENERAL -> {
                        item {
                            DrawerSwitchRow("Auto start app on boot", null, autoBoot) {
                                autoBoot = it; settings.setAutoStartBoot(it)
                            }
                            DrawerSwitchRow("Auto start app on wake up from sleep mode", "May not work on all devices", autoWake) {
                                autoWake = it; settings.setAutoStartWake(it)
                            }
                            DrawerSwitchRow("Turn on last channel on app start", null, turnOnLast) {
                                turnOnLast = it; settings.setTurnOnLastChannel(it)
                            }
                            DrawerSwitchRow("Switch to picture-in-picture mode on press Home", null, pipHome) {
                                pipHome = it; settings.setPipOnHome(it)
                            }
                            DrawerSwitchRow("Confirm exit by second press Back", null, confirmExit) {
                                confirmExit = it; settings.setConfirmExitBack(it)
                            }
                            DrawerValueRow("User-Agent", userAgent.ifBlank { "Not set" }) {
                                textEditDialog = Triple("User-Agent", userAgent) {
                                    userAgent = it; settings.setUserAgent(it)
                                }
                            }
                            DrawerValueRow("UDP proxy (address:port)", udpProxy.ifBlank { "Not set" }) {
                                textEditDialog = Triple("UDP proxy (address:port)", udpProxy) {
                                    udpProxy = it; settings.setUdpProxy(it)
                                }
                            }
                            DrawerMenuRow("Back up data") {
                                scope.launch {
                                    backupText = onExportBackup()
                                    clipboard.setText(AnnotatedString(backupText))
                                    showBackupDialog = true
                                }
                            }
                            DrawerMenuRow("Restore data") {
                                backupText = ""
                                showBackupDialog = true
                            }
                        }
                    }

                    SettingsPage.PLAYLISTS -> {
                        item {
                            DrawerMenuRow("+ Add playlist", highlight = true) {
                                onClose()
                                onAddPlaylist()
                            }
                            DrawerValueRow("All playlists", if (activePlaylistId == "ALL") "Active" else "Tap to show all") {
                                onSelectPlaylist("ALL")
                            }
                        }
                        items(playlists, key = { it.id }) { pl ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .tvFocusableBorder(4)
                                    .clickable { onSelectPlaylist(pl.id) }
                                    .padding(horizontal = 20.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "${pl.name} (${pl.type.name})",
                                        color = if (pl.id == activePlaylistId) TiviColors.AccentBlue else Color.White,
                                        fontSize = 14.sp
                                    )
                                    Text(pl.primaryUrl, color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                IconButton(onClick = { onClose(); onEditPlaylist(pl) }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TiviColors.AccentBlue, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onDeletePlaylist(pl.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TiviColors.DangerRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    SettingsPage.EPG -> {
                        val lastStr = if (epgLastUpdated <= 0L) "—"
                        else SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(epgLastUpdated))
                        item {
                            DrawerMenuRow("EPG sources") { page = SettingsPage.PLAYLISTS }
                            DrawerValueRow("Past days to keep EPG", "$epgPastDays") {
                                val next = when (epgPastDays) { 3 -> 7; 7 -> 14; else -> 3 }
                                epgPastDays = next; settings.setEpgPastDays(next)
                            }
                            DrawerSwitchRow("Store program descriptions", null, storeEpgDesc) {
                                storeEpgDesc = it; settings.setStoreProgramDesc(it)
                            }
                            Text(
                                "Update options",
                                color = TiviColors.AccentBlue,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                            )
                            DrawerValueRow("Update interval, hours", "$epgInterval") {
                                val next = when (epgIntervalHours) { 4 -> 12; 12 -> 24; else -> 4 }
                                onUpdateEpgInterval(next)
                            }
                            DrawerSwitchRow("Update on app start", null, epgOnStart) {
                                epgOnStart = it; settings.setEpgUpdateOnStart(it)
                            }
                            DrawerSwitchRow("Update on playlists change", null, epgOnChange) {
                                epgOnChange = it; settings.setEpgUpdateOnPlaylistChange(it)
                            }
                            DrawerMenuRow("Update EPG") { onSyncAll() }
                            DrawerMenuRow("Clear EPG") {}
                            DrawerValueRow("Latest update status", lastStr) {}
                        }
                    }

                    SettingsPage.APPEARANCE -> {
                        item {
                            DrawerMenuRow("TV guide") {}
                            DrawerMenuRow("Player") {}
                            DrawerMenuRow("Groups") {}
                            DrawerMenuRow("Logos") {}
                            DrawerValueRow("Language", "System") {}
                            DrawerValueRow("Font size", fontSize) {
                                val next = when (fontSize) { "Small" -> "Medium"; "Medium" -> "Large"; else -> "Small" }
                                fontSize = next; settings.setFontSize(next)
                            }
                            DrawerValueRow("Color theme", "Dark • Blue") {}
                            DrawerValueRow("User interface transparency, %", "$transparency") {
                                val next = (transparency + 25) % 100
                                transparency = next; settings.setUiTransparency(next)
                            }
                        }
                    }

                    SettingsPage.PLAYBACK -> {
                        item {
                            DrawerValueRow("Buffer size", bufferSize) {
                                val next = when (bufferSize) { "Small" -> "Normal"; "Normal" -> "Large"; else -> "Small" }
                                bufferSize = next; settings.setBufferSize(next)
                            }
                            DrawerValueRow("Audio decoder", audioDec) {
                                val next = if (audioDec == "Hardware") "Software (FFmpeg)" else "Hardware"
                                audioDec = next; settings.setAudioDecoder(next)
                            }
                            DrawerValueRow("Video decoder", videoDec) {
                                val next = if (videoDec == "Hardware") "Software" else "Hardware"
                                videoDec = next; settings.setVideoDecoder(next)
                            }
                            DrawerSwitchRow("Auto frame rate (AFR)", null, afrEnabled) {
                                afrEnabled = it; settings.setAfrEnabled(it)
                            }
                            DrawerSwitchRow("Select surround audio track by default", null, surroundDef) {
                                surroundDef = it; settings.setSurroundDefault(it)
                            }
                            DrawerSwitchRow("Audio passthrough", null, passthrough) {
                                passthrough = it; settings.setAudioPassthrough(it)
                            }
                            DrawerValueRow("Use external player", if (useExtPlayer) "Yes" else "No") {
                                useExtPlayer = !useExtPlayer; settings.setUseExternalPlayer(useExtPlayer)
                            }
                            DrawerMenuRow("Skip steps") {}
                        }
                    }

                    SettingsPage.REMOTE -> {
                        item {
                            DrawerValueRow("0–9 Number keys", "Channel zapping") {}
                            DrawerValueRow("DPAD Up / Down", "Switch channel") {}
                            DrawerValueRow("DPAD Left / Guide", "Live Guide overlay") {}
                        }
                    }

                    SettingsPage.PARENTAL -> {
                        item {
                            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Parental Control PIN (blank = off)", color = Color.White, fontSize = 14.sp)
                                OutlinedTextField(
                                    value = pinInput,
                                    onValueChange = { if (it.length <= 6) pinInput = it },
                                    singleLine = true,
                                    label = { Text("PIN") }
                                )
                                Button(onClick = { onSetParentalPin(pinInput.trim()) }) {
                                    Text("Save PIN")
                                }
                            }
                        }
                    }

                    SettingsPage.OTHER -> {
                        item {
                            DrawerMenuRow("Sync all playlists & EPG") { onSyncAll() }
                        }
                    }

                    SettingsPage.ABOUT -> {
                        item {
                            DrawerValueRow("TiviClone IPTV", "v4.0.0 (TiviMate Engine)") {}
                            DrawerValueRow("Player Engine", "Media3 1.5.0 + FFmpeg") {}
                        }
                    }
                }
            }
        }
    }

    textEditDialog?.let { (title, current, onSave) ->
        var txt by remember { mutableStateOf(current) }
        AlertDialog(
            onDismissRequest = { textEditDialog = null },
            title = { Text(title) },
            text = { OutlinedTextField(value = txt, onValueChange = { txt = it }, singleLine = true) },
            confirmButton = {
                Button(onClick = { onSave(txt.trim()); textEditDialog = null }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { textEditDialog = null }) { Text("Cancel") }
            }
        )
    }

    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("Backup / Restore JSON") },
            text = {
                OutlinedTextField(
                    value = backupText,
                    onValueChange = { backupText = it },
                    modifier = Modifier.fillMaxWidth().height(200.dp)
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (backupText.isNotBlank()) onImportBackup(backupText)
                    showBackupDialog = false
                }) { Text("Restore") }
            },
            dismissButton = {
                TextButton(onClick = { showBackupDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
fun PlaylistTypeWizard(
    onSelectM3u: () -> Unit,
    onSelectXtream: () -> Unit,
    onSelectStalker: () -> Unit,
    onCancel: () -> Unit
) {
    Row(modifier = Modifier.fillMaxSize().background(Color(0xFF14171A))) {
        // Left column
        Box(
            modifier = Modifier
                .weight(0.45f)
                .fillMaxHeight()
                .background(Color(0xFF22262B))
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Icon(Icons.Default.PlaylistAdd, contentDescription = null, tint = Color.White, modifier = Modifier.size(56.dp))
                Text("Playlist type", color = Color.White, fontSize = 24.sp)
            }
        }

        // Middle column
        Column(
            modifier = Modifier
                .weight(0.35f)
                .fillMaxHeight()
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            DrawerMenuRow("M3U playlist", onClick = onSelectM3u)
            DrawerMenuRow("Xtream Codes", onClick = onSelectXtream)
            DrawerMenuRow("Stalker Portal", onClick = onSelectStalker)
        }

        // Right column
        Box(
            modifier = Modifier
                .weight(0.20f)
                .fillMaxHeight()
                .padding(16.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            TextButton(onClick = onCancel) {
                Text("Cancel", color = Color.White, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun DrawerMenuRow(label: String, highlight: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Text(label, color = if (highlight) TiviColors.AccentBlue else Color.White, fontSize = 15.sp)
    }
}

@Composable
private fun DrawerValueRow(label: String, value: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(label, color = Color.White, fontSize = 14.sp)
        Text(value, color = TiviColors.TextSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun DrawerSwitchRow(label: String, subtitle: String?, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(label, color = Color.White, fontSize = 14.sp)
            if (!subtitle.isNullOrBlank()) {
                Text(subtitle, color = TiviColors.TextSecondary, fontSize = 11.sp)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
