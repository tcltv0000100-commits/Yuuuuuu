package com.tiviclone.iptv.data.repository

import android.content.Context
import android.net.Uri
import com.tiviclone.iptv.data.db.*
import com.tiviclone.iptv.data.model.SourceType
import com.tiviclone.iptv.data.model.StalkerConfig
import com.tiviclone.iptv.data.model.XtreamConfig
import com.tiviclone.iptv.data.network.HttpClientProvider
import com.tiviclone.iptv.data.network.StalkerClient
import com.tiviclone.iptv.data.network.XtreamClient
import com.tiviclone.iptv.data.parser.M3uParser
import com.tiviclone.iptv.data.parser.XmltvEpgParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class GlobalSearchResults(
    val channels: List<ChannelEntity> = emptyList(),
    val movies: List<VodMovieEntity> = emptyList(),
    val series: List<SeriesEntity> = emptyList(),
    val programs: List<EpgProgramEntity> = emptyList()
)

class IptvRepository(
    private val context: Context,
    private val db: AppDatabase,
    private val settings: SettingsStore
) {
    fun observePlaylists(): Flow<List<PlaylistEntity>> = db.playlistDao().observeAll()
    fun observeChannels(playlistId: String): Flow<List<ChannelEntity>> =
        if (playlistId == "ALL" || playlistId.isBlank()) db.channelDao().observeAll() else db.channelDao().observeByPlaylist(playlistId)
    fun observeFavoriteChannels(): Flow<List<ChannelEntity>> = db.channelDao().observeFavorites()
    fun observeMovies(playlistId: String): Flow<List<VodMovieEntity>> =
        if (playlistId == "ALL" || playlistId.isBlank()) db.vodDao().observeAll() else db.vodDao().observeByPlaylist(playlistId)
    fun observeFavoriteMovies(): Flow<List<VodMovieEntity>> = db.vodDao().observeFavorites()
    fun observeSeries(playlistId: String): Flow<List<SeriesEntity>> =
        if (playlistId == "ALL" || playlistId.isBlank()) db.seriesDao().observeAll() else db.seriesDao().observeByPlaylist(playlistId)
    fun observeFavoriteSeries(): Flow<List<SeriesEntity>> = db.seriesDao().observeFavorites()
    fun observeEpisodes(seriesDbId: String): Flow<List<EpisodeEntity>> = db.seriesDao().observeEpisodes(seriesDbId)
    fun observeEpg(): Flow<List<EpgProgramEntity>> = db.epgDao().observeUpcomingAndCurrent(System.currentTimeMillis() - 6 * 3600_000L)
    fun observeContinueWatching(): Flow<List<WatchHistoryEntity>> = db.watchHistoryDao().observeContinueWatching()
    fun observeRecordings(): Flow<List<RecordingEntity>> = db.recordingDao().observeAll()
    fun observeReminders(): Flow<List<ReminderEntity>> = db.reminderDao().observeAll()

    suspend fun addOrSyncM3uUrl(
        name: String,
        url: String,
        epgUrl: String = "",
        existingId: String? = null,
        includeVod: Boolean = true
    ): PlaylistEntity = withContext(Dispatchers.IO) {
        val id = existingId ?: UUID.randomUUID().toString()
        val req = Request.Builder().url(url.trim()).build()
        val parsed = HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("HTTP ${resp.code}")
            val stream = resp.body?.byteStream() ?: error("Empty M3U body")
            M3uParser.parse(id, stream)
        }
        val movies = if (includeVod) parsed.movies else emptyList()
        val entity = PlaylistEntity(
            id = id,
            name = name.ifBlank { "M3U Playlist" },
            type = SourceType.M3U,
            primaryUrl = url.trim(),
            epgUrl = epgUrl.trim(),
            includeVod = includeVod,
            channelsCount = parsed.channels.size,
            moviesCount = movies.size,
            seriesCount = 0,
            lastSyncedAt = System.currentTimeMillis()
        )
        replacePlaylistContent(entity, parsed.channels, movies, emptyList())
        if (epgUrl.isNotBlank()) syncEpgUrl(id, epgUrl)
        entity
    }

    suspend fun addM3uFile(name: String, uri: Uri): PlaylistEntity = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val parsed = context.contentResolver.openInputStream(uri)?.use { stream ->
            M3uParser.parse(id, stream)
        } ?: error("Cannot open M3U file")
        val entity = PlaylistEntity(
            id = id,
            name = name.ifBlank { "Local M3U" },
            type = SourceType.M3U,
            primaryUrl = uri.toString(),
            channelsCount = parsed.channels.size,
            moviesCount = parsed.movies.size,
            lastSyncedAt = System.currentTimeMillis()
        )
        replacePlaylistContent(entity, parsed.channels, parsed.movies, emptyList())
        entity
    }

    suspend fun addOrSyncXtream(
        name: String,
        cfg: XtreamConfig,
        existingId: String? = null,
        includeVod: Boolean = true,
        outputFormat: String = "MPEG-TS"
    ): PlaylistEntity = withContext(Dispatchers.IO) {
        val id = existingId ?: UUID.randomUUID().toString()
        val result = XtreamClient.loadAll(id, cfg)
        val xmltv = XtreamClient.getXmltvUrl(cfg)
        val movies = if (includeVod) result.movies else emptyList()
        val series = if (includeVod) result.series else emptyList()
        val ext = if (outputFormat == "HLS") ".m3u8" else ".ts"
        val channels = result.channels.map { ch ->
            if (outputFormat == "HLS") ch.copy(streamUrl = ch.streamUrl.replace(".ts", ext)) else ch
        }
        val entity = PlaylistEntity(
            id = id,
            name = name.ifBlank { cfg.username },
            type = SourceType.XTREAM,
            primaryUrl = cfg.serverUrl.trim().trimEnd('/'),
            extra1 = cfg.username.trim(),
            extra2 = cfg.password.trim(),
            epgUrl = xmltv,
            accountStatus = result.accountInfo.status,
            accountExpiry = result.accountInfo.expDate,
            maxConnections = result.accountInfo.maxConnections,
            activeConnections = result.accountInfo.activeCons,
            includeVod = includeVod,
            outputFormat = outputFormat,
            channelsCount = channels.size,
            moviesCount = movies.size,
            seriesCount = series.size,
            lastSyncedAt = System.currentTimeMillis()
        )
        replacePlaylistContent(entity, channels, movies, series)
        runCatching { syncEpgUrl(id, xmltv) }
        entity
    }

    suspend fun addOrSyncStalker(
        name: String,
        cfg: StalkerConfig,
        existingId: String? = null,
        includeVod: Boolean = true
    ): PlaylistEntity = withContext(Dispatchers.IO) {
        val id = existingId ?: UUID.randomUUID().toString()
        val result = StalkerClient.loadAll(id, cfg)
        val movies = if (includeVod) result.movies else emptyList()
        val series = if (includeVod) result.series else emptyList()
        val entity = PlaylistEntity(
            id = id,
            name = name.ifBlank { "Stalker Portal" },
            type = SourceType.STALKER,
            primaryUrl = result.activePortalUrl,
            extra1 = cfg.macAddress.trim().uppercase(),
            stalkerToken = result.token,
            stbType = cfg.stbType,
            serialNumber = cfg.serialNumber,
            deviceId = cfg.deviceId,
            deviceId2 = cfg.deviceId2,
            signature = cfg.signature,
            includeVod = includeVod,
            channelsCount = result.channels.size,
            moviesCount = movies.size,
            seriesCount = series.size,
            lastSyncedAt = System.currentTimeMillis()
        )
        replacePlaylistContent(entity, result.channels, movies, series)
        entity
    }

    private suspend fun replacePlaylistContent(
        playlist: PlaylistEntity,
        channels: List<ChannelEntity>,
        movies: List<VodMovieEntity>,
        series: List<SeriesEntity>
    ) {
        db.playlistDao().upsert(playlist)
        db.channelDao().deleteByPlaylist(playlist.id)
        db.vodDao().deleteByPlaylist(playlist.id)
        db.seriesDao().deleteEpisodesByPlaylist(playlist.id)
        db.seriesDao().deleteByPlaylist(playlist.id)

        if (channels.isNotEmpty()) db.channelDao().insertAll(channels)
        if (movies.isNotEmpty()) db.vodDao().insertAll(movies)
        if (series.isNotEmpty()) db.seriesDao().insertAllSeries(series)
    }

    suspend fun setPlaylistEnabled(id: String, enabled: Boolean) =
        db.playlistDao().setEnabled(id, enabled)

    suspend fun syncEpgUrl(playlistId: String, epgUrl: String) = withContext(Dispatchers.IO) {
        if (epgUrl.isBlank()) return@withContext
        val req = Request.Builder().url(epgUrl.trim()).build()
        HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("EPG HTTP ${resp.code}")
            val stream = resp.body?.byteStream() ?: error("Empty EPG")
            db.epgDao().deleteByPlaylist(playlistId)
            XmltvEpgParser.parse(playlistId, stream) { batch ->
                kotlinx.coroutines.runBlocking {
                    db.epgDao().insertAll(batch)
                }
            }
            settings.setEpgLastUpdated(System.currentTimeMillis())
        }
    }

    suspend fun syncAllPlaylists() {
        val all = db.playlistDao().getAll().filter { it.isEnabled }
        for (pl in all) {
            runCatching {
                when (pl.type) {
                    SourceType.M3U -> if (pl.primaryUrl.startsWith("http")) {
                        addOrSyncM3uUrl(pl.name, pl.primaryUrl, pl.epgUrl, pl.id, pl.includeVod)
                    }
                    SourceType.XTREAM -> addOrSyncXtream(
                        pl.name,
                        XtreamConfig(pl.primaryUrl, pl.extra1, pl.extra2),
                        pl.id,
                        pl.includeVod,
                        pl.outputFormat
                    )
                    SourceType.STALKER -> addOrSyncStalker(
                        pl.name,
                        StalkerConfig(pl.primaryUrl, pl.extra1, pl.stbType, pl.serialNumber, pl.deviceId, pl.deviceId2, pl.signature),
                        pl.id,
                        pl.includeVod
                    )
                }
            }
        }
        db.epgDao().pruneOld(System.currentTimeMillis() - 24 * 3600_000L)
    }

    suspend fun fetchMovieDetails(movie: VodMovieEntity): VodMovieEntity {
        if (movie.detailsFetched || movie.sourceType != SourceType.XTREAM) return movie
        val pl = db.playlistDao().getById(movie.playlistId) ?: return movie
        val cfg = XtreamConfig(pl.primaryUrl, pl.extra1, pl.extra2)
        val updated = XtreamClient.loadVodInfo(cfg, movie)
        db.vodDao().upsert(updated)
        return updated
    }

    suspend fun fetchSeriesDetailsAndEpisodes(series: SeriesEntity): Pair<SeriesEntity, List<EpisodeEntity>> {
        val existingEps = db.seriesDao().getEpisodes(series.id)
        if (series.detailsFetched && existingEps.isNotEmpty()) {
            return series to existingEps
        }
        val pl = db.playlistDao().getById(series.playlistId) ?: return series to existingEps
        return when (series.sourceType) {
            SourceType.XTREAM -> {
                val cfg = XtreamConfig(pl.primaryUrl, pl.extra1, pl.extra2)
                val (updated, eps) = XtreamClient.loadSeriesDetails(pl.id, cfg, series)
                db.seriesDao().upsertSeries(updated)
                if (eps.isNotEmpty()) db.seriesDao().insertEpisodes(eps)
                updated to eps
            }
            SourceType.STALKER -> {
                val cfg = StalkerConfig(pl.primaryUrl, pl.extra1, pl.stbType, pl.serialNumber, pl.deviceId, pl.deviceId2, pl.signature)
                val eps = StalkerClient.loadSeriesEpisodes(pl.id, cfg, pl.stalkerToken, series)
                val updated = series.copy(detailsFetched = true)
                db.seriesDao().upsertSeries(updated)
                if (eps.isNotEmpty()) db.seriesDao().insertEpisodes(eps)
                updated to eps
            }
            else -> series to existingEps
        }
    }

    suspend fun resolveChannelStream(channel: ChannelEntity): String {
        if (channel.sourceType != SourceType.STALKER) return channel.streamUrl
        val pl = db.playlistDao().getById(channel.playlistId) ?: return channel.streamUrl
        return StalkerClient.createStreamLink(pl.primaryUrl, StalkerConfig(pl.primaryUrl, pl.extra1, pl.stbType, pl.serialNumber, pl.deviceId, pl.deviceId2, pl.signature), pl.stalkerToken, channel.stalkerCmd, "itv")
            ?: channel.streamUrl
    }

    suspend fun resolveVodStream(movie: VodMovieEntity): String {
        if (movie.sourceType != SourceType.STALKER) return movie.streamUrl
        val pl = db.playlistDao().getById(movie.playlistId) ?: return movie.streamUrl
        return StalkerClient.createStreamLink(pl.primaryUrl, StalkerConfig(pl.primaryUrl, pl.extra1, pl.stbType, pl.serialNumber, pl.deviceId, pl.deviceId2, pl.signature), pl.stalkerToken, movie.stalkerCmd, "vod")
            ?: movie.streamUrl
    }

    suspend fun resolveEpisodeStream(ep: EpisodeEntity): String {
        if (ep.sourceType != SourceType.STALKER) return ep.streamUrl
        val pl = db.playlistDao().getById(ep.playlistId) ?: return ep.streamUrl
        return StalkerClient.createStreamLink(pl.primaryUrl, StalkerConfig(pl.primaryUrl, pl.extra1, pl.stbType, pl.serialNumber, pl.deviceId, pl.deviceId2, pl.signature), pl.stalkerToken, ep.stalkerCmd, "vod")
            ?: ep.streamUrl
    }

    suspend fun buildCatchupUrl(channel: ChannelEntity, program: EpgProgramEntity): String? {
        if (!channel.hasCatchup || channel.sourceType != SourceType.XTREAM) return null
        val pl = db.playlistDao().getById(channel.playlistId) ?: return null
        val durationMin = ((program.endTimeMillis - program.startTimeMillis) / 60_000L).toInt().coerceAtLeast(1)
        return XtreamClient.buildCatchupUrl(
            XtreamConfig(pl.primaryUrl, pl.extra1, pl.extra2),
            channel.streamId,
            program.startTimeMillis,
            durationMin
        )
    }

    suspend fun toggleChannelFavorite(channel: ChannelEntity) =
        db.channelDao().setFavorite(channel.id, !channel.isFavorite)

    suspend fun setChannelHidden(id: String, hidden: Boolean) =
        db.channelDao().setHidden(id, hidden)

    suspend fun setChannelBlocked(id: String, blocked: Boolean) =
        db.channelDao().setBlocked(id, blocked)

    suspend fun setChannelTvgId(id: String, tvgId: String) =
        db.channelDao().setTvgId(id, tvgId)

    suspend fun unhideAllChannels() = db.channelDao().unhideAll()
    suspend fun unblockAllChannels() = db.channelDao().unblockAll()

    suspend fun toggleMovieFavorite(movie: VodMovieEntity) =
        db.vodDao().setFavorite(movie.id, !movie.isFavorite)

    suspend fun toggleSeriesFavorite(series: SeriesEntity) =
        db.seriesDao().setFavorite(series.id, !series.isFavorite)

    suspend fun saveWatchProgress(
        itemId: String,
        playlistId: String,
        mediaType: String,
        title: String,
        subtitle: String,
        posterUrl: String,
        streamUrl: String,
        stalkerCmd: String,
        seriesDbId: String,
        positionMs: Long,
        durationMs: Long
    ) {
        val watched = durationMs > 0L && positionMs >= (durationMs * 0.92).toLong()
        db.watchHistoryDao().upsert(
            WatchHistoryEntity(
                itemId = itemId,
                playlistId = playlistId,
                mediaType = mediaType,
                title = title,
                subtitle = subtitle,
                posterUrl = posterUrl,
                streamUrl = streamUrl,
                stalkerCmd = stalkerCmd,
                seriesDbId = seriesDbId,
                positionMs = positionMs,
                durationMs = durationMs,
                isWatched = watched,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun globalSearch(query: String): GlobalSearchResults = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.length < 2) return@withContext GlobalSearchResults()
        GlobalSearchResults(
            channels = db.channelDao().search(q),
            movies = db.vodDao().search(q),
            series = db.seriesDao().search(q),
            programs = db.epgDao().search(q, System.currentTimeMillis())
        )
    }

    suspend fun deletePlaylist(id: String) {
        db.channelDao().deleteByPlaylist(id)
        db.vodDao().deleteByPlaylist(id)
        db.seriesDao().deleteEpisodesByPlaylist(id)
        db.seriesDao().deleteByPlaylist(id)
        db.epgDao().deleteByPlaylist(id)
        db.playlistDao().deleteById(id)
    }

    suspend fun addRecordingRecord(item: RecordingEntity): Long = db.recordingDao().insert(item)
    suspend fun updateRecordingStatus(id: Long, status: String, path: String) = db.recordingDao().updateStatus(id, status, path)
    suspend fun deleteRecording(id: Long) = db.recordingDao().deleteById(id)

    suspend fun addReminder(item: ReminderEntity): Long = db.reminderDao().insert(item)
    suspend fun deleteReminder(id: Long) = db.reminderDao().deleteById(id)

    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val playlists = db.playlistDao().getAll()
        val arr = JSONArray()
        for (p in playlists) {
            arr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("type", p.type.name)
                put("primaryUrl", p.primaryUrl)
                put("extra1", p.extra1)
                put("extra2", p.extra2)
                put("epgUrl", p.epgUrl)
                put("includeVod", p.includeVod)
                put("outputFormat", p.outputFormat)
                put("isEnabled", p.isEnabled)
            })
        }
        JSONObject().apply {
            put("version", 4)
            put("epgIntervalHours", settings.getEpgIntervalHours())
            put("playlists", arr)
        }.toString(2)
    }

    suspend fun importBackupJson(raw: String): Int = withContext(Dispatchers.IO) {
        val root = JSONObject(raw)
        val interval = root.optInt("epgIntervalHours", 24)
        settings.setEpgIntervalHours(interval)
        val arr = root.optJSONArray("playlists") ?: return@withContext 0
        var count = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val type = runCatching { SourceType.valueOf(o.optString("type")) }.getOrNull() ?: continue
            val name = o.optString("name", "Restored")
            val url = o.optString("primaryUrl")
            val e1 = o.optString("extra1")
            val e2 = o.optString("extra2")
            val epg = o.optString("epgUrl")
            val incVod = o.optBoolean("includeVod", true)
            val fmt = o.optString("outputFormat", "MPEG-TS")
            runCatching {
                when (type) {
                    SourceType.M3U -> addOrSyncM3uUrl(name, url, epg, includeVod = incVod)
                    SourceType.XTREAM -> addOrSyncXtream(name, XtreamConfig(url, e1, e2), includeVod = incVod, outputFormat = fmt)
                    SourceType.STALKER -> addOrSyncStalker(name, StalkerConfig(url, e1), includeVod = incVod)
                }
                count++
            }
        }
        count
    }
}
