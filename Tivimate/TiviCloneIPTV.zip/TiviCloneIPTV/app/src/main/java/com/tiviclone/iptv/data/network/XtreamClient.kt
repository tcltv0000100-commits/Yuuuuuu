package com.tiviclone.iptv.data.network

import android.util.Base64
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.data.db.EpisodeEntity
import com.tiviclone.iptv.data.db.SeriesEntity
import com.tiviclone.iptv.data.db.VodMovieEntity
import com.tiviclone.iptv.data.model.AccountInfo
import com.tiviclone.iptv.data.model.SourceType
import com.tiviclone.iptv.data.model.XtreamConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

data class XtreamLoadResult(
    val accountInfo: AccountInfo,
    val channels: List<ChannelEntity>,
    val movies: List<VodMovieEntity>,
    val series: List<SeriesEntity>
)

object XtreamClient {

    private fun baseApi(cfg: XtreamConfig): String {
        val clean = cfg.serverUrl.trim().trimEnd('/')
        return "$clean/player_api.php?username=${cfg.username}&password=${cfg.password}"
    }

    fun getXmltvUrl(cfg: XtreamConfig): String {
        val clean = cfg.serverUrl.trim().trimEnd('/')
        return "$clean/xmltv.php?username=${cfg.username}&password=${cfg.password}"
    }

    fun buildCatchupUrl(
        cfg: XtreamConfig,
        streamId: String,
        startMillis: Long,
        durationMinutes: Int
    ): String {
        val clean = cfg.serverUrl.trim().trimEnd('/')
        val fmt = SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val startStr = fmt.format(startMillis)
        return "$clean/timeshift/${cfg.username}/${cfg.password}/$durationMinutes/$startStr/$streamId.ts"
    }

    suspend fun loadAll(playlistId: String, cfg: XtreamConfig): XtreamLoadResult =
        withContext(Dispatchers.IO) {
            val base = baseApi(cfg)
            val cleanServer = cfg.serverUrl.trim().trimEnd('/')

            // 1. Account Info
            val accountInfo = fetchAccountInfo(base)

            // 2. Live TV
            val liveCats = fetchCategoryMap("$base&action=get_live_categories")
            val liveArr = fetchJsonArray("$base&action=get_live_streams")
            val channels = ArrayList<ChannelEntity>(liveArr.length())
            for (i in 0 until liveArr.length()) {
                val obj = liveArr.optJSONObject(i) ?: continue
                val sid = obj.optString("stream_id")
                if (sid.isBlank()) continue
                val catId = obj.optString("category_id")
                val tvArchive = obj.optInt("tv_archive", 0) == 1
                val archiveDays = obj.optInt("tv_archive_duration", 0)
                channels.add(
                    ChannelEntity(
                        id = "${playlistId}_live_$sid",
                        playlistId = playlistId,
                        number = obj.optInt("num", i + 1),
                        name = obj.optString("name", "Channel ${i + 1}"),
                        groupName = liveCats[catId] ?: "Live TV",
                        logoUrl = obj.optString("stream_icon"),
                        streamUrl = "$cleanServer/live/${cfg.username}/${cfg.password}/$sid.ts",
                        tvgId = obj.optString("epg_channel_id"),
                        hasCatchup = tvArchive,
                        catchupDays = archiveDays,
                        sourceType = SourceType.XTREAM,
                        streamId = sid
                    )
                )
            }

            // 3. Movies (VOD)
            val vodCats = fetchCategoryMap("$base&action=get_vod_categories")
            val vodArr = fetchJsonArray("$base&action=get_vod_streams")
            val movies = ArrayList<VodMovieEntity>(vodArr.length())
            for (i in 0 until vodArr.length()) {
                val obj = vodArr.optJSONObject(i) ?: continue
                val sid = obj.optString("stream_id")
                if (sid.isBlank()) continue
                val ext = obj.optString("container_extension", "mp4").ifBlank { "mp4" }
                val catId = obj.optString("category_id")
                movies.add(
                    VodMovieEntity(
                        id = "${playlistId}_vod_$sid",
                        playlistId = playlistId,
                        streamId = sid,
                        name = obj.optString("name", "Movie ${i + 1}"),
                        categoryName = vodCats[catId] ?: "Movies",
                        posterUrl = obj.optString("stream_icon"),
                        streamUrl = "$cleanServer/movie/${cfg.username}/${cfg.password}/$sid.$ext",
                        sourceType = SourceType.XTREAM,
                        containerExtension = ext,
                        rating = obj.optString("rating"),
                        addedAt = obj.optString("added").toLongOrNull() ?: 0L
                    )
                )
            }

            // 4. Series
            val seriesCats = fetchCategoryMap("$base&action=get_series_categories")
            val seriesArr = fetchJsonArray("$base&action=get_series")
            val seriesList = ArrayList<SeriesEntity>(seriesArr.length())
            for (i in 0 until seriesArr.length()) {
                val obj = seriesArr.optJSONObject(i) ?: continue
                val sid = obj.optString("series_id")
                if (sid.isBlank()) continue
                val catId = obj.optString("category_id")
                val backdropArr = obj.optJSONArray("backdrop_path")
                val backdrop = if (backdropArr != null && backdropArr.length() > 0) backdropArr.optString(0) else ""
                seriesList.add(
                    SeriesEntity(
                        id = "${playlistId}_series_$sid",
                        playlistId = playlistId,
                        seriesId = sid,
                        name = obj.optString("name", "Series ${i + 1}"),
                        categoryName = seriesCats[catId] ?: "Series",
                        posterUrl = obj.optString("cover"),
                        backdropUrl = backdrop,
                        sourceType = SourceType.XTREAM,
                        rating = obj.optString("rating"),
                        releaseDate = obj.optString("releaseDate"),
                        genre = obj.optString("genre"),
                        plot = obj.optString("plot"),
                        cast = obj.optString("cast"),
                        director = obj.optString("director")
                    )
                )
            }

            XtreamLoadResult(accountInfo, channels, movies, seriesList)
        }

    suspend fun loadVodInfo(cfg: XtreamConfig, existing: VodMovieEntity): VodMovieEntity =
        withContext(Dispatchers.IO) {
            val url = "${baseApi(cfg)}&action=get_vod_info&vod_id=${existing.streamId}"
            val json = fetchJsonObject(url) ?: return@withContext existing
            val info = json.optJSONObject("info") ?: return@withContext existing
            val movieData = json.optJSONObject("movie_data")
            val ext = movieData?.optString("container_extension")?.ifBlank { existing.containerExtension }
                ?: existing.containerExtension
            val cleanServer = cfg.serverUrl.trim().trimEnd('/')
            val backdropArr = info.optJSONArray("backdrop_path")
            val backdrop = if (backdropArr != null && backdropArr.length() > 0) {
                backdropArr.optString(0)
            } else {
                info.optString("movie_image", existing.posterUrl)
            }
            existing.copy(
                posterUrl = info.optString("movie_image").ifBlank { existing.posterUrl },
                backdropUrl = backdrop.ifBlank { existing.backdropUrl },
                streamUrl = "$cleanServer/movie/${cfg.username}/${cfg.password}/${existing.streamId}.$ext",
                containerExtension = ext,
                rating = info.optString("rating").ifBlank { existing.rating },
                releaseDate = info.optString("releasedate").ifBlank { existing.releaseDate },
                duration = info.optString("duration").ifBlank { existing.duration },
                genre = info.optString("genre").ifBlank { existing.genre },
                plot = info.optString("plot").ifBlank { existing.plot },
                cast = info.optString("cast").ifBlank { existing.cast },
                director = info.optString("director").ifBlank { existing.director },
                trailerUrl = info.optString("youtube_trailer"),
                detailsFetched = true
            )
        }

    suspend fun loadSeriesDetails(
        playlistId: String,
        cfg: XtreamConfig,
        series: SeriesEntity
    ): Pair<SeriesEntity, List<EpisodeEntity>> = withContext(Dispatchers.IO) {
        val cleanServer = cfg.serverUrl.trim().trimEnd('/')
        val url = "${baseApi(cfg)}&action=get_series_info&series_id=${series.seriesId}"
        val root = fetchJsonObject(url) ?: return@withContext series to emptyList()

        val info = root.optJSONObject("info")
        val backdropArr = info?.optJSONArray("backdrop_path")
        val backdrop = if (backdropArr != null && backdropArr.length() > 0) {
            backdropArr.optString(0)
        } else series.backdropUrl

        val updatedSeries = if (info != null) {
            series.copy(
                posterUrl = info.optString("cover").ifBlank { series.posterUrl },
                backdropUrl = backdrop.ifBlank { series.backdropUrl },
                rating = info.optString("rating").ifBlank { series.rating },
                releaseDate = info.optString("releaseDate").ifBlank { series.releaseDate },
                genre = info.optString("genre").ifBlank { series.genre },
                plot = info.optString("plot").ifBlank { series.plot },
                cast = info.optString("cast").ifBlank { series.cast },
                director = info.optString("director").ifBlank { series.director },
                detailsFetched = true
            )
        } else series

        val episodes = mutableListOf<EpisodeEntity>()
        val epsObj = root.optJSONObject("episodes")
        if (epsObj != null) {
            val keys = epsObj.keys()
            while (keys.hasNext()) {
                val seasonKey = keys.next()
                val arr = epsObj.optJSONArray(seasonKey) ?: continue
                val seasonNum = seasonKey.toIntOrNull() ?: 1
                for (i in 0 until arr.length()) {
                    val ep = arr.optJSONObject(i) ?: continue
                    val epId = ep.optString("id")
                    if (epId.isBlank()) continue
                    val ext = ep.optString("container_extension", "mp4").ifBlank { "mp4" }
                    val epInfo = ep.optJSONObject("info")
                    val epNum = ep.optString("episode_num").toIntOrNull() ?: (i + 1)
                    episodes.add(
                        EpisodeEntity(
                            id = "${series.id}_s${seasonNum}_e${epNum}_$epId",
                            seriesDbId = series.id,
                            playlistId = playlistId,
                            episodeId = epId,
                            seasonNumber = seasonNum,
                            episodeNumber = epNum,
                            title = ep.optString("title", "Episode $epNum"),
                            plot = epInfo?.optString("plot") ?: "",
                            duration = epInfo?.optString("duration") ?: "",
                            thumbnailUrl = epInfo?.optString("movie_image") ?: series.posterUrl,
                            streamUrl = "$cleanServer/series/${cfg.username}/${cfg.password}/$epId.$ext",
                            sourceType = SourceType.XTREAM
                        )
                    )
                }
            }
        }
        updatedSeries to episodes.sortedWith(compareBy({ it.seasonNumber }, { it.episodeNumber }))
    }

    suspend fun fetchShortEpg(
        playlistId: String,
        cfg: XtreamConfig,
        streamId: String,
        tvgId: String
    ): List<EpgProgramEntity> = withContext(Dispatchers.IO) {
        val url = "${baseApi(cfg)}&action=get_short_epg&stream_id=$streamId&limit=12"
        val obj = fetchJsonObject(url) ?: return@withContext emptyList()
        val arr = obj.optJSONArray("epg_listings") ?: return@withContext emptyList()
        val list = ArrayList<EpgProgramEntity>(arr.length())
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val start = item.optString("start_timestamp").toLongOrNull()?.times(1000L) ?: continue
            val stop = item.optString("stop_timestamp").toLongOrNull()?.times(1000L) ?: continue
            val rawTitle = item.optString("title")
            val rawDesc = item.optString("description")
            val title = decodeBase64Safe(rawTitle)
            val desc = decodeBase64Safe(rawDesc)
            list.add(
                EpgProgramEntity(
                    playlistId = playlistId,
                    channelTvgId = tvgId.ifBlank { streamId },
                    title = title,
                    description = desc,
                    startTimeMillis = start,
                    endTimeMillis = stop
                )
            )
        }
        list
    }

    private fun decodeBase64Safe(input: String): String {
        if (input.isBlank()) return ""
        return try {
            val bytes = Base64.decode(input, Base64.DEFAULT)
            val decoded = String(bytes, Charsets.UTF_8)
            if (decoded.any { it.code < 9 }) input else decoded
        } catch (_: Exception) {
            input
        }
    }

    private fun fetchAccountInfo(base: String): AccountInfo {
        val obj = fetchJsonObject(base) ?: return AccountInfo()
        val user = obj.optJSONObject("user_info")
        val server = obj.optJSONObject("server_info")
        return AccountInfo(
            username = user?.optString("username") ?: "",
            status = user?.optString("status") ?: "",
            expDate = user?.optString("exp_date") ?: "",
            activeCons = user?.optString("active_cons") ?: "0",
            maxConnections = user?.optString("max_connections") ?: "1",
            serverTimezone = server?.optString("timezone") ?: ""
        )
    }

    private fun fetchCategoryMap(url: String): Map<String, String> {
        val arr = fetchJsonArray(url)
        val map = HashMap<String, String>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            map[o.optString("category_id")] = o.optString("category_name")
        }
        return map
    }

    private fun fetchJsonArray(url: String): JSONArray {
        val body = fetchRaw(url) ?: return JSONArray()
        return try {
            JSONArray(body)
        } catch (_: Exception) {
            JSONArray()
        }
    }

    private fun fetchJsonObject(url: String): JSONObject? {
        val body = fetchRaw(url) ?: return null
        return try {
            JSONObject(body)
        } catch (_: Exception) {
            null
        }
    }

    private fun fetchRaw(url: String): String? {
        val req = Request.Builder().url(url).build()
        return try {
            HttpClientProvider.sharedClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) null else resp.body?.string()
            }
        } catch (_: Exception) {
            null
        }
    }
}
