package com.tiviclone.iptv.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.tiviclone.iptv.data.model.SourceType

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: SourceType,
    val primaryUrl: String,
    val extra1: String = "",
    val extra2: String = "",
    val epgUrl: String = "",
    val stalkerToken: String = "",
    val stbType: String = "MAG250",
    val serialNumber: String = "",
    val deviceId: String = "",
    val deviceId2: String = "",
    val signature: String = "",
    val accountStatus: String = "",
    val accountExpiry: String = "",
    val maxConnections: String = "1",
    val activeConnections: String = "0",
    val includeVod: Boolean = true,
    val outputFormat: String = "MPEG-TS",
    val isEnabled: Boolean = true,
    val channelsCount: Int = 0,
    val moviesCount: Int = 0,
    val seriesCount: Int = 0,
    val lastSyncedAt: Long = 0L,
    val isActive: Boolean = true
)

@Entity(
    tableName = "channels",
    indices = [
        Index("playlistId"),
        Index("groupName"),
        Index("tvgId"),
        Index("isFavorite")
    ]
)
data class ChannelEntity(
    @PrimaryKey val id: String,
    val playlistId: String,
    val number: Int,
    val name: String,
    val groupName: String,
    val logoUrl: String = "",
    val streamUrl: String = "",
    val tvgId: String = "",
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false,
    val isBlocked: Boolean = false,
    val hasCatchup: Boolean = false,
    val catchupDays: Int = 0,
    val sourceType: SourceType = SourceType.M3U,
    val stalkerCmd: String = "",
    val streamId: String = "",
    val userAgent: String = ""
)

@Entity(
    tableName = "vod_movies",
    indices = [
        Index("playlistId"),
        Index("categoryName"),
        Index("isFavorite")
    ]
)
data class VodMovieEntity(
    @PrimaryKey val id: String,
    val playlistId: String,
    val streamId: String,
    val name: String,
    val categoryName: String,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val streamUrl: String = "",
    val stalkerCmd: String = "",
    val sourceType: SourceType = SourceType.XTREAM,
    val containerExtension: String = "mp4",
    val rating: String = "",
    val releaseDate: String = "",
    val duration: String = "",
    val genre: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val trailerUrl: String = "",
    val detailsFetched: Boolean = false,
    val isFavorite: Boolean = false,
    val addedAt: Long = 0L
)

@Entity(
    tableName = "series",
    indices = [
        Index("playlistId"),
        Index("categoryName"),
        Index("isFavorite")
    ]
)
data class SeriesEntity(
    @PrimaryKey val id: String,
    val playlistId: String,
    val seriesId: String,
    val name: String,
    val categoryName: String,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val sourceType: SourceType = SourceType.XTREAM,
    val stalkerCmd: String = "",
    val rating: String = "",
    val releaseDate: String = "",
    val genre: String = "",
    val plot: String = "",
    val cast: String = "",
    val director: String = "",
    val detailsFetched: Boolean = false,
    val isFavorite: Boolean = false
)

@Entity(
    tableName = "episodes",
    indices = [Index("seriesDbId"), Index("seasonNumber")]
)
data class EpisodeEntity(
    @PrimaryKey val id: String,
    val seriesDbId: String,
    val playlistId: String,
    val episodeId: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val plot: String = "",
    val duration: String = "",
    val thumbnailUrl: String = "",
    val streamUrl: String = "",
    val stalkerCmd: String = "",
    val sourceType: SourceType = SourceType.XTREAM
)

@Entity(
    tableName = "epg_programs",
    indices = [Index("channelTvgId"), Index("startTimeMillis"), Index("endTimeMillis")]
)
data class EpgProgramEntity(
    @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
    val playlistId: String,
    val channelTvgId: String,
    val title: String,
    val description: String = "",
    val startTimeMillis: Long,
    val endTimeMillis: Long
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val itemId: String,
    val playlistId: String,
    val mediaType: String,
    val title: String,
    val subtitle: String = "",
    val posterUrl: String = "",
    val streamUrl: String = "",
    val stalkerCmd: String = "",
    val seriesDbId: String = "",
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val isWatched: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelId: String,
    val channelName: String,
    val programTitle: String,
    val startTimeMillis: Long
)

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelId: String,
    val channelName: String,
    val programTitle: String,
    val streamUrl: String,
    val filePath: String = "",
    val scheduledStartMs: Long = 0L,
    val scheduledEndMs: Long = 0L,
    val status: String = "COMPLETED",
    val createdAt: Long = System.currentTimeMillis()
)
