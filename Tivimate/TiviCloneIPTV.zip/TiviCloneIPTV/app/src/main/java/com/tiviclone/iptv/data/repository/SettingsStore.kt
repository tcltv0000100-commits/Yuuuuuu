package com.tiviclone.iptv.data.repository

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("tiviclone_settings", Context.MODE_PRIVATE)

    fun getActivePlaylistId(): String = prefs.getString(KEY_ACTIVE_PLAYLIST, "").orEmpty()
    fun setActivePlaylistId(id: String) = prefs.edit().putString(KEY_ACTIVE_PLAYLIST, id).apply()

    fun getEpgIntervalHours(): Int = prefs.getInt(KEY_EPG_INTERVAL, 12)
    fun setEpgIntervalHours(hours: Int) = prefs.edit().putInt(KEY_EPG_INTERVAL, hours).apply()

    fun getEpgLastUpdated(): Long = prefs.getLong(KEY_EPG_LAST_UPDATED, 0L)
    fun setEpgLastUpdated(ts: Long) = prefs.edit().putLong(KEY_EPG_LAST_UPDATED, ts).apply()

    fun getParentalPin(): String = prefs.getString(KEY_PARENTAL_PIN, "").orEmpty()
    fun setParentalPin(pin: String) = prefs.edit().putString(KEY_PARENTAL_PIN, pin).apply()

    fun isAutoPlayNextEpisode(): Boolean = prefs.getBoolean(KEY_AUTO_NEXT_EP, true)
    fun setAutoPlayNextEpisode(enabled: Boolean) = prefs.edit().putBoolean(KEY_AUTO_NEXT_EP, enabled).apply()

    companion object {
        private const val KEY_ACTIVE_PLAYLIST = "active_playlist_id"
        private const val KEY_EPG_INTERVAL = "epg_interval_hours"
        private const val KEY_EPG_LAST_UPDATED = "epg_last_updated"
        private const val KEY_PARENTAL_PIN = "parental_pin"
        private const val KEY_AUTO_NEXT_EP = "auto_next_episode"
    }
}
