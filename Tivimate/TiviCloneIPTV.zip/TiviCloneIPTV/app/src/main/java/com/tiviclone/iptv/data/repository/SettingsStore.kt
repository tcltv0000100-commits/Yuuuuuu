package com.tiviclone.iptv.data.repository

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("tiviclone_settings", Context.MODE_PRIVATE)

    fun getActivePlaylistId(): String = prefs.getString(KEY_ACTIVE_PLAYLIST, "ALL").orEmpty()
    fun setActivePlaylistId(id: String) = prefs.edit().putString(KEY_ACTIVE_PLAYLIST, id).apply()

    // General
    fun isAutoStartBoot(): Boolean = prefs.getBoolean("auto_start_boot", false)
    fun setAutoStartBoot(v: Boolean) = prefs.edit().putBoolean("auto_start_boot", v).apply()

    fun isAutoStartWake(): Boolean = prefs.getBoolean("auto_start_wake", false)
    fun setAutoStartWake(v: Boolean) = prefs.edit().putBoolean("auto_start_wake", v).apply()

    fun isTurnOnLastChannel(): Boolean = prefs.getBoolean("turn_on_last_channel", true)
    fun setTurnOnLastChannel(v: Boolean) = prefs.edit().putBoolean("turn_on_last_channel", v).apply()

    fun isPipOnHome(): Boolean = prefs.getBoolean("pip_on_home", false)
    fun setPipOnHome(v: Boolean) = prefs.edit().putBoolean("pip_on_home", v).apply()

    fun isConfirmExitBack(): Boolean = prefs.getBoolean("confirm_exit_back", false)
    fun setConfirmExitBack(v: Boolean) = prefs.edit().putBoolean("confirm_exit_back", v).apply()

    fun getUserAgent(): String = prefs.getString("user_agent", "").orEmpty()
    fun setUserAgent(v: String) = prefs.edit().putString("user_agent", v).apply()

    fun getUdpProxy(): String = prefs.getString("udp_proxy", "").orEmpty()
    fun setUdpProxy(v: String) = prefs.edit().putString("udp_proxy", v).apply()

    // EPG
    fun getEpgPastDays(): Int = prefs.getInt("epg_past_days", 7)
    fun setEpgPastDays(v: Int) = prefs.edit().putInt("epg_past_days", v).apply()

    fun isStoreProgramDesc(): Boolean = prefs.getBoolean("store_epg_desc", true)
    fun setStoreProgramDesc(v: Boolean) = prefs.edit().putBoolean("store_epg_desc", v).apply()

    fun getEpgIntervalHours(): Int = prefs.getInt(KEY_EPG_INTERVAL, 24)
    fun setEpgIntervalHours(hours: Int) = prefs.edit().putInt(KEY_EPG_INTERVAL, hours).apply()

    fun isEpgUpdateOnStart(): Boolean = prefs.getBoolean("epg_update_start", false)
    fun setEpgUpdateOnStart(v: Boolean) = prefs.edit().putBoolean("epg_update_start", v).apply()

    fun isEpgUpdateOnPlaylistChange(): Boolean = prefs.getBoolean("epg_update_change", false)
    fun setEpgUpdateOnPlaylistChange(v: Boolean) = prefs.edit().putBoolean("epg_update_change", v).apply()

    fun getEpgLastUpdated(): Long = prefs.getLong(KEY_EPG_LAST_UPDATED, 0L)
    fun setEpgLastUpdated(ts: Long) = prefs.edit().putLong(KEY_EPG_LAST_UPDATED, ts).apply()

    // Appearance
    fun getFontSize(): String = prefs.getString("font_size", "Medium").orEmpty()
    fun setFontSize(v: String) = prefs.edit().putString("font_size", v).apply()

    fun getUiTransparency(): Int = prefs.getInt("ui_transparency", 50)
    fun setUiTransparency(v: Int) = prefs.edit().putInt("ui_transparency", v).apply()

    // Playback
    fun getBufferSize(): String = prefs.getString("buffer_size", "Small").orEmpty()
    fun setBufferSize(v: String) = prefs.edit().putString("buffer_size", v).apply()

    fun getAudioDecoder(): String = prefs.getString("audio_decoder", "Hardware").orEmpty()
    fun setAudioDecoder(v: String) = prefs.edit().putString("audio_decoder", v).apply()

    fun getVideoDecoder(): String = prefs.getString("video_decoder", "Hardware").orEmpty()
    fun setVideoDecoder(v: String) = prefs.edit().putString("video_decoder", v).apply()

    fun isAfrEnabled(): Boolean = prefs.getBoolean("afr_enabled", false)
    fun setAfrEnabled(v: Boolean) = prefs.edit().putBoolean("afr_enabled", v).apply()

    fun isSurroundDefault(): Boolean = prefs.getBoolean("surround_default", false)
    fun setSurroundDefault(v: Boolean) = prefs.edit().putBoolean("surround_default", v).apply()

    fun isAudioPassthrough(): Boolean = prefs.getBoolean("audio_passthrough", false)
    fun setAudioPassthrough(v: Boolean) = prefs.edit().putBoolean("audio_passthrough", v).apply()

    fun isUseExternalPlayer(): Boolean = prefs.getBoolean("use_external_player", false)
    fun setUseExternalPlayer(v: Boolean) = prefs.edit().putBoolean("use_external_player", v).apply()

    // Parental
    fun getParentalPin(): String = prefs.getString(KEY_PARENTAL_PIN, "").orEmpty()
    fun setParentalPin(pin: String) = prefs.edit().putString(KEY_PARENTAL_PIN, pin).apply()

    companion object {
        private const val KEY_ACTIVE_PLAYLIST = "active_playlist_id"
        private const val KEY_EPG_INTERVAL = "epg_interval_hours"
        private const val KEY_EPG_LAST_UPDATED = "epg_last_updated"
        private const val KEY_PARENTAL_PIN = "parental_pin"
    }
}
