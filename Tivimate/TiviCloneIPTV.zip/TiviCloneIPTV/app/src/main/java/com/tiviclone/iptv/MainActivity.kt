package com.tiviclone.iptv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.data.db.PlaylistEntity
import com.tiviclone.iptv.data.model.AppSection
import com.tiviclone.iptv.ui.MainViewModel
import com.tiviclone.iptv.ui.player.IptvPlayerView
import com.tiviclone.iptv.ui.player.MultiviewGrid
import com.tiviclone.iptv.ui.screens.*
import com.tiviclone.iptv.ui.theme.TiviCloneTheme
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TiviCloneTheme {
                TiviCloneRoot(vm)
            }
        }
    }
}

@Composable
private fun TiviCloneRoot(vm: MainViewModel) {
    val section by vm.activeSection.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val activePlaylistId by vm.activePlaylistId.collectAsState()
    val channels by vm.channels.collectAsState()
    val movies by vm.movies.collectAsState()
    val seriesList by vm.seriesList.collectAsState()
    val favChannels by vm.favoriteChannels.collectAsState()
    val favMovies by vm.favoriteMovies.collectAsState()
    val favSeries by vm.favoriteSeries.collectAsState()
    val epgPrograms by vm.epgPrograms.collectAsState()
    val recordings by vm.recordings.collectAsState()
    val searchResults by vm.searchResults.collectAsState()
    val selectedMovie by vm.selectedMovie.collectAsState()
    val selectedSeries by vm.selectedSeries.collectAsState()
    val seriesEpisodes by vm.selectedSeriesEpisodes.collectAsState()
    val activePlayback by vm.activePlayback.collectAsState()
    val showMultiview by vm.showMultiview.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val statusMessage by vm.statusMessage.collectAsState()
    val epgInterval by vm.epgIntervalHours.collectAsState()
    val epgLastUpdated by vm.epgLastUpdated.collectAsState()
    val parentalPin by vm.parentalPin.collectAsState()

    var showSettingsDrawer by remember { mutableStateOf(false) }
    var showPlaylistTypeWizard by remember { mutableStateOf(false) }
    var showAddSourceDialog by remember { mutableStateOf(false) }
    var addSourceInitialTab by remember { mutableStateOf("Stalker") }
    var editingPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }

    var unlocked by remember(parentalPin) { mutableStateOf(parentalPin.isBlank()) }
    var pinEntry by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addM3uFile("Local M3U", uri)
    }

    val app = LocalContext.current.applicationContext as TiviCloneApp

    if (!unlocked) {
        Box(modifier = Modifier.fillMaxSize().background(Color(0xFF121417)), contentAlignment = Alignment.Center) {
            Column(
                modifier = Modifier
                    .width(300.dp)
                    .background(Color(0xFF1A1D21), RoundedCornerShape(12.dp))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = TiviColors.AccentBlue, modifier = Modifier.size(36.dp))
                Text("Enter Parental PIN", color = Color.White, fontSize = 18.sp)
                OutlinedTextField(
                    value = pinEntry,
                    onValueChange = { pinEntry = it; pinError = false },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    isError = pinError
                )
                Button(onClick = {
                    if (pinEntry == parentalPin) unlocked = true else pinError = true
                }, modifier = Modifier.fillMaxWidth()) { Text("Unlock") }
            }
        }
        return
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF121417))) {
        when {
            showMultiview -> {
                MultiviewGrid(
                    channels = channels,
                    initialChannel = channels.firstOrNull { it.id == activePlayback?.itemId } ?: channels.firstOrNull(),
                    onResolveUrl = { ch -> app.repository.resolveChannelStream(ch) },
                    onExit = { vm.showMultiview.value = false }
                )
            }
            showPlaylistTypeWizard -> {
                PlaylistTypeWizard(
                    onSelectM3u = {
                        showPlaylistTypeWizard = false
                        addSourceInitialTab = "M3U"
                        editingPlaylist = null
                        showAddSourceDialog = true
                    },
                    onSelectXtream = {
                        showPlaylistTypeWizard = false
                        addSourceInitialTab = "Xtream"
                        editingPlaylist = null
                        showAddSourceDialog = true
                    },
                    onSelectStalker = {
                        showPlaylistTypeWizard = false
                        addSourceInitialTab = "Stalker"
                        editingPlaylist = null
                        showAddSourceDialog = true
                    },
                    onCancel = { showPlaylistTypeWizard = false }
                )
            }
            activePlayback?.isFullscreen == true -> {
                val pb = activePlayback!!
                val nextEpAction: (() -> Unit)? = remember(pb.itemId, seriesEpisodes, selectedSeries) {
                    if (pb.mediaType == "SERIES" && selectedSeries != null) {
                        val idx = seriesEpisodes.indexOfFirst { it.id == pb.itemId }
                        if (idx >= 0 && idx + 1 < seriesEpisodes.size) {
                            { vm.playEpisode(selectedSeries!!, seriesEpisodes[idx + 1]) }
                        } else null
                    } else null
                }

                IptvPlayerView(
                    playback = pb,
                    channels = channels,
                    epgPrograms = epgPrograms,
                    modifier = Modifier.fillMaxSize(),
                    onBack = {
                        if (pb.mediaType == "LIVE") vm.setFullscreen(false) else vm.closePlayer()
                    },
                    onToggleFullscreen = { vm.setFullscreen(false) },
                    onOpenMultiview = { vm.showMultiview.value = true },
                    onSaveProgress = { pos, dur -> vm.savePlaybackProgress(pb, pos, dur) },
                    onSwitchChannel = { ch -> vm.playChannel(ch, true) },
                    onZapByNumber = { num ->
                        channels.firstOrNull { it.number == num }?.let { vm.playChannel(it, true) }
                    },
                    onNextEpisode = nextEpAction
                )
            }
            // Image 1: First-launch Empty State ("TiviClone does not provide any content" + "Add your playlist" + [Add playlist] [Settings])
            playlists.isEmpty() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "TiviClone does not provide any content",
                            color = Color.White,
                            fontSize = 18.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Add your playlist",
                            color = TiviColors.TextSecondary,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(24.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { showPlaylistTypeWizard = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF23272E), contentColor = Color.White),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Add playlist")
                            }
                            Button(
                                onClick = { showSettingsDrawer = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE6E8EC), contentColor = Color.Black),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Settings")
                            }
                        }
                    }
                }
            }
            // Image 8: Main TiviMate Home Layout
            else -> {
                Row(modifier = Modifier.fillMaxSize()) {
                    // Left Sidebar: tiviclone + Search, TV, Movies, Shows, Recordings, My list + Settings
                    Column(
                        modifier = Modifier
                            .width(180.dp)
                            .fillMaxHeight()
                            .background(Color(0xFF14171A))
                            .padding(horizontal = 12.dp, vertical = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            buildAnnotatedString {
                                withStyle(SpanStyle(color = Color(0xFF3E8BFF), fontWeight = FontWeight.Bold)) { append("tivi") }
                                withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Normal)) { append("clone") }
                            },
                            fontSize = 24.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        TiviNavItem(AppSection.SEARCH, Icons.Default.Search, section == AppSection.SEARCH) {
                            vm.activeSection.value = AppSection.SEARCH
                        }
                        TiviNavItem(AppSection.TV, Icons.Default.Tv, section == AppSection.TV) {
                            vm.selectedMovie.value = null; vm.selectedSeries.value = null
                            vm.activeSection.value = AppSection.TV
                        }
                        TiviNavItem(AppSection.MOVIES, Icons.Default.Movie, section == AppSection.MOVIES) {
                            vm.selectedMovie.value = null
                            vm.activeSection.value = AppSection.MOVIES
                        }
                        TiviNavItem(AppSection.SHOWS, Icons.Default.LiveTv, section == AppSection.SHOWS) {
                            vm.selectedSeries.value = null
                            vm.activeSection.value = AppSection.SHOWS
                        }
                        TiviNavItem(AppSection.RECORDINGS, Icons.Default.Dvr, section == AppSection.RECORDINGS) {
                            vm.activeSection.value = AppSection.RECORDINGS
                        }
                        TiviNavItem(AppSection.MY_LIST, Icons.Default.BookmarkBorder, section == AppSection.MY_LIST) {
                            vm.activeSection.value = AppSection.MY_LIST
                        }
                        Spacer(Modifier.weight(1f))
                        TiviNavItem(AppSection.SETTINGS, Icons.Default.Settings, showSettingsDrawer) {
                            showSettingsDrawer = true
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        when (section) {
                            AppSection.TV -> TiviMateTvHomeScreen(
                                channels = channels,
                                epgPrograms = epgPrograms,
                                activePlayback = activePlayback,
                                onSelectChannel = { ch, full -> vm.playChannel(ch, full) },
                                onToggleFavorite = { vm.toggleFavorite(it) },
                                onToggleFullscreen = { vm.setFullscreen(true) },
                                onOpenMultiview = { vm.showMultiview.value = true },
                                onClosePlayer = { vm.closePlayer() },
                                onPlayCatchup = { ch, prog -> vm.playCatchup(ch, prog) },
                                onSetReminder = { ch, prog -> vm.setReminder(ch, prog) },
                                onRecordChannel = { ch, title -> vm.startRecording(ch, title) },
                                onOpenSearch = { vm.activeSection.value = AppSection.SEARCH },
                                onOpenSettings = { showSettingsDrawer = true },
                                onSaveProgress = { pos, dur ->
                                    activePlayback?.let { vm.savePlaybackProgress(it, pos, dur) }
                                }
                            )
                            AppSection.MOVIES -> {
                                val m = selectedMovie
                                if (m != null) {
                                    MovieDetailScreen(
                                        movie = m,
                                        onPlay = { vm.playMovie(it) },
                                        onToggleFavorite = { vm.toggleFavorite(it) },
                                        onBack = { vm.selectedMovie.value = null }
                                    )
                                } else {
                                    MoviesScreen(movies = movies, onSelectMovie = { vm.openMovieDetails(it) })
                                }
                            }
                            AppSection.SHOWS -> {
                                val s = selectedSeries
                                if (s != null) {
                                    SeriesDetailScreen(
                                        series = s,
                                        episodes = seriesEpisodes,
                                        isLoading = isLoading,
                                        onPlayEpisode = { sr, ep -> vm.playEpisode(sr, ep) },
                                        onToggleFavorite = { vm.toggleFavorite(it) },
                                        onBack = { vm.selectedSeries.value = null }
                                    )
                                } else {
                                    SeriesScreen(seriesList = seriesList, onSelectSeries = { vm.openSeriesDetails(it) })
                                }
                            }
                            AppSection.MY_LIST -> FavoritesScreen(
                                channels = favChannels,
                                movies = favMovies,
                                series = favSeries,
                                onPlayChannel = { vm.playChannel(it, true) },
                                onOpenMovie = { vm.openMovieDetails(it); vm.activeSection.value = AppSection.MOVIES },
                                onOpenSeries = { vm.openSeriesDetails(it); vm.activeSection.value = AppSection.SHOWS }
                            )
                            AppSection.RECORDINGS -> RecordingsScreen(
                                recordings = recordings,
                                onDelete = { vm.deleteRecording(it) }
                            )
                            AppSection.SEARCH -> SearchScreen(
                                results = searchResults,
                                onQueryChange = { vm.search(it) },
                                onPlayChannel = { vm.playChannel(it, true) },
                                onOpenMovie = { vm.openMovieDetails(it); vm.activeSection.value = AppSection.MOVIES },
                                onOpenSeries = { vm.openSeriesDetails(it); vm.activeSection.value = AppSection.SHOWS }
                            )
                            AppSection.SETTINGS -> Unit
                        }
                    }
                }
            }
        }

        // Right-side Settings Drawer (Images 2, 3, 5, 6, 7)
        if (showSettingsDrawer) {
            TiviMateSettingsDrawer(
                settings = app.settingsStore,
                playlists = playlists,
                activePlaylistId = activePlaylistId,
                epgIntervalHours = epgInterval,
                epgLastUpdated = epgLastUpdated,
                parentalPin = parentalPin,
                onSelectPlaylist = { vm.selectPlaylist(it) },
                onAddPlaylist = { showPlaylistTypeWizard = true },
                onEditPlaylist = { pl -> editingPlaylist = pl; showAddSourceDialog = true },
                onDeletePlaylist = { vm.deletePlaylist(it) },
                onSyncAll = { vm.refreshAll() },
                onUpdateEpgInterval = { vm.updateEpgInterval(it) },
                onSetParentalPin = { vm.setParentalPin(it) },
                onExportBackup = { vm.exportBackupJson() },
                onImportBackup = { vm.importBackupJson(it) },
                onClose = { showSettingsDrawer = false }
            )
        }

        if (isLoading) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }

        statusMessage?.let { msg ->
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action = { TextButton(onClick = { vm.clearStatus() }) { Text("OK") } }
            ) { Text(msg) }
        }
    }

    if (showAddSourceDialog) {
        AddSourceDialog(
            initialTab = addSourceInitialTab,
            editingPlaylist = editingPlaylist,
            onAddM3uUrl = { n, u, e, id -> vm.addOrUpdateM3uUrl(n, u, e, id) },
            onPickM3uFile = { filePicker.launch(arrayOf("*/*")) },
            onAddXtream = { n, h, u, p, id -> vm.addOrUpdateXtream(n, h, u, p, id) },
            onAddStalker = { n, u, m, id -> vm.addOrUpdateStalker(n, u, m, id) },
            onDismiss = { showAddSourceDialog = false; editingPlaylist = null }
        )
    }
}

@Composable
private fun TiviNavItem(
    section: AppSection,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) Color(0xFFE8EAED) else Color.Transparent)
            .tvFocusableBorder()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = section.label,
            tint = if (selected) Color.Black else Color.White,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(12.dp))
        Text(
            section.label,
            color = if (selected) Color.Black else Color.White,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal
        )
    }
}
