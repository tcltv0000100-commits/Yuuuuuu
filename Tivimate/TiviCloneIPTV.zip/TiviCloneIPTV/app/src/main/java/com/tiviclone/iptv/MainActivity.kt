package com.tiviclone.iptv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.data.model.AppSection
import com.tiviclone.iptv.ui.MainViewModel
import com.tiviclone.iptv.ui.player.IptvPlayerView
import com.tiviclone.iptv.ui.player.MultiviewGrid
import com.tiviclone.iptv.ui.screens.*
import com.tiviclone.iptv.ui.theme.TiviCloneTheme
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TiviCloneTheme {
                TiviCloneRoot(vm)
            }
        }
    }
}

@Composable
private fun TiviCloneRoot(vm: MainViewModel) {
    val section by vm.activeSection.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val activePlaylistId by vm.activePlaylistId.collectAsState()
    val channels by vm.channels.collectAsState()
    val movies by vm.movies.collectAsState()
    val seriesList by vm.seriesList.collectAsState()
    val favChannels by vm.favoriteChannels.collectAsState()
    val favMovies by vm.favoriteMovies.collectAsState()
    val favSeries by vm.favoriteSeries.collectAsState()
    val continueWatching by vm.continueWatching.collectAsState()
    val epgPrograms by vm.epgPrograms.collectAsState()
    val recordings by vm.recordings.collectAsState()
    val searchResults by vm.searchResults.collectAsState()
    val selectedMovie by vm.selectedMovie.collectAsState()
    val selectedSeries by vm.selectedSeries.collectAsState()
    val seriesEpisodes by vm.selectedSeriesEpisodes.collectAsState()
    val activePlayback by vm.activePlayback.collectAsState()
    val showMultiview by vm.showMultiview.collectAsState()
    val isLoading by vm.isLoading.collectAsState()
    val statusMessage by vm.statusMessage.collectAsState()
    val epgInterval by vm.epgIntervalHours.collectAsState()
    val epgLastUpdated by vm.epgLastUpdated.collectAsState()
    val parentalPin by vm.parentalPin.collectAsState()

    var showAddSource by remember { mutableStateOf(false) }
    var unlocked by remember(parentalPin) { mutableStateOf(parentalPin.isBlank()) }
    var pinEntry by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addM3uFile("Local M3U", uri)
    }

    val app = androidx.compose.ui.platform.LocalContext.current.applicationContext as TiviCloneApp

    if (!unlocked) {
        Box(modifier = Modifier.fillMaxSize().background(TiviColors.Background), contentAlignment = Alignment.Center) {
            Column(
                modifier = Modifier
                    .width(300.dp)
                    .background(TiviColors.PanelBg, RoundedCornerShape(12.dp))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = TiviColors.AccentBlue, modifier = Modifier.size(36.dp))
                Text("Enter Parental PIN", color = Color.White, fontSize = 18.sp)
                OutlinedTextField(
                    value = pinEntry,
                    onValueChange = { pinEntry = it; pinError = false },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    isError = pinError
                )
                Button(onClick = {
                    if (pinEntry == parentalPin) unlocked = true else pinError = true
                }, modifier = Modifier.fillMaxWidth()) {
                    Text("Unlock")
                }
            }
        }
        return
    }

    Box(modifier = Modifier.fillMaxSize().background(TiviColors.Background)) {
        when {
            showMultiview -> {
                MultiviewGrid(
                    channels = channels,
                    initialChannel = channels.firstOrNull { it.id == activePlayback?.itemId } ?: channels.firstOrNull(),
                    onResolveUrl = { ch -> app.repository.resolveChannelStream(ch) },
                    onExit = { vm.showMultiview.value = false }
                )
            }
            activePlayback?.isFullscreen == true -> {
                val pb = activePlayback!!
                val nextEpAction: (() -> Unit)? = remember(pb.itemId, seriesEpisodes, selectedSeries) {
                    if (pb.mediaType == "SERIES" && selectedSeries != null) {
                        val idx = seriesEpisodes.indexOfFirst { it.id == pb.itemId }
                        if (idx >= 0 && idx + 1 < seriesEpisodes.size) {
                            { vm.playEpisode(selectedSeries!!, seriesEpisodes[idx + 1]) }
                        } else null
                    } else null
                }

                IptvPlayerView(
                    playback = pb,
                    channels = channels,
                    epgPrograms = epgPrograms,
                    modifier = Modifier.fillMaxSize(),
                    onBack = {
                        if (pb.mediaType == "LIVE") vm.setFullscreen(false) else vm.closePlayer()
                    },
                    onToggleFullscreen = { vm.setFullscreen(false) },
                    onOpenMultiview = { vm.showMultiview.value = true },
                    onSaveProgress = { pos, dur -> vm.savePlaybackProgress(pb, pos, dur) },
                    onSwitchChannel = { ch -> vm.playChannel(ch, true) },
                    onZapByNumber = { num ->
                        channels.firstOrNull { it.number == num }?.let { vm.playChannel(it, true) }
                    },
                    onNextEpisode = nextEpAction
                )
            }
            else -> {
                Row(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier
                            .width(160.dp)
                            .fillMaxHeight()
                            .background(Color(0xFF07090D))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            "TiviClone 4.0",
                            color = TiviColors.AccentBlue,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp)
                        )
                        NavItem(AppSection.LIVE, Icons.Default.LiveTv, section == AppSection.LIVE) {
                            vm.selectedMovie.value = null; vm.selectedSeries.value = null
                            vm.activeSection.value = AppSection.LIVE
                        }
                        NavItem(AppSection.EPG_GUIDE, Icons.Default.CalendarViewWeek, section == AppSection.EPG_GUIDE) {
                            vm.activeSection.value = AppSection.EPG_GUIDE
                        }
                        NavItem(AppSection.MOVIES, Icons.Default.Movie, section == AppSection.MOVIES) {
                            vm.selectedMovie.value = null
                            vm.activeSection.value = AppSection.MOVIES
                        }
                        NavItem(AppSection.SERIES, Icons.Default.Tv, section == AppSection.SERIES) {
                            vm.selectedSeries.value = null
                            vm.activeSection.value = AppSection.SERIES
                        }
                        NavItem(AppSection.CONTINUE_WATCHING, Icons.Default.History, section == AppSection.CONTINUE_WATCHING) {
                            vm.activeSection.value = AppSection.CONTINUE_WATCHING
                        }
                        NavItem(AppSection.FAVORITES, Icons.Default.Star, section == AppSection.FAVORITES) {
                            vm.activeSection.value = AppSection.FAVORITES
                        }
                        NavItem(AppSection.RECORDINGS, Icons.Default.FiberManualRecord, section == AppSection.RECORDINGS) {
                            vm.activeSection.value = AppSection.RECORDINGS
                        }
                        NavItem(AppSection.SEARCH, Icons.Default.Search, section == AppSection.SEARCH) {
                            vm.activeSection.value = AppSection.SEARCH
                        }
                        Spacer(Modifier.weight(1f))
                        NavItem(AppSection.SETTINGS, Icons.Default.Settings, section == AppSection.SETTINGS) {
                            vm.activeSection.value = AppSection.SETTINGS
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        when (section) {
                            AppSection.LIVE -> LiveTvScreen(
                                channels = channels,
                                epgPrograms = epgPrograms,
                                activePlayback = activePlayback,
                                onSelectChannel = { ch, full -> vm.playChannel(ch, full) },
                                onToggleFavorite = { vm.toggleFavorite(it) },
                                onToggleFullscreen = { vm.setFullscreen(true) },
                                onOpenMultiview = { vm.showMultiview.value = true },
                                onClosePlayer = { vm.closePlayer() },
                                onSaveProgress = { pos, dur ->
                                    activePlayback?.let { vm.savePlaybackProgress(it, pos, dur) }
                                }
                            )
                            AppSection.EPG_GUIDE -> EpgTimelineScreen(
                                channels = channels,
                                epgPrograms = epgPrograms,
                                onPlayLive = { ch -> vm.playChannel(ch, true) },
                                onPlayCatchup = { ch, prog -> vm.playCatchup(ch, prog) },
                                onSetReminder = { ch, prog -> vm.setReminder(ch, prog) },
                                onRecordChannel = { ch, title -> vm.startRecording(ch, title) }
                            )
                            AppSection.MOVIES -> {
                                val m = selectedMovie
                                if (m != null) {
                                    MovieDetailScreen(
                                        movie = m,
                                        onPlay = { vm.playMovie(it) },
                                        onToggleFavorite = { vm.toggleFavorite(it) },
                                        onBack = { vm.selectedMovie.value = null }
                                    )
                                } else {
                                    MoviesScreen(movies = movies, onSelectMovie = { vm.openMovieDetails(it) })
                                }
                            }
                            AppSection.SERIES -> {
                                val s = selectedSeries
                                if (s != null) {
                                    SeriesDetailScreen(
                                        series = s,
                                        episodes = seriesEpisodes,
                                        isLoading = isLoading,
                                        onPlayEpisode = { sr, ep -> vm.playEpisode(sr, ep) },
                                        onToggleFavorite = { vm.toggleFavorite(it) },
                                        onBack = { vm.selectedSeries.value = null }
                                    )
                                } else {
                                    SeriesScreen(seriesList = seriesList, onSelectSeries = { vm.openSeriesDetails(it) })
                                }
                            }
                            AppSection.FAVORITES -> FavoritesScreen(
                                channels = favChannels,
                                movies = favMovies,
                                series = favSeries,
                                onPlayChannel = { vm.playChannel(it, true) },
                                onOpenMovie = { vm.openMovieDetails(it); vm.activeSection.value = AppSection.MOVIES },
                                onOpenSeries = { vm.openSeriesDetails(it); vm.activeSection.value = AppSection.SERIES }
                            )
                            AppSection.CONTINUE_WATCHING -> ContinueWatchingScreen(
                                items = continueWatching,
                                onResume = { vm.resumeHistoryItem(it) }
                            )
                            AppSection.RECORDINGS -> RecordingsScreen(
                                recordings = recordings,
                                onDelete = { vm.deleteRecording(it) }
                            )
                            AppSection.SEARCH -> SearchScreen(
                                results = searchResults,
                                onQueryChange = { vm.search(it) },
                                onPlayChannel = { vm.playChannel(it, true) },
                                onOpenMovie = { vm.openMovieDetails(it); vm.activeSection.value = AppSection.MOVIES },
                                onOpenSeries = { vm.openSeriesDetails(it); vm.activeSection.value = AppSection.SERIES }
                            )
                            AppSection.SETTINGS -> SettingsScreen(
                                playlists = playlists,
                                activePlaylistId = activePlaylistId,
                                epgIntervalHours = epgInterval,
                                epgLastUpdated = epgLastUpdated,
                                parentalPin = parentalPin,
                                onSelectPlaylist = { vm.selectPlaylist(it) },
                                onDeletePlaylist = { vm.deletePlaylist(it) },
                                onRefreshAll = { vm.refreshAll() },
                                onUpdateEpgInterval = { vm.updateEpgInterval(it) },
                                onSetParentalPin = { vm.setParentalPin(it) },
                                onOpenAddSource = { showAddSource = true },
                                onExportBackup = { vm.exportBackupJson() },
                                onImportBackup = { vm.importBackupJson(it) }
                            )
                        }
                    }
                }
            }
        }

        if (isLoading) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }

        statusMessage?.let { msg ->
            Snackbar(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                action = {
                    TextButton(onClick = { vm.clearStatus() }) { Text("OK") }
                }
            ) {
                Text(msg)
            }
        }
    }

    if (showAddSource) {
        AddSourceDialog(
            onAddM3uUrl = { n, u, e -> vm.addM3uUrl(n, u, e) },
            onPickM3uFile = { filePicker.launch(arrayOf("*/*")) },
            onAddXtream = { n, h, u, p -> vm.addXtream(n, h, u, p) },
            onAddStalker = { n, u, m -> vm.addStalker(n, u, m) },
            onDismiss = { showAddSource = false }
        )
    }
}

@Composable
private fun NavItem(
    section: AppSection,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) TiviColors.AccentBlue else Color.Transparent)
            .tvFocusableBorder()
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = section.label, tint = if (selected) Color.White else TiviColors.TextSecondary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(section.label, color = if (selected) Color.White else TiviColors.TextSecondary, fontSize = 13.sp)
    }
}
