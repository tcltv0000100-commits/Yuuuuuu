package com.tiviclone.iptv.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.ui.ActivePlayback
import com.tiviclone.iptv.ui.player.IptvPlayerView
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TiviMateTvHomeScreen(
    channels: List<ChannelEntity>,
    epgPrograms: List<EpgProgramEntity>,
    activePlayback: ActivePlayback?,
    onSelectChannel: (ChannelEntity, Boolean) -> Unit,
    onToggleFavorite: (ChannelEntity) -> Unit,
    onToggleFullscreen: () -> Unit,
    onOpenMultiview: () -> Unit,
    onClosePlayer: () -> Unit,
    onPlayCatchup: (ChannelEntity, EpgProgramEntity) -> Unit,
    onSetReminder: (ChannelEntity, EpgProgramEntity) -> Unit,
    onRecordChannel: (ChannelEntity, String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onSaveProgress: (Long, Long) -> Unit
) {
    val context = LocalContext.current
    val hiddenIds = remember { mutableStateListOf<String>() }
    val blockedIds = remember { mutableStateListOf<String>() }
    val customEpgOverrides = remember { mutableStateMapOf<String, String>() }

    val visibleChannels = remember(channels, hiddenIds.size) {
        channels.filter { it.id !in hiddenIds }
    }
    val groups = remember(visibleChannels) {
        listOf("Favorites", "All channels") + visibleChannels.map { it.groupName }.distinct()
    }
    var selectedGroup by remember { mutableStateOf("All channels") }
    var contextChannel by remember { mutableStateOf<ChannelEntity?>(null) }
    var infoDialog by remember { mutableStateOf<Pair<String, String>?>(null) }
    var assignEpgChannel by remember { mutableStateOf<ChannelEntity?>(null) }
    var manageVisibilityOpen by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val groupedEpg = remember(epgPrograms) { epgPrograms.groupBy { it.channelTvgId } }
    val currentEpgMap = remember(epgPrograms, now) {
        epgPrograms.filter { it.startTimeMillis <= now && it.endTimeMillis >= now }
            .associateBy { it.channelTvgId }
    }

    val filtered = remember(visibleChannels, selectedGroup) {
        when (selectedGroup) {
            "Favorites" -> visibleChannels.filter { it.isFavorite }
            "All channels" -> visibleChannels
            else -> visibleChannels.filter { it.groupName == selectedGroup }
        }
    }

    val activeChannel = remember(visibleChannels, activePlayback) {
        visibleChannels.firstOrNull { it.id == activePlayback?.itemId } ?: filtered.firstOrNull()
    }
    val activeEpgId = activeChannel?.let { customEpgOverrides[it.id] ?: it.tvgId }
    val activeProg = activeEpgId?.let { currentEpgMap[it] }
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val headerTimeFmt = remember { SimpleDateFormat("EEE, dd MMM, hh:mm a", Locale.getDefault()) }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0E1013))) {
        Row(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier
                    .width(200.dp)
                    .fillMaxHeight()
                    .background(Color(0xFF111418))
                    .padding(horizontal = 10.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(groups) { grp ->
                    val sel = grp == selectedGroup
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (sel) Color(0xFF282D34) else Color.Transparent)
                            .tvFocusableBorder(6)
                            .clickable { selectedGroup = grp }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Text(
                            grp,
                            color = if (sel) Color.White else TiviColors.TextSecondary,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp)
                        .background(Color(0xFF0A0C0F))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(280.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black)
                    ) {
                        if (activePlayback != null && activePlayback.mediaType == "LIVE" && !activePlayback.isFullscreen) {
                            IptvPlayerView(
                                playback = activePlayback,
                                modifier = Modifier.fillMaxSize(),
                                onBack = onClosePlayer,
                                onToggleFullscreen = onToggleFullscreen,
                                onOpenMultiview = onOpenMultiview,
                                onSaveProgress = onSaveProgress
                            )
                        } else if (activeChannel != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clickable { onSelectChannel(activeChannel, false) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Tap channel to preview", color = TiviColors.TextSecondary, fontSize = 13.sp)
                            }
                        }
                    }

                    Column(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            activeProg?.title ?: "No information",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(6.dp))
                        if (activeProg != null) {
                            val span = (activeProg.endTimeMillis - activeProg.startTimeMillis).coerceAtLeast(1L)
                            val pct = ((now - activeProg.startTimeMillis).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                            val remMin = ((activeProg.endTimeMillis - now) / 60_000L).coerceAtLeast(0L)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    "${timeFmt.format(Date(activeProg.startTimeMillis))} – ${timeFmt.format(Date(activeProg.endTimeMillis))}",
                                    color = TiviColors.TextSecondary,
                                    fontSize = 12.sp
                                )
                                LinearProgressIndicator(
                                    progress = { pct },
                                    modifier = Modifier.width(90.dp).height(3.dp),
                                    color = TiviColors.AccentBlue,
                                    trackColor = TiviColors.Divider
                                )
                                Text("$remMin min", color = TiviColors.TextSecondary, fontSize = 12.sp)
                            }
                            if (activeProg.description.isNotBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    activeProg.description,
                                    color = TiviColors.TextSecondary,
                                    fontSize = 12.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        } else {
                            Text("Select a channel • Long-press for options", color = TiviColors.TextSecondary, fontSize = 12.sp)
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF101317))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        headerTimeFmt.format(Date(now)),
                        color = Color(0xFF5C9EFF),
                        fontSize = 12.sp,
                        modifier = Modifier.width(240.dp)
                    )
                    Text("Now", color = TiviColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.width(170.dp))
                    Text("Next", color = TiviColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.width(170.dp))
                    Text("Later", color = TiviColors.TextSecondary, fontSize = 12.sp)
                }

                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No channels in this group", color = TiviColors.TextSecondary)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filtered, key = { it.id }) { ch ->
                            val isSelected = activePlayback?.itemId == ch.id
                            val isBlocked = ch.id in blockedIds
                            val epgKey = customEpgOverrides[ch.id] ?: ch.tvgId
                            val progs = groupedEpg[epgKey].orEmpty().take(5)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .background(if (isSelected) Color(0xFF1D232C) else Color(0xFF121519))
                                    .tvFocusableBorder(4)
                                    .combinedClickable(
                                        onClick = {
                                            if (isBlocked) {
                                                infoDialog = "Blocked Channel" to "${ch.name} is blocked. Unblock it from Channel Options."
                                            } else {
                                                onSelectChannel(ch, isSelected)
                                            }
                                        },
                                        onLongClick = { contextChannel = ch }
                                    )
                                    .padding(horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${ch.number}", color = TiviColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.width(30.dp))
                                if (ch.logoUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = ch.logoUrl,
                                        contentDescription = ch.name,
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.size(30.dp).padding(end = 8.dp)
                                    )
                                }
                                Row(modifier = Modifier.width(185.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        if (isBlocked) "🔒 ${ch.name}" else ch.name,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (isSelected) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TiviColors.AccentBlue, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Row(
                                    modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (progs.isEmpty()) {
                                        EpgSlotBox("No information", false) { contextChannel = ch }
                                        EpgSlotBox("No information", false) { contextChannel = ch }
                                    } else {
                                        progs.forEach { p ->
                                            val isLive = p.startTimeMillis <= now && p.endTimeMillis >= now
                                            EpgSlotBox(p.title, isLive) {
                                                if (p.endTimeMillis < now && ch.hasCatchup) {
                                                    onPlayCatchup(ch, p)
                                                } else if (p.startTimeMillis > now) {
                                                    onSetReminder(ch, p)
                                                } else {
                                                    contextChannel = ch
                                                }
                                            }
                                        }
                                    }
                                }

                                IconButton(onClick = { contextChannel = ch }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = TiviColors.TextSecondary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right-side Channel Context Menu Drawer (Images 9 & 10)
        contextChannel?.let { ch ->
            val isBlocked = ch.id in blockedIds
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x77000000))
                    .clickable { contextChannel = null }
            ) {
                LazyColumn(
                    modifier = Modifier
                        .width(290.dp)
                        .fillMaxHeight()
                        .align(Alignment.CenterEnd)
                        .background(Color(0xFF1A1D21))
                        .clickable(enabled = false) {}
                        .padding(vertical = 12.dp)
                ) {
                    item {
                        ContextRow(Icons.Default.Search, "Search") { contextChannel = null; onOpenSearch() }
                        ContextRow(Icons.Default.Settings, "Settings") { contextChannel = null; onOpenSettings() }
                        HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 6.dp))
                        Text(
                            currentEpgMap[customEpgOverrides[ch.id] ?: ch.tvgId]?.title ?: "No information",
                            color = TiviColors.AccentBlue,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp)
                        )
                        ContextRow(null, "Open in external player") {
                            contextChannel = null
                            if (ch.streamUrl.isNotBlank()) {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(Uri.parse(ch.streamUrl), "video/*")
                                    })
                                }
                            }
                        }
                        ContextRow(null, "Record") {
                            contextChannel = null
                            onRecordChannel(ch, currentEpgMap[ch.tvgId]?.title ?: ch.name)
                        }
                        ContextRow(null, "Custom recording") {
                            contextChannel = null
                            onRecordChannel(ch, ch.name)
                        }
                        HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 6.dp))
                        Text(ch.name, color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
                        ContextRow(null, if (ch.isFavorite) "Remove from Favorites" else "Add to Favorites") {
                            onToggleFavorite(ch); contextChannel = null
                        }
                        ContextRow(null, if (isBlocked) "Unblock channel" else "Block channel") {
                            if (isBlocked) blockedIds.remove(ch.id) else blockedIds.add(ch.id)
                            contextChannel = null
                        }
                        ContextRow(null, "Hide channel") {
                            hiddenIds.add(ch.id)
                            contextChannel = null
                        }
                        ContextRow(null, "Assign EPG") {
                            assignEpgChannel = ch
                            contextChannel = null
                        }
                        ContextRow(null, "Channel options") {
                            infoDialog = ch.name to "Group: ${ch.groupName}\nSource: ${ch.sourceType.name}\nCatch-up: ${if (ch.hasCatchup) "${ch.catchupDays} days" else "No"}\nTVG ID: ${ch.tvgId.ifBlank { "None" }}"
                            contextChannel = null
                        }
                        HorizontalDivider(color = TiviColors.Divider, modifier = Modifier.padding(vertical = 6.dp))
                        Text(selectedGroup, color = TiviColors.AccentBlue, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
                        ContextRow(null, "Manage Favorites") {
                            selectedGroup = "Favorites"
                            contextChannel = null
                        }
                        ContextRow(null, "Manage blocking") {
                            blockedIds.clear()
                            infoDialog = "Manage blocking" to "All blocked channels unlocked."
                            contextChannel = null
                        }
                        ContextRow(null, "Manage visibility") {
                            manageVisibilityOpen = true
                            contextChannel = null
                        }
                        ContextRow(null, "Group options") {
                            infoDialog = selectedGroup to "Channels in group: ${filtered.size}\nHidden channels: ${hiddenIds.size}"
                            contextChannel = null
                        }
                    }
                }
            }
        }
    }

    assignEpgChannel?.let { ch ->
        var epgIdInput by remember { mutableStateOf(customEpgOverrides[ch.id] ?: ch.tvgId) }
        AlertDialog(
            onDismissRequest = { assignEpgChannel = null },
            title = { Text("Assign EPG: ${ch.name}") },
            text = {
                OutlinedTextField(
                    value = epgIdInput,
                    onValueChange = { epgIdInput = it },
                    label = { Text("XMLTV Channel ID (tvg-id)") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    customEpgOverrides[ch.id] = epgIdInput.trim()
                    assignEpgChannel = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { assignEpgChannel = null }) { Text("Cancel") }
            }
        )
    }

    if (manageVisibilityOpen) {
        AlertDialog(
            onDismissRequest = { manageVisibilityOpen = false },
            title = { Text("Hidden Channels (${hiddenIds.size})") },
            text = {
                if (hiddenIds.isEmpty()) Text("No channels are hidden.")
                else Text("${hiddenIds.size} channel(s) hidden. Tap Restore All to unhide.")
            },
            confirmButton = {
                Button(onClick = {
                    hiddenIds.clear()
                    manageVisibilityOpen = false
                }) { Text("Restore All") }
            },
            dismissButton = {
                TextButton(onClick = { manageVisibilityOpen = false }) { Text("Close") }
            }
        )
    }

    infoDialog?.let { (title, body) ->
        AlertDialog(
            onDismissRequest = { infoDialog = null },
            title = { Text(title) },
            text = { Text(body) },
            confirmButton = { TextButton(onClick = { infoDialog = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun EpgSlotBox(title: String, isLive: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(165.dp)
            .height(38.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (isLive) Color(0xFF2B313B) else Color(0xFF191D23))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(title, color = if (isLive) Color.White else TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ContextRow(icon: androidx.compose.ui.graphics.vector.ImageVector?, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .tvFocusableBorder(4)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}
