package com.tiviclone.iptv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tiviclone.iptv.data.db.*
import com.tiviclone.iptv.data.repository.GlobalSearchResults
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FavoritesScreen(
    channels: List<ChannelEntity>,
    movies: List<VodMovieEntity>,
    series: List<SeriesEntity>,
    onPlayChannel: (ChannelEntity) -> Unit,
    onOpenMovie: (VodMovieEntity) -> Unit,
    onOpenSeries: (SeriesEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(TiviColors.Background).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("Favorites", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        if (channels.isEmpty() && movies.isEmpty() && series.isEmpty()) {
            item { Text("No favorites yet.", color = TiviColors.TextSecondary) }
        }
        if (channels.isNotEmpty()) {
            item { Text("Live Channels", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold) }
            items(channels, key = { it.id }) { ch ->
                SimpleListRow(ch.name, ch.groupName) { onPlayChannel(ch) }
            }
        }
        if (movies.isNotEmpty()) {
            item { Text("Movies", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold) }
            items(movies, key = { it.id }) { m ->
                SimpleListRow(m.name, m.categoryName) { onOpenMovie(m) }
            }
        }
        if (series.isNotEmpty()) {
            item { Text("Series", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold) }
            items(series, key = { it.id }) { s ->
                SimpleListRow(s.name, s.categoryName) { onOpenSeries(s) }
            }
        }
    }
}

@Composable
fun ContinueWatchingScreen(
    items: List<WatchHistoryEntity>,
    onResume: (WatchHistoryEntity) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(TiviColors.Background).padding(16.dp)) {
        Text("Continue Watching", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (items.isEmpty()) {
            Text("Nothing in progress yet.", color = TiviColors.TextSecondary)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.itemId }) { item ->
                    val pct = if (item.durationMs > 0L) (item.positionMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f, 1f) else 0f
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(TiviColors.PanelBg)
                            .tvFocusableBorder()
                            .clickable { onResume(item) }
                            .padding(12.dp)
                    ) {
                        Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                        if (item.subtitle.isNotBlank()) {
                            Text(item.subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}

@Composable
fun RecordingsScreen(
    recordings: List<RecordingEntity>,
    onDelete: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().background(TiviColors.Background).padding(16.dp)) {
        Text("Recordings (DVR)", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (recordings.isEmpty()) {
            Text("No recordings yet.", color = TiviColors.TextSecondary)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(recordings, key = { it.id }) { rec ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(TiviColors.PanelBg, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rec.programTitle, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${rec.channelName} • ${rec.status}", color = TiviColors.TextSecondary, fontSize = 12.sp)
                            Text(rec.filePath, color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { onDelete(rec.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TiviColors.DangerRed)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchScreen(
    results: GlobalSearchResults,
    onQueryChange: (String) -> Unit,
    onPlayChannel: (ChannelEntity) -> Unit,
    onOpenMovie: (VodMovieEntity) -> Unit,
    onOpenSeries: (SeriesEntity) -> Unit
) {
    var query by remember { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().background(TiviColors.Background).padding(16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = {
                query = it
                onQueryChange(it)
            },
            label = { Text("Search Live, Movies, Series, or EPG...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (results.channels.isNotEmpty()) {
                item { Text("Channels (${results.channels.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold) }
                items(results.channels, key = { it.id }) { ch ->
                    SimpleListRow(ch.name, ch.groupName) { onPlayChannel(ch) }
                }
            }
            if (results.movies.isNotEmpty()) {
                item { Text("Movies (${results.movies.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold) }
                items(results.movies, key = { it.id }) { m ->
                    SimpleListRow(m.name, m.categoryName) { onOpenMovie(m) }
                }
            }
            if (results.series.isNotEmpty()) {
                item { Text("Series (${results.series.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold) }
                items(results.series, key = { it.id }) { s ->
                    SimpleListRow(s.name, s.categoryName) { onOpenSeries(s) }
                }
            }
            if (results.programs.isNotEmpty()) {
                item { Text("EPG Programs (${results.programs.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.Bold) }
                items(results.programs, key = { it.rowId }) { p ->
                    SimpleListRow(p.title, p.description.take(80)) {}
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    playlists: List<PlaylistEntity>,
    activePlaylistId: String,
    epgIntervalHours: Int,
    epgLastUpdated: Long,
    parentalPin: String,
    onSelectPlaylist: (String) -> Unit,
    onDeletePlaylist: (String) -> Unit,
    onRefreshAll: () -> Unit,
    onUpdateEpgInterval: (Int) -> Unit,
    onSetParentalPin: (String) -> Unit,
    onOpenAddSource: () -> Unit,
    onExportBackup: suspend () -> String,
    onImportBackup: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var showBackupDialog by remember { mutableStateOf(false) }
    var backupText by remember { mutableStateOf("") }
    var pinInput by remember(parentalPin) { mutableStateOf(parentalPin) }

    val lastStr = remember(epgLastUpdated) {
        if (epgLastUpdated <= 0L) "Never"
        else SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(epgLastUpdated))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TiviColors.Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Settings & Playlists", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onOpenAddSource) { Text("+ Add Playlist / Portal") }
                OutlinedButton(onClick = onRefreshAll) { Text("Sync All") }
            }
        }

        Text("Saved Playlists (${playlists.size})", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold)
        playlists.forEach { pl ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (pl.id == activePlaylistId) TiviColors.CardFocused else TiviColors.PanelBg,
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onSelectPlaylist(pl.id) }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("${pl.name} (${pl.type.name})", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(pl.primaryUrl, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (pl.accountStatus.isNotBlank()) {
                        Text("Status: ${pl.accountStatus}", color = TiviColors.CatchupGreen, fontSize = 11.sp)
                    }
                }
                IconButton(onClick = { onDeletePlaylist(pl.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TiviColors.DangerRed)
                }
            }
        }

        Text("EPG Auto-Update (Last: $lastStr)", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(4, 12, 24).forEach { hrs ->
                FilterChip(
                    selected = epgIntervalHours == hrs,
                    onClick = { onUpdateEpgInterval(hrs) },
                    label = { Text("Every ${hrs}h") }
                )
            }
        }

        Text("Parental Control PIN (empty = off)", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = pinInput,
                onValueChange = { if (it.length <= 6) pinInput = it },
                label = { Text("4-6 digit PIN") },
                singleLine = true,
                modifier = Modifier.width(180.dp)
            )
            Button(onClick = { onSetParentalPin(pinInput.trim()) }) { Text("Save PIN") }
        }

        Text("Backup & Restore", color = TiviColors.AccentBlue, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                scope.launch {
                    backupText = onExportBackup()
                    clipboard.setText(AnnotatedString(backupText))
                    showBackupDialog = true
                }
            }) { Text("Export Backup JSON") }
            OutlinedButton(onClick = {
                backupText = ""
                showBackupDialog = true
            }) { Text("Restore from JSON") }
        }
    }

    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("Backup / Restore JSON") },
            text = {
                OutlinedTextField(
                    value = backupText,
                    onValueChange = { backupText = it },
                    modifier = Modifier.fillMaxWidth().height(200.dp)
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (backupText.isNotBlank()) onImportBackup(backupText)
                    showBackupDialog = false
                }) { Text("Restore") }
            },
            dismissButton = {
                TextButton(onClick = { showBackupDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
fun AddSourceDialog(
    onAddM3uUrl: (String, String, String) -> Unit,
    onPickM3uFile: () -> Unit,
    onAddXtream: (String, String, String, String) -> Unit,
    onAddStalker: (String, String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var tab by remember { mutableStateOf("Stalker") }
    var name by remember { mutableStateOf("") }
    var m3uUrl by remember { mutableStateOf("") }
    var epgUrl by remember { mutableStateOf("") }
    var xtreamHost by remember { mutableStateOf("") }
    var xtreamUser by remember { mutableStateOf("") }
    var xtreamPass by remember { mutableStateOf("") }
    var stalkerUrl by remember { mutableStateOf("") }
    var stalkerMac by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add IPTV Source") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Stalker", "Xtream", "M3U").forEach { t ->
                        FilterChip(
                            selected = tab == t,
                            onClick = { tab = t },
                            label = { Text(t) }
                        )
                    }
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Playlist Name (Optional)") },
                    singleLine = true
                )
                when (tab) {
                    "Stalker" -> {
                        OutlinedTextField(
                            value = stalkerUrl,
                            onValueChange = { stalkerUrl = it },
                            label = { Text("Portal URL (http://.../c/)") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = stalkerMac,
                            onValueChange = { stalkerMac = it },
                            label = { Text("MAC Address (SN & DeviceID auto)") },
                            singleLine = true
                        )
                    }
                    "Xtream" -> {
                        OutlinedTextField(
                            value = xtreamHost,
                            onValueChange = { xtreamHost = it },
                            label = { Text("Server URL (http://host:port)") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = xtreamUser,
                            onValueChange = { xtreamUser = it },
                            label = { Text("Username") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = xtreamPass,
                            onValueChange = { xtreamPass = it },
                            label = { Text("Password") },
                            singleLine = true
                        )
                    }
                    "M3U" -> {
                        OutlinedTextField(
                            value = m3uUrl,
                            onValueChange = { m3uUrl = it },
                            label = { Text("M3U / M3U8 URL") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = epgUrl,
                            onValueChange = { epgUrl = it },
                            label = { Text("XMLTV EPG URL (Optional)") },
                            singleLine = true
                        )
                        OutlinedButton(onClick = { onPickM3uFile(); onDismiss() }) {
                            Text("Or Pick Local .m3u File")
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                when (tab) {
                    "Stalker" -> if (stalkerUrl.isNotBlank() && stalkerMac.isNotBlank()) {
                        onAddStalker(name, stalkerUrl, stalkerMac)
                    }
                    "Xtream" -> if (xtreamHost.isNotBlank() && xtreamUser.isNotBlank()) {
                        onAddXtream(name, xtreamHost, xtreamUser, xtreamPass)
                    }
                    "M3U" -> if (m3uUrl.isNotBlank()) {
                        onAddM3uUrl(name, m3uUrl, epgUrl)
                    }
                }
                onDismiss()
            }) { Text("Connect") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun SimpleListRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(TiviColors.PanelBg)
            .tvFocusableBorder()
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Medium)
            if (subtitle.isNotBlank()) {
                Text(subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
