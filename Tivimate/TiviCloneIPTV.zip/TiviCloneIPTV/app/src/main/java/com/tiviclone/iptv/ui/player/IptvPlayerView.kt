package com.tiviclone.iptv.ui.player

import android.view.KeyEvent as AndroidKeyEvent
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.data.model.TrackOption
import com.tiviclone.iptv.data.model.VideoRatioMode
import com.tiviclone.iptv.data.network.HttpClientProvider
import com.tiviclone.iptv.recorder.RecordingService
import com.tiviclone.iptv.ui.ActivePlayback
import com.tiviclone.iptv.ui.theme.TiviColors
import com.tiviclone.iptv.ui.theme.tvFocusableBorder
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun IptvPlayerView(
    playback: ActivePlayback,
    channels: List<ChannelEntity> = emptyList(),
    epgPrograms: List<EpgProgramEntity> = emptyList(),
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onOpenMultiview: () -> Unit,
    onSaveProgress: (Long, Long) -> Unit,
    onSwitchChannel: (ChannelEntity) -> Unit = {},
    onZapByNumber: (Int) -> Unit = {},
    onNextEpisode: (() -> Unit)? = null
) {
    val context = LocalContext.current
    var ratioMode by remember { mutableStateOf(VideoRatioMode.FIT) }
    var showControls by remember { mutableStateOf(true) }
    var showEpgOverlay by remember { mutableStateOf(false) }
    var showTracksDialog by remember { mutableStateOf(false) }
    var showSleepDialog by remember { mutableStateOf(false) }
    var sleepMinutesLeft by remember { mutableIntStateOf(0) }
    var isRecording by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var tracks by remember { mutableStateOf<Tracks>(Tracks.EMPTY) }
    var retryKey by remember { mutableIntStateOf(0) }
    var zapDigits by remember { mutableStateOf("") }

    val player = remember(playback.streamUrl, retryKey) {
        val rf = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        val ua = playback.userAgent.ifBlank { HttpClientProvider.DEFAULT_USER_AGENT }
        val dsFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)

        ExoPlayer.Builder(context, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
            .build().apply {
                setMediaItem(MediaItem.fromUri(playback.streamUrl))
                if (playback.resumePositionMs > 5000L) {
                    seekTo(playback.resumePositionMs)
                }
                prepare()
                playWhenReady = true
            }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onPlayerError(error: PlaybackException) {
                errorMessage = "Playback error (${error.errorCodeName})"
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) errorMessage = null
                if (playbackState == Player.STATE_ENDED && playback.mediaType == "SERIES") {
                    onNextEpisode?.invoke()
                }
            }
        }
        player.addListener(listener)
        onDispose {
            onSaveProgress(player.currentPosition, player.duration)
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(player, playback.itemId) {
        while (true) {
            delay(10_000L)
            if (player.isPlaying) {
                onSaveProgress(player.currentPosition, player.duration)
            }
        }
    }

    // 0-9 Remote Zapping debounce
    LaunchedEffect(zapDigits) {
        if (zapDigits.isNotEmpty()) {
            delay(1400L)
            val num = zapDigits.toIntOrNull()
            zapDigits = ""
            if (num != null) onZapByNumber(num)
        }
    }

    LaunchedEffect(sleepMinutesLeft) {
        if (sleepMinutesLeft > 0) {
            delay(60_000L)
            sleepMinutesLeft -= 1
            if (sleepMinutesLeft == 0) {
                player.pause()
                onBack()
            }
        }
    }

    Box(
        modifier = modifier
            .background(Color.Black)
            .focusable()
            .onPreviewKeyEvent { keyEvent ->
                val native = keyEvent.nativeKeyEvent
                if (native.action == AndroidKeyEvent.ACTION_DOWN && playback.isFullscreen && playback.mediaType == "LIVE") {
                    val code = native.keyCode
                    when {
                        code in AndroidKeyEvent.KEYCODE_0..AndroidKeyEvent.KEYCODE_9 -> {
                            val digit = code - AndroidKeyEvent.KEYCODE_0
                            if (zapDigits.length < 5) zapDigits += digit.toString()
                            true
                        }
                        code == AndroidKeyEvent.KEYCODE_CHANNEL_UP || (code == AndroidKeyEvent.KEYCODE_DPAD_UP && !showEpgOverlay) -> {
                            val idx = channels.indexOfFirst { it.id == playback.itemId }
                            if (idx >= 0 && channels.isNotEmpty()) {
                                val next = channels[(idx + 1) % channels.size]
                                onSwitchChannel(next)
                            }
                            true
                        }
                        code == AndroidKeyEvent.KEYCODE_CHANNEL_DOWN || (code == AndroidKeyEvent.KEYCODE_DPAD_DOWN && !showEpgOverlay) -> {
                            val idx = channels.indexOfFirst { it.id == playback.itemId }
                            if (idx >= 0 && channels.isNotEmpty()) {
                                val prev = channels[(idx - 1 + channels.size) % channels.size]
                                onSwitchChannel(prev)
                            }
                            true
                        }
                        code == AndroidKeyEvent.KEYCODE_DPAD_LEFT || code == AndroidKeyEvent.KEYCODE_GUIDE -> {
                            showEpgOverlay = !showEpgOverlay
                            true
                        }
                        else -> false
                    }
                } else false
            }
            .clickable { showControls = !showControls }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = playback.mediaType != "LIVE"
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { view ->
                view.player = player
                view.resizeMode = when (ratioMode) {
                    VideoRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    VideoRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    VideoRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // 0-9 Zapping OSD
        if (zapDigits.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp)
                    .background(Color(0xDD10151E), RoundedCornerShape(10.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text("CH $zapDigits", color = TiviColors.AccentBlue, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Fullscreen Live EPG Overlay Drawer
        if (showEpgOverlay && playback.isFullscreen && playback.mediaType == "LIVE") {
            val now = System.currentTimeMillis()
            val epgMap = remember(epgPrograms, now) {
                epgPrograms.filter { it.startTimeMillis <= now && it.endTimeMillis >= now }
                    .associateBy { it.channelTvgId }
            }
            Column(
                modifier = Modifier
                    .width(320.dp)
                    .fillMaxHeight()
                    .align(Alignment.CenterStart)
                    .background(Color(0xE60A0D12))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Live Guide", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(onClick = { showEpgOverlay = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(channels, key = { it.id }) { ch ->
                        val prog = epgMap[ch.tvgId]
                        val active = ch.id == playback.itemId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (active) TiviColors.CardFocused else Color(0x88161D29))
                                .tvFocusableBorder(6)
                                .clickable {
                                    onSwitchChannel(ch)
                                    showEpgOverlay = false
                                }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${ch.number}", color = TiviColors.TextSecondary, fontSize = 11.sp, modifier = Modifier.width(28.dp))
                            if (ch.logoUrl.isNotBlank()) {
                                AsyncImage(
                                    model = ch.logoUrl,
                                    contentDescription = ch.name,
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.size(26.dp).padding(end = 6.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ch.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (prog != null) {
                                    Text(prog.title, color = TiviColors.TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (errorMessage != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0xCC111622), RoundedCornerShape(12.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(errorMessage!!, color = TiviColors.DangerRed, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { errorMessage = null; retryKey++ }) {
                    Text("Retry Stream")
                }
            }
        }

        if (showControls) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xAA0A0D12))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .align(Alignment.TopCenter),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(playback.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (playback.subtitle.isNotBlank()) {
                        Text(playback.subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp)
                    }
                }
                if (sleepMinutesLeft > 0) {
                    Text("Sleep ${sleepMinutesLeft}m", color = TiviColors.FavoriteGold, fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
                }
                if (playback.isFullscreen && playback.mediaType == "LIVE") {
                    IconButton(onClick = { showEpgOverlay = !showEpgOverlay }) {
                        Icon(Icons.Default.ViewList, contentDescription = "Guide Overlay", tint = Color.White)
                    }
                }
                IconButton(onClick = { showTracksDialog = true }) {
                    Icon(Icons.Default.Subtitles, contentDescription = "Audio & Subtitles", tint = Color.White)
                }
                TextButton(onClick = {
                    val modes = VideoRatioMode.entries
                    ratioMode = modes[(modes.indexOf(ratioMode) + 1) % modes.size]
                }) {
                    Text(ratioMode.label, color = Color.White)
                }
                IconButton(onClick = { showSleepDialog = true }) {
                    Icon(Icons.Default.Bedtime, contentDescription = "Sleep Timer", tint = Color.White)
                }
                if (playback.mediaType == "LIVE") {
                    IconButton(onClick = {
                        if (isRecording) {
                            RecordingService.stop(context)
                            isRecording = false
                        } else {
                            RecordingService.start(context, playback.itemId, playback.title, playback.title, playback.streamUrl)
                            isRecording = true
                        }
                    }) {
                        Icon(
                            Icons.Default.FiberManualRecord,
                            contentDescription = "Record",
                            tint = if (isRecording) TiviColors.DangerRed else Color.White
                        )
                    }
                    IconButton(onClick = onOpenMultiview) {
                        Icon(Icons.Default.GridView, contentDescription = "Multiview", tint = Color.White)
                    }
                }
                if (playback.mediaType == "SERIES" && onNextEpisode != null) {
                    TextButton(onClick = onNextEpisode) {
                        Text("Next Ep ⏭", color = TiviColors.CatchupGreen)
                    }
                }
                IconButton(onClick = onToggleFullscreen) {
                    Icon(
                        if (playback.isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                        contentDescription = "Fullscreen",
                        tint = Color.White
                    )
                }
            }
        }
    }

    if (showTracksDialog) {
        TrackSelectorDialog(
            tracks = tracks,
            onSelect = { opt ->
                val builder = player.trackSelectionParameters.buildUpon()
                builder.setOverrideForType(TrackSelectionOverride(opt.group.mediaTrackGroup, opt.trackIndex))
                player.trackSelectionParameters = builder.build()
                showTracksDialog = false
            },
            onDisableSubtitles = {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showTracksDialog = false
            },
            onDismiss = { showTracksDialog = false }
        )
    }

    if (showSleepDialog) {
        AlertDialog(
            onDismissRequest = { showSleepDialog = false },
            title = { Text("Sleep Timer") },
            text = {
                Column {
                    listOf(0 to "Off", 15 to "15 minutes", 30 to "30 minutes", 60 to "60 minutes", 90 to "90 minutes")
                        .forEach { (mins, label) ->
                            TextButton(onClick = { sleepMinutesLeft = mins; showSleepDialog = false }) {
                                Text(label)
                            }
                        }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSleepDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun TrackSelectorDialog(
    tracks: Tracks,
    onSelect: (TrackOption) -> Unit,
    onDisableSubtitles: () -> Unit,
    onDismiss: () -> Unit
) {
    val options = remember(tracks) {
        val list = mutableListOf<TrackOption>()
        for (g in tracks.groups) {
            if (g.type == C.TRACK_TYPE_AUDIO || g.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until g.length) {
                    val fmt = g.getTrackFormat(i)
                    val prefix = if (g.type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                    val lang = fmt.language ?: "und"
                    val label = "$prefix: ${fmt.label ?: lang} (${fmt.sampleMimeType ?: ""})"
                    list.add(TrackOption(g.type, g, i, label, g.isTrackSelected(i)))
                }
            }
        }
        list
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Audio & Subtitles") },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                item {
                    TextButton(onClick = onDisableSubtitles) {
                        Text("Subtitles: Off", color = TiviColors.TextSecondary)
                    }
                }
                items(options) { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(opt) }
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = opt.isSelected, onClick = { onSelect(opt) })
                        Spacer(Modifier.width(8.dp))
                        Text(opt.label, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
