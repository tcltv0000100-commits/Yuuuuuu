package com.tiviclone.iptv.ui.player

import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.tiviclone.iptv.data.model.TrackOption
import com.tiviclone.iptv.data.model.VideoRatioMode
import com.tiviclone.iptv.data.network.HttpClientProvider
import com.tiviclone.iptv.recorder.RecordingService
import com.tiviclone.iptv.ui.ActivePlayback
import com.tiviclone.iptv.ui.theme.TiviColors
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun IptvPlayerView(
    playback: ActivePlayback,
    modifier: Modifier = Modifier,
    onBack: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onOpenMultiview: () -> Unit,
    onSaveProgress: (Long, Long) -> Unit
) {
    val context = LocalContext.current
    var ratioMode by remember { mutableStateOf(VideoRatioMode.FIT) }
    var showControls by remember { mutableStateOf(true) }
    var showTracksDialog by remember { mutableStateOf(false) }
    var showSleepDialog by remember { mutableStateOf(false) }
    var sleepMinutesLeft by remember { mutableIntStateOf(0) }
    var isRecording by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var tracks by remember { mutableStateOf<Tracks>(Tracks.EMPTY) }
    var retryKey by remember { mutableIntStateOf(0) }

    val player = remember(playback.streamUrl, retryKey) {
        val rf = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        val ua = playback.userAgent.ifBlank { HttpClientProvider.DEFAULT_USER_AGENT }
        val dsFactory = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)

        ExoPlayer.Builder(context, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
            .build().apply {
                setMediaItem(MediaItem.fromUri(playback.streamUrl))
                if (playback.resumePositionMs > 5000L) {
                    seekTo(playback.resumePositionMs)
                }
                prepare()
                playWhenReady = true
            }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onPlayerError(error: PlaybackException) {
                errorMessage = "Playback error (${error.errorCodeName})"
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) errorMessage = null
            }
        }
        player.addListener(listener)
        onDispose {
            onSaveProgress(player.currentPosition, player.duration)
            player.removeListener(listener)
            player.release()
        }
    }

    // Periodic progress saver (every 10s) & Sleep timer countdown
    LaunchedEffect(player, playback.itemId) {
        while (true) {
            delay(10_000L)
            if (player.isPlaying) {
                onSaveProgress(player.currentPosition, player.duration)
            }
        }
    }

    LaunchedEffect(sleepMinutesLeft) {
        if (sleepMinutesLeft > 0) {
            delay(60_000L)
            sleepMinutesLeft -= 1
            if (sleepMinutesLeft == 0) {
                player.pause()
                onBack()
            }
        }
    }

    Box(
        modifier = modifier
            .background(Color.Black)
            .clickable { showControls = !showControls }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = playback.mediaType != "LIVE"
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { view ->
                view.player = player
                view.resizeMode = when (ratioMode) {
                    VideoRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    VideoRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    VideoRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (errorMessage != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(Color(0xCC111622), RoundedCornerShape(12.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(errorMessage!!, color = TiviColors.DangerRed, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { errorMessage = null; retryKey++ }) {
                    Text("Retry Stream")
                }
            }
        }

        if (showControls) {
            // Top OSD bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xAA0A0D12))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .align(Alignment.TopCenter),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(playback.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (playback.subtitle.isNotBlank()) {
                        Text(playback.subtitle, color = TiviColors.TextSecondary, fontSize = 12.sp)
                    }
                }
                if (sleepMinutesLeft > 0) {
                    Text("Sleep ${sleepMinutesLeft}m", color = TiviColors.FavoriteGold, fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
                }
                IconButton(onClick = { showTracksDialog = true }) {
                    Icon(Icons.Default.Subtitles, contentDescription = "Audio & Subtitles", tint = Color.White)
                }
                TextButton(onClick = {
                    val modes = VideoRatioMode.entries
                    ratioMode = modes[(modes.indexOf(ratioMode) + 1) % modes.size]
                }) {
                    Text(ratioMode.label, color = Color.White)
                }
                IconButton(onClick = { showSleepDialog = true }) {
                    Icon(Icons.Default.Bedtime, contentDescription = "Sleep Timer", tint = Color.White)
                }
                if (playback.mediaType == "LIVE") {
                    IconButton(onClick = {
                        if (isRecording) {
                            RecordingService.stop(context)
                            isRecording = false
                        } else {
                            RecordingService.start(context, playback.itemId, playback.title, playback.title, playback.streamUrl)
                            isRecording = true
                        }
                    }) {
                        Icon(
                            Icons.Default.FiberManualRecord,
                            contentDescription = "Record",
                            tint = if (isRecording) TiviColors.DangerRed else Color.White
                        )
                    }
                    IconButton(onClick = onOpenMultiview) {
                        Icon(Icons.Default.GridView, contentDescription = "Multiview", tint = Color.White)
                    }
                }
                IconButton(onClick = onToggleFullscreen) {
                    Icon(
                        if (playback.isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                        contentDescription = "Fullscreen",
                        tint = Color.White
                    )
                }
            }
        }
    }

    if (showTracksDialog) {
        TrackSelectorDialog(
            tracks = tracks,
            onSelect = { opt ->
                val builder = player.trackSelectionParameters.buildUpon()
                builder.setOverrideForType(TrackSelectionOverride(opt.group.mediaTrackGroup, opt.trackIndex))
                player.trackSelectionParameters = builder.build()
                showTracksDialog = false
            },
            onDisableSubtitles = {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                showTracksDialog = false
            },
            onDismiss = { showTracksDialog = false }
        )
    }

    if (showSleepDialog) {
        AlertDialog(
            onDismissRequest = { showSleepDialog = false },
            title = { Text("Sleep Timer") },
            text = {
                Column {
                    listOf(0 to "Off", 15 to "15 minutes", 30 to "30 minutes", 60 to "60 minutes", 90 to "90 minutes")
                        .forEach { (mins, label) ->
                            TextButton(onClick = { sleepMinutesLeft = mins; showSleepDialog = false }) {
                                Text(label)
                            }
                        }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSleepDialog = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun TrackSelectorDialog(
    tracks: Tracks,
    onSelect: (TrackOption) -> Unit,
    onDisableSubtitles: () -> Unit,
    onDismiss: () -> Unit
) {
    val options = remember(tracks) {
        val list = mutableListOf<TrackOption>()
        for (g in tracks.groups) {
            if (g.type == C.TRACK_TYPE_AUDIO || g.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until g.length) {
                    val fmt = g.getTrackFormat(i)
                    val prefix = if (g.type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                    val lang = fmt.language ?: "und"
                    val label = "$prefix: ${fmt.label ?: lang} (${fmt.sampleMimeType ?: ""})"
                    list.add(TrackOption(g.type, g, i, label, g.isTrackSelected(i)))
                }
            }
        }
        list
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Audio & Subtitles") },
        text = {
            LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                item {
                    TextButton(onClick = onDisableSubtitles) {
                        Text("Subtitles: Off", color = TiviColors.TextSecondary)
                    }
                }
                items(options) { opt ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(opt) }
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = opt.isSelected, onClick = { onSelect(opt) })
                        Spacer(Modifier.width(8.dp))
                        Text(opt.label, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
