package com.tiviclone.iptv.data.network

import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.data.db.EpisodeEntity
import com.tiviclone.iptv.data.db.SeriesEntity
import com.tiviclone.iptv.data.db.VodMovieEntity
import com.tiviclone.iptv.data.model.SourceType
import com.tiviclone.iptv.data.model.StalkerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.MessageDigest

data class StalkerLoadResult(
    val activePortalUrl: String,
    val token: String,
    val channels: List<ChannelEntity>,
    val movies: List<VodMovieEntity>,
    val series: List<SeriesEntity>
)

object StalkerClient {

    const val STB_USER_AGENT =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

    private val stalkerHttp by lazy { HttpClientProvider.createClient(STB_USER_AGENT) }

    fun fixScheme(url: String): String {
        val trimmed = url.trim()
        return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed else "http://$trimmed"
    }

    fun extractOrigin(url: String): String {
        return try {
            val u = URI(fixScheme(url))
            val port = if (u.port > 0) ":${u.port}" else ""
            "${u.scheme}://${u.host}$port"
        } catch (_: Exception) {
            fixScheme(url).trimEnd('/')
        }
    }

    /**
     * Auto-generates candidate Stalker portal endpoints from any base URL
     */
    fun buildPortalCandidates(rawUrl: String): List<String> {
        val base = fixScheme(rawUrl).trimEnd('/')
        val origin = extractOrigin(base)
        return listOf(
            "$base/portal.php",
            "$base/server/load.php",
            "$origin/stalker_portal/server/load.php",
            "$origin/c/server/load.php",
            "$origin/portal.php",
            "$origin/server/load.php",
            base
        ).distinct()
    }

    private fun md5Upper(input: String): String {
        val md = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return md.joinToString("") { "%02X".format(it) }
    }

    private fun sha256Upper(input: String): String {
        val md = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return md.joinToString("") { "%02X".format(it) }
    }

    private fun buildStbHeaders(mac: String, token: String = ""): Map<String, String> {
        val cleanMac = mac.trim().uppercase()
        val sn = md5Upper(cleanMac).take(13)
        val devId = sha256Upper(cleanMac)
        val devId2 = sha256Upper("DEV2_$cleanMac")
        val sig = sha256Upper("${cleanMac}_${sn}_${devId}")
        val encMac = URLEncoder.encode(cleanMac, "UTF-8")
        val headers = mutableMapOf(
            "Cookie" to "mac=$encMac; stb_lang=en; timezone=UTC",
            "X-User-Agent" to "Model: MAG250; Link: WiFi",
            "SN" to sn,
            "Device-Id" to devId,
            "Device-Id2" to devId2,
            "Signature" to sig
        )
        if (token.isNotBlank()) {
            headers["Authorization"] = "Bearer $token"
        }
        return headers
    }

    suspend fun loadAll(playlistId: String, cfg: StalkerConfig): StalkerLoadResult =
        withContext(Dispatchers.IO) {
            val candidates = buildPortalCandidates(cfg.portalUrl)
            var activePortal = candidates.first()
            var token = ""

            for (candidate in candidates) {
                val hs = fetchJsonDetailed(
                    "$candidate?type=stb&action=handshake&token=&JsHttpRequest=1-xml",
                    buildStbHeaders(cfg.macAddress)
                )
                val t = hs?.optJSONObject("js")?.optString("token").orEmpty()
                if (t.isNotBlank()) {
                    activePortal = candidate
                    token = t
                    break
                }
            }

            if (token.isBlank()) {
                throw IllegalStateException("Stalker handshake failed for ${cfg.portalUrl}")
            }

            val headers = buildStbHeaders(cfg.macAddress, token)
            val origin = extractOrigin(activePortal)

            // Fetch profile to keep session warm
            fetchJsonDetailed("$activePortal?type=stb&action=get_profile&JsHttpRequest=1-xml", headers)

            // 1. Live TV Genres & Channels
            val liveGenres = fetchGenreMap("$activePortal?type=itv&action=get_genres&JsHttpRequest=1-xml", headers)
            val chJson = fetchJsonDetailed("$activePortal?type=itv&action=get_all_channels&JsHttpRequest=1-xml", headers)
            val chArr = chJson?.optJSONObject("js")?.optJSONArray("data") ?: JSONArray()
            val channels = ArrayList<ChannelEntity>(chArr.length())
            for (i in 0 until chArr.length()) {
                val o = chArr.optJSONObject(i) ?: continue
                val cid = o.optString("id")
                val cmd = o.optString("cmd")
                if (cmd.isBlank()) continue
                val genreId = o.optString("tv_genre_id")
                channels.add(
                    ChannelEntity(
                        id = "${playlistId}_stalker_live_$cid",
                        playlistId = playlistId,
                        number = o.optString("number").toIntOrNull() ?: (i + 1),
                        name = o.optString("name", "Channel ${i + 1}"),
                        groupName = liveGenres[genreId] ?: "Live TV",
                        logoUrl = resolveLogo(origin, o.optString("logo")),
                        tvgId = o.optString("xmltv_id").ifBlank { cid },
                        hasCatchup = o.optInt("enable_tv_archive", 0) == 1,
                        catchupDays = o.optInt("tv_archive_duration", 0),
                        sourceType = SourceType.STALKER,
                        stalkerCmd = cmd,
                        streamId = cid
                    )
                )
            }

            // 2. VOD Movies (Paginated p=1..N, max 20 pages)
            val vodCats = fetchGenreMap("$activePortal?type=vod&action=get_categories&JsHttpRequest=1-xml", headers)
            val movies = mutableListOf<VodMovieEntity>()
            var vodPage = 1
            while (vodPage <= 20) {
                val vodJson = fetchJsonDetailed(
                    "$activePortal?type=vod&action=get_ordered_list&p=$vodPage&JsHttpRequest=1-xml",
                    headers
                )
                val js = vodJson?.optJSONObject("js") ?: break
                val data = js.optJSONArray("data") ?: break
                if (data.length() == 0) break
                for (i in 0 until data.length()) {
                    val o = data.optJSONObject(i) ?: continue
                    val vid = o.optString("id")
                    val cmd = o.optString("cmd")
                    if (vid.isBlank()) continue
                    val catId = o.optString("category_id")
                    movies.add(
                        VodMovieEntity(
                            id = "${playlistId}_stalker_vod_$vid",
                            playlistId = playlistId,
                            streamId = vid,
                            name = o.optString("name", "Movie"),
                            categoryName = vodCats[catId] ?: o.optString("genres_str", "Movies"),
                            posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                            stalkerCmd = cmd,
                            sourceType = SourceType.STALKER,
                            rating = o.optString("rating_imdb"),
                            releaseDate = o.optString("year"),
                            duration = o.optString("time"),
                            plot = o.optString("description"),
                            cast = o.optString("actors"),
                            director = o.optString("director"),
                            detailsFetched = true
                        )
                    )
                }
                val total = js.optInt("total_items", 0)
                if (movies.size >= total || data.length() < 14) break
                vodPage++
            }

            // 3. Series (Paginated p=1..N, max 20 pages)
            val seriesCats = fetchGenreMap("$activePortal?type=series&action=get_categories&JsHttpRequest=1-xml", headers)
            val seriesList = mutableListOf<SeriesEntity>()
            var sPage = 1
            while (sPage <= 20) {
                val sJson = fetchJsonDetailed(
                    "$activePortal?type=series&action=get_ordered_list&p=$sPage&JsHttpRequest=1-xml",
                    headers
                )
                val js = sJson?.optJSONObject("js") ?: break
                val data = js.optJSONArray("data") ?: break
                if (data.length() == 0) break
                for (i in 0 until data.length()) {
                    val o = data.optJSONObject(i) ?: continue
                    val sid = o.optString("id")
                    if (sid.isBlank()) continue
                    val catId = o.optString("category_id")
                    seriesList.add(
                        SeriesEntity(
                            id = "${playlistId}_stalker_series_$sid",
                            playlistId = playlistId,
                            seriesId = sid,
                            name = o.optString("name", "Series"),
                            categoryName = seriesCats[catId] ?: o.optString("genres_str", "Series"),
                            posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                            sourceType = SourceType.STALKER,
                            stalkerCmd = o.optString("cmd"),
                            rating = o.optString("rating_imdb"),
                            releaseDate = o.optString("year"),
                            plot = o.optString("description"),
                            cast = o.optString("actors"),
                            director = o.optString("director")
                        )
                    )
                }
                val total = js.optInt("total_items", 0)
                if (seriesList.size >= total || data.length() < 14) break
                sPage++
            }

            StalkerLoadResult(activePortal, token, channels, movies, seriesList)
        }

    suspend fun loadSeriesEpisodes(
        playlistId: String,
        cfg: StalkerConfig,
        token: String,
        series: SeriesEntity
    ): List<EpisodeEntity> = withContext(Dispatchers.IO) {
        val portal = buildPortalCandidates(cfg.portalUrl).first()
        val headers = buildStbHeaders(cfg.macAddress, token)
        val seasonsJson = fetchJsonDetailed(
            "$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&JsHttpRequest=1-xml",
            headers
        )
        val seasons = seasonsJson?.optJSONObject("js")?.optJSONArray("data") ?: return@withContext emptyList()
        val episodes = mutableListOf<EpisodeEntity>()
        for (i in 0 until seasons.length()) {
            val sObj = seasons.optJSONObject(i) ?: continue
            val seasonId = sObj.optString("id")
            val seasonNum = sObj.optString("season_number").toIntOrNull() ?: (i + 1)
            val epJson = fetchJsonDetailed(
                "$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&season_id=$seasonId&JsHttpRequest=1-xml",
                headers
            )
            val epArr = epJson?.optJSONObject("js")?.optJSONArray("data") ?: continue
            for (j in 0 until epArr.length()) {
                val ep = epArr.optJSONObject(j) ?: continue
                val eid = ep.optString("id")
                val cmd = ep.optString("cmd")
                val epNum = ep.optString("episode_number").toIntOrNull() ?: (j + 1)
                episodes.add(
                    EpisodeEntity(
                        id = "${series.id}_s${seasonNum}_e${epNum}_$eid",
                        seriesDbId = series.id,
                        playlistId = playlistId,
                        episodeId = eid,
                        seasonNumber = seasonNum,
                        episodeNumber = epNum,
                        title = ep.optString("name", "Episode $epNum"),
                        thumbnailUrl = series.posterUrl,
                        stalkerCmd = cmd,
                        sourceType = SourceType.STALKER
                    )
                )
            }
        }
        episodes
    }

    suspend fun createStreamLink(
        portalUrl: String,
        mac: String,
        token: String,
        cmd: String,
        type: String = "itv"
    ): String? = withContext(Dispatchers.IO) {
        val cleanCmd = cmd.removePrefix("ffmpeg ").trim()
        if (cleanCmd.startsWith("http://") || cleanCmd.startsWith("https://")) {
            return@withContext cleanCmd
        }
        val portal = buildPortalCandidates(portalUrl).first()
        val encCmd = URLEncoder.encode(cmd, "UTF-8")
        val url = "$portal?type=$type&action=create_link&cmd=$encCmd&JsHttpRequest=1-xml"
        val res = fetchJsonDetailed(url, buildStbHeaders(mac, token))
        val link = res?.optJSONObject("js")?.optString("cmd").orEmpty()
            .removePrefix("ffmpeg ")
            .trim()
        link.ifBlank { null }
    }

    suspend fun fetchChannelEpg(
        playlistId: String,
        portalUrl: String,
        mac: String,
        token: String,
        channelId: String,
        tvgId: String
    ): List<EpgProgramEntity> = withContext(Dispatchers.IO) {
        val portal = buildPortalCandidates(portalUrl).first()
        val res = fetchJsonDetailed(
            "$portal?type=itv&action=get_short_epg&ch_id=$channelId&size=10&JsHttpRequest=1-xml",
            buildStbHeaders(mac, token)
        ) ?: return@withContext emptyList()
        val arr = res.optJSONArray("js") ?: return@withContext emptyList()
        val out = ArrayList<EpgProgramEntity>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val start = o.optLong("start_timestamp", 0L) * 1000L
            val stop = o.optLong("stop_timestamp", 0L) * 1000L
            if (start <= 0L || stop <= 0L) continue
            out.add(
                EpgProgramEntity(
                    playlistId = playlistId,
                    channelTvgId = tvgId.ifBlank { channelId },
                    title = o.optString("name", "No Title"),
                    description = o.optString("descr"),
                    startTimeMillis = start,
                    endTimeMillis = stop
                )
            )
        }
        out
    }

    private fun resolveLogo(origin: String, logo: String): String {
        if (logo.isBlank()) return ""
        return if (logo.startsWith("http")) logo else "$origin/${logo.trimStart('/')}"
    }

    private fun fetchGenreMap(url: String, headers: Map<String, String>): Map<String, String> {
        val obj = fetchJsonDetailed(url, headers) ?: return emptyMap()
        val arr = obj.optJSONArray("js") ?: return emptyMap()
        val map = HashMap<String, String>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            map[o.optString("id")] = o.optString("title")
        }
        return map
    }

    private fun fetchJsonDetailed(url: String, headers: Map<String, String>): JSONObject? {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        return try {
            stalkerHttp.newCall(builder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val raw = resp.body?.string() ?: return null
                JSONObject(raw)
            }
        } catch (_: Exception) {
            null
        }
    }
}
