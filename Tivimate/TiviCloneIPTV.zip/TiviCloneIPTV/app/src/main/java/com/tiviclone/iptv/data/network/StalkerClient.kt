package com.tiviclone.iptv.data.network

import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpisodeEntity
import com.tiviclone.iptv.data.db.SeriesEntity
import com.tiviclone.iptv.data.db.VodMovieEntity
import com.tiviclone.iptv.data.model.SourceType
import com.tiviclone.iptv.data.model.StalkerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.MessageDigest

data class StalkerLoadResult(
    val activePortalUrl: String,
    val token: String,
    val accountStatus: String,
    val accountExpiry: String,
    val channels: List<ChannelEntity>,
    val movies: List<VodMovieEntity>,
    val series: List<SeriesEntity>
)

data class StbIdentity(
    val mac: String,
    val stbType: String,
    val sn: String,
    val deviceId: String,
    val deviceId2: String,
    val signature: String,
    val hwVersion2: String
)

object StalkerClient {

    val MAG_MODELS = listOf("MAG250", "MAG254", "MAG270", "MAG275", "MAG322", "MAG324", "MAG420", "MAG524")

    const val STB_USER_AGENT =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

    private val stalkerHttp by lazy { HttpClientProvider.createClient(STB_USER_AGENT) }

    fun fixScheme(raw: String): String {
        var s = raw.trim().trimStart('/')
        if (s.startsWith("http:/") && !s.startsWith("http://")) s = "http://" + s.removePrefix("http:/")
        if (s.startsWith("https:/") && !s.startsWith("https://")) s = "https://" + s.removePrefix("https:/")
        return if (s.startsWith("http://") || s.startsWith("https://")) s else "http://$s"
    }

    fun extractOrigin(url: String): String {
        return try {
            val u = URI(fixScheme(url))
            val port = if (u.port > 0) ":${u.port}" else ""
            "${u.scheme}://${u.host}$port"
        } catch (_: Exception) {
            fixScheme(url).trimEnd('/')
        }
    }

    fun buildPortalCandidates(rawUrl: String): List<String> {
        val fixed = fixScheme(rawUrl).trimEnd('/')
        val origin = extractOrigin(fixed)
        val cleanBase = fixed.removeSuffix("/c").trimEnd('/')
        val list = mutableListOf<String>()
        if (fixed.endsWith(".php", ignoreCase = true)) list.add(fixed)
        list.addAll(
            listOf(
                "$cleanBase/portal.php",
                "$cleanBase/server/load.php",
                "$cleanBase/stalker_portal/server/load.php",
                "$origin/portal.php",
                "$origin/stalker_portal/server/load.php",
                "$origin/server/load.php",
                "$origin/c/server/load.php"
            )
        )
        return list.distinct()
    }

    private fun md5Upper(input: String): String {
        val md = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return md.joinToString("") { "%02X".format(it) }
    }

    private fun sha256Upper(input: String): String {
        val md = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return md.joinToString("") { "%02X".format(it) }
    }

    fun generateIdentityFromMac(mac: String, stbType: String = "MAG250"): StbIdentity {
        val cleanMac = mac.trim().uppercase()
        val sn = md5Upper(cleanMac).take(13)
        val devId = sha256Upper(cleanMac)
        val devId2 = sha256Upper("DEV2_$cleanMac")
        val sig = sha256Upper("${cleanMac}_${sn}_${devId}")
        val hw2 = md5Upper(cleanMac).lowercase()
        return StbIdentity(cleanMac, stbType.ifBlank { "MAG250" }, sn, devId, devId2, sig, hw2)
    }

    private fun resolveIdentity(cfg: StalkerConfig): StbIdentity {
        val auto = generateIdentityFromMac(cfg.macAddress, cfg.stbType)
        return auto.copy(
            stbType = cfg.stbType.ifBlank { auto.stbType },
            sn = cfg.serialNumber.trim().ifBlank { auto.sn },
            deviceId = cfg.deviceId.trim().ifBlank { auto.deviceId },
            deviceId2 = cfg.deviceId2.trim().ifBlank { auto.deviceId2 },
            signature = cfg.signature.trim().ifBlank { auto.signature }
        )
    }

    private fun buildStbHeaders(
        id: StbIdentity,
        token: String = "",
        referer: String = "",
        phpSessId: String = ""
    ): Map<String, String> {
        val cookieParts = mutableListOf(
            "mac=${id.mac}",
            "stb_lang=en",
            "timezone=UTC"
        )
        if (phpSessId.isNotBlank()) cookieParts.add("PHPSESSID=$phpSessId")
        val headers = mutableMapOf(
            "Cookie" to cookieParts.joinToString("; "),
            "X-User-Agent" to "Model: ${id.stbType}; Link: WiFi",
            "SN" to id.sn,
            "Device-Id" to id.deviceId,
            "Device-Id2" to id.deviceId2,
            "Signature" to id.signature
        )
        if (token.isNotBlank()) headers["Authorization"] = "Bearer $token"
        if (referer.isNotBlank()) headers["Referer"] = referer
        return headers
    }

    private data class ProfileResult(
        val sessId: String,
        val status: String,
        val expiry: String
    )

    private fun authenticateProfile(portal: String, id: StbIdentity, token: String, sessId: String): ProfileResult {
        val metrics = URLEncoder.encode(
            JSONObject().apply {
                put("mac", id.mac)
                put("sn", id.sn)
                put("model", id.stbType)
                put("type", "STB")
                put("uid", "")
                put("random", "")
            }.toString(),
            "UTF-8"
        )
        val profileUrl = "$portal?type=stb&action=get_profile" +
            "&hd=1&ver=ImageDescription:%200.2.18-r14-pub-250;%20ImageDate:%20Fri%20Jan%2015%2015:20:44%20EET%202016;%20PORTAL%20version:%205.1.0;%20API%20Version:%20JS%20API%20version:%20328;%20STB%20API%20version:%20134;%20Player%20Engine%20version:%200x566" +
            "&num_banks=2&sn=${id.sn}&stb_type=${id.stbType}&image_version=218&video_out=hdmi" +
            "&device_id=${id.deviceId}&device_id2=${id.deviceId2}&signature=${id.signature}" +
            "&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0&client_type=STB" +
            "&hw_version_2=${id.hwVersion2}&api_signature=263&metrics=$metrics&JsHttpRequest=1-xml"
        val (json, newSess, _) = fetchJsonWithSession(profileUrl, buildStbHeaders(id, token, portal, sessId))
        val js = json?.optJSONObject("js")
        val msg = js?.optString("msg").orEmpty()
        if (msg.contains("blocked", ignoreCase = true) || msg.contains("expired", ignoreCase = true)) {
            throw IllegalStateException("Portal message: $msg")
        }
        val activeSess = newSess.ifBlank { sessId }
        var expiry = js?.optString("expire_billing_date").orEmpty()
            .ifBlank { js?.optString("tariff_expired_date").orEmpty() }
            .ifBlank { js?.optString("end_date").orEmpty() }
        var status = if (js?.optInt("blocked", 0) == 1) "Blocked" else "Active"

        // Try account_info as fallback for expiry date
        if (expiry.isBlank() || expiry == "0000-00-00" || expiry == "null") {
            val (accJson, _, _) = fetchJsonWithSession(
                "$portal?type=account_info&action=get_main_info&JsHttpRequest=1-xml",
                buildStbHeaders(id, token, portal, activeSess)
            )
            val accJs = accJson?.optJSONObject("js")
            val accExp = accJs?.optString("end_date").orEmpty()
                .ifBlank { accJs?.optString("phone").orEmpty() }
            if (accExp.isNotBlank() && accExp != "null") expiry = accExp
        }

        return ProfileResult(activeSess, status, expiry)
    }

    suspend fun loadAll(playlistId: String, cfg: StalkerConfig): StalkerLoadResult =
        withContext(Dispatchers.IO) {
            val id = resolveIdentity(cfg)
            val candidates = buildPortalCandidates(cfg.portalUrl)
            var activePortal = ""
            var token = ""
            var sessId = ""
            var lastDiag = ""

            for (candidate in candidates) {
                val (hs, hsSess, rawInfo) = fetchJsonWithSession(
                    "$candidate?type=stb&action=handshake&token=&JsHttpRequest=1-xml",
                    buildStbHeaders(id, "", candidate, "")
                )
                lastDiag = rawInfo
                val t = hs?.optJSONObject("js")?.optString("token").orEmpty()
                if (t.isNotBlank()) {
                    activePortal = candidate
                    token = t
                    sessId = hsSess
                    break
                }
            }

            if (token.isBlank() || activePortal.isBlank()) {
                throw IllegalStateException("Stalker handshake failed for ${cfg.portalUrl} ($lastDiag)")
            }

            val profile = authenticateProfile(activePortal, id, token, sessId)
            val headers = buildStbHeaders(id, token, activePortal, profile.sessId)
            val origin = extractOrigin(activePortal)

            // 1. Live TV
            val liveGenres = fetchGenreMap("$activePortal?type=itv&action=get_genres&JsHttpRequest=1-xml", headers)
            val (chJson, _, chDiag) = fetchJsonWithSession(
                "$activePortal?type=itv&action=get_all_channels&JsHttpRequest=1-xml",
                headers
            )
            var chArr = extractDataArray(chJson)
            if (chArr.length() == 0) {
                val combined = JSONArray()
                var p = 1
                while (p <= 15) {
                    val (pgJson, _, _) = fetchJsonWithSession(
                        "$activePortal?type=itv&action=get_ordered_list&genre=*&force_ch_link_check=&fav=0&sortby=number&hd=0&p=$p&JsHttpRequest=1-xml",
                        headers
                    )
                    val pageArr = extractDataArray(pgJson)
                    if (pageArr.length() == 0) break
                    for (k in 0 until pageArr.length()) combined.put(pageArr.get(k))
                    if (pageArr.length() < 14) break
                    p++
                }
                chArr = combined
            }

            val channels = ArrayList<ChannelEntity>(chArr.length())
            for (i in 0 until chArr.length()) {
                val o = chArr.optJSONObject(i) ?: continue
                val cid = o.optString("id").ifBlank { "${i + 1}" }
                val cmd = extractCmd(o)
                if (cmd.isBlank()) continue
                val genreId = o.optString("tv_genre_id")
                channels.add(
                    ChannelEntity(
                        id = "${playlistId}_stalker_live_$cid",
                        playlistId = playlistId,
                        number = o.optString("number").toIntOrNull() ?: (i + 1),
                        name = o.optString("name", "Channel ${i + 1}"),
                        groupName = liveGenres[genreId] ?: "Live TV",
                        logoUrl = resolveLogo(origin, o.optString("logo")),
                        tvgId = o.optString("xmltv_id").ifBlank { cid },
                        hasCatchup = o.optInt("enable_tv_archive", 0) == 1,
                        catchupDays = o.optInt("tv_archive_duration", 0),
                        sourceType = SourceType.STALKER,
                        stalkerCmd = cmd,
                        streamId = cid
                    )
                )
            }

            // 2. VOD Movies & Series-in-VOD
            val vodCats = fetchGenreMap("$activePortal?type=vod&action=get_categories&JsHttpRequest=1-xml", headers)
                .ifEmpty { fetchGenreMap("$activePortal?type=vod&action=get_genres&JsHttpRequest=1-xml", headers) }
            val movies = mutableListOf<VodMovieEntity>()
            val seriesList = mutableListOf<SeriesEntity>()

            val vodItems = fetchOrderedPages(activePortal, "vod", headers, vodCats.keys.take(10))
            for (o in vodItems) {
                val vid = o.optString("id")
                if (vid.isBlank()) continue
                val catId = o.optString("category_id")
                val catName = vodCats[catId] ?: o.optString("genres_str", "Movies").ifBlank { "Movies" }
                if (o.optInt("is_series", 0) == 1) {
                    seriesList.add(
                        SeriesEntity(
                            id = "${playlistId}_stalker_series_$vid",
                            playlistId = playlistId,
                            seriesId = vid,
                            name = o.optString("name", "Series"),
                            categoryName = catName,
                            posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                            sourceType = SourceType.STALKER,
                            stalkerCmd = extractCmd(o),
                            rating = o.optString("rating_imdb"),
                            releaseDate = o.optString("year"),
                            plot = o.optString("description"),
                            cast = o.optString("actors"),
                            director = o.optString("director")
                        )
                    )
                } else {
                    movies.add(
                        VodMovieEntity(
                            id = "${playlistId}_stalker_vod_$vid",
                            playlistId = playlistId,
                            streamId = vid,
                            name = o.optString("name", "Movie"),
                            categoryName = catName,
                            posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                            stalkerCmd = extractCmd(o),
                            sourceType = SourceType.STALKER,
                            rating = o.optString("rating_imdb"),
                            releaseDate = o.optString("year"),
                            duration = o.optString("time"),
                            plot = o.optString("description"),
                            cast = o.optString("actors"),
                            director = o.optString("director"),
                            detailsFetched = true
                        )
                    )
                }
            }

            // 3. Dedicated Series tab
            val seriesCats = fetchGenreMap("$activePortal?type=series&action=get_categories&JsHttpRequest=1-xml", headers)
                .ifEmpty { fetchGenreMap("$activePortal?type=series&action=get_genres&JsHttpRequest=1-xml", headers) }
            val sItems = fetchOrderedPages(activePortal, "series", headers, seriesCats.keys.take(10))
            for (o in sItems) {
                val sid = o.optString("id")
                if (sid.isBlank()) continue
                val catId = o.optString("category_id")
                seriesList.add(
                    SeriesEntity(
                        id = "${playlistId}_stalker_series_$sid",
                        playlistId = playlistId,
                        seriesId = sid,
                        name = o.optString("name", "Series"),
                        categoryName = seriesCats[catId] ?: o.optString("genres_str", "Series").ifBlank { "Series" },
                        posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                        sourceType = SourceType.STALKER,
                        stalkerCmd = extractCmd(o),
                        rating = o.optString("rating_imdb"),
                        releaseDate = o.optString("year"),
                        plot = o.optString("description"),
                        cast = o.optString("actors"),
                        director = o.optString("director")
                    )
                )
            }

            if (channels.isEmpty() && movies.isEmpty() && seriesList.isEmpty()) {
                throw IllegalStateException("Portal connected ($activePortal, ${id.stbType}) but returned 0 items. ($chDiag)")
            }

            StalkerLoadResult(
                activePortalUrl = activePortal,
                token = token,
                accountStatus = profile.status,
                accountExpiry = profile.expiry,
                channels = channels,
                movies = movies,
                series = seriesList.distinctBy { it.id }
            )
        }

    private fun fetchOrderedPages(
        portal: String,
        type: String,
        headers: Map<String, String>,
        fallbackCategories: List<String>
    ): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        var page = 1
        while (page <= 15) {
            var (json, _, _) = fetchJsonWithSession(
                "$portal?type=$type&action=get_ordered_list&category=*&p=$page&sortby=added&JsHttpRequest=1-xml",
                headers
            )
            var arr = extractDataArray(json)
            if (arr.length() == 0 && page == 1) {
                val res2 = fetchJsonWithSession(
                    "$portal?type=$type&action=get_ordered_list&movie_id=0&season_id=0&episode_id=0&p=1&JsHttpRequest=1-xml",
                    headers
                )
                json = res2.first
                arr = extractDataArray(json)
            }
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(it) }
            val total = json?.optJSONObject("js")?.optInt("total_items", 0) ?: 0
            if (total > 0 && out.size >= total) break
            if (arr.length() < 14) break
            page++
        }

        if (out.isEmpty() && fallbackCategories.isNotEmpty()) {
            for (cat in fallbackCategories) {
                if (cat == "*" || cat.isBlank()) continue
                val (json, _, _) = fetchJsonWithSession(
                    "$portal?type=$type&action=get_ordered_list&category=$cat&p=1&JsHttpRequest=1-xml",
                    headers
                )
                val arr = extractDataArray(json)
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(it) }
            }
        }
        return out
    }

    private fun extractCmd(o: JSONObject): String {
        val direct = o.optString("cmd")
        if (direct.isNotBlank()) return direct
        val cmds = o.optJSONArray("cmds") ?: return ""
        return cmds.optJSONObject(0)?.optString("url").orEmpty()
    }

    private fun stripStreamPrefix(raw: String): String {
        var s = raw.trim()
        for (prefix in listOf("ffmpeg ", "ffrt ", "ffrt2 ", "ffrt3 ", "ffrt4 ", "auto ")) {
            if (s.startsWith(prefix, ignoreCase = true)) {
                s = s.substring(prefix.length).trim()
            }
        }
        return s
    }

    suspend fun loadSeriesEpisodes(
        playlistId: String,
        cfg: StalkerConfig,
        token: String,
        series: SeriesEntity
    ): List<EpisodeEntity> = withContext(Dispatchers.IO) {
        val id = resolveIdentity(cfg)
        val portal = if (cfg.portalUrl.endsWith(".php", ignoreCase = true)) cfg.portalUrl else buildPortalCandidates(cfg.portalUrl).first()
        val headers = buildStbHeaders(id, token, portal)
        var seasons = extractDataArray(
            fetchJsonWithSession("$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&JsHttpRequest=1-xml", headers).first
        )
        if (seasons.length() == 0) {
            seasons = extractDataArray(
                fetchJsonWithSession("$portal?type=vod&action=get_ordered_list&movie_id=${series.seriesId}&JsHttpRequest=1-xml", headers).first
            )
        }
        val episodes = mutableListOf<EpisodeEntity>()
        for (i in 0 until seasons.length()) {
            val sObj = seasons.optJSONObject(i) ?: continue
            val seasonId = sObj.optString("id")
            val seasonNum = sObj.optString("season_number").toIntOrNull() ?: (i + 1)
            val epArr = extractDataArray(
                fetchJsonWithSession(
                    "$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&season_id=$seasonId&JsHttpRequest=1-xml",
                    headers
                ).first
            )
            for (j in 0 until epArr.length()) {
                val ep = epArr.optJSONObject(j) ?: continue
                val eid = ep.optString("id")
                val cmd = extractCmd(ep)
                val epNum = ep.optString("episode_number").toIntOrNull() ?: (j + 1)
                episodes.add(
                    EpisodeEntity(
                        id = "${series.id}_s${seasonNum}_e${epNum}_$eid",
                        seriesDbId = series.id,
                        playlistId = playlistId,
                        episodeId = eid,
                        seasonNumber = seasonNum,
                        episodeNumber = epNum,
                        title = ep.optString("name", "Episode $epNum"),
                        thumbnailUrl = series.posterUrl,
                        stalkerCmd = cmd,
                        sourceType = SourceType.STALKER
                    )
                )
            }
        }
        episodes
    }

    suspend fun createStreamLink(
        portalUrl: String,
        cfg: StalkerConfig,
        token: String,
        cmd: String,
        type: String = "itv"
    ): String? = withContext(Dispatchers.IO) {
        val id = resolveIdentity(cfg)
        val portal = if (portalUrl.endsWith(".php", ignoreCase = true)) portalUrl else buildPortalCandidates(portalUrl).first()
        val encCmd = URLEncoder.encode(cmd, "UTF-8")
        val url = "$portal?type=$type&action=create_link&cmd=$encCmd&series=&forced_storage=0&disable_ad=0&download=0&JsHttpRequest=1-xml"
        val (res, _, _) = fetchJsonWithSession(url, buildStbHeaders(id, token, portal))
        val created = res?.optJSONObject("js")?.optString("cmd").orEmpty()
        val resolved = stripStreamPrefix(created)
        if (resolved.startsWith("http://") || resolved.startsWith("https://")) {
            return@withContext resolved
        }
        val fallback = stripStreamPrefix(cmd)
        fallback.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    private fun extractDataArray(root: JSONObject?): JSONArray {
        val js = root?.opt("js") ?: return JSONArray()
        return when (js) {
            is JSONArray -> js
            is JSONObject -> js.optJSONArray("data") ?: JSONArray()
            else -> JSONArray()
        }
    }

    private fun resolveLogo(origin: String, logo: String): String {
        if (logo.isBlank()) return ""
        return if (logo.startsWith("http")) logo else "$origin/${logo.trimStart('/')}"
    }

    private fun fetchGenreMap(url: String, headers: Map<String, String>): Map<String, String> {
        val (obj, _, _) = fetchJsonWithSession(url, headers)
        val arr = extractDataArray(obj)
        val map = HashMap<String, String>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            map[o.optString("id")] = o.optString("title")
        }
        return map
    }

    private fun fetchJsonWithSession(url: String, headers: Map<String, String>): Triple<JSONObject?, String, String> {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        return try {
            stalkerHttp.newCall(builder.build()).execute().use { resp ->
                var phpSess = ""
                for (sc in resp.headers("Set-Cookie")) {
                    if (sc.contains("PHPSESSID=")) {
                        phpSess = sc.substringAfter("PHPSESSID=").substringBefore(";").trim()
                    }
                }
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return Triple(null, phpSess, "HTTP ${resp.code}")
                }
                val parsed = runCatching { JSONObject(raw) }.getOrNull()
                Triple(parsed, phpSess, raw.take(120))
            }
        } catch (e: Exception) {
            Triple(null, "", e.message ?: "Network error")
        }
    }
}
