package com.tiviclone.iptv.data.network

import com.tiviclone.iptv.data.db.ChannelEntity
import com.tiviclone.iptv.data.db.EpgProgramEntity
import com.tiviclone.iptv.data.db.EpisodeEntity
import com.tiviclone.iptv.data.db.SeriesEntity
import com.tiviclone.iptv.data.db.VodMovieEntity
import com.tiviclone.iptv.data.model.SourceType
import com.tiviclone.iptv.data.model.StalkerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.MessageDigest

data class StalkerLoadResult(
    val activePortalUrl: String,
    val token: String,
    val channels: List<ChannelEntity>,
    val movies: List<VodMovieEntity>,
    val series: List<SeriesEntity>
)

object StalkerClient {

    const val STB_USER_AGENT =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

    private val stalkerHttp by lazy { HttpClientProvider.createClient(STB_USER_AGENT) }

    fun fixScheme(url: String): String {
        val trimmed = url.trim()
        return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed else "http://$trimmed"
    }

    fun extractOrigin(url: String): String {
        return try {
            val u = URI(fixScheme(url))
            val port = if (u.port > 0) ":${u.port}" else ""
            "${u.scheme}://${u.host}$port"
        } catch (_: Exception) {
            fixScheme(url).trimEnd('/')
        }
    }

    fun buildPortalCandidates(rawUrl: String): List<String> {
        val fixed = fixScheme(rawUrl).trimEnd('/')
        val origin = extractOrigin(fixed)
        val withoutC = fixed.removeSuffix("/c").removeSuffix("/c/")
        return listOf(
            if (fixed.endsWith(".php")) fixed else "$withoutC/server/load.php",
            "$withoutC/portal.php",
            "$origin/stalker_portal/server/load.php",
            "$origin/c/server/load.php",
            "$origin/portal.php",
            "$origin/server/load.php",
            "$fixed/portal.php"
        ).distinct()
    }

    private fun md5Upper(input: String): String {
        val md = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return md.joinToString("") { "%02X".format(it) }
    }

    private fun sha256Upper(input: String): String {
        val md = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return md.joinToString("") { "%02X".format(it) }
    }

    private data class StbIdentity(
        val mac: String,
        val sn: String,
        val deviceId: String,
        val deviceId2: String,
        val signature: String,
        val hwVersion2: String
    )

    private fun identityFromMac(mac: String): StbIdentity {
        val cleanMac = mac.trim().uppercase()
        val sn = md5Upper(cleanMac).take(13)
        val devId = sha256Upper(cleanMac)
        val devId2 = sha256Upper("DEV2_$cleanMac")
        val sig = sha256Upper("${cleanMac}_${sn}_${devId}")
        val hw2 = md5Upper(cleanMac).lowercase()
        return StbIdentity(cleanMac, sn, devId, devId2, sig, hw2)
    }

    private fun buildStbHeaders(id: StbIdentity, token: String = "", referer: String = ""): Map<String, String> {
        val encMac = URLEncoder.encode(id.mac, "UTF-8")
        val headers = mutableMapOf(
            "Cookie" to "mac=$encMac; stb_lang=en; timezone=UTC",
            "X-User-Agent" to "Model: MAG250; Link: WiFi",
            "SN" to id.sn,
            "Device-Id" to id.deviceId,
            "Device-Id2" to id.deviceId2,
            "Signature" to id.signature
        )
        if (token.isNotBlank()) headers["Authorization"] = "Bearer $token"
        if (referer.isNotBlank()) headers["Referer"] = referer
        return headers
    }

    private fun authenticateProfile(portal: String, id: StbIdentity, token: String) {
        val metrics = URLEncoder.encode(
            JSONObject().apply {
                put("mac", id.mac)
                put("sn", id.sn)
                put("model", "MAG250")
                put("type", "STB")
                put("uid", "")
                put("random", "")
            }.toString(),
            "UTF-8"
        )
        val profileUrl = "$portal?type=stb&action=get_profile" +
            "&hd=1&ver=ImageDescription:%200.2.18-r14-pub-250;%20ImageDate:%20Fri%20Jan%2015%2015:20:44%20EET%202016;%20PORTAL%20version:%205.1.0;%20API%20Version:%20JS%20API%20version:%20328;%20STB%20API%20version:%20134;%20Player%20Engine%20version:%200x566" +
            "&num_banks=2&sn=${id.sn}&stb_type=MAG250&image_version=218&video_out=hdmi" +
            "&device_id=${id.deviceId}&device_id2=${id.deviceId2}&signature=${id.signature}" +
            "&auth_second_step=1&hw_version=1.7-BD-00&not_valid_token=0&client_type=STB" +
            "&hw_version_2=${id.hwVersion2}&api_signature=263&metrics=$metrics&JsHttpRequest=1-xml"
        fetchJsonDetailed(profileUrl, buildStbHeaders(id, token, portal))
    }

    suspend fun loadAll(playlistId: String, cfg: StalkerConfig): StalkerLoadResult =
        withContext(Dispatchers.IO) {
            val id = identityFromMac(cfg.macAddress)
            val candidates = buildPortalCandidates(cfg.portalUrl)
            var activePortal = ""
            var token = ""

            for (candidate in candidates) {
                val hs = fetchJsonDetailed(
                    "$candidate?type=stb&action=handshake&token=&JsHttpRequest=1-xml",
                    buildStbHeaders(id, "", candidate)
                )
                val t = hs?.optJSONObject("js")?.optString("token").orEmpty()
                if (t.isNotBlank()) {
                    activePortal = candidate
                    token = t
                    break
                }
            }

            if (token.isBlank() || activePortal.isBlank()) {
                throw IllegalStateException("Stalker handshake failed for ${cfg.portalUrl}")
            }

            // Full MAG250 second-step profile auth (required by Stalker portals)
            authenticateProfile(activePortal, id, token)

            val headers = buildStbHeaders(id, token, activePortal)
            val origin = extractOrigin(activePortal)

            // 1. Live TV Genres & Channels
            val liveGenres = fetchGenreMap("$activePortal?type=itv&action=get_genres&JsHttpRequest=1-xml", headers)
            val chJson = fetchJsonDetailed("$activePortal?type=itv&action=get_all_channels&JsHttpRequest=1-xml", headers)
            val chArr = extractDataArray(chJson)
            val channels = ArrayList<ChannelEntity>(chArr.length())
            for (i in 0 until chArr.length()) {
                val o = chArr.optJSONObject(i) ?: continue
                val cid = o.optString("id")
                val cmd = o.optString("cmd")
                if (cmd.isBlank()) continue
                val genreId = o.optString("tv_genre_id")
                channels.add(
                    ChannelEntity(
                        id = "${playlistId}_stalker_live_$cid",
                        playlistId = playlistId,
                        number = o.optString("number").toIntOrNull() ?: (i + 1),
                        name = o.optString("name", "Channel ${i + 1}"),
                        groupName = liveGenres[genreId] ?: "Live TV",
                        logoUrl = resolveLogo(origin, o.optString("logo")),
                        tvgId = o.optString("xmltv_id").ifBlank { cid },
                        hasCatchup = o.optInt("enable_tv_archive", 0) == 1,
                        catchupDays = o.optInt("tv_archive_duration", 0),
                        sourceType = SourceType.STALKER,
                        stalkerCmd = cmd,
                        streamId = cid
                    )
                )
            }

            // 2. VOD Movies (Paginated p=1..20 with category=* fallback)
            val vodCats = fetchGenreMap("$activePortal?type=vod&action=get_categories&JsHttpRequest=1-xml", headers)
            val movies = mutableListOf<VodMovieEntity>()
            var vodPage = 1
            while (vodPage <= 20) {
                var vodJson = fetchJsonDetailed(
                    "$activePortal?type=vod&action=get_ordered_list&category=*&p=$vodPage&sortby=added&JsHttpRequest=1-xml",
                    headers
                )
                var data = extractDataArray(vodJson)
                if (data.length() == 0 && vodPage == 1) {
                    vodJson = fetchJsonDetailed(
                        "$activePortal?type=vod&action=get_ordered_list&p=1&JsHttpRequest=1-xml",
                        headers
                    )
                    data = extractDataArray(vodJson)
                }
                if (data.length() == 0) break
                for (i in 0 until data.length()) {
                    val o = data.optJSONObject(i) ?: continue
                    val vid = o.optString("id")
                    val cmd = o.optString("cmd")
                    if (vid.isBlank()) continue
                    val catId = o.optString("category_id")
                    movies.add(
                        VodMovieEntity(
                            id = "${playlistId}_stalker_vod_$vid",
                            playlistId = playlistId,
                            streamId = vid,
                            name = o.optString("name", "Movie"),
                            categoryName = vodCats[catId] ?: o.optString("genres_str", "Movies").ifBlank { "Movies" },
                            posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                            stalkerCmd = cmd,
                            sourceType = SourceType.STALKER,
                            rating = o.optString("rating_imdb"),
                            releaseDate = o.optString("year"),
                            duration = o.optString("time"),
                            plot = o.optString("description"),
                            cast = o.optString("actors"),
                            director = o.optString("director"),
                            detailsFetched = true
                        )
                    )
                }
                val total = vodJson?.optJSONObject("js")?.optInt("total_items", 0) ?: 0
                if (total > 0 && movies.size >= total) break
                if (data.length() < 14) break
                vodPage++
            }

            // 3. Series (Paginated p=1..20 with category=* fallback)
            val seriesCats = fetchGenreMap("$activePortal?type=series&action=get_categories&JsHttpRequest=1-xml", headers)
            val seriesList = mutableListOf<SeriesEntity>()
            var sPage = 1
            while (sPage <= 20) {
                var sJson = fetchJsonDetailed(
                    "$activePortal?type=series&action=get_ordered_list&category=*&p=$sPage&sortby=added&JsHttpRequest=1-xml",
                    headers
                )
                var data = extractDataArray(sJson)
                if (data.length() == 0 && sPage == 1) {
                    sJson = fetchJsonDetailed(
                        "$activePortal?type=series&action=get_ordered_list&p=1&JsHttpRequest=1-xml",
                        headers
                    )
                    data = extractDataArray(sJson)
                }
                if (data.length() == 0) break
                for (i in 0 until data.length()) {
                    val o = data.optJSONObject(i) ?: continue
                    val sid = o.optString("id")
                    if (sid.isBlank()) continue
                    val catId = o.optString("category_id")
                    seriesList.add(
                        SeriesEntity(
                            id = "${playlistId}_stalker_series_$sid",
                            playlistId = playlistId,
                            seriesId = sid,
                            name = o.optString("name", "Series"),
                            categoryName = seriesCats[catId] ?: o.optString("genres_str", "Series").ifBlank { "Series" },
                            posterUrl = resolveLogo(origin, o.optString("screenshot_uri")),
                            sourceType = SourceType.STALKER,
                            stalkerCmd = o.optString("cmd"),
                            rating = o.optString("rating_imdb"),
                            releaseDate = o.optString("year"),
                            plot = o.optString("description"),
                            cast = o.optString("actors"),
                            director = o.optString("director")
                        )
                    )
                }
                val total = sJson?.optJSONObject("js")?.optInt("total_items", 0) ?: 0
                if (total > 0 && seriesList.size >= total) break
                if (data.length() < 14) break
                sPage++
            }

            StalkerLoadResult(activePortal, token, channels, movies, seriesList)
        }

    suspend fun loadSeriesEpisodes(
        playlistId: String,
        cfg: StalkerConfig,
        token: String,
        series: SeriesEntity
    ): List<EpisodeEntity> = withContext(Dispatchers.IO) {
        val id = identityFromMac(cfg.macAddress)
        val portal = if (cfg.portalUrl.endsWith(".php")) cfg.portalUrl else buildPortalCandidates(cfg.portalUrl).first()
        val headers = buildStbHeaders(id, token, portal)
        val seasonsJson = fetchJsonDetailed(
            "$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&JsHttpRequest=1-xml",
            headers
        )
        val seasons = extractDataArray(seasonsJson)
        val episodes = mutableListOf<EpisodeEntity>()
        for (i in 0 until seasons.length()) {
            val sObj = seasons.optJSONObject(i) ?: continue
            val seasonId = sObj.optString("id")
            val seasonNum = sObj.optString("season_number").toIntOrNull() ?: (i + 1)
            val epJson = fetchJsonDetailed(
                "$portal?type=series&action=get_ordered_list&movie_id=${series.seriesId}&season_id=$seasonId&JsHttpRequest=1-xml",
                headers
            )
            val epArr = extractDataArray(epJson)
            for (j in 0 until epArr.length()) {
                val ep = epArr.optJSONObject(j) ?: continue
                val eid = ep.optString("id")
                val cmd = ep.optString("cmd")
                val epNum = ep.optString("episode_number").toIntOrNull() ?: (j + 1)
                episodes.add(
                    EpisodeEntity(
                        id = "${series.id}_s${seasonNum}_e${epNum}_$eid",
                        seriesDbId = series.id,
                        playlistId = playlistId,
                        episodeId = eid,
                        seasonNumber = seasonNum,
                        episodeNumber = epNum,
                        title = ep.optString("name", "Episode $epNum"),
                        thumbnailUrl = series.posterUrl,
                        stalkerCmd = cmd,
                        sourceType = SourceType.STALKER
                    )
                )
            }
        }
        episodes
    }

    suspend fun createStreamLink(
        portalUrl: String,
        mac: String,
        token: String,
        cmd: String,
        type: String = "itv"
    ): String? = withContext(Dispatchers.IO) {
        val cleanCmd = cmd.removePrefix("ffmpeg ").trim()
        if (cleanCmd.startsWith("http://") || cleanCmd.startsWith("https://")) {
            return@withContext cleanCmd
        }
        val id = identityFromMac(mac)
        val portal = if (portalUrl.endsWith(".php")) portalUrl else buildPortalCandidates(portalUrl).first()
        val encCmd = URLEncoder.encode(cmd, "UTF-8")
        val url = "$portal?type=$type&action=create_link&cmd=$encCmd&series=&forced_storage=0&disable_ad=0&download=0&JsHttpRequest=1-xml"
        val res = fetchJsonDetailed(url, buildStbHeaders(id, token, portal))
        val link = res?.optJSONObject("js")?.optString("cmd").orEmpty()
            .removePrefix("ffmpeg ")
            .trim()
        link.ifBlank { null }
    }

    private fun extractDataArray(root: JSONObject?): JSONArray {
        val js = root?.opt("js") ?: return JSONArray()
        return when (js) {
            is JSONArray -> js
            is JSONObject -> js.optJSONArray("data") ?: JSONArray()
            else -> JSONArray()
        }
    }

    private fun resolveLogo(origin: String, logo: String): String {
        if (logo.isBlank()) return ""
        return if (logo.startsWith("http")) logo else "$origin/${logo.trimStart('/')}"
    }

    private fun fetchGenreMap(url: String, headers: Map<String, String>): Map<String, String> {
        val obj = fetchJsonDetailed(url, headers) ?: return emptyMap()
        val arr = extractDataArray(obj)
        val map = HashMap<String, String>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            map[o.optString("id")] = o.optString("title")
        }
        return map
    }

    private fun fetchJsonDetailed(url: String, headers: Map<String, String>): JSONObject? {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        return try {
            stalkerHttp.newCall(builder.build()).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val raw = resp.body?.string() ?: return null
                JSONObject(raw)
            }
        } catch (_: Exception) {
            null
        }
    }
}
