package com.tiviclone.iptv.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object TiviColors {
    val Background = Color(0xFF0A0D12)
    val SidebarBg = Color(0xFF10151E)
    val PanelBg = Color(0xFF161D29)
    val CardFocused = Color(0xFF223047)
    val AccentBlue = Color(0xFF2979FF)
    val CatchupGreen = Color(0xFF00E676)
    val FavoriteGold = Color(0xFFFFD54F)
    val DangerRed = Color(0xFFFF5252)
    val TextPrimary = Color(0xFFF2F5FA)
    val TextSecondary = Color(0xFF9AA5B8)
    val Divider = Color(0xFF232C3B)
}

private val TiviDarkScheme = darkColorScheme(
    primary = TiviColors.AccentBlue,
    background = TiviColors.Background,
    surface = TiviColors.PanelBg,
    onPrimary = Color.White,
    onBackground = TiviColors.TextPrimary,
    onSurface = TiviColors.TextPrimary
)

@Composable
fun TiviCloneTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TiviDarkScheme,
        content = content
    )
}

@Composable
fun Modifier.tvFocusableBorder(cornerDp: Int = 8): Modifier {
    var focused by remember { mutableStateOf(false) }
    return this
        .onFocusChanged { focused = it.isFocused }
        .focusable()
        .then(
            if (focused) {
                Modifier.border(
                    BorderStroke(2.dp, TiviColors.AccentBlue),
                    RoundedCornerShape(cornerDp.dp)
                )
            } else Modifier
        )
}
