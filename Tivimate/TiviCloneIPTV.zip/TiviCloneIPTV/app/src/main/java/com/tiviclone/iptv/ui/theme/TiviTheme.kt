package com.tiviclone.iptv.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

object TiviColors {
    var Background by mutableStateOf(Color(0xFF0E1013))
    var SidebarBg by mutableStateOf(Color(0xFF111418))
    var PanelBg by mutableStateOf(Color(0xFF161A20))
    var CardFocused by mutableStateOf(Color(0xFF223047))
    var AccentBlue by mutableStateOf(Color(0xFF2979FF))
    val CatchupGreen = Color(0xFF00E676)
    val FavoriteGold = Color(0xFFFFD54F)
    val DangerRed = Color(0xFFFF5252)
    val TextPrimary = Color(0xFFF2F5FA)
    val TextSecondary = Color(0xFF9AA5B8)
    val Divider = Color(0xFF232C3B)

    fun applyTheme(bgName: String, accentName: String) {
        when (bgName) {
            "AMOLED Black" -> {
                Background = Color(0xFF000000)
                SidebarBg = Color(0xFF070709)
                PanelBg = Color(0xFF101216)
            }
            "Slate" -> {
                Background = Color(0xFF181C22)
                SidebarBg = Color(0xFF1E232B)
                PanelBg = Color(0xFF252B35)
            }
            "Deep Navy" -> {
                Background = Color(0xFF080E1A)
                SidebarBg = Color(0xFF0C1424)
                PanelBg = Color(0xFF131E33)
            }
            else -> { // "Dark"
                Background = Color(0xFF0E1013)
                SidebarBg = Color(0xFF111418)
                PanelBg = Color(0xFF161A20)
            }
        }
        AccentBlue = when (accentName) {
            "Teal" -> Color(0xFF00BFA5)
            "Purple" -> Color(0xFF9C27B0)
            "Amber" -> Color(0xFFFFA000)
            "Green" -> Color(0xFF00C853)
            "Red" -> Color(0xFFE53935)
            else -> Color(0xFF2979FF) // "Blue"
        }
        CardFocused = AccentBlue.copy(alpha = 0.25f)
    }
}

@Composable
fun TiviCloneTheme(
    bgTheme: String = "Dark",
    accentTheme: String = "Blue",
    content: @Composable () -> Unit
) {
    TiviColors.applyTheme(bgTheme, accentTheme)
    val scheme = darkColorScheme(
        primary = TiviColors.AccentBlue,
        background = TiviColors.Background,
        surface = TiviColors.PanelBg,
        onPrimary = Color.White,
        onBackground = TiviColors.TextPrimary,
        onSurface = TiviColors.TextPrimary
    )
    MaterialTheme(
        colorScheme = scheme,
        content = content
    )
}

@Composable
fun Modifier.tvFocusableBorder(cornerDp: Int = 8): Modifier {
    var focused by remember { mutableStateOf(false) }
    return this
        .onFocusChanged { focused = it.isFocused }
        .focusable()
        .then(
            if (focused) {
                Modifier.border(
                    BorderStroke(2.dp, TiviColors.AccentBlue),
                    RoundedCornerShape(cornerDp.dp)
                )
            } else Modifier
        )
}
