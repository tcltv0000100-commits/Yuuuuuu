package com.tiviclone.iptv.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tiviclone.iptv.TiviCloneApp
import com.tiviclone.iptv.data.db.*
import com.tiviclone.iptv.data.model.AppSection
import com.tiviclone.iptv.data.model.StalkerConfig
import com.tiviclone.iptv.data.model.XtreamConfig
import com.tiviclone.iptv.data.repository.GlobalSearchResults
import com.tiviclone.iptv.recorder.RecordingService
import com.tiviclone.iptv.recorder.ReminderAlarmReceiver
import com.tiviclone.iptv.worker.SyncScheduler
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ActivePlayback(
    val itemId: String,
    val playlistId: String,
    val mediaType: String,
    val title: String,
    val subtitle: String = "",
    val posterUrl: String = "",
    val streamUrl: String,
    val stalkerCmd: String = "",
    val seriesDbId: String = "",
    val resumePositionMs: Long = 0L,
    val userAgent: String = "",
    val isFullscreen: Boolean = false
)

data class PlaylistProcessingState(
    val isProcessing: Boolean = false,
    val isDone: Boolean = false,
    val statusText: String = "",
    val errorText: String? = null,
    val channelsProcessed: Int = 0,
    val moviesProcessed: Int = 0,
    val showsProcessed: Int = 0
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as TiviCloneApp
    private val repo = app.repository
    private val settings = app.settingsStore

    val activeSection = MutableStateFlow(AppSection.TV)
    val activePlaylistId = MutableStateFlow(settings.getActivePlaylistId().ifBlank { "ALL" })
    val statusMessage = MutableStateFlow<String?>(null)
    val isLoading = MutableStateFlow(false)
    val processingState = MutableStateFlow<PlaylistProcessingState?>(null)

    val backgroundTheme = MutableStateFlow(settings.getBackgroundTheme())
    val accentTheme = MutableStateFlow(settings.getAccentTheme())

    val playlists: StateFlow<List<PlaylistEntity>> = repo.observePlaylists()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val channels: StateFlow<List<ChannelEntity>> = activePlaylistId.flatMapLatest { pid ->
        repo.observeChannels(pid)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val movies: StateFlow<List<VodMovieEntity>> = activePlaylistId.flatMapLatest { pid ->
        repo.observeMovies(pid)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val seriesList: StateFlow<List<SeriesEntity>> = activePlaylistId.flatMapLatest { pid ->
        repo.observeSeries(pid)
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val favoriteChannels: StateFlow<List<ChannelEntity>> = repo.observeFavoriteChannels()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val favoriteMovies: StateFlow<List<VodMovieEntity>> = repo.observeFavoriteMovies()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    val favoriteSeries: StateFlow<List<SeriesEntity>> = repo.observeFavoriteSeries()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val continueWatching: StateFlow<List<WatchHistoryEntity>> = repo.observeContinueWatching()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val epgPrograms: StateFlow<List<EpgProgramEntity>> = repo.observeEpg()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val recordings: StateFlow<List<RecordingEntity>> = repo.observeRecordings()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val reminders: StateFlow<List<ReminderEntity>> = repo.observeReminders()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val selectedMovie = MutableStateFlow<VodMovieEntity?>(null)
    val selectedSeries = MutableStateFlow<SeriesEntity?>(null)
    val selectedSeriesEpisodes = MutableStateFlow<List<EpisodeEntity>>(emptyList())
    val activePlayback = MutableStateFlow<ActivePlayback?>(null)
    val showMultiview = MutableStateFlow(false)
    val searchResults = MutableStateFlow(GlobalSearchResults())

    val epgIntervalHours = MutableStateFlow(settings.getEpgIntervalHours())
    val epgLastUpdated = MutableStateFlow(settings.getEpgLastUpdated())
    val parentalPin = MutableStateFlow(settings.getParentalPin())

    fun updateTheme(bg: String, accent: String) {
        settings.setBackgroundTheme(bg)
        settings.setAccentTheme(accent)
        backgroundTheme.value = bg
        accentTheme.value = accent
    }

    fun selectPlaylist(id: String) {
        activePlaylistId.value = id
        settings.setActivePlaylistId(id)
    }

    fun setPlaylistEnabled(id: String, enabled: Boolean) = viewModelScope.launch {
        repo.setPlaylistEnabled(id, enabled)
    }

    fun dismissProcessing() {
        processingState.value = null
    }

    fun addOrUpdateM3uUrl(
        name: String,
        url: String,
        epgUrl: String,
        existingId: String? = null,
        includeVod: Boolean = true
    ) = runProcessing("Processing M3U playlist...") {
        val pl = repo.addOrSyncM3uUrl(name, url, epgUrl, existingId, includeVod)
        selectPlaylist("ALL")
        pl
    }

    fun addM3uFile(name: String, uri: Uri) = runProcessing("Reading M3U file...") {
        val pl = repo.addM3uFile(name, uri)
        selectPlaylist("ALL")
        pl
    }

    fun addOrUpdateXtream(
        name: String,
        server: String,
        user: String,
        pass: String,
        existingId: String? = null,
        includeVod: Boolean = true,
        outputFormat: String = "MPEG-TS"
    ) = runProcessing("Processing Xtream Codes playlist...") {
        val pl = repo.addOrSyncXtream(name, XtreamConfig(server, user, pass), existingId, includeVod, outputFormat)
        epgLastUpdated.value = settings.getEpgLastUpdated()
        selectPlaylist("ALL")
        pl
    }

    fun addOrUpdateStalker(
        name: String,
        cfg: StalkerConfig,
        existingId: String? = null,
        includeVod: Boolean = true
    ) = runProcessing("Connecting to Stalker Portal...") {
        val pl = repo.addOrSyncStalker(name, cfg, existingId, includeVod)
        selectPlaylist("ALL")
        pl
    }

    private fun runProcessing(label: String, block: suspend () -> PlaylistEntity) {
        viewModelScope.launch {
            processingState.value = PlaylistProcessingState(isProcessing = true, statusText = label)
            try {
                val pl = block()
                processingState.value = PlaylistProcessingState(
                    isProcessing = false,
                    isDone = true,
                    statusText = "Playlist processed: ${pl.name}",
                    channelsProcessed = pl.channelsCount,
                    moviesProcessed = pl.moviesCount,
                    showsProcessed = pl.seriesCount
                )
            } catch (e: Exception) {
                processingState.value = PlaylistProcessingState(
                    isProcessing = false,
                    isDone = true,
                    statusText = "Failed to process playlist",
                    errorText = e.message ?: "Unknown error"
                )
            }
        }
    }

    fun deletePlaylist(id: String) = viewModelScope.launch {
        repo.deletePlaylist(id)
        if (activePlaylistId.value == id) selectPlaylist("ALL")
        statusMessage.value = "Playlist deleted"
    }

    fun refreshAll() = launchWithLoading("Updating playlists & EPG...") {
        repo.syncAllPlaylists()
        epgLastUpdated.value = settings.getEpgLastUpdated()
        statusMessage.value = "Update complete"
    }

    fun playChannel(channel: ChannelEntity, fullscreen: Boolean = false) = viewModelScope.launch {
        val url = repo.resolveChannelStream(channel)
        if (url.isBlank()) {
            statusMessage.value = "Empty stream URL"
            return@launch
        }
        activePlayback.value = ActivePlayback(
            itemId = channel.id,
            playlistId = channel.playlistId,
            mediaType = "LIVE",
            title = channel.name,
            subtitle = channel.groupName,
            posterUrl = channel.logoUrl,
            streamUrl = url,
            stalkerCmd = channel.stalkerCmd,
            userAgent = settings.getUserAgent().ifBlank { channel.userAgent },
            isFullscreen = fullscreen
        )
    }

    fun playCatchup(channel: ChannelEntity, program: EpgProgramEntity) = viewModelScope.launch {
        val url = repo.buildCatchupUrl(channel, program)
        if (url == null) {
            statusMessage.value = "Catch-up requires Xtream TV Archive channel"
            return@launch
        }
        activePlayback.value = ActivePlayback(
            itemId = "${channel.id}_catchup_${program.startTimeMillis}",
            playlistId = channel.playlistId,
            mediaType = "LIVE",
            title = "${channel.name} • ${program.title}",
            subtitle = "Catch-up",
            posterUrl = channel.logoUrl,
            streamUrl = url,
            isFullscreen = true
        )
    }

    fun openMovieDetails(movie: VodMovieEntity) = viewModelScope.launch {
        selectedMovie.value = movie
        val detailed = repo.fetchMovieDetails(movie)
        selectedMovie.value = detailed
    }

    fun playMovie(movie: VodMovieEntity, resumeMs: Long = 0L) = viewModelScope.launch {
        val url = repo.resolveVodStream(movie)
        if (url.isBlank()) {
            statusMessage.value = "Cannot resolve movie stream"
            return@launch
        }
        activePlayback.value = ActivePlayback(
            itemId = movie.id,
            playlistId = movie.playlistId,
            mediaType = "MOVIES",
            title = movie.name,
            subtitle = movie.genre.ifBlank { movie.categoryName },
            posterUrl = movie.posterUrl,
            streamUrl = url,
            stalkerCmd = movie.stalkerCmd,
            resumePositionMs = resumeMs,
            isFullscreen = true
        )
    }

    fun openSeriesDetails(series: SeriesEntity) = viewModelScope.launch {
        selectedSeries.value = series
        selectedSeriesEpisodes.value = emptyList()
        isLoading.value = true
        try {
            val (updated, eps) = repo.fetchSeriesDetailsAndEpisodes(series)
            selectedSeries.value = updated
            selectedSeriesEpisodes.value = eps
        } finally {
            isLoading.value = false
        }
    }

    fun playEpisode(series: SeriesEntity, ep: EpisodeEntity, resumeMs: Long = 0L) = viewModelScope.launch {
        val url = repo.resolveEpisodeStream(ep)
        if (url.isBlank()) {
            statusMessage.value = "Cannot resolve episode stream"
            return@launch
        }
        activePlayback.value = ActivePlayback(
            itemId = ep.id,
            playlistId = ep.playlistId,
            mediaType = "SERIES",
            title = "${series.name} — S${ep.seasonNumber}E${ep.episodeNumber}",
            subtitle = ep.title,
            posterUrl = ep.thumbnailUrl.ifBlank { series.posterUrl },
            streamUrl = url,
            stalkerCmd = ep.stalkerCmd,
            seriesDbId = series.id,
            resumePositionMs = resumeMs,
            isFullscreen = true
        )
    }

    fun savePlaybackProgress(pb: ActivePlayback, posMs: Long, durMs: Long) {
        if (pb.mediaType == "LIVE" || posMs < 5000L) return
        viewModelScope.launch {
            repo.saveWatchProgress(
                itemId = pb.itemId,
                playlistId = pb.playlistId,
                mediaType = pb.mediaType,
                title = pb.title,
                subtitle = pb.subtitle,
                posterUrl = pb.posterUrl,
                streamUrl = pb.streamUrl,
                stalkerCmd = pb.stalkerCmd,
                seriesDbId = pb.seriesDbId,
                positionMs = posMs,
                durationMs = durMs
            )
        }
    }

    fun setFullscreen(full: Boolean) {
        activePlayback.value = activePlayback.value?.copy(isFullscreen = full)
    }

    fun closePlayer() {
        activePlayback.value = null
    }

    fun toggleFavorite(channel: ChannelEntity) = viewModelScope.launch { repo.toggleChannelFavorite(channel) }
    fun hideChannel(id: String) = viewModelScope.launch { repo.setChannelHidden(id, true) }
    fun blockChannel(id: String, blocked: Boolean) = viewModelScope.launch { repo.setChannelBlocked(id, blocked) }
    fun assignChannelEpg(id: String, tvgId: String) = viewModelScope.launch { repo.setChannelTvgId(id, tvgId) }
    fun unhideAllChannels() = viewModelScope.launch { repo.unhideAllChannels() }
    fun unblockAllChannels() = viewModelScope.launch { repo.unblockAllChannels() }

    fun toggleFavorite(movie: VodMovieEntity) = viewModelScope.launch { repo.toggleMovieFavorite(movie) }
    fun toggleFavorite(series: SeriesEntity) = viewModelScope.launch { repo.toggleSeriesFavorite(series) }

    fun search(query: String) = viewModelScope.launch {
        searchResults.value = repo.globalSearch(query)
    }

    fun startRecording(channel: ChannelEntity, programTitle: String = channel.name) = viewModelScope.launch {
        val url = repo.resolveChannelStream(channel)
        if (url.isNotBlank()) {
            RecordingService.start(app, channel.id, channel.name, programTitle, url)
            statusMessage.value = "Recording started: $programTitle"
        }
    }

    fun deleteRecording(id: Long) = viewModelScope.launch { repo.deleteRecording(id) }

    fun setReminder(channel: ChannelEntity, program: EpgProgramEntity) = viewModelScope.launch {
        repo.addReminder(
            ReminderEntity(
                channelId = channel.id,
                channelName = channel.name,
                programTitle = program.title,
                startTimeMillis = program.startTimeMillis
            )
        )
        ReminderAlarmReceiver.schedule(app, program.startTimeMillis, channel.name, program.title)
        statusMessage.value = "Reminder set for ${program.title}"
    }

    fun updateEpgInterval(hours: Int) {
        settings.setEpgIntervalHours(hours)
        epgIntervalHours.value = hours
        SyncScheduler.schedulePeriodicSync(app, hours)
    }

    fun setParentalPin(pin: String) {
        settings.setParentalPin(pin)
        parentalPin.value = pin
    }

    suspend fun exportBackupJson(): String = repo.exportBackupJson()

    fun importBackupJson(raw: String) = launchWithLoading("Restoring backup...") {
        val count = repo.importBackupJson(raw)
        statusMessage.value = "Restored $count playlists"
    }

    fun clearStatus() { statusMessage.value = null }

    private fun launchWithLoading(msg: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            isLoading.value = true
            statusMessage.value = msg
            try {
                block()
            } catch (e: Exception) {
                statusMessage.value = "Error: ${e.message ?: "Unknown"}"
            } finally {
                isLoading.value = false
            }
        }
    }
}
